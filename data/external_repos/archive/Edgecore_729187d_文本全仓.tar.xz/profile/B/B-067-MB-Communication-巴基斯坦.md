---
structured_profile:
  code: B-067
  rating: B
  country: 巴基斯坦
  role: 分销商
  segment: generic
  p1: STC-424DGGPM-280W
  stage: 00-lead
  struct_version: v2-lite
  updated: 2026-10-27
---

# MB Communication

> **评级 B** | 巴基斯坦 · Lahore / Karachi（多城价目） | 档案编号 `B-067` | 角色：网络产品分销商 | 状态：00-未触达
> 证据：官网（mbcommunication.com.pk）PoE 交换机价目页 | 2026-10-18 检索；**邮箱未定位，首触前必须补**
> **首选触达邮箱**：`sales@mbcommunication.com.pk`（备选与 KP 见联系方式/触达名单）

## SALES BRIEF（压缩模型）

- **是谁**：巴基斯坦网络产品分销商，官网按品类公开 PoE 交换机价目（拉合尔/卡拉奇/费萨拉巴德/拉瓦尔品第/木尔坦/海得拉巴多城报价）
- **为什么跟**：**公开价目=现成破价锚点**：其 24 口 PoE 均价 Rs 91,170（≈$325）、24 口千兆 PoE Rs 59,429（≈$212）、8 口 PoE 均价 Rs 17,106（≈$61）；我方 STC-424DGGPM-280W 三档 ¥900/938/975（≈$125-135）**价差 2-2.6 倍**【推断】
- **P1（首触唯一主推）**：STC-424DGGPM-280W — 24×GbE PoE+ 280W 管理型（对位其 24 口 PoE 均价 Rs 91,170）
- **第一问（只问一个）**：For your PoE switch range, which port count moves the most volume — 8, 24 or 48?
- **最大未知**：网络产品线年量级及其在总盘中的战略权重未公开
- **下一步**：由用户按档首首选邮箱首触；KP 定级见触达名单/R20 段（Agent 不发信）

## 客户概览

MB Communication（巴基斯坦·拉合尔/卡拉奇）为网络产品分销商，官网公开 PoE 交换机多城价目（2026-10-18 检索）。定位：价格敏感型渠道的破价切入点。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | MB Communication | 事实（官网（mbcommunication.com.pk）PoE 交换机价目页） |
| 国家/城市 | 巴基斯坦 / Lahore / Karachi（多城价目） | 事实（官网（mbcommunication.com.pk）PoE 交换机价目页） |
| 渠道角色 | 网络产品分销商 | 事实（官网（mbcommunication.com.pk）PoE 交换机价目页 口径） |
| 联系方式 | 电话 021-32270926-7；邮箱 sales@mbcommunication.com.pk；三地门店（卡拉奇/拉合尔/拉瓦尔品第） | 事实（官网 Contact 与门店页） |
| 商业模式 | 网络产品（含 **Ubiquiti/UBNT 线**）分销+POS 与配件+多城门店；2004 年成立，51-200 人【事实（官网+LinkedIn）】 | 【推断】 |
| 决策链 | 未确认 | 【假设】 |

> 来源 URL：https://www.mbcommunication.com.pk/308-poe-network-switch、https://www.mbcommunication.com.pk/321-poe-switch-24-port、https://www.mbcommunication.com.pk/671-24-port-gigabit-poe-switch（2026-10-18 检索）。
> 检索命中只证明「当日页面列出/展示该主体与其业务描述」，**不证明**当前采购意愿、在职人员、邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：月走量档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：现售哪些品牌型号、PoE 预算/上联速度、有没有改标需求。
- 【研发工程师】看：ERPS/PoE+（802.3af/at）/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- 公开价目可直接算价差，首触即可给「同规格低多少」的量化说法
- 多城报价说明其渠道覆盖广，走量潜力大
- 价格敏感型市场，我方成本档优势最大
- 风险：渠道型客户可能只比价；其公开价为**卢比零售/渠道价**，汇率与税（巴基斯坦高关税）会吃掉部分价差，报价前须算落地成本

## 联系方式（公开来源）
- 邮箱：sales@mbcommunication.com.pk（官网/门店页/官方 FB 三处一致）
- 电话：+92 21 32270926/7（卡拉奇）、0321-2448868；官网 https://www.mbcommunication.com.pk
- 地址：Shop SA-16, 2nd Floor TechnoCity, Hasrat Mohani Road, Karachi 74200

## 产品决策（Saga · 单一决策口径）

- **P1**：STC-424DGGPM-280W — 24×GbE PoE+ 280W 管理型（对位其 24 口 PoE 均价 Rs 91,170）
- 备选不进首触：8 口→STC-28DGGPM（¥540/563/585）；48 口→STC-448DGGPM（¥2064/2150/2236）
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |


## 关键人（KP）·深挖核验（2026-10-19）
- **Muhammad Najeeb Hanif，CEO / Director**（ZoomInfo、RocketReach、Datanyze 三库一致 + 巴国商业目录 lookup.pk「Managed By: Mr. Muhammad Najeeb Hanif」+ PakBiz 登记联系人）
- 个人直达邮箱未公开
- 【同名甄别】≠ MB Communications (Pvt) Ltd（伊斯兰堡宽带 ISP，异业同名）

## B类深挖核验·批6（2026-10-19）
- 2004 年至今的卡拉奇分销商（LinkedIn 51–200 人）：主业为 POS/条码（BlackCopper 巴基斯坦独家总代，另 Posiflex/Zebra/TSC/Honeywell/ZKTeco/Hikvision/Panduit），网络产品线在营（官网 Networking 53 个产品、UBNT/D-Link、PoE 交换机多品类页）
- 交换机非其主粮，但渠道体量与进口分销体系真实
- **成色判定：保留（POS 主业、网络在营；CEO 实名到位）**

## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs 其在售同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 完整首触邮件（EN · 用户自行发送 · Agent 不发信）

> Subject: A question about your PoE switch range
>
> Hi, I'm Simon with Saga Telecom. We build managed PoE+ switches — 8/24/48-port Gigabit with VLAN, IGMP snooping and PoE watchdog — supplied direct from factory, with OEM branding available.
>
> One question: for your PoE switch range, which port count moves the most volume — 8, 24 or 48?
>
> Best regards, Simon — Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；⚠️U28：商用 PoE=af/at 单口 30W，不得宣称 802.3bt 90W 对等；bt 场景转工业系。发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥来源 | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| STC-424DGGPM-280W | 见 docs/sales/P1产品价格快照.md 对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE+（802.3af/at）/IGMP；OEM/ODM；交期快
- **W**：品牌认知度低；认证缺口（UL/CE 需核；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：巴基斯坦安防/园区 PoE 需求增长；贴牌可帮其做自有价格层
- **T**：TP-Link/D-Link 与本地白牌的低价竞争；卢比汇率波动

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。⚠️报价前先算**卢比汇率+巴基斯坦关税/PTA**后的落地价，勿用裸 EXW 价承诺价差。

## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求
- [ ] 项目是否要求本地认证/进口许可（巴基斯坦 PTA / 尼日利亚 NCC / 埃及 NTRA 等）

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- https://www.mbcommunication.com.pk/308-poe-network-switch（2026-10-18 检索）；批次：batch/contact_research-2026-10-18_R13_南亚非洲拓线与联系方式核验.json
- https://www.mbcommunication.com.pk/321-poe-switch-24-port（2026-10-18 检索）；批次：batch/contact_research-2026-10-18_R13_南亚非洲拓线与联系方式核验.json
- https://www.mbcommunication.com.pk/671-24-port-gigabit-poe-switch（2026-10-18 检索）；批次：batch/contact_research-2026-10-18_R13_南亚非洲拓线与联系方式核验.json

### B-067 联系方式核验（R14 · 2026-10-18）
- 官网 Contact 与门店页实锤：**sales@mbcommunication.com.pk**
- 三地门店：卡拉奇 TechnoCity（Showroom #SA-16, 2F, Hasrat Mohani Road）、拉合尔 IT Tower Gulberg III（LG-45, Hali Road, 042-35754487）、拉瓦尔品第（Taj Plaza, D.A.V. College Road）
- 总机：021-32270926-7（卡拉奇）；手机 0321-2448868
- 规模升级：LinkedIn 显示 **2004 年成立、51-200 人**；官网设有 **UBNT（Ubiquiti）分销页**——与 B-066、B-068 同属巴基斯坦 Ubiquiti 生态
- ⚠️ **同名陷阱**：另有 MB Communications Private Limited（mbcommunications.com.pk，伊斯兰堡，宽带 ISP）为**不同公司**，勿混用

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。情报标注 `[半]`（半年内有效，见 docs/rules/二年期情报维护清单.md）。

## R20 B类全量复挖加厚（2026-10-19）

- **域名与邮件基础设施**：主域名 `mbcommunication.com.pk` 于 2026-10-19 经公共 DNS（8.8.8.8）复测：A 记录 173.254.31.151；MX 0 mail.mbcommunication.com.pk；平台特征 **自建/本地托管或其他邮件服务**。判定：**A 与 MX 均存在，域级收信基础设施现行有效**
- **邮箱定版**：首选触达 `sales@mbcommunication.com.pk`（来源见联系方式段）。支持/人事类邮箱不作销售首触。
- **KP 状态**：维持深挖定版——Muhammad Najeeb Hanif，CEO / Director（定级与限定语以本档 KP 段为准，本轮无新增实名）。
- **口径边界**：DNS 阳性只证明域级收信基础设施在查询时存在，不证明具体邮箱可投递、人员在职或采购意愿；邮箱来源与定级以联系方式/KP 段为准。结构化底稿见 `batch/contact_research-2026-10-19_R20_B类全量复挖加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`mbcommunication.com.pk`为A与MX均存在；网站IPv4 `173.254.31.151`（AS46606 UNIFIEDLAYER-AS-1 - Unified Layer, US），未见AAAA；邮件入口 `mail.mbcommunication.com.pk`（平台特征：自有域邮件主机（自建或本地托管））；NS托管特征为justhost.com。
- **邮件认证与发信系统信号**：SPF已发布（授权include `websitewelcome.com`，结尾`~all`）；DMARC `p=none`。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 84、跨档出现 ≤3 档的专属行 40、≤10 档的稀有行 43、外链来源域 1 个、全档去重邮箱 1 个；启发式审计分 67/100（主体 12/15、联系 18/20、KP 10/15、业务专属度 12/20、证据 8/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `sales@mbcommunication.com.pk`（状态 `public_primary_email_recorded`）；KP 状态 `named_single_candidate`，结构化抽到：Muhammad Najeeb Hanif。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：商用 PoE 模板已按 U28 收紧为 802.3af/at PoE+；首触发送人 Kevin 已改为 Simon。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：B-067｜MB Communication（巴基斯坦，分销商）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 67/100、专属行 41（专属证据密度中高）；联系状态 `public_primary_email_recorded`，主口 `sales@mbcommunication.com.pk`；KP 状态 `named_single_candidate`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行品牌缺货或交期拉长；下游经销商/SI 的真实项目 BOM；EOL 型号备件与替换需求；价格带下探或自有品牌计划是否真实存在。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Muhammad Najeeb Hanif；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424DGGPM-280W 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方确认有自有品牌计划，再拆解 Logo、Web UI、标签、包装、手册与 MOQ；未确认前不把 OEM 写成既有需求；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号、库存周转与下游月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：本地进口主体、型式批准、关税与外汇路径仍须由对方逐项确认，未核前不承诺落地价。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
