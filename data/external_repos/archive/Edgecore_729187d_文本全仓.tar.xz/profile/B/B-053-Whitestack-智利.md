---
structured_profile:
  code: B-053
  rating: B
  country: 智利
  role: SI/VAR
  segment: generic
  p1: STC-424XGGPM-280W
  stage: 00-lead
  struct_version: v2-lite
  updated: 2026-10-27
---

# Whitestack

> **评级 B** | 智利 · Santiago | 档案编号 `B-053` | 角色：SI/VAR/集成商 | 状态：00-未触达
> 证据：Edgecore 官方渠道名录（LAT-R）+ 2026-10-18 检索 | 来源：https://www.edge-core.com/where-to-buy/LatinAmerica-reseller/
> **邮箱状态**：无公开商务邮箱；官方技术口 `development@whitestack.com`（见 R20 段）

## SALES BRIEF（压缩模型）

- **是谁**：智利·Santiago 的SI/VAR/集成商；Edgecore 官方渠道名录收录（事实）
- **为什么跟**：在售/集成 Edgecore，说明白牌/开放网络硬件已被接受；用 Saga（STC/STI）同规格更低价+OEM/ODM 做第二货源【推断】
- **P1（首触唯一主推）**：STC-424XGGPM-280W — 24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）
- **第一问（只问一个）**：Which Edgecore models do you move most, and what price tier wins your deals?
- 最大未知：公开商务邮箱未定位；企业接入层项目占比未公开
- **下一步**：无公开商务邮箱；由用户经官网表单或官方技术口点名联合创始人切入（见 R20 段；Agent 不发信）

## 客户概览

Whitestack（智利·Santiago）为 SI/VAR/集成商，列于 Edgecore 官方渠道名录（LAT-R）。备注：OpenStack背景待核。定位：接入层第二货源/OEM 目标（A 级主攻）。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Whitestack | 事实（官方名录） |
| 国家/城市 | 智利 / Santiago | 事实（官方名录） |
| 电话 | （官网） | 事实（官方名录） |
| 渠道角色 | SI/VAR/集成商（LAT-R） | 事实（官方名录口径） |
| 备注 | OpenStack背景待核 | 事实（本轮记录） |
| 商业模式 | SI/VAR/集成商，转售/集成 Edgecore 并可能代理多品牌 | 【推断】 |
| 决策链 | 未确认 | 【假设】 |

> 来源 URL：https://www.edge-core.com/where-to-buy/LatinAmerica-reseller/（2026-10-18 检索）。官方名录只证明「当日页面列出该伙伴」，不证明当前采购意愿/在职人员/邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：他月走量在哪个档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：他现售 Edgecore 哪些料号、PoE 预算/上联速度需求、有没有改标需求。
- 【研发工程师】看：ERPS/PoE+（802.3af/at）/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- 已接受白牌/开放网络硬件【推断自其在 Edgecore 渠道名录】
- Saga 同规格成本档可做第二货源 + OEM 贴牌 + 交期优势
- 风险：认证约束（UL 无；CE/FCC 须在欧美触达前按具体型号核实；轨交/EN50155 非全线）在部分项目型需求处需留证

## 联系方式（公开来源）
- 公开邮箱：**未定位**（官网 Contact 为表单制；公开源未见公示邮箱，禁止拼接）
- 电话：+1 (650) 248-2490（ZoomInfo 转引）；官网 https://whitestack.com
- 地址：总部 Miami, FL；智利办 Avenida Apoquindo 4700 piso 11, Las Condes, Santiago（另有阿根廷/哥伦比亚/墨西哥/秘鲁/乌拉圭点）

## 产品决策（Saga · 单一决策口径）

- **P1**：STC-424XGGPM-280W — 24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）
- 备选不进首触：工业场景→STI 系列；纯千兆成本敏感→STC-424DGGM（¥552 档）
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |

## 触达名单

- 邮箱：公开商务邮箱未定位（见 R20 段路径；禁止编造）
- LinkedIn/电话：（官网）（官方名录）


## 关键人（KP）·深挖核验（2026-10-19）
- **José Miguel Guzmán，Co-Founder**（兼 Telco/NFV 商务拓展负责人，2023–2026 年多场合公开署名、多官方新闻稿引言）
- 创始团队为 Google 与 Cisco 前高管（媒体多源）
- 个人直达邮箱未公开

## B类深挖核验·批5（2026-10-19）
- 2015/16 年创立的拉美电信云与开放网络工程公司（51–200 人）：以开源栈（OpenStack/ONOS/白盒）为运营商建网，标杆案例为智利 Mundo Pacífico 的 HyperNET 解耦光网络（TIP Cassini）——工程/软件主导型集成商，硬件随项目采购
- 2020 年获 Sixbell 战略投资；2023 年与 AMD/Dell 建拉美首个 Telco Cloud 互操作实验室
- 定位在运营商核心/光层，接入层企业交换非其主场——项目型硬件切入需挑场景
- **成色判定：保留观察（工程型头部，但品类重心在电信云；无公开邮箱待补）**
## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs Edgecore 同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 首触邮件要点（模板素材，用户自行发送）

> Subject: Second-source switching for your Edgecore line
> 观察（在 Edgecore 渠道名录看到你们）→ 相关性（同规格白牌+OEM 贴牌+交期）→ 一个问题（哪个型号走量？）
> 红线：不提「Made in China」；不提「研究过你官网」；一次只问一个问题


### 完整首触邮件（英文 · 用户自行发送 · Agent 不发信）

> Subject: Your Edgecore access switches — a same-spec second source
>
> Dear Purchasing / Procurement Team,
>
> I noticed Whitestack carries the Edgecore access line. With the ECS2100 family entering end-of-life (last order date 2026-04-01), many partners are moving to a same-spec second source to keep projects and spares covered.
>
> We manufacture managed access switches — 24×GbE/PoE+ with 4×10G uplinks, 280W/440W PoE budgets, ERPS / IGMP snooping / 802.3af/at PoE+ — and we support OEM branding (logo, packaging, docs) from 10 units.
>
> One question: which access model moves the most volume for you right now?
>
> Best regards, Simon · Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥ | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| STC-424XGGPM-280W | 见 P1 价格快照对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE+（802.3af/at）/IGMP；OEM/ODM；交期快
- **W**：品牌认知度低；认证约束（UL 无；CE/FCC 须按具体型号核实；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：ECS2100 EOL 替换窗口（2026-04-01 前后）；客户双货源策略
- **T**：Edgecore 官方替代（ECS4150 系列）价格竞争；大客户锁价长约

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。

## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求

## 未知项清单

- 邮箱/KP：见联系方式与 R20 定版（首选邮箱见档首；KP 状态见 R20 段）
- 在售型号清单：待首触确认
- 认证敏感度（UL/轨交/E-mark/KC）：未知，涉及轨交/车载需求先声明缺口

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- https://www.edge-core.com/where-to-buy/LatinAmerica-reseller/（2026-10-18 检索，官方渠道名录）；批次：batch/contact_research_2026-10-18_R1_官方渠道全量.json

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。

## R20 B类全量复挖加厚（2026-10-19）

- **域名与邮件基础设施**：主域名 `whitestack.com` 于 2026-10-19 经公共 DNS（8.8.8.8）复测：A 记录 192.124.249.7；MX 1 aspmx.l.google.com；5 alt2.aspmx.l.google.com 等4条；平台特征 **Google Workspace**。判定：**A 与 MX 均存在，域级收信基础设施现行有效**
- **邮箱定版**：商务直达邮箱未定位；本轮新增官方技术口 `development@whitestack.com`（GitHub 官方组织公示），可作技术线备口（见下增量）。
- **KP 状态**：维持深挖定版——José Miguel Guzmán，Co-Founder（定级与限定语以本档 KP 段为准，本轮无新增实名）。
- **本轮定向增量（首个官方公开邮箱）**：其 GitHub 官方组织 `github.com/whitestack`（33 个仓库，2026-10 仍活跃）公示邮箱 **`development@whitestack.com`**——属研发/技术口，可做技术线备口，但不等同商务采购口。联合创始人 **Gianpietro Lavado**（Telco Cloud Architect & Co-founder，本人 GitHub 主页自述，利马）公开个人邮箱 `gianpietro1@gmail.com`——仅作创始人技术线记录，销售首触仍优先官网表单/技术口点名 José Miguel Guzmán，不对个人 Gmail 群发销售信。商务直达邮箱仍记未定位。
- **口径边界**：DNS 阳性只证明域级收信基础设施在查询时存在，不证明具体邮箱可投递、人员在职或采购意愿；邮箱来源与定级以联系方式/KP 段为准。结构化底稿见 `batch/contact_research-2026-10-19_R20_B类全量复挖加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`whitestack.com`为A与MX均存在；网站IPv4 `192.124.249.7`（AS30148 SUCURI-SEC - Sucuri, US），未见AAAA；邮件入口 `alt3.aspmx.l.google.com`、`aspmx.l.google.com`等4条（平台特征：Google Workspace）；NS托管特征为GoDaddy。
- **邮件认证与发信系统信号**：SPF已发布（Zoho、Google Workspace，结尾`-all`）；DMARC `p=reject`。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **GitHub公开技术足迹**：[whitestack](https://github.com/whitestack)（Organization，官网域互指/官方资料绑定），主页公开邮箱`development@whitestack.com`；公开仓库33个，最近推送2026-10-23，近作含`keep`、`keep-topology-ui`。技术活动不自动升格采购KP。
- **技术联系人补厚（非采购口）**：CNCF Kubernetes conformance的WhiteMist `PRODUCT.yaml`公开列`hventura@whitestack.com`、`srojas@whitestack.com`与`cncf-k8s-conformance@whitestack.com`为产品一致性联系邮箱。它们只证明技术/产品合规接口，姓名与采购权均未公开，不替换官网/GitHub公示的开发或销售入口，不作采购首触名单。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 89、跨档出现 ≤3 档的专属行 29、≤10 档的稀有行 31、外链来源域 3 个、全档去重邮箱 5 个；启发式审计分 54/100（主体 12/15、联系 5/20、KP 10/15、业务专属度 9/20、证据 14/20、可执行性 4/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 无已确认可执行的公开商务首选邮箱（状态 `technical_email_only`）；KP 状态 `named_single_candidate`，结构化抽到：José Miguel Guzmán。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：认证口径已按 U31 改为“UL 无；CE/FCC 按型号核实”；商用 PoE 模板已按 U28 收紧为 802.3af/at PoE+。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：公开可执行商务邮箱未闭合；用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：优先从官网 Team/Impressum、厂商伙伴稿、展会或登记材料补公开商务入口；未取得前用电话/表单索址，不拼个人邮箱。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：B-053｜Whitestack（智利，SI/VAR）。本轮类型：定向外部复核/负结果 + 运营化合成；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 C、质量基线 57/100、专属行 32（专属证据密度中等）；联系状态 `technical_email_only`，主口 `无已确认公开商务首选邮箱`；KP 状态 `named_single_candidate`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：在手项目的交换机 BOM 与交付节点；存量网络扩容、维保与备件替换；现用品牌价格或交期压力；多站点标准化与批量复制项目。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 José Miguel Guzmán；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：先经表单/总机索取商务口与实名负责人。下一证据路径：优先从官网 Team/Impressum、厂商伙伴稿、展会或登记材料补公开商务入口；未取得前用电话/表单索址，不拼个人邮箱。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424XGGPM-280W 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 在手项目型号、数量、最终用户行业与交付节点；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：涉及轨交/车载时，EN50155/E-mark 无证即为硬停项；普通园区项目须与轨交项目分开确认。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：公开可执行商务邮箱未闭合；用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **定向外部补挖**：2026-10-27 原页复核 Whitestack Contact：官网仍只提供表单，不公开销售邮箱；页脚列美国、阿根廷、智利、哥伦比亚、秘鲁、墨西哥、乌拉圭七地办公室，伙伴标识含 IP Infusion、UfiSpace 与 Edgecore。Crunchbase/Golden 等第三方页列 `contacto@whitestack.com`，但官网未复现，本轮只记未升格候选，不关闭公开商务邮箱缺口。来源：https://whitestack.com/contact-us/ 。
- **定向外部补挖**：LinkedIn 公开摘要可见 Felipe Suazo 具 Business Development Director 类商务拓展职务线索；该信息可辅助表单点名商务拓展团队，但不证明其负责硬件采购。Whitestack 的核心仍是私有云/虚拟化与开放网络方案，下一步先确认其是否为客户集采交换硬件，还是只做软件与架构交付。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
