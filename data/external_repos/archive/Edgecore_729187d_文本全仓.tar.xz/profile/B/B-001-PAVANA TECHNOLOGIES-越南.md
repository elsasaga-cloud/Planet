---
structured_profile:
  id: B-001
  company: PAVANA TECHNOLOGIES
  country: 越南
  rating: B
  biz_model: 科技/安防网络集成与分销（河内）
  needs: [CCTV PoE, 项目机, 价格, 交期]
  p1: STC-424XGGPM-280W（待核价）
  stage: 未接触
  volume_potential: 中
  risk_flags: [价格战, 账期待谈]
  updated: 2026-10-27
---

# B-001 · PAVANA TECHNOLOGIES · 越南

> 级别：B（可跟进）｜建档 2026-10-18｜加厚 2026-10-18 18:00

## SALES BRIEF
- **是谁**：河内科技公司，Edgecore 亚太分销名录收录（The Vista, 4/15 Duy Tan, Cau Giay, Hanoi）
- **为什么跟**：越南首攻市场；安防/园区项目；中国供应链近（陆运 2-4 天到货）
- **P1**：STC-424XGGPM-280W（24口 PoE+ CCTV/项目机）
- **第一问**：Which projects are you bidding this quarter that need PoE access switches?
- **最大未知**：在售具体型号与月采购量未确认（邮箱/KP/工商进展见「B类深挖核验·批1」段）
- **下一步**：与 A-005 越南线并行首触

## 基本事实
| 内容 | 标签 |
|---|---|
| 地址/电话 (+84) 8 5333 5995 | 事实（Edgecore 名录） |
| 收录为 Edgecore 亚太分销商 | 事实（名录） |
| 主营安防/园区网络集成 | 【推断】依据：名录类别+市场结构 |
| 习惯中国供应链 | 【推断】依据：越南行业惯例 |

## 技术与在用
- Edgecore 接入层在售（名录）；其他品牌无公开

## 需求与场景
- 【推断】CCTV 项目 PoE 为主——依据：越南安防建设期

## 联系方式

- **邮箱**：hello@pavana.tech（官网 Contact）；实名 phuongnguyen@pavana.tech（EMIS 企业通讯录，职务未标）
- **电话**：(+84) 8 5333 5995（Edgecore 名录）/ 0904 634 288（越南企业登记库）
- **网站**：pavana.tech

## 关键人（KP）

### KP 实名（B类深挖·批1 2026-10-19）

- **Nguyen Trung Kien（阮忠坚）— Founder & CEO / 总经理（法定代表人）**【官网 About + 越南企业登记库双源；德国汉诺威大学电信电子博士】
- Cuong Tran — Co-Founder & CTO【LinkedIn】

## 跟进步骤（≤3）
1. **首触**：CCTV PoE 价目一角（P1）；问在投项目；exit：14 天无回复→月度低频
2. **台阶**：样品+对比报价；问月量/账期；exit：只比价→停
3. **台阶**：贴牌试探；exit：无回应→归档

## 产品决策
- **P1**：STC-424XGGPM-280W —— 待核价（报价前核价）
- 备选（不进首触）：STI-21616GP（户外 CCTV 机箱款）

## SWOT
- S：交期/价格/贴牌｜W：品牌弱｜O：越南安防增长｜T：大陆同行价格战

## 触达与风险红线
- 不承诺 UL/KC；**停止开发条件**：3 次无回复/只比价/书面拒绝

## Unknowns
- [ ] 月量 [ ] 现用品牌 [ ] 账期 [ ] 决策人

## 首触邮件（英文）
**Subject: CCTV PoE switches for your Hanoi projects — fast delivery**

> Hi,
>
> I'm Simon with Saga Telecom. We manufacture managed PoE switches for CCTV and campus networks — 24-port PoE+ with 10G uplinks (STC-424XGGPM-280W), ERPS and IGMP — with chips in stock, 2–4 day land shipping to Hanoi, and OEM labeling.
>
> One question: which projects are you bidding this quarter that need PoE access switches?
>
> Glad to send our catalog and a sample quotation.
>
> Best regards, Simon | Saga Telecom | https://sagatele.com


## B类深挖核验·批1（2026-10-19）

- **主体定版**：Pavana Technologies Joint Stock Company，税号 2500667973，河内 The Vista, 4/15 Duy Tan, Cau Giay（与 Edgecore 名录全等），工厂在永福省 Thang Long 工业园 Lot F1-2-3
- **主业**：越南第一家相机 ODM 制造商（安防摄像头/NVR/AI 盒子自研自产，伙伴 Qualcomm/Ambarella/VinCSS 等）——制造商/品牌商思维
- ★**2025 年 6 月新签 Edgecore Networks 越南官方总代**（官网新闻）：网络分销是新开线、交换机与其相机业务天然打包（PoE 场景），正值扩品期，本批最优标的之一
- ⚠️ Volza 所载联系人系该库惯性假名，依既往判定不采

## 跟进记录
| 日期 | 渠道 | 动作 | 反应 | 结论 | 下次动作日期 |
|---|---|---|---|---|---|
| 2026-10-18 | — | 建档+加厚 | — | 未联系 | 首触待排（第 B 波） |

## R20 B类全量复挖加厚（2026-10-19）

- **域名与邮件基础设施**：主域名 `pavana.tech` 于 2026-10-19 经公共 DNS（8.8.8.8）复测：A 记录 172.104.39.250；MX 0 pavana-tech.mail.protection.outlook.com；平台特征 **Microsoft 365**。判定：**A 与 MX 均存在，域级收信基础设施现行有效**
- **邮箱定版**：首选触达 `hello@pavana.tech`（来源见联系方式段）；备选 `phuongnguyen@pavana.tech`。支持/人事类邮箱不作销售首触。
- **KP 状态**：维持深挖定版——Nguyen Trung Kien（阮忠坚）— Founder & CEO / 总经理（法定代表人）（定级与限定语以本档 KP 段为准，本轮无新增实名）。
- **口径边界**：DNS 阳性只证明域级收信基础设施在查询时存在，不证明具体邮箱可投递、人员在职或采购意愿；邮箱来源与定级以联系方式/KP 段为准。结构化底稿见 `batch/contact_research-2026-10-19_R20_B类全量复挖加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`pavana.tech`为A与MX均存在；网站IPv4 `172.104.39.250`（AS63949 AKAMAI-LINODE-AP - Akamai Connected Cloud, SG），未见AAAA；邮件入口 `pavana-tech.mail.protection.outlook.com`（平台特征：Microsoft 365）；NS托管特征为microsoftonline.com。
- **邮件认证与发信系统信号**：SPF已发布（Microsoft 365，结尾`-all`）；未见公开DMARC政策。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 49、跨档出现 ≤3 档的专属行 42、≤10 档的稀有行 44、外链来源域 1 个、全档去重邮箱 2 个；启发式审计分 72/100（主体 12/15、联系 18/20、KP 15/15、业务专属度 12/20、证据 8/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `hello@pavana.tech`（状态 `public_primary_email_recorded`）；KP 状态 `named_multiple_candidates`，结构化抽到：Nguyen Trung Kien、Cuong Tran。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：首触自我介绍中的 Shenzhen 已删除。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：B-001｜B-001 · PAVANA TECHNOLOGIES · 越南（越南，渠道/项目伙伴）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 72/100、专属行 43（专属证据密度中高）；联系状态 `public_primary_email_recorded`，主口 `hello@pavana.tech`；KP 状态 `named_multiple_candidates`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行项目 BOM；现用品牌缺货或 EOL 替换；多站点复制交付；成本档与本地库存压力。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Nguyen Trung Kien、Cuong Tran；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424XGGPM-280W（待核价） 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号与月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：本地进口主体、型式批准、关税与外汇路径仍须由对方逐项确认，未核前不承诺落地价。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
