---
structured_profile:
  code: B-066
  rating: B
  country: 巴基斯坦
  role: 分销商
  segment: generic
  p1: STC-424DGGPM-280W
  stage: 00-lead
  struct_version: v2-lite
  updated: 2026-10-27
---

# Microtech Inc

> **评级 B** | 巴基斯坦 · Karachi（+Lahore / Islamabad） | 档案编号 `B-066` | 角色：ICT 分销商（官方总代型） | 状态：00-未触达
> 证据：官网（microtech.net.pk）Contact 与分销页 | 2026-10-18 检索；非 Edgecore 官方名录来源
> **首选触达邮箱**：`zishan@microtech.net.pk`（备选与 KP 见联系方式/触达名单）

## SALES BRIEF（压缩模型）

- **是谁**：卡拉奇的 ICT 分销商，1997 年起运营；**Ubiquiti 官方分销商 + MikroTik 官方分销商**，代理 12+ 全球 ICT 品牌；卡拉奇总部+拉合尔与伊斯兰堡区域办公室；服务 ISP、企业、SMB、政府与高校
- **为什么跟**：**MikroTik 官方分销 + Ubiquiti 官方分销**——巴基斯坦 ISP 网络两大主力品牌都在他手上，说明其掌握 ISP 与园区接入的真实走量通道；我方以「补价格层/第二货源」切入不被视为抢代理线【推断】
- **P1（首触唯一主推）**：STC-424DGGPM-280W — 24×GbE PoE+ 280W 管理型（ISP/园区接入主力）
- **第一问（只问一个）**：Across your MikroTik and Ubiquiti lines, is there a price tier you don't cover today — between entry-level and the major brands?
- **最大未知**：其交换机品类中白牌/OEM 补充线的接受度未公开（已握多家中国品牌总代）
- **下一步**：由用户按档首首选邮箱首触；KP 定级见触达名单/R20 段（Agent 不发信）

## 客户概览

Microtech Inc（巴基斯坦·卡拉奇，拉合尔/伊斯兰堡设点）为 1997 年成立的 ICT 分销商，Ubiquiti 与 MikroTik 官方分销，代理 12+ 品牌，客户覆盖 ISP/企业/政府/高校（2026-10-18 检索）。定位：ISP 与园区接入层白牌二供。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Microtech Inc | 事实（官网（microtech.net.pk）Contact 与分销页） |
| 国家/城市 | 巴基斯坦 / Karachi（+Lahore / Islamabad） | 事实（官网（microtech.net.pk）Contact 与分销页） |
| 渠道角色 | ICT 分销商（官方总代型） | 事实（官网（microtech.net.pk）Contact 与分销页 口径） |
| 联系方式 | 电话 +92 21 35684888-999 / 35684555-777（KHI）、+92 42 35752631-2（LHE）、+92 51 6166828（ISB）；邮箱 sales@microtech.net.pk、info@microtech.net.pk | 事实（官网 Contact 页） |
| 商业模式 | 官方分销（**巴基斯坦唯一 UniFi Enterprise 授权分销**；Ubiquiti、MikroTik、Huawei eKit、ZKTeco、Dahua、**Ruijie**、VSOL、Linksys、Dinstar、Corning、Imou 等）+ 直接进口 + 本地备货【事实（官网）】 | 【推断】 |
| 决策链 | 未确认 | 【假设】 |

> 来源 URL：https://microtech.net.pk/、https://microtech.net.pk/ubiquiti-distributor-in-pakistan/（2026-10-18 检索）。
> 检索命中只证明「当日页面列出/展示该主体与其业务描述」，**不证明**当前采购意愿、在职人员、邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：月走量档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：现售哪些品牌型号、PoE 预算/上联速度、有没有改标需求。
- 【研发工程师】看：ERPS/PoE+（802.3af/at）/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- 官方分销身份=有直接进口能力与本地库存，谈 OEM/整柜有基础
- MikroTik/Ubiquiti 价格带与我方对位清晰，价差可算
- 巴基斯坦 ISP 与园区接入扩容需求大，复购稳定
- 风险：同时持两大品牌官方分销，可能只比价不投入；首封只谈「补价格层」，不碰其代理线；巴基斯坦进口涉及 **PTA 认证**与关税，触达前核实（U31）

## 联系方式（公开来源）
- **实名公开邮箱（官网 About 页明示）：zishan@microtech.net.pk（Zeeshan Arabi，CEO）、aman@microtech.net.pk（Amaan Arabi，Managing Director）**
- 通用口：sales@microtech.net.pk / info@microtech.net.pk / info.lhr@microtech.net.pk（拉合尔）
- 电话：+92 21 35684888-999（卡拉奇总部）、+92 42 35752631-2（拉合尔）、+92 51 6166828（伊斯兰堡）；官网 https://microtech.net.pk
- 地址：Suite #503, 5th Floor, The Progressive Plaza, Beaumont Road, Karachi

## 产品决策（Saga · 单一决策口径）

- **P1**：STC-424DGGPM-280W — 24×GbE PoE+ 280W 管理型（ISP/园区接入主力）
- 备选不进首触：48 口园区→STC-448DGGPM；工业/ISP 机房→STI 系列
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |


## 关键人（KP）·深挖核验（2026-10-19）
- **Saleem Arabi，Chairman & Founder**（1997 年创办，家族企业）
- **Zeeshan Arabi，CEO**（创始人之子；实名邮箱见联系方式段）
- **Amaan Arabi，Managing Director**（实名邮箱见联系方式段）
- Zubair Khan，Director of Corporate Sales & Marketing（原档 zubair.khan@microtech.net.pk 的职务本次核实）；Muhammad Usman Khan，COO；Usman Niazi 为 UniFi Enterprise 线对口人

## B类深挖核验·批6（2026-10-19）
- 巴基斯坦头部 ICT 分销商（201–500 人，卡拉奇/拉合尔/伊斯兰堡三点）：2019 年起 **Ubiquiti 巴基斯坦独家分销**、UniFi Enterprise 唯一授权分销；MikroTik 主分销；同时分销 **Huawei eKit、Ruijie、VSOL（金牌分销）、ZKTeco、Dahua、TOTOLINK（独家）、CDATA、Dinstar**——中国品牌组合之全为本批之最
- CEO/MD 实名邮箱在官网公开，本批触达条件最佳的对象之一
- 【交叉注记】B-068 Dreams 亦自称 Ubiquiti/MikroTik 主分销——两家同为真实头部渠道，巴国市场双头并存
- **成色判定：保留（本批最强档位之一）**

## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs 其在售同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 完整首触邮件（EN · 用户自行发送 · Agent 不发信）

> Subject: A question about your ISP and campus access range
>
> Hi, I'm Simon with Saga Telecom. We build managed access switches (PoE+, 10G uplinks, ERPS, IGMP snooping) direct from factory, with OEM branding and short lead times. Many distributors add us as a price-tier line alongside their existing brands.
>
> One question: across your ISP and campus projects, is there a price tier you don't cover today?
>
> Best regards, Simon — Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；⚠️U28：商用 PoE=af/at 单口 30W，不得宣称 802.3bt 90W 对等；bt 场景转工业系。发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥来源 | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| STC-424DGGPM-280W | 见 docs/sales/P1产品价格快照.md 对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE+（802.3af/at）/IGMP；OEM/ODM；交期快
- **W**：品牌认知度低；认证缺口（UL/CE 需核；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：ISP 接入扩容；可做其自有品牌线（OEM）；政府/高校项目价格层
- **T**：MikroTik/Ubiquiti 原厂返点与价格保护；本地低价白牌竞争

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。巴基斯坦线额外红线：不贬低其 Ubiquiti/MikroTik 代理线；**PTA 认证/进口许可**要求须在报价前问清（U31）。

## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求
- [ ] 项目是否要求本地认证/进口许可（巴基斯坦 PTA / 尼日利亚 NCC / 埃及 NTRA 等）

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- https://microtech.net.pk/（2026-10-18 检索）；批次：batch/contact_research-2026-10-18_R13_南亚非洲拓线与联系方式核验.json
- https://microtech.net.pk/ubiquiti-distributor-in-pakistan/（2026-10-18 检索）；批次：batch/contact_research-2026-10-18_R13_南亚非洲拓线与联系方式核验.json

### B-066 联系方式核验（R14 · 2026-10-18）
- 官网 Contact/Support 页实锤：**sales@microtech.net.pk、info@microtech.net.pk**，拉合尔线 info.lhr@microtech.net.pk
- 三地电话：卡拉奇 +92 21 35684888-999 / 35684555-777；拉合尔 +92 42 35752631-2；伊斯兰堡 +92 51 6166828
- **KP 实锤**：Usman Niazi（usman.niazi@microtech.net.pk，UniFi Enterprise 咨询线）、Zubair Khan（zubair.khan@microtech.net.pk，伊斯兰堡）
- ★重大情报升级：官网自述为**巴基斯坦唯一的 Ubiquiti UniFi Enterprise 授权分销商**，且代理清单新增 **Ruijie、Dahua、ZKTeco、Huawei eKit**——竞品线比我方原先判断更宽，但同时说明其**渠道覆盖面是巴基斯坦最强的之一**
- 沿革：1997 年零售起家 → 2006 转网络 → 2007 大规模进口 → 2016 成为 Ubiquiti 分销商
- ⚠️ 因 Ruijie 亦在其代理清单，首封必须走「云管理之外的价格层」而非直接比价

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。情报标注 `[半]`（半年内有效，见 docs/rules/二年期情报维护清单.md）。

## R20 B类全量复挖加厚（2026-10-19）

- **域名与邮件基础设施**：主域名 `microtech.net.pk` 于 2026-10-19 经公共 DNS（8.8.8.8）复测：A 记录 191.96.144.94、195.35.60.39；MX 1 smtp.google.com；平台特征 **Google Workspace**。判定：**A 与 MX 均存在，域级收信基础设施现行有效**
- **邮箱定版**：首选触达 `zishan@microtech.net.pk`（来源见联系方式段）；备选 `aman@microtech.net.pk`、`sales@microtech.net.pk`、`info@microtech.net.pk`。支持/人事类邮箱不作销售首触。
- **KP 状态**：维持深挖定版——Saleem Arabi，Chairman & Founder（定级与限定语以本档 KP 段为准，本轮无新增实名）。
- **口径边界**：DNS 阳性只证明域级收信基础设施在查询时存在，不证明具体邮箱可投递、人员在职或采购意愿；邮箱来源与定级以联系方式/KP 段为准。结构化底稿见 `batch/contact_research-2026-10-19_R20_B类全量复挖加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`microtech.net.pk`为A与MX均存在；网站IPv4 `191.96.144.18`、`191.101.104.174`（AS47583 AS-HOSTINGER - Hostinger International Limited, CY），AAAA 2条；邮件入口 `smtp.google.com`（平台特征：Google Workspace）；NS托管特征为Hostinger。
- **邮件认证与发信系统信号**：未见SPF记录；DMARC `p=none`；CAA授权CA：sectigo.com、letsencrypt.org、comodoca.com、pki.goog、globalsign.com。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **公开服务面（DNS）**：检出`store.microtech.net.pk`、`support.microtech.net.pk`、`portal.microtech.net.pk`。子域存在只证明DNS/服务配置，不单独证明页面当前可用或交易活跃。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 89、跨档出现 ≤3 档的专属行 47、≤10 档的稀有行 50、外链来源域 1 个、全档去重邮箱 7 个；启发式审计分 74/100（主体 12/15、联系 20/20、KP 15/15、业务专属度 12/20、证据 8/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `zishan@microtech.net.pk`（状态 `public_primary_email_recorded`）；KP 状态 `named_multiple_candidates`，结构化抽到：Saleem Arabi、Zeeshan Arabi、Amaan Arabi。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：商用 PoE 模板已按 U28 收紧为 802.3af/at PoE+；首触发送人 Kevin 已改为 Simon。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：B-066｜Microtech Inc（巴基斯坦，分销商）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 74/100、专属行 48（专属证据密度中高）；联系状态 `public_primary_email_recorded`，主口 `zishan@microtech.net.pk`；KP 状态 `named_multiple_candidates`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行品牌缺货或交期拉长；下游经销商/SI 的真实项目 BOM；EOL 型号备件与替换需求；价格带下探或自有品牌计划是否真实存在。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Saleem Arabi、Zeeshan Arabi、Amaan Arabi；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424DGGPM-280W 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方确认有自有品牌计划，再拆解 Logo、Web UI、标签、包装、手册与 MOQ；未确认前不把 OEM 写成既有需求；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号、库存周转与下游月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：本地进口主体、型式批准、关税与外汇路径仍须由对方逐项确认，未核前不承诺落地价。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
