---
structured_profile:
  code: B-074
  rating: B
  country: 埃及
  role: 分销商
  segment: generic
  p1: STC-424DGGPM-280W
  stage: 00-lead
  struct_version: v2-lite
  updated: 2026-10-27
---

# Contra Technology

> **评级 B** | 埃及 · Maadi, Cairo | 档案编号 `B-074` | 角色：网络产品分销商 | 状态：00-未触达
> 证据：QNAP 官方 Where-to-Buy 名录（埃及 Networking Distributor） | 2026-10-18 检索；**官网与邮箱未定位，首触前必须补**
> **首选触达邮箱**：`info@contratechnology.com`（备选与 KP 见联系方式/触达名单）

## SALES BRIEF（压缩模型）

- **是谁**：开罗 Maadi 的埃及网络产品分销商，**QNAP 官方埃及 Networking Distributor 名录收录**；地址 19 (D/1) Yehia Abd El Razek, Takseem El Laselky, Maadi, Cairo
- **为什么跟**：被 QNAP 官方列为埃及 **Networking Distributor**，说明其具备网络品类的正式分销资质与渠道能力——是埃及线里**资质最明确**的一家【事实（厂商官方伙伴名录）】
- **P1（首触唯一主推）**：STC-424DGGPM-280W — 24×GbE PoE+ 280W 管理型（渠道接入主力）
- **第一问（只问一个）**：Which networking categories do you distribute today — and is PoE switching among them?
- **最大未知**：交换机单品类量级及其工业 IT 线的实际占比未公开
- **下一步**：由用户按档首首选邮箱首触；KP 定级见触达名单/R20 段（Agent 不发信）

## 客户概览

Contra Technology（埃及·开罗 Maadi）为网络产品分销商，QNAP 官方埃及 Networking Distributor 名录收录（2026-10-18 检索）。定位：埃及渠道资质型破口。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Contra Technology | 事实（QNAP 官方 Where-to-Buy 名录（埃及 Networking Distributor）） |
| 国家/城市 | 埃及 / Maadi, Cairo | 事实（QNAP 官方 Where-to-Buy 名录（埃及 Networking Distributor）） |
| 渠道角色 | 网络产品分销商 | 事实（QNAP 官方 Where-to-Buy 名录（埃及 Networking Distributor） 口径） |
| 联系方式 | 电话 01000502545 / +202 25201365；邮箱 info@contratechnology.com；地址 19 (D/1) Yehia Abd El Razek, Takseem El Laselky, Maadi, Cairo | 事实（官网+QNAP 名录） |
| 商业模式 | 埃及与中东的企业 IT 官方分销商：Synology、QNAP、AirLive、Teltonika、Matrix、Asustor、UGREEN、**Moxa（工业网络）**；主营 NAS 存储、监控、网络与**工业 IT**【事实（官网自述）】 | 【推断】 |
| 决策链 | 未确认 | 【假设】 |

> 来源 URL：https://www.qnap.com/en-us/where-to-buy/middle-east/egypt/Networking%20Distributor（2026-10-18 检索）。
> 检索命中只证明「当日页面列出/展示该主体与其业务描述」，**不证明**当前采购意愿、在职人员、邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：月走量档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：现售哪些品牌型号、PoE 预算/上联速度、有没有改标需求。
- 【研发工程师】看：ERPS/PoE+（802.3af/at）/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- 厂商官方名录收录=分销资质获第三方背书，非自述
- 网络品类是其正式经营范围，接入交换机切入门槛低
- 埃及市场我方档案此前为 0，先入者优势
- 风险：QNAP 以存储/NAS 为主，其网络线实际能力待确认；NTRA 合规须问清

## 联系方式（公开来源）
- 邮箱：info@contratechnology.com（官网/LinkedIn/官方社媒一致）
- 职员实名邮箱：samar.mahmoud@contratechnology.com（官网团队页公示，办公室对口人）
- 电话：+20 100 050 2545（WhatsApp 主线）、(+202) 2701 2177/2402；官网 https://contratechnology.com
- 地址：19 (D/1) Yehia Abd El Razek, Takseem EL Laselky, Maadi, Cairo（QNAP 官方购买指南同载）；关联旧站 contratechno.com 同区，疑同一主体早期站点

## 产品决策（Saga · 单一决策口径）

- **P1**：STC-424DGGPM-280W — 24×GbE PoE+ 280W 管理型（渠道接入主力）
- 备选不进首触：48 口→STC-448DGGPM；8 口→STC-28DGGPM
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |


## 关键人（KP）·深挖核验（2026-10-19）
- **Mahmoud Hanafy Nasr，Founder, President & CEO**（官网 About 页结构化数据明示 + CEO 寄语署名 + LinkedIn 本人页三源实锤；原档第二条「KP 待定位」系空行，一并清除）
- 个人直达邮箱未公开（走 info@ 指名或团队页 Samar Mahmoud 对口）

## B类深挖核验·批6（2026-10-19）
- 2012 年至今的开罗分销商（自述 650+ 项目）：QNAP 官方「Where to Buy」列其为埃及 **Networking Distributor**；Synology/QNAP 官方分销自述，2026 年新签 ASUSTOR 埃及伙伴；品牌含 Milesight（中国星纵）、AirLive（台湾）、Teltonika、Matrix（印度）——多国别中小品牌进口分销模式成熟，与本方画像高度同构
- 低电流系统+NAS 存储+网络三线并行，非纯安防商
- **成色判定：保留（埃及三档中最强，官方网络分销商身份实锤）**

## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs 其在售同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 完整首触邮件（EN · 用户自行发送 · Agent 不发信）

> Subject: A question about your networking distribution lines
>
> Hi, I'm Simon with Saga Telecom. We build managed PoE+ access switches (8/24/48-port, 10G uplinks, ERPS) direct from factory, with OEM branding from small quantities.
>
> One question: which networking categories do you distribute today — and is PoE switching among them?
>
> Best regards, Simon — Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；⚠️U28：商用 PoE=af/at 单口 30W，不得宣称 802.3bt 90W 对等；bt 场景转工业系。发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥来源 | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| STC-424DGGPM-280W | 见 docs/sales/P1产品价格快照.md 对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE+（802.3af/at）/IGMP；OEM/ODM；交期快
- **W**：品牌认知度低；认证缺口（UL/CE 需核；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：埃及渠道接入层补线；可做贴牌
- **T**：埃及既有网络分销（Cisco/TP-Link 系）价格体系

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。

## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求
- [ ] 项目是否要求本地认证/进口许可（巴基斯坦 PTA / 尼日利亚 NCC / 埃及 NTRA 等）

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- https://www.qnap.com/en-us/where-to-buy/middle-east/egypt/Networking%20Distributor（2026-10-18 检索）；批次：batch/contact_research-2026-10-18_R13_南亚非洲拓线与联系方式核验.json

### B-074 联系方式核验（R14 · 2026-10-18）
- 官网（contratechnology.com）Contact 与结构化数据实锤：**info@contratechnology.com**
- 电话：01000502545（WhatsApp 主线）、+202 25201365、+2 01065442366
- **KP 实锤**：**Mahmoud Hanafy Nasr**（Founder / President / CEO，LinkedIn 实名，公司对外帖文均留其号）
- ★重大情报升级：其代理清单含 **Moxa（工业网络与自动化）**——直接对位我方 **STI 工业系 + LT-IS6312 光旁路**；同时代理 Teltonika（工业路由器/交换机）
  → 打法：以「工业以太网 + 旁路二合一，可 ODM 贴牌」切入，价格与形态差异化，不正面抢 Moxa 品牌单
- ⚠️ **同名陷阱**：另有 **Contra Techno**（contratechno.com，New Maadi，info@contratechno.com，400+ 项目、EGP 500 万注册资本）为**完全不同的公司**，切勿混用

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。情报标注 `[半]`（半年内有效，见 docs/rules/二年期情报维护清单.md）。

## R20 B类全量复挖加厚（2026-10-19）

- **域名与邮件基础设施**：主域名 `contratechnology.com` 于 2026-10-19 经公共 DNS（8.8.8.8）复测：A 记录 104.21.59.171、172.67.181.93；MX 0 mail.contratechnology.com；平台特征 **自建/本地托管或其他邮件服务**。判定：**A 与 MX 均存在，域级收信基础设施现行有效**
- **邮箱定版**：首选触达 `info@contratechnology.com`（来源见联系方式段）；备选 `samar.mahmoud@contratechnology.com`。支持/人事类邮箱不作销售首触。
- **KP 状态**：维持深挖定版——Mahmoud Hanafy Nasr，Founder, President & CEO（定级与限定语以本档 KP 段为准，本轮无新增实名）。
- **口径边界**：DNS 阳性只证明域级收信基础设施在查询时存在，不证明具体邮箱可投递、人员在职或采购意愿；邮箱来源与定级以联系方式/KP 段为准。结构化底稿见 `batch/contact_research-2026-10-19_R20_B类全量复挖加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`contratechnology.com`为A与MX均存在；网站IPv4 `172.67.181.93`、`104.21.59.171`（AS13335 CLOUDFLARENET - Cloudflare, Inc., US），AAAA 2条；邮件入口 `mail.contratechnology.com`（平台特征：自有域邮件主机（自建或本地托管））；NS托管特征为Cloudflare。
- **邮件认证与发信系统信号**：SPF已发布（MailChannels，结尾`~all`）；DMARC `p=none`。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **关联/候选域状态**：`contratechno.com`=A-noMX（无公开MX）。关联域均按档内上下文人工保留，未经主体归属再核者不据此新增联系方式。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 85、跨档出现 ≤3 档的专属行 42、≤10 档的稀有行 45、外链来源域 2 个、全档去重邮箱 3 个；启发式审计分 72/100（主体 12/15、联系 18/20、KP 12/15、业务专属度 12/20、证据 11/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `info@contratechnology.com`（状态 `public_primary_email_recorded`）；KP 状态 `named_single_candidate`，结构化抽到：Mahmoud Hanafy Nasr。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：商用 PoE 模板已按 U28 收紧为 802.3af/at PoE+；首触发送人 Kevin 已改为 Simon。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：B-074｜Contra Technology（埃及，分销商）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 72/100、专属行 43（专属证据密度中高）；联系状态 `public_primary_email_recorded`，主口 `info@contratechnology.com`；KP 状态 `named_single_candidate`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行品牌缺货或交期拉长；下游经销商/SI 的真实项目 BOM；EOL 型号备件与替换需求；价格带下探或自有品牌计划是否真实存在。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Mahmoud Hanafy Nasr；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424DGGPM-280W 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方确认有自有品牌计划，再拆解 Logo、Web UI、标签、包装、手册与 MOQ；未确认前不把 OEM 写成既有需求；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号、库存周转与下游月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：本地进口主体、型式批准、关税与外汇路径仍须由对方逐项确认，未核前不承诺落地价。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
