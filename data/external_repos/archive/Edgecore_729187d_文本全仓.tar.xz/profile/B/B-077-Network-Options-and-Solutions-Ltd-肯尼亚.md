---
structured_profile:
  code: B-077
  rating: B
  country: 肯尼亚
  role: 分销商/SI
  segment: generic
  p1: STC-424DGGPM-280W
  stage: 01-blocked
  struct_version: v2-lite
  updated: 2026-10-27
---

# Network Options and Solutions Ltd

> **评级 B** | 肯尼亚 · Nairobi（East Africa） | 档案编号 `B-077` | 角色：增值分销商（VAD）+集成商 | 状态：01-首触被拦截（官网主口）
> 证据：官网（network-options.co.ke）业务自述 | 2026-10-25 用户回执：官网主口`sales@network-options.co.ke` Message blocked；并列域备选未测
> **首选触达邮箱**：`sales@network-options.co.ke`（2026-10-25回执被拦截；未测备选`sales@network-options.com`，KP见联系方式/触达名单）

## SALES BRIEF（压缩模型）

- **是谁**：内罗毕的增值分销商（VAD）兼集成商，覆盖**肯尼亚与东非区域**；业务线=无线网络、IP 电话、统一通信、综合布线、光纤、**IP 监控/安防**
- **为什么跟**：**VAD + SI 双身份 + 五条业务线**：其每个项目都同时需要交换、布线、无线与安防，接入层 PoE 是交叉点；且官网支持在线下单，说明渠道化程度高【推断】
- **P1（首触唯一主推）**：STC-424DGGPM-280W — 24×GbE PoE+ 280W 管理型（项目接入主力）
- **第一问（只问一个）**：On your IP surveillance and wireless projects, is the access-layer switching sourced in-house or per project?
- **最大未知**：五条业务线营收占比与交换机月走量；KP 姓名待首触索取
- **下一步**：暂停向`.co.ke`主口原样重发；由用户先电话确认放行要求或决定改用官网并列域`sales@network-options.com`，并继续索取采购KP（Agent 不发信）

## 客户概览

Network Options and Solutions Ltd（肯尼亚·内罗毕）为覆盖肯尼亚与东非的增值分销商兼集成商，业务含无线网络、IP 电话、统一通信、综合布线、光纤与 IP 监控（2026-10-18 检索）。定位：东非项目型接入层二供。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Network Options and Solutions Ltd | 事实（官网（network-options.co.ke）业务自述） |
| 国家/城市 | 肯尼亚 / Nairobi（East Africa） | 事实（官网（network-options.co.ke）业务自述） |
| 渠道角色 | 增值分销商（VAD）+集成商 | 事实（官网（network-options.co.ke）业务自述 口径） |
| 联系方式 | 官网在线下单系统与区域业务描述 | 事实（官网自述） |
| 商业模式 | VAD + 系统集成（多业务线）【推断自官网自述】 | 【推断】 |
| 决策链 | 未确认 | 【假设】 |

> 来源 URL：https://network-options.co.ke/（2026-10-18 检索）。
> 检索命中只证明「当日页面列出/展示该主体与其业务描述」，**不证明**当前采购意愿、在职人员、邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：月走量档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：现售哪些品牌型号、PoE 预算/上联速度、有没有改标需求。
- 【研发工程师】看：ERPS/PoE+（802.3af/at）/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- VAD+SI 双身份=自采自用，决策链短
- 五业务线交叉=接入层 PoE 需求稳定复购
- 东非区域覆盖（不止肯尼亚）
- 风险：渠道型客户可能只比价；KEBS 合规须问清；邮箱待补

## 联系方式

- **邮箱**：sales@network-options.co.ke（官网；2026-10-25用户回执Message blocked，暂停原样重发）；sales@network-options.com（官网并列域，Google Workspace，尚未实测）；support@network-options.co.ke（支持口，不作销售首触）
- **网站**：https://network-options.co.ke
- **地址**：Kitamu House, Tubman Road, Nairobi, Kenya
- **关键人（KP）**：未定位（见下 KP 段）

## 产品决策（Saga · 单一决策口径）

- **P1**：STC-424DGGPM-280W — 24×GbE PoE+ 280W 管理型（项目接入主力）
- 备选不进首触：48 口→STC-448DGGPM；工业/弱电间→STI 系列
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |

## 关键人（KP）·深挖核验（2026-10-19）

- 决策层 KP 未定位：公开源仅见公司职能邮箱，未披露董事姓名；首触向 sales@ 索要采购负责人。

- 【KP补挖·终局轮 2026-10-19】仍未定位：商业名录口径为 2013 年创立、1–5 人微型团队；官网/FB/名录均无负责人实名披露。首触向 sales@ 索名即可（微团队大概率业主本人回信）。

## B类深挖核验·批7（2026-10-19）

- **主体**：Network Options and Solutions Ltd，自述东非增值分销商/系统集成商；官网称 Ubiquiti 官方分销、Grandstream 认证伙伴、MikroTik 分销。
- **进口实锤**：Tendata 记录 102 票进口、9 家供应商——真实进口商（第三方海关聚合数据，量级仅供定级参考）。
- **品牌**：官网列 Planet（台）、Dahua、Hikvision、TP-Link 等，中国品牌经验有。
- **成色**：保留（小中型 VAD，进口行为实锤）。

## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs 其在售同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 完整首触邮件（EN · 用户自行发送 · Agent 不发信）

> Subject: A question about access-layer sourcing on your projects
>
> Hi, I'm Simon with Saga Telecom. We supply managed access switching (24/48-port PoE+, 10G uplinks, ERPS) for surveillance, wireless and structured-cabling projects, with OEM branding and lead times around 5–7 days.
>
> One question: on your IP surveillance and wireless projects, is the access-layer switching sourced in-house or per project?
>
> Best regards, Simon — Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；⚠️U28：商用 PoE=af/at 单口 30W，不得宣称 802.3bt 90W 对等；bt 场景转工业系。发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥来源 | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| STC-424DGGPM-280W | 见 docs/sales/P1产品价格快照.md 对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE+（802.3af/at）/IGMP；OEM/ODM；交期快
- **W**：品牌认知度低；认证缺口（UL/CE 需核；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：东非安防与园区项目；OEM 做其交付品牌
- **T**：Ubiquiti/MikroTik/TP-Link 在东非渗透；项目特价

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。

## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求
- [ ] 项目是否要求本地认证/进口许可

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| 1 | 2026-10-25（用户转交日；原通知日期未含） | 邮箱回执 | 用户转来`sales@network-options.co.ke`投递通知 | Message blocked，未送达；不证明邮箱不存在 | 电话确认放行或由用户决定改用并列域备选 |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- https://network-options.co.ke/（2026-10-18 检索）；批次：batch/contact_research-2026-10-18_R14_非洲亚洲拓线与邮箱补齐.json

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。情报标注 `[半]`（半年内有效，见 docs/rules/二年期情报维护清单.md）。

## R20 B类全量复挖加厚（2026-10-19）

- **域名与邮件基础设施**：主域名 `network-options.co.ke` 于 2026-10-19 经公共 DNS（8.8.8.8）复测：A 记录 34.160.17.71、35.227.194.51 等4条；MX 30 mx30.antispam.mailspamprotection.com；20 mx20.antispam.mailspamprotection.com 等3条；平台特征 **Microsoft 365**。判定：**A 与 MX 均存在，域级收信基础设施现行有效**
- **邮箱定版**：首选触达 `sales@network-options.co.ke`（来源见联系方式段）；备选 `sales@network-options.com`。支持/人事类邮箱不作销售首触。
- **KP 状态**：仍未定位——微型团队未披露负责人，首触向 sales@ 索名（大概率业主本人回信）。
- **口径边界**：DNS 阳性只证明域级收信基础设施在查询时存在，不证明具体邮箱可投递、人员在职或采购意愿；邮箱来源与定级以联系方式/KP 段为准。结构化底稿见 `batch/contact_research-2026-10-19_R20_B类全量复挖加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`network-options.co.ke`为A与MX均存在；网站IPv4 `34.160.17.71`、`34.120.190.48`等4条（AS396982 GOOGLE-CLOUD-PLATFORM - Google LLC, US），未见AAAA；邮件入口 `mx10.antispam.mailspamprotection.com`、`mx20.antispam.mailspamprotection.com`等3条（平台特征：SiteGround反垃圾网关）；NS托管特征为SiteGround。
- **邮件认证与发信系统信号**：SPF已发布（授权include `network-options.co.ke.spf.auto.dnssmarthost.net`，结尾`~all`）；DMARC `p=none`。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **关联/候选域状态**：`network-options.com`=A+MX（Google Workspace）。关联域均按档内上下文人工保留，未经主体归属再核者不据此新增联系方式。
- **最新回执收口**：用户2026-10-25转来官网首选`sales@network-options.co.ke`“Message blocked”。主域MX经SiteGround反垃圾网关，单封被政策/安全机制拦截不证明邮箱不存在；官网并列域`sales@network-options.com`为Google Workspace且尚未实测。GitHub两条公司/域名精确检索均为0，KP仍未定位。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 80、跨档出现 ≤3 档的专属行 40、≤10 档的稀有行 41、外链来源域 1 个、全档去重邮箱 3 个；启发式审计分 51/100（主体 12/15、联系 11/20、KP 0/15、业务专属度 12/20、证据 8/20、可执行性 8/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：官网/历史主口为 `sales@network-options.co.ke`（状态 `recorded_but_blocked_last_attempt_alternate_domain_untested`）；KP 状态 `not_located`，结构化抽到：未从结构化 KP 段抽到可升格实名。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：商用 PoE 模板已按 U28 收紧为 802.3af/at PoE+；首触发送人 Kevin 已改为 Simon。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：采购/产品决策人实名或现行任职未闭合；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：用现有企业口或总机确认采购/产品负责人姓名与现行任职，再决定是否点名首触；技术作者和普通员工不升格为采购 KP。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：B-077｜Network Options and Solutions Ltd（肯尼亚，分销商/SI）。本轮类型：定向外部复核/负结果 + 运营化合成；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 C、质量基线 51/100、专属行 42（专属证据密度中高）；联系状态 `recorded_but_blocked_last_attempt_alternate_domain_untested`，主口 `sales@network-options.co.ke`；KP 状态 `not_located`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行品牌缺货或交期拉长；下游经销商/SI 的真实项目 BOM；EOL 型号备件与替换需求；价格带下探或自有品牌计划是否真实存在。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：经济买家、产品负责人、技术评估人、进口/财务签核人四类角色均未实名闭合；只能经总机或现有企业口按职能索名，普通员工、技术作者和招聘联系人不升格。
- **触达顺序与停发规则**：先修复投递路线，不原样重发。下一证据路径：用现有企业口或总机确认采购/产品负责人姓名与现行任职，再决定是否点名首触；技术作者和普通员工不升格为采购 KP。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424DGGPM-280W 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方确认有自有品牌计划，再拆解 Logo、Web UI、标签、包装、手册与 MOQ；未确认前不把 OEM 写成既有需求；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号、库存周转与下游月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：本地进口主体、型式批准、关税与外汇路径仍须由对方逐项确认，未核前不承诺落地价。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：采购/产品决策人实名或现行任职未闭合；现行采购型号、月量和认证要求未由客户确认。
- **定向外部补挖**：Network Options 官网联系面本轮仍同时支持 `.co.ke` 与 `.com` 两条销售路线；已知事实是 `.co.ke` 最近一封被 Message blocked，而 `.com` 尚未实测。官网没有管理层/采购负责人名单，第三方 102 票进口记录在旧段已按聚合数据降级使用，本轮未找到更强的原始海关或董事材料。来源：https://network-options.co.ke/ 。
- **定向外部补挖**：KP 与现行采购量继续未闭合。下一证据不是继续猜邮箱，而是电话确认两个域哪个是现行订单口、外部邮件放行要求及采购负责人姓名；未确认前不把被拦截写成地址不存在。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
