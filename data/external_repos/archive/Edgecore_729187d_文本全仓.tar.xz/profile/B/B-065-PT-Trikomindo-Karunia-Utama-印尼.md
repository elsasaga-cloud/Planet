---
structured_profile:
  code: B-065
  rating: B
  country: 印尼
  role: 分销商
  segment: generic
  p1: STC-28DGGPM
  stage: 00-lead
  struct_version: v2-lite
  updated: 2026-10-27
---

# PT Trikomindo Karunia Utama

> **评级 B** | 印尼 · Jakarta Pusat（Mangga Dua） | 档案编号 `B-065` | 角色：IT 设备经销商 | 状态：00-未触达
> 证据：第三方 B2B 平台挂牌页（indonetwork.co.id） | 2026-10-18 检索；**官网未直接核验，邮箱/KP 待补后再首触**
> **首选触达邮箱**：`sales@trikomindo.co.id`（备选与 KP 见联系方式/触达名单）

## SALES BRIEF（压缩模型）

- **是谁**：雅加达 Mangga Dua 的 IT 设备供应企业，20 年经营；Linksys 授权伙伴/经销商，销售 8 口 PoE 等管理型交换机；在 indonetwork 平台挂牌
- **为什么跟**：**货架型渠道**：Mangga Dua 是雅加达 IT 批发集散地，其客户是下游零售商与小型集成商——小口数管理型 PoE 走量快、试单门槛低【推断】
- **P1（首触唯一主推）**：STC-28DGGPM — 小口数 PoE+ 管理型（渠道铺货主力）
- **第一问（只问一个）**：Which managed PoE models move fastest through your channel?
- **最大未知**：自营进口 vs 本地拿货的比例未公开
- **下一步**：由用户按档首首选邮箱首触；KP 定级见触达名单/R20 段（Agent 不发信）

## 客户概览

PT Trikomindo Karunia Utama（雅加达 Mangga Dua，Harco 商圈）为 20 年 IT 设备经销商，Linksys 授权伙伴，挂牌销售管理型 PoE 交换机（2026-10-18 检索）。定位：渠道铺货型二供。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | PT Trikomindo Karunia Utama | 事实（第三方 B2B 平台挂牌页（indonetwork.co.id）） |
| 国家/城市 | 印尼 / Jakarta Pusat（Mangga Dua） | 事实（第三方 B2B 平台挂牌页（indonetwork.co.id）） |
| 渠道角色 | IT 设备经销商 | 事实（第三方 B2B 平台挂牌页（indonetwork.co.id） 口径） |
| 联系方式 | 官网 trikomindo.co.id；电话 (021) 6120196-97 / 6003622-23；邮箱 sales@trikomindo.co.id | 事实（官网 Contact 页） |
| 商业模式 | **系统整合与 ICT 方案商**（官网自述 System Integrator & ICT Solution，端到端 IT 基础设施与网络），兼 Mangga Dua 批发零售；Linksys 授权伙伴【事实（官网自述）+推断】 | 【推断】 |
| 决策链 | 未确认 | 【假设】 |

> 来源 URL：https://www.indonetwork.co.id/product/distributor-linksys-switch-managed-2210126（2026-10-18 检索）。
> 检索命中只证明「当日页面列出/展示该主体与其业务描述」，**不证明**当前采购意愿、在职人员、邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：月走量档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：现售哪些品牌型号、PoE 预算/上联速度、有没有改标需求。
- 【研发工程师】看：ERPS/PoE+（802.3af/at）/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- 批发集散地渠道，走量快、复购频繁
- 小口数管理型 PoE 是其挂牌主力，我方直接对位
- 试单门槛低（MOQ 10 台起），易建立首次合作
- 风险：渠道型客户可能只比价；需 Qualification 三问确认是否有真实下游

## 联系方式（公开来源）
- 邮箱：sales@trikomindo.co.id（官网 Contact 页）；wirawan@trikomindoutama.com（原档所载业务邮箱，与董事实名对应，见下）
- 电话：(021) 6120196/6120197（办公室）、(021) 6003622/6003623（门店）；官网 https://trikomindo.co.id
- 地址：Komplek Harco Mangga Dua, Ruko Apartemen Pesona Bahari Blok R17, Jakarta Pusat 10730（另 Harco Mangga Dua Plaza 门店）

## 产品决策（Saga · 单一决策口径）

- **P1**：STC-28DGGPM — 小口数 PoE+ 管理型（渠道铺货主力）
- 备选不进首触：24 口→STC-424DGGPM-280W；纯千兆非 PoE→STC-28DGGM（¥456/475/494）
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |


## 关键人（KP）·深挖核验（2026-10-19）
- **Wirawan Wijaya，Director**（LinkedIn 本人页「Director at PT Trikomindo Karunia Utama」——原档仅名「Wirawan」，本次补齐全名与职务）
- 【同名甄别】≠ PT Trikomindo **Kharis** Utama（业主 Susanto，拼写不同，系另一公司，勿混）

## B类深挖核验·批6（2026-10-19）
- 1999/2000 年起盘踞雅加达 Harco Mangga Dua 电子商圈的 IT 分销+零售+项目三栖商：光纤产品见长（INDOFIBER 分销、Panduit 授权伙伴），网络设备在营（Huawei、TP-Link、D-Link、Linksys 等多品牌现货转售）
- 规模小（目录载 1–10 人），但二十余年一线电子市场现货渠道，模式为现货贸易型
- **成色判定：保留（小型现货渠道，董事实名到位）**

## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs 其在售同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 完整首触邮件（EN · 用户自行发送 · Agent 不发信）

> Subject: A question about your managed PoE range
>
> Hi, I'm Simon with Saga Telecom. We build managed PoE+ switches — 8/24/48-port Gigabit with VLAN, IGMP snooping and PoE watchdog — supplied direct from factory with OEM branding available from small quantities.
>
> One question: which managed PoE models move fastest through your channel?
>
> Best regards, Simon — Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；⚠️U28：商用 PoE=af/at 单口 30W，不得宣称 802.3bt 90W 对等；bt 场景转工业系。发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥来源 | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| STC-28DGGPM | 见 docs/sales/P1产品价格快照.md 对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE+（802.3af/at）/IGMP；OEM/ODM；交期快
- **W**：品牌认知度低；认证缺口（UL/CE 需核；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：印尼群岛零售与小型集成商网络；可做贴牌铺货
- **T**：TP-Link/D-Link 在印尼批发渠道价格极低

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。

## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求
- [ ] 项目是否要求本地认证/进口许可

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- https://www.indonetwork.co.id/product/distributor-linksys-switch-managed-2210126（2026-10-18 检索）；批次：batch/contact_research-2026-10-18_R12_孟印尼建档工业线问答.json

### B-065 联系方式核验（R13 · 2026-10-18）
- 官网（trikomindo.co.id）Contact 页实锤：**sales@trikomindo.co.id**；(021) 6120196-97（办公室）、(021) 6003622-23（门店）
- 销售 WA：0811-933-066、0811-1828-876、0811-1666-066、0851-9911-1352
- 地址：Ruko APB / Komplek Harco Mangga Dua, Ruko Apartemen Pesona Bahari Blok R17, Jakarta Pusat 10730；门店 Harco Mangga Dua Plaza Lt. Dasar Blok B No.114-115
- KP：**Wirawan**（wirawan@trikomindoutama.com，多平台署名）、Ibu Sana（销售，WA 0851-9911-1352）
- **升级信号**：官网自述为 **System Integrator & ICT Solution（端到端 IT 基础设施与网络）**，比原先"批发经销商"定位更高——可同时打**项目线 + 批发线**，P1 可考虑由 STC-28DGGPM 上调为 STC-424DGGPM-280W（按首触反馈决定）
- ⚠️ 多个 sister domain（trikomindoutama.co.id / toko-trikomindo.com / trikomindo-network.com）为同一集团，发信只走 sales@trikomindo.co.id 避免重复触达

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。情报标注 `[半]`（半年内有效，见 docs/rules/二年期情报维护清单.md）。

## R20 B类全量复挖加厚（2026-10-19）

- **域名与邮件基础设施**：主域名 `trikomindo.co.id` 于 2026-10-19 经公共 DNS（8.8.8.8）复测：A 记录 103.185.53.120；MX 0 trikomindo.co.id；平台特征 **自建/本地托管或其他邮件服务**。判定：**A 与 MX 均存在，域级收信基础设施现行有效**
- **邮箱定版**：首选触达 `sales@trikomindo.co.id`（来源见联系方式段）；`wirawan@trikomindoutama.com` 已停用（见下条），不作备选。
- **KP 状态**：维持深挖定版——Wirawan Wijaya，Director（定级与限定语以本档 KP 段为准，本轮无新增实名）。
- **⚠️ 不可发地址**：`trikomindoutama.com` 的 MX 为空主机（Null MX，RFC 7505，表示明确不收信）——`wirawan@trikomindoutama.com` 发送必退，即日起停用作触达地址（仅保留为域名沿革记录）。首选维持 `sales@trikomindo.co.id`，点名 Director Wirawan Wijaya。
- **口径边界**：DNS 阳性只证明域级收信基础设施在查询时存在，不证明具体邮箱可投递、人员在职或采购意愿；邮箱来源与定级以联系方式/KP 段为准。结构化底稿见 `batch/contact_research-2026-10-19_R20_B类全量复挖加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`trikomindo.co.id`为A与MX均存在；网站IPv4 `103.185.53.120`（AS139456 IDNIC-NSR-DEWAWEB-AS-ID - PT DEWAWEB, ID），未见AAAA；邮件入口 `trikomindo.co.id`（平台特征：自有域邮件主机（自建或本地托管））；NS托管特征为dewaweb.com。
- **邮件认证与发信系统信号**：SPF已发布（MailChannels，结尾`~all`）；未见公开DMARC政策。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **关联/候选域状态**：`trikomindoutama.com`=A+NullMX（Null MX（明确不收信））。关联域均按档内上下文人工保留，未经主体归属再核者不据此新增联系方式。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 83、跨档出现 ≤3 档的专属行 44、≤10 档的稀有行 46、外链来源域 2 个、全档去重邮箱 2 个；启发式审计分 75/100（主体 12/15、联系 18/20、KP 15/15、业务专属度 12/20、证据 11/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `sales@trikomindo.co.id`（状态 `public_primary_email_recorded`）；KP 状态 `named_multiple_candidates`，结构化抽到：Wirawan Wijaya、Kharis。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：商用 PoE 模板已按 U28 收紧为 802.3af/at PoE+；首触发送人 Kevin 已改为 Simon。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：B-065｜PT Trikomindo Karunia Utama（印尼，分销商）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 75/100、专属行 45（专属证据密度中高）；联系状态 `public_primary_email_recorded`，主口 `sales@trikomindo.co.id`；KP 状态 `named_multiple_candidates`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行品牌缺货或交期拉长；下游经销商/SI 的真实项目 BOM；EOL 型号备件与替换需求；价格带下探或自有品牌计划是否真实存在。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Wirawan Wijaya、Kharis；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-28DGGPM 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方确认有自有品牌计划，再拆解 Logo、Web UI、标签、包装、手册与 MOQ；未确认前不把 OEM 写成既有需求；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号、库存周转与下游月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：本地进口主体、型式批准、关税与外汇路径仍须由对方逐项确认，未核前不承诺落地价。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
