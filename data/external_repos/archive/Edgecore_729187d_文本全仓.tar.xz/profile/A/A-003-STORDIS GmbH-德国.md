---
structured_profile:
  id: A-003
  company: STORDIS GmbH（及 STORDIS Limited 英国）
  country: 德国/英国
  rating: A
  biz_model: 开放网络专业分销+集成+24/7 TAC
  decision_speed: 专业评估制
  needs: [白牌/开放网络硬件货源, OEM, 长期供货与交期, 技术支持]
  p1: 白牌/开放网络接入层（可谈OEM）待核价
  stage: 未接触
  volume_potential: 中高（欧洲开放网络专业渠道）
  risk_flags: [对品质/支持要求高, 与Edgecore关系深]
  updated: 2026-10-27
---

# A-003 · STORDIS GmbH · 德国/英国

## 1. SALES BRIEF
- **是谁**：欧洲开放网络专家分销（2007 成立，11-50 人），设计-集成-维护-24/7 TAC，服务云 DC/电信/大企业
- **为什么跟**：开放网络生态商天然需要多硬件货源与白牌合作；IPNexia 案例三方之一（与 Deca/Edgecore）
- **P1**：白牌/可贴牌开放网络接入层
- **第一问**：When you build second-source hardware into client designs, what matters most — lead time, customization depth, or unit cost?
- **最大未知**：白牌需求真实度、年量、验厂/认证要求
- **下一步**：首触邮件 → 供货能力对话

## 2. 基本事实
| 内容 | 标签 |
|---|---|
| GmbH：Rübteile 24, 72574 Bad Urach / Rosenwiesstr.17, 70567 Stuttgart；+49 711 342 158 0；info@stordis.com | 事实（官网/名录） |
| Limited（英国）：Pershore WR10 1DP（名录口径） | 事实（Edgecore 名录） |
| 自述 "Open Networking Expert"，11-50 人（LinkedIn），2007 成立 | 事实（LinkedIn） |
| 参与 IPNexia 开放网络数据中心（自述案例页） | 事实（stordis.com） |
| 需要多供应商硬件底座 | 【推断】依据：开放网络分销定位 |

## 3. 技术与在用
- 组合：Edgecore 硬件+SONiC/Cumulus 类 NOS、Chelsio 等生态（合作伙伴页）
- 自有 TAC（24/7）→ 对可支持性敏感

## 4. 需求与场景
- 【推断】白牌/第二货源用于非旗舰或成本敏感项目
- 【推断】对 OEM 固件/品牌有成熟流程——依据：长期做开放网络集成

## 5. HR 与规模信号
- 11-50 人、成立 2007、跨国双实体 → 稳定中型渠道

## 6. 联系方式
- **邮箱**：info@stordis.com / enquiries@stordis.com（官网）；**waldemar.scheck@stordis.com**（Chelsio 伙伴页公开的 CEO 直达邮箱）
- **电话**：+49 711 342 158 0
- **网站**：stordis.com

## 7. 关键人（KP）
- **Waldemar Scheck — CEO**（2007 年加入公司，2020 年任 CEO；兼 route2open Chief Enablement Officer）【事实：官网 About/Careers + RocketReach】→ 决策层直达邮箱已公开（见 §6），首触可点名但建议先走 info@ 并抄送逻辑待用户定
- Alexander Scheck（培训/学院线，Alexander.Scheck@stordis.com，LinkedIn 公司页公开）
- Kamal Bhatt — Head of Value Driven Software Delivery（OCP EMEA 2025 议程署名，软件线负责人）

## 8. 跟进步骤（≤3）
1. **首触**：供货能力一页纸（芯片库存/交期/OEM 清单）；问第二货源标准；exit：14 天无回复→季度低频
2. **台阶**：样机+技术对齐（CLI/MIB）；问年量结构；exit：只比价→停
3. **台阶**：小批量试单/项目报备；exit：书面拒绝→停

## 9. 调研要点与证据
- stordis.com（about-us/contact/case）；LinkedIn 公司页；Edgecore EMEA 分销/经销名录

## 10. 产品决策
- **P1**：可贴牌 24 口管理型 L2+（Marvell 线）——待核价
- 备选（不进首触）：PoE 项目款、工业款

## 11. SWOT
- S：OEM 深度+交期+价格弹性；W：品牌弱、无 SONiC；O：欧洲开放网络增长；T：Edgecore 原厂绑定
## 12. 触达与风险红线
- 不贬 Edgecore，定位第二货源；**停止开发条件**：3 次无回复/书面拒绝
## 13. Qualification
- 技术合格待验证；商业合格待首触（年量/条款）
## 14. Unknowns
- [ ] 白牌真实需求？ [ ] 验厂/认证门槛？ [ ] 年量？ [ ] 决策人？
## 15. 首触邮件（英文）
**Subject: Second-source white-box switches for your open networking projects**

> Hi,
>
> I'm Simon with Saga Telecom. We manufacture managed switches with deep OEM/ODM support — Web GUI, CLI, MIB, firmware branding — chips in stock and short lead times.
>
> STORDIS builds open networking designs across Europe with Edgecore and SONiC; for projects that need a cost-optimized second source or private-labeled access layer, we can help without touching your flagship stack.
>
> One question: when you evaluate second-source hardware for client designs, what matters most — lead time, customization depth, or unit cost?
>
> I can share our customization matrix and a sample quotation.
>
> Best regards, Simon | Saga Telecom | https://sagatele.com


## R15 深度核验（2026-10-19）
- **规模定版**：2007 年成立，LinkedIn 口径 11-50 人，团队分布德国/波兰/英国，设 24/7 国际 TAC【事实：官网 About】
- **总部现址**：Ruebteile 24, 72574 Bad Urach（官网 Contact，2025-12 更新）；旧址 Stuttgart Rosenwiesstr. 17 仍见于旧文件，寄样前确认
- ★**与 A-008 Pine Networks 战略合作**（2025-08-01 起，主攻法国云/AI/企业市场）——两档互为通道
- 自有软件线：ORCA / Monsoon（SONiC 发行与管理），纯硬件白牌话题须绑定其软件生态谈

## 16. 跟进记录
| 日期 | 渠道 | 动作 | 客户反应 | 结论 | 下次动作日期 |
|---|---|---|---|---|---|
| 2026-10-18 | — | 建档 | — | 未联系 | 首触待排 |

## 17. 下次复核
首触后 14 天无回复 → 降频季度复核。

## R18 A类增量加厚（2026-10-19）

- **现行域名与邮件基础设施**：主域名 `stordis.com` 于 2026-10-19 经公共 DNS（8.8.8.8）实查：A 记录 `82.165.141.86`；MX `10 mx01.hornetsecurity.com, 20 mx02.hornetsecurity.com, 30 mx03.hornetsecurity.com, 40 mx04.hornetsecurity.com`；邮件平台特征为 **Hornetsecurity邮件网关**。判定：**A与MX均存在**。
- **官方渠道快照对账**：仓库留存的 Edgecore 官方渠道快照（2026-10-18，分区 `emea-distributors`）载：地址 **Rübteile 24, 72574 Bad Urach / Rosenwiesstr.17, 70567 Stuttgart**；电话 +49-711-342 158 0；渠道定位 分销商。此项用于补齐主体地址并与档内电话对账；若与本档 R15 后段更新的登记/官网字段冲突，以后段为准。
- **R18 定点增量**：官方 GitHub 组织 `STORDIS` 主页链接 `stordis.com`，组织资料于 2026-09-07 更新；其 `monsoon` 仓库自述为 SONiC telemetry/monitoring，2026-01-14 仍有提交。贡献者 Kamal Krishna Bhatt 的 GitHub 个人资料自述 `Company=STORDIS`、`Software Product Manager at STORDIS`（2026-09-08 更新）；与本档既有 OCP 2025“Head of Value Driven Software Delivery”并存记录、不互相覆盖。其属软件/产品线利益相关者，不据此认定硬件采购 KP；Saga 无 SONiC 的边界不变。
- **口径边界**：DNS 阳性仅证明域名与收信基础设施在查询时存在，不证明任一具体邮箱可投递、人员仍在职或有采购意愿；KP/邮箱仍以本档 R15 定版为准。结构化底稿见 `batch/contact_research-2026-10-19_R18_A类增量加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`stordis.com`为A与MX均存在；网站IPv4 `82.165.141.86`（AS8560 IONOS-AS - IONOS SE, DE），AAAA 1条；邮件入口 `mx01.hornetsecurity.com`、`mx02.hornetsecurity.com`等4条（平台特征：Hornetsecurity邮件网关）；NS托管特征为mk.de。
- **邮件认证与发信系统信号**：SPF已发布（Hornetsecurity、Zendesk，结尾`-all`）；未见公开DMARC政策；CAA授权CA：sectigo.com、letsencrypt.org、digicert.com。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **公开服务面（DNS）**：检出`support.stordis.com`（Zendesk）。子域存在只证明DNS/服务配置，不单独证明页面当前可用或交易活跃。
- **GitHub公开技术足迹**：[STORDIS](https://github.com/STORDIS)（Organization，官网域互指/官方资料绑定）；公开仓库2个，最近推送2026-01-14，近作含`monsoon`、`BGP_Monsoon_Demo`。技术活动不自动升格采购KP。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 60、跨档出现 ≤3 档的专属行 53、≤10 档的稀有行 57、外链来源域 2 个、全档去重邮箱 4 个；启发式审计分 78/100（主体 12/15、联系 18/20、KP 15/15、业务专属度 15/20、证据 11/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `enquiries@stordis.com`（状态 `public_primary_email_recorded`）；KP 状态 `named_multiple_candidates`，结构化抽到：Waldemar Scheck、Kamal Bhatt。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：首触自我介绍中的 Shenzhen 已删除。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：A-003｜A-003 · STORDIS GmbH · 德国/英国（德国/英国，渠道/项目伙伴）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 78/100、专属行 54（专属证据密度强）；联系状态 `public_primary_email_recorded`，主口 `enquiries@stordis.com`；KP 状态 `named_multiple_candidates`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行项目 BOM；现用品牌缺货或 EOL 替换；多站点复制交付；成本档与本地库存压力。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Waldemar Scheck、Kamal Bhatt；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 白牌/开放网络接入层（可谈OEM）待核价 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号与月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：欧英市场按具体型号核 CE/UKCA 与进口商义务；UL 无证口径不替代当地符合性确认。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
