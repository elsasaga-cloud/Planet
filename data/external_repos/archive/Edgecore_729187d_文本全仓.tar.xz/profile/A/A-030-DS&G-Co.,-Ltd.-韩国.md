---
structured_profile:
  code: A-030
  rating: A
  country: 韩国
  role: SI/VAR
  segment: generic
  p1: STC-424XGGPM-280W
  stage: 00-lead
  struct_version: v2-lite
  updated: 2026-10-27
---

# DS&G Co., Ltd.

> **评级 A** | 韩国 · Seoul | 档案编号 `A-030` | 角色：SI/VAR/集成商 | 状态：00-未触达
> 证据：Edgecore 官方渠道名录（ASIA-R）+ 2026-10-18 检索 | 来源：https://www.edge-core.com/where-to-buy/asia-reseller/

## SALES BRIEF（压缩模型）

- **是谁**：韩国·Seoul 的SI/VAR/集成商；Edgecore 官方渠道名录收录（事实）
- **为什么跟**：在售/集成 Edgecore，说明白牌/开放网络硬件已被接受；用 Saga（STC/STI）同规格更低价+OEM/ODM 做第二货源【推断】
- **P1（首触唯一主推）**：STC-424XGGPM-280W — 24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）
- **第一问（只问一个）**：Which Edgecore models do you move most, and what price tier wins your deals?
- **最大未知**：在售具体型号与月采购量未确认；联系人状态以本档后段 R15/R18 定版为准（见触达名单与 R18 段）
- **下一步**：先由用户电话确认是否仍设网络产品部门及负责人；官网公开的 dsng_support@ 仅技术支持，不作销售首选（Agent 不发信）

## 客户概览

DS&G Co., Ltd.（韩国·Seoul）为 SI/VAR/集成商，列于 Edgecore 官方渠道名录（ASIA-R）。备注：官方SI。定位：接入层第二货源/OEM 目标（A 级主攻）。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | DS&G Co., Ltd. | 事实（官方名录） |
| 国家/城市 | 韩国 / Seoul | 事实（官方名录） |
| 电话 | +82 2 6949 1850 | 事实（官方名录） |
| 渠道角色 | SI/VAR/集成商（ASIA-R） | 事实（官方名录口径） |
| 备注 | 官方SI | 事实（本轮记录） |
| 商业模式 | SI/VAR/集成商，转售/集成 Edgecore 并可能代理多品牌 | 【推断】 |
| 决策链 | 见后段「触达名单」及 R15/R18 定版；本行旧模板口径已失效 | 事实/线索分层 |

> 来源 URL：https://www.edge-core.com/where-to-buy/asia-reseller/（2026-10-18 检索）。官方名录只证明「当日页面列出该伙伴」，不证明当前采购意愿/在职人员/邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：他月走量在哪个档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：他现售 Edgecore 哪些料号、PoE 预算/上联速度需求、有没有改标需求。
- 【研发工程师】看：ERPS/PoE+（802.3af/at）/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- 已接受白牌/开放网络硬件【推断自其在 Edgecore 渠道名录】
- Saga 同规格成本档可做第二货源 + OEM 贴牌 + 交期优势
- 风险：认证约束（UL 无；CE/FCC 须在欧美触达前按具体型号核实；轨交/EN50155 非全线）在部分项目型需求处需留证

## 联系方式

- **电话**：+82 2 6949 1850（官方名录）
- **邮箱**：**dsng_support@dsngsystem.co.kr**（官网公告页公开，技术支持口）；电话 +82-2-6309-1830（官网代表号）/ +82 2 6949 1850（Edgecore 名录）
- **网站**：serverworld.co.kr(dsngsystem.co.kr)（R2 官网核验 2026-10-18）

## 产品决策（Saga · 单一决策口径）

- **P1**：STC-424XGGPM-280W — 24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）
- 备选不进首触：工业场景→STI 系列；纯千兆成本敏感→STC-424DGGM（¥552 档）
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |

## 触达名单

### KP 实名（R15 深度挖掘·批2 2026-10-19）
- **서정열（徐正烈 Seo Jeong-yeol）— 代表理事/CEO**（saramin·jobkorea 企业登记 + 2023 年全北日报专访；全北大学电子工程出身，前现代汽车，1999 年创办）
- Shinbong Kang — Director（ZoomInfo，所用 @serverworld.co.kr 为其旧品牌域）

- 邮箱：s***@serverworld.co.kr(域名)（R2 官网核验 2026-10-18 已填，禁止编造原则已满足）
- LinkedIn/电话：+82 2 6949 1850（官方名录）

## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs Edgecore 同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 首触邮件要点（模板素材，用户自行发送）

> Subject: Second-source switching for your Edgecore line
> 观察（在 Edgecore 渠道名录看到你们）→ 相关性（同规格白牌+OEM 贴牌+交期）→ 一个问题（哪个型号走量？）
> 红线：不提「Made in China」；不提「研究过你官网」；一次只问一个问题


### 完整首触邮件（英文 · 用户自行发送 · Agent 不发信）

> Subject: Your Edgecore access switches — a same-spec second source
>
> Dear Purchasing / Procurement Team,
>
> I noticed DS&G Co., Ltd. carries the Edgecore access line. With the ECS2100 family entering end-of-life (last order date 2026-04-01), many partners are moving to a same-spec second source to keep projects and spares covered.
>
> We manufacture managed access switches — 24×GbE/PoE+ with 4×10G uplinks, 280W/440W PoE budgets, ERPS / IGMP snooping / 802.3af/at PoE+ — and we support OEM branding (logo, packaging, docs) from 10 units.
>
> One question: which access model moves the most volume for you right now?
>
> Best regards, Simon · Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥ | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| STC-424XGGPM-280W | 见 P1 价格快照对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE+（802.3af/at）/IGMP；OEM/ODM；交期快
- **W**：品牌认知度低；认证约束（UL 无；CE/FCC 须按具体型号核实；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：ECS2100 EOL 替换窗口（2026-04-01 前后）；客户双货源策略
- **T**：Edgecore 官方替代（ECS4150 系列）价格竞争；大客户锁价长约

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。

## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求

## 未知项清单

- 邮箱/KP：R2 已核验——KP：Shinbong Kang강신봉(常务/董事);Yeongmin Seo(战略规划)；邮箱：s***@serverworld.co.kr(域名)
- 在售型号清单：待首触确认
- 认证敏感度（UL/轨交/E-mark/KC）：未知，涉及轨交/车载需求先声明缺口

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- https://www.edge-core.com/where-to-buy/asia-reseller/（2026-10-18 检索，官方渠道名录）；批次：batch/contact_research_2026-10-18_R1_官方渠道全量.json


## R15 深度核验·批2（2026-10-19）
- **身份**：（주）디에스앤지시스템 DS&G System，1999 年以 Supermicro 韩国官方代理起家（法人登记 2003），51-200 人，总部首尔永登浦 ACE Hitech City
- **地位**：**Supermicro 韩国总代**（首家获 Distributor Certification）、NVIDIA Solution Provider；客户含 Naver/Kakao/三星
- 官网产品线明列「Network: CREDO; **Edgecore**」⇒ 交换机是其服务器整柜配套品类；韩国 KC 认证红线照旧
- ⚠️同名陷阱：DSG Enterprise（dsg.kr）与井邑钢铁 DS&G Co. 均无关

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。

## 【R2 官网核验 2026-10-18】

- **核验批次**：contact_research-2026-10-18_R2_A级官网核验
- **官网**：serverworld.co.kr(dsngsystem.co.kr)
- **公开邮箱**：s***@serverworld.co.kr(域名)
- **关键联系人（KP）**：Shinbong Kang강신봉(常务/董事);Yeongmin Seo(战略规划)
- **情报要点**：★Supermicro韩国首家认证分销(台牌合作经验命中!);客户NAVER/Kakao/Samsung;11-50人$6M
- **来源**：zoominfo;platformalliance
- **核验状态**：官网/公开渠道核验通过
- **纪律**：首触由用户自理；Agent 不发信不排期。一切价格先按 SmartByte 成本核价再按 +20%/+25%/+30% 报 RMB，外报 USD 按当日/近期汇率。

## 【R3 深挖 2026-10-18】（批次 contact_research-2026-10-18_R3_型号价格待核收尾）

- **①产品**：DSG
  - 发现：Supermicro韩国首家总代+NVIDIA Solution Provider(Blackwell/GB200);服务器/存储/GPU/HPC;交换机仅Supermicro SSE系(SSE-C4632 SONiC);⚠️风险注记:2026-03 NYT Supermicro出口违规起诉案
  - 结论/对位：对位:服务器配套ToR/接入白牌;合规敏感需低调
  - 来源：src=dsngsystem.co.kr;platformalliance;nytimes
- **纪律**：报价先按 SmartByte 成本核价×1.20/1.25/1.30=RMB 未税 EXW，外报 USD 按当日/近期汇率；首触用户自理。

## R18 A类增量加厚（2026-10-19）

- **现行域名与邮件基础设施**：主域名 `dsngsystem.co.kr` 于 2026-10-19 经公共 DNS（8.8.8.8）实查：A 记录 `125.141.209.196`；MX `10 mail.dsngsystem.co.kr, 10 mailapp.hiworks.co.kr`；邮件平台特征为 **Hiworks（韩）**。判定：**A与MX均存在**。
- **官方渠道快照对账**：仓库留存的 Edgecore 官方渠道快照（2026-10-18，分区 `asia-reseller`）载：地址 **1-501, 502, ACE Hitech City, 775, Gyeongin-ro, Yeongdeungpo-gu, Seoul**；电话 +82-2-6949 1850；渠道定位 SI·VAR·经销商。此项用于补齐主体地址并与档内电话对账；若与本档 R15 后段更新的登记/官网字段冲突，以后段为准。
- **R18 定点增量**：旧站域 `serverworld.co.kr` 当前 A 指向 127.0.0.1、MX 为 `deny-aaa.com`，显示该旧域名不可作现行网站/邮箱域；本档后续以 `dsngsystem.co.kr` 的 A/MX 为准。
- **口径边界**：DNS 阳性仅证明域名与收信基础设施在查询时存在，不证明任一具体邮箱可投递、人员仍在职或有采购意愿；KP/邮箱仍以本档 R15 定版为准。结构化底稿见 `batch/contact_research-2026-10-19_R18_A类增量加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`dsngsystem.co.kr`为A与MX均存在；网站IPv4 `125.141.209.196`（AS4766 KIXS-AS-KR-KR - Korea Telecom, KR），未见AAAA；邮件入口 `mailapp.hiworks.co.kr`、`mail.dsngsystem.co.kr`（平台特征：Hiworks）；NS托管特征为co.kr。
- **邮件认证与发信系统信号**：SPF已发布（Hiworks，结尾`~all`）；未见公开DMARC政策。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 97、跨档出现 ≤3 档的专属行 26、≤10 档的稀有行 29、外链来源域 1 个、全档去重邮箱 1 个；启发式审计分 52/100（主体 15/15、联系 5/20、KP 13/15、业务专属度 9/20、证据 8/20、可执行性 4/10、风险扣分 -2）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 无已确认可执行的公开商务首选邮箱（状态 `technical_email_only`）；KP 状态 `named_multiple_candidates`，结构化抽到：서정열、Shinbong Kang。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：认证口径已按 U31 改为“UL 无；CE/FCC 按型号核实”；商用 PoE 模板已按 U28 收紧为 802.3af/at PoE+。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：公开可执行商务邮箱未闭合；专属经营事实偏薄；用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认；风险旗需在报价前处理：KC缺口。
- **下一证据路径**：先以官网代表电话索取商务/采购邮箱；技术支持邮箱不作销售首选，旧 serverworld.co.kr 域不复用。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：A-030｜DS&G Co., Ltd.（韩国，SI/VAR）。本轮类型：定向外部复核/负结果 + 运营化合成；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 C、质量基线 52/100、专属行 29（专属证据密度中等）；联系状态 `technical_email_only`，主口 `无已确认公开商务首选邮箱`；KP 状态 `named_multiple_candidates`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：在手项目的交换机 BOM 与交付节点；存量网络扩容、维保与备件替换；现用品牌价格或交期压力；多站点标准化与批量复制项目。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 서정열、Shinbong Kang；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：先经表单/总机索取商务口与实名负责人。下一证据路径：先电话确认 DS&G 是否仍设网络产品部门及负责人，再决定是否谈接入交换配套；不向技术支持口发送泛销售目录。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424XGGPM-280W 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 在手项目型号、数量、最终用户行业与交付节点；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：涉及轨交/车载时，EN50155/E-mark 无证即为硬停项；普通园区项目须与轨交项目分开确认。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：KC缺口。未闭合：公开可执行商务邮箱未闭合；专属经营事实偏薄；用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认；风险旗需在报价前处理：KC缺口。
- **定向外部补挖**：2026-10-27 复核 DS&G 官网首页与站内索引：现行主轴已明显转向 Supermicro 总代理、NVIDIA Solution Provider，以及 AI/HPC、GPU、服务器和 WEKA 存储；页脚公开邮箱仍只有 `dsng_support@dsngsystem.co.kr`，关联 ServerWorld 页脚复现代表理事 Seo Jeong-yeol、代表电话 02-6309-1830。未发现销售/采购公开邮箱。来源：https://www.dsngsystem.co.kr/ 。
- **定向外部补挖**：商业含义是接入交换机更可能只是服务器/AI 基础设施项目的配套采购，不能再按纯网络分销商假设库存深度。下一步证据应先电话确认是否仍设网络产品部门及其负责人，再讨论具体型号；技术支持口不改作销售首选。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
