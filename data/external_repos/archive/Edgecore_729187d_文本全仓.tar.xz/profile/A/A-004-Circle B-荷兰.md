---
structured_profile:
  id: A-004
  company: Circle B（Taurus Group 旗下）
  country: 荷兰
  rating: A
  biz_model: 开放硬件/OCP 方案商（IaaS/BMaaS/托管）
  decision_speed: 评估制
  needs: [开放硬件货源, 白牌/OEM, 数据中心+园区接入, 供货稳定性]
  p1: 白牌接入层 L2+ 待核价
  stage: 未接触
  volume_potential: 中高（51-200 人，泛欧）
  risk_flags: [偏数据中心, 接入层占比未知]
  updated: 2026-10-27
---

# A-004 · Circle B · 荷兰

## 1. SALES BRIEF
- **是谁**：荷兰开放硬件方案商（Taurus 集团），OCP 生态，向欧洲中大型企业提供开放基础设施
- **为什么跟**：开放硬件=多货源白牌需求；体量适中（非巨头）符合我方画像
- **P1**：可贴牌 L2+ 接入层
- **第一问**：Beyond OCP datacenter gear, how much access-layer switching do your customers need from you?
- **最大未知**：接入层需求占比、品牌策略
- **下一步**：首触邮件 → 需求分层对话

## 2. 基本事实
| 内容 | 标签 |
|---|---|
| Beechavenue 113, 1119 RB Schiphol-Rijk / Anton Jurgenslaan 4, Hoofddorp；info@circleb.eu；+31 85 800 0430 | 事实（官网） |
| Taurus Group 旗下（GM Jason Masliana 公开播客） | 事实（公开播客） |
| 51-200 人（LinkedIn） | 事实（LinkedIn） |
| 主营开放硬件/IaaS/BMaaS/托管 | 事实（官网/pitchbook） |
| 接入层交换机是其补充品类 | 【推断】依据：主营 OCP/DC |

## 3. 技术与在用
- OCP 服务器/存储/网络；开放交换机生态；Edgecore 在其合作版图（where-to-buy 收录）

## 4. 需求与场景
- 【推断】客户项目需要整包（含接入层）→ 需稳定白牌伙伴
- 【推断】对开放/可定制敏感——依据：开放硬件基因

## 5. HR 与规模信号
- 51-200 人、集团背景 → 中型稳定

## 6. 联系方式
- **邮箱**：info@circleb.eu（官网）；**menno@circleb.eu**（纬颖 Wiwynn 官方 Where-to-Buy 公开的实名联系人邮箱——直达通道）
- **电话**：+31 85 800 0430
- **网站**：circleb.eu

## 7. 关键人（KP）
- **Menno（姓氏待核）** — Wiwynn 官方分销名录中的 Circle B 实名联系人，menno@circleb.eu 直达【事实：wiwynn.com/where-to-buy】
- **Andre van Vliet — Head of Technology**【事实：RocketReach 职员表】→ 技术议题对口人
- 邮箱命名格式 {名首字母}{姓}@circleb.eu 为第三方统计，**不得据此臆造** Andre 的邮箱

## 8. 跟进步骤（≤3）
1. **首触**：贴牌能力一页纸；问接入层需求占比；exit：14 天无回复→季度低频
2. **台阶**：样机+规格对齐；问项目形态；exit：无接入层需求→停
3. **台阶**：试单/联合方案；exit：书面拒绝→停

## 9. 调研要点与证据
- circleb.eu（contact）；LinkedIn；STORDIS 播客（Taurus Group 背景）；Edgecore EMEA 名录

## 10. 产品决策
- **P1**：可贴牌 24 口管理型 L2+——待核价
- 备选（不进首触）：PoE 款、10G 上联款

## 11. SWOT
- S：OEM/贴牌+价格；W：非其核心品类；O：整包项目带动；T：其更偏 DC 白盒大厂
## 12. 触达与风险红线
- **停止开发条件**：3 次无回复/明确无接入层需求
## 13. Qualification
- 技术合格待验证；商业合格待首触
## 14. Unknowns
- [ ] 接入层年需求？ [ ] 贴牌与否？ [ ] 决策人？
## 15. 首触邮件（英文）
**Subject: Private-label access switches for OCP-style projects**

> Hi Jason,
>
> I'm Simon with Saga Telecom. We manufacture managed and PoE switches with deep OEM/ODM support — hardware, Web GUI/CLI, labels and packaging.
>
> Circle B delivers open hardware to European enterprises; when a project needs a cost-effective, private-labeled access layer alongside your OCP stack, we can supply it with stable chips and short lead times.
>
> One question: beyond datacenter gear, how much access-layer switching do your customers need from you today?
>
> Happy to send our customization matrix and catalog.
>
> Best regards, Simon | Saga Telecom | https://sagatele.com


## R15 深度核验（2026-10-19）
- **成立年份两说并存**：官网 About 称 2012 年成立，LinkedIn 公司页写 2015 年——待首触核实，不影响触达
- **欧洲首家 OCP Solution Provider**（2018-06 OCP 基金会官宣）【事实：opencompute.org】
- **规模口径差大**：LinkedIn 51-200 人 vs RocketReach 约 16 人——按小团队估算决策链【推断】
- **在售含交换机**：Wiwynn 名录载明其销售 "Network Switch, ToR Switch" 及 OCP 整柜——交换机为其整柜配套品类【事实】

## 16. 跟进记录
| 日期 | 渠道 | 动作 | 客户反应 | 结论 | 下次动作日期 |
|---|---|---|---|---|---|
| 2026-10-18 | — | 建档 | — | 未联系 | 首触待排 |

## 17. 下次复核
首触后 14 天无回复 → 降频季度复核。

## R18 A类增量加厚（2026-10-19）

- **现行域名与邮件基础设施**：主域名 `circleb.eu` 于 2026-10-19 经公共 DNS（8.8.8.8）实查：A 记录 `35.214.128.192`；MX `0 circleb-eu.mail.protection.outlook.com`；邮件平台特征为 **Microsoft 365 / Exchange Online Protection**。判定：**A与MX均存在**。
- **官方渠道快照对账**：仓库留存的 Edgecore 官方渠道快照（2026-10-18，分区 `emea-reseller`）载：地址 **Zekeringstraat 17, 1014 BM, Amsterdam**；电话 +31-85-800 0430；渠道定位 SI·VAR·经销商。此项用于补齐主体地址并与档内电话对账；若与本档 R15 后段更新的登记/官网字段冲突，以后段为准。
- **R18 定点增量**：PeeringDB 派生 ASN 数据（GitHub `tiagozip/asn-data`，源记录更新至 2024-06-26）载 Circle B 为 AS43861、类型 NSP、流量 50–100Gbps、3 个设施；备注其基于 OCP 硬件提供裸金属计算/存储，受保护 100G 与 DWDM 波长连接 maincubes AMS01—NIKHEF，并在 AMS01 与 Digital Realty Interxion AMS3 提供 IP Transit。其网络运营/基础设施属性强于普通转售，接入交换采购需求仍须首触确认。
- **口径边界**：DNS 阳性仅证明域名与收信基础设施在查询时存在，不证明任一具体邮箱可投递、人员仍在职或有采购意愿；KP/邮箱仍以本档 R15 定版为准。结构化底稿见 `batch/contact_research-2026-10-19_R18_A类增量加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`circleb.eu`为A与MX均存在；网站IPv4 `35.214.128.192`（未取得ASN映射），未见AAAA；邮件入口 `circleb-eu.mail.protection.outlook.com`（平台特征：Microsoft 365）；NS托管特征为transip.net。
- **邮件认证与发信系统信号**：SPF已发布（Microsoft 365、Brevo、HubSpot，结尾`-all`）；DMARC `p=quarantine`。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **GitHub公开技术足迹**：[Circle-B](https://github.com/Circle-B)（Organization，官网域互指/官方资料绑定），主页公开邮箱`info@circleb.eu`；无公开仓库，当前主要作为主体绑定证据。技术活动不自动升格采购KP。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 55、跨档出现 ≤3 档的专属行 48、≤10 档的稀有行 52、外链来源域 2 个、全档去重邮箱 2 个；启发式审计分 77/100（主体 12/15、联系 20/20、KP 15/15、业务专属度 12/20、证据 11/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `menno@circleb.eu`（状态 `public_primary_email_recorded`）；KP 状态 `named_multiple_candidates`，结构化抽到：Menno、Andre van Vliet。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：首触自我介绍中的 Shenzhen 已删除。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：A-004｜A-004 · Circle B · 荷兰（荷兰，渠道/项目伙伴）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 77/100、专属行 49（专属证据密度中高）；联系状态 `public_primary_email_recorded`，主口 `menno@circleb.eu`；KP 状态 `named_multiple_candidates`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行项目 BOM；现用品牌缺货或 EOL 替换；多站点复制交付；成本档与本地库存压力。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Menno、Andre van Vliet；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 白牌接入层 L2+ 待核价 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号与月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：欧英市场按具体型号核 CE/UKCA 与进口商义务；UL 无证口径不替代当地符合性确认。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
