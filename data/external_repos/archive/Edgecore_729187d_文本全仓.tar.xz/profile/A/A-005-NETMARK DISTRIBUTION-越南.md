---
structured_profile:
  id: A-005
  company: NETMARK DISTRIBUTION
  country: 越南
  rating: A
  biz_model: 安防/网络产品分销（胡志明市）
  decision_speed: 快（贸易习惯）
  needs: [CCTV交换机, PoE现货, 价格, 交期, 贴牌]
  p1: 24口 CCTV/PoE 交换机 待核价
  stage: 未接触
  volume_potential: 中高（越南安防市场）
  risk_flags: [价格战激烈, 付款条件待谈]
  updated: 2026-10-27
---

# A-005 · NETMARK DISTRIBUTION · 越南

## 1. SALES BRIEF
- **是谁**：胡志明市分销商（Edgecore 名录收录），安防/园区渠道
- **为什么跟**：越南市场 CCTV/PoE 需求大，中国供应链近，进口熟手——首攻区域
- **P1**：24 口 CCTV/PoE 交换机
- **第一问**：Which PoE port-count sells fastest in your CCTV projects — 8, 16 or 24?
- **最大未知**：月走量、现用品牌、账期习惯
- **下一步**：首触邮件

## 2. 基本事实
| 内容 | 标签 |
|---|---|
| 37 Sixth Street, Cityland Park Hills, Go Vap District, HCMC；(84) 906 814 510 | 事实（Edgecore 名录） |
| 与 Edgecore 有分销关系 | 事实（名录） |
| 主营安防/网络分销 | 【推断】依据：市场+收录类别 |
| 习惯中国供应链 | 【推断】依据：越南分销行业惯例 |

## 3. 技术与在用
- 在售：Edgecore 接入层（名录）；其他品牌无公开

## 4. 需求与场景
- 【推断】CCTV 项目 PoE 为主——依据：越南安防市场结构

## 5. HR 与规模信号
- 无公开

## 6. 联系方式
- **电话**：(84) 906 814 510（已有）；**邮箱/网站**：**info@netmark.com.vn**（官网/Facebook/Peplink 伙伴页三方一致）；电话 +84 28 6275 1377，热线 +84 909 878 577；网站 netmark.com.vn / netmark.vn

## 7. 关键人（KP）
- **Han Ho — CEO**【事实：ZoomInfo 实名职员页】→ 首封可点名（Dear Mr. Ho / Han Ho 注意越南姓名顺序，首触用全名更稳）
- 其直达邮箱未公开（ZoomInfo 打码），**禁止按格式臆造**；走 info@ 点名转交

## 8. 跟进步骤（≤3）
1. **首触**：CCTV PoE 价目一角；问热销端口规格；exit：14 天无回复→月度低频
2. **台阶**：样品+对比报价；问月量/账期；exit：只比价→停
3. **台阶**：贴牌试探；exit：无回应→归档

## 9. 调研要点与证据
- Edgecore 亚太分销名录：https://www.edge-core.com/where-to-buy/asia-distributors/

## 10. 产品决策
- **P1**：24 口 PoE+ CCTV 交换机（Marvell 线）——待核价
- 备选（不进首触）：8/16 口小机、工业款

## 11. SWOT
- S：价格/交期/贴牌；W：品牌弱；O：越南安防增长；T：大陆同行价格战
## 12. 触达与风险红线
- **停止开发条件**：3 次无回复/只比价
## 13. Qualification
- 技术合格待验证；商业合格待首触（量、账期）
## 14. Unknowns
- [ ] 月量？ [ ] 现用品牌？ [ ] 账期？ [ ] 决策人？
## 15. 首触邮件（英文）
**Subject: CCTV PoE switches for Vietnam projects — stock ready, OEM available**

> Hi,
>
> I'm Simon with Saga Telecom. We manufacture managed PoE switches for CCTV and campus — 8/16/24/48 ports, ERPS, IGMP snooping — with chips in stock and fast delivery, plus OEM labeling.
>
> For NETMARK's CCTV and networking distribution, our models can win both price and lead-time.
>
> One question: which PoE port-count sells fastest in your projects — 8, 16 or 24?
>
> I'll send our catalog and a sample quotation.
>
> Best regards, Simon | Saga Telecom | https://sagatele.com


## R15 深度核验（2026-10-19）
- **法人定版**：CÔNG TY CỔ PHẦN PHÂN PHỐI NETMARK（Netmark 分销股份公司），营业执照 0313375374（2015-07-30 胡志明市计投厅签发），址：胡志明市 Gò Vấp 区 Cityland Park Hills 6 号路 37 号【事实：官网页脚工商信息】
- **定位=进口+分销**（官网自述 nhập khẩu và phân phối），规模 50-99 人【事实：nhansu.vn 企业页】
- **品牌线**：Peplink、**Edgecore**、IgniteNet、Open Mesh、UniFi、Mimosa（官网自述）；另为 **EnGenius 越南官方分销**【事实：hca.org.vn 协会新闻】——交换机货架已有 Edgecore/EnGenius，我方打"价格层补位+可贴牌"
- ⚠️**同名陷阱（重大）**：NETMARKS Vietnam（netmarks.com.vn，日系 SI，河内 Thang Long 工业园 + 胡志明分公司，info@netmarks.com.vn）是**完全不同的另一家公司**；本档认准 netmark.com.vn / netmark.vn

## 16. 跟进记录
| 日期 | 渠道 | 动作 | 客户反应 | 结论 | 下次动作日期 |
|---|---|---|---|---|---|
| 2026-10-18 | — | 建档 | — | 未联系 | 首触待排 |

## 17. 下次复核
首触后 14 天无回复 → 月度低频复核。

## R18 A类增量加厚（2026-10-19）

- **现行域名与邮件基础设施**：主域名 `netmark.com.vn` 于 2026-10-19 经公共 DNS（8.8.8.8）实查：A 记录 `210.211.119.245`；MX `10 mail92100.maychuemail.com`；邮件平台特征为 **自建/本地托管或其他邮件服务**。判定：**A与MX均存在**。
- **官方渠道快照对账**：仓库留存的 Edgecore 官方渠道快照（2026-10-18，分区 `asia-distributors`）载：地址 **37 Sixth Street, Cityland Park Hills, Go Vap District, Ho Chi Minh City**；电话 (84) 906 814 510；渠道定位 分销商。此项用于补齐主体地址并与档内电话对账；若与本档 R15 后段更新的登记/官网字段冲突，以后段为准。
- **口径边界**：DNS 阳性仅证明域名与收信基础设施在查询时存在，不证明任一具体邮箱可投递、人员仍在职或有采购意愿；KP/邮箱仍以本档 R15 定版为准。结构化底稿见 `batch/contact_research-2026-10-19_R18_A类增量加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`netmark.com.vn`为A与MX均存在；网站IPv4 `210.211.119.245`（AS38731 VTDC-AS-VN - Vietel - CHT Compamy Ltd, VN），未见AAAA；邮件入口 `mail92100.maychuemail.com`（平台特征：其他托管/本地邮件服务）；NS托管特征为dotvndns.com。
- **邮件认证与发信系统信号**：SPF已发布（授权include `spf.maychuemail.com`，结尾`-all`）；DMARC `p=quarantine`。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **关联/候选域状态**：`netmarks.com.vn`=A+MX（其他托管/本地邮件服务）；`netmark.vn`=A+MX（其他托管/本地邮件服务）。关联域均按档内上下文人工保留，未经主体归属再核者不据此新增联系方式。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 52、跨档出现 ≤3 档的专属行 46、≤10 档的稀有行 49、外链来源域 2 个、全档去重邮箱 2 个；启发式审计分 73/100（主体 15/15、联系 18/20、KP 10/15、业务专属度 12/20、证据 11/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `info@netmark.com.vn`（状态 `public_primary_email_recorded`）；KP 状态 `named_single_candidate`，结构化抽到：Han Ho。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：首触自我介绍中的 Shenzhen 已删除。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：A-005｜A-005 · NETMARK DISTRIBUTION · 越南（越南，渠道/项目伙伴）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 73/100、专属行 47（专属证据密度中高）；联系状态 `public_primary_email_recorded`，主口 `info@netmark.com.vn`；KP 状态 `named_single_candidate`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行项目 BOM；现用品牌缺货或 EOL 替换；多站点复制交付；成本档与本地库存压力。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Han Ho；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 24口 CCTV/PoE 交换机 待核价 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号与月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：本地进口主体、型式批准、关税与外汇路径仍须由对方逐项确认，未核前不承诺落地价。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
