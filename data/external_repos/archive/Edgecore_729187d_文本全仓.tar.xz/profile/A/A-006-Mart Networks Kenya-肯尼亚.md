---
structured_profile:
  id: A-006
  company: Mart Networks（Kenya/Tanzania/Uganda/Rwanda 四国体系）
  country: 肯尼亚（东非）
  rating: A
  biz_model: 区域网络产品分销/SI（东非多国）
  decision_speed: 中
  needs: [性价比L2+/PoE, 长期供货, 项目配套, 贴牌]
  p1: 24口 PoE+ 项目机 待核价
  stage: 未接触
  volume_potential: 中高（四国网络）
  risk_flags: [物流/结算风险, 项目回款周期]
  updated: 2026-10-27
---

# A-006 · Mart Networks Kenya · 肯尼亚（东非）

## 1. SALES BRIEF
- **是谁**：东非分销/SI 网络（肯尼亚、坦桑尼亚、乌干达、卢旺达四国同名体系，Edgecore 名录四国收录）
- **为什么跟**：新兴市场性价比+长期供货正是我方打法；多国网络=复制空间
- **P1**：24 口 PoE+ 项目机
- **第一问**：Do you buy access switches per-country or for the whole East Africa network?
- **最大未知**：采购集中度、量、结算
- **下一步**：首触邮件（肯尼亚总部）

## 2. 基本事实
| 内容 | 标签 |
|---|---|
| KE: 2nd Floor Museum Hill Centre, Nairobi, +254 20 5135200 | 事实（名录） |
| TZ: Chole Road, Dar es Salaam, +255 784 444490 | 事实（名录） |
| UG: Regus Course View Towers, Kampala, +256 703 834115 | 事实（名录） |
| RW: Kigali City Tower, +250 788180100 | 事实（名录） |
| 四国同体系统一采购 | 【推断】依据：同名同结构 |
| 价格敏感、对交期敏感 | 【推断】依据：新兴市场分销特征 |

## 3. 技术与在用
- 在售：Edgecore 产品（名录）；其余无公开

## 4. 需求与场景
- 【推断】政企/园区/ISP 项目 PoE+L2+——依据：东非 ICT 项目建设期

## 5. HR 与规模信号
- 四国布点 → 区域中型商【推断】

## 6. 联系方式
- **电话**：+254 20 5135200（KE 总部）；各国有独立电话（见上）
- **邮箱/网站**：**sales.kenya@mart-networks.com**（肯尼亚公司官方 FB + Giganet 名录）；集团 sales@mart-networks.com；网站 mart-networks.com

## 7. 关键人（KP）
- **Aunally Maloo（法定全名 Aunally Gulamhusein Maloo）— CEO / 董事**【事实：ContactOut 职员表 + 英国 Companies House（MART NETWORK SOLUTIONS LIMITED 在任董事，肯尼亚籍，驻内罗毕）】→ 集团实控层，首封可点名
- Tasneem Maloo — Director of Finance（财务董事，ContactOut）；Hamid Chaudhry — Technosales-Head WECA Region（西/东/中非技术销售负责人）
- 邮箱格式 {名首字母}{姓}@mart-networks.com 仅为第三方统计（75% 采用率），**不得据此臆造直达邮箱**

## 8. 跟进步骤（≤3）
1. **首触**：项目机报价+交期承诺；问采购集中度；exit：14 天无回复→季度低频
2. **台阶**：分国样机试单；问量与结算；exit：只比价→停
3. **台阶**：贴牌/区域独家探讨；exit：书面拒绝→停

## 9. 调研要点与证据
- Edgecore EMEA 名录（四国条目）：https://www.edge-core.com/where-to-buy/emea-reseller/

## 10. 产品决策
- **P1**：24 口 PoE+ 管理型（Marvell 线）——待核价
- 备选（不进首触）：8/16 口小机、光纤上联款

## 11. SWOT
- S：价格+交期+贴牌；W：距离远、品牌弱；O：东非数字化项目潮；T：回款/汇兑风险
## 12. 触达与风险红线
- 首单款到发货或小额度；**停止开发条件**：3 次无回复/书面拒绝
## 13. Qualification
- 技术合格待验证；商业合格待首触（结算能力）
## 14. Unknowns
- [ ] 集团采购是否集中？ [ ] 年量？ [ ] 结算币种？ [ ] 决策人？
## 15. 首触邮件（英文）
**Subject: Project-grade PoE switches for East Africa — fast delivery, OEM ready**

> Hi,
>
> I'm Simon with Saga Telecom. We manufacture managed PoE and L2+ switches (8–48 ports, ERPS, IGMP) for CCTV, campus and ISP projects — chips in stock, fast delivery, OEM labeling available.
>
> I noticed Mart Networks operates across Kenya, Tanzania, Uganda and Rwanda. We supply similar regional distributors with project-grade hardware at competitive prices.
>
> One question: do you buy access switches per-country or for the whole East Africa network?
>
> Glad to send our catalog and a sample quotation.
>
> Best regards, Simon | Saga Telecom | https://sagatele.com


## R15 深度核验（2026-10-19）
- **集团版图**：1996 年成立的泛非 VAD，在肯尼亚/坦桑尼亚/乌干达/卢旺达/尼日利亚/阿联酋/科威特/英国设点并配在地分销仓【事实：官网/ContactOut 公司简介】——一家通多国，渠道价值高于单国分销
- **规模**：LinkedIn 11-50 人 / ContactOut 约 50 人；总部 Museum Hill Centre, 87 Muthithi Road, Westlands, Nairobi【事实】
- ★其坦桑尼亚邮箱 sales.tanzania@mart-networks.com 已见于 R14 未建档线索——与本档同集团，触达时避免多头发信打架，先打肯尼亚总部
- 英国主体 MART NETWORK SOLUTIONS LIMITED 存在 ⇒ 欧洲原厂采购可能经英国主体走账【推断，首触可探】

## 16. 跟进记录
| 日期 | 渠道 | 动作 | 客户反应 | 结论 | 下次动作日期 |
|---|---|---|---|---|---|
| 2026-10-18 | — | 建档 | — | 未联系 | 首触待排 |

## 17. 下次复核
首触后 14 天无回复 → 降频季度复核。

## R18 A类增量加厚（2026-10-19）

- **现行域名与邮件基础设施**：主域名 `mart-networks.com` 于 2026-10-19 经公共 DNS（8.8.8.8）实查：A 记录 `52.87.87.36`；MX `0 martnetworks-com01b.mail.protection.outlook.com`；邮件平台特征为 **Microsoft 365 / Exchange Online Protection**。判定：**A与MX均存在**。
- **官方渠道快照对账**：仓库留存的 Edgecore 官方渠道快照（2026-10-18，分区 `emea-reseller`）载：地址 **2nd Floor Museum Hill Centre, Nairobi**；电话 +254-20-5135200；渠道定位 SI·VAR·经销商。此项用于补齐主体地址并与档内电话对账；若与本档 R15 后段更新的登记/官网字段冲突，以后段为准。
- **口径边界**：DNS 阳性仅证明域名与收信基础设施在查询时存在，不证明任一具体邮箱可投递、人员仍在职或有采购意愿；KP/邮箱仍以本档 R15 定版为准。结构化底稿见 `batch/contact_research-2026-10-19_R18_A类增量加厚.json`。首触仍由用户执行，Agent 不发信。

## R19 用户反馈处理与邮箱复挖（2026-10-19）

- **集团覆盖图（防重复触达）**：本档为 Mart Networks 肯尼亚总部/四国体系主档。关联分支档为 B-011 卢旺达、B-013 乌干达；坦桑尼亚线同时有 B-012（Edgecore 名录名 Mart Networks Tanzania）与 B-078（本地运营名 Network Distribution Tanzania Limited），后两档指向同一运营臂，以 B-078 记跟进。
- **触达顺序**：先打本档总部并问清接入交换是集团集中采购还是分国采购；在得到答案前，不向各分支并行重复首触。用户指出的“B-011 似乎已在 A 出现”按此集团覆盖关系处理，不删除分支档的地方证据。

## R21 用户首触反馈处理（2026-10-21）

- **集团个人邮箱试发同步**：针对坦桑运营臂职员 Aisha Adams 的未核验个人试发地址 `Aisha.Adams@mart-networks.com` 已被集团 Microsoft 365 域政策拒收，完整跟进记在 B-078 主档。本档既有“第三方邮箱格式统计不得臆造直达邮箱”的纪律不变，且自此禁止继续枚举 Mart 员工个人地址；集团触达只走已公开的肯尼亚/集团职能口或电话索址。本记录只作集团纪律同步，不表示肯尼亚总部已被单独首触。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`mart-networks.com`为A与MX均存在；网站IPv4 `52.87.87.36`（AS16509 AMAZON-02 - Amazon.com, Inc., US），未见AAAA；邮件入口 `martnetworks-com01b.mail.protection.outlook.com`（平台特征：Microsoft 365）；NS托管特征为microsoftonline.com。
- **邮件认证与发信系统信号**：SPF已发布（Microsoft 365、Zoho Campaigns，结尾`-all`）；DMARC `p=reject`。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **公开服务面（DNS）**：检出`support.mart-networks.com`（ManageEngine）。子域存在只证明DNS/服务配置，不单独证明页面当前可用或交易活跃。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 56、跨档出现 ≤3 档的专属行 49、≤10 档的稀有行 53、外链来源域 2 个、全档去重邮箱 4 个；启发式审计分 77/100（主体 12/15、联系 20/20、KP 15/15、业务专属度 12/20、证据 11/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `sales.kenya@mart-networks.com`（状态 `public_primary_email_recorded`）；KP 状态 `named_multiple_candidates`，结构化抽到：Aunally Maloo、Tasneem Maloo。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：首触自我介绍中的 Shenzhen 已删除。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：A-006｜A-006 · Mart Networks Kenya · 肯尼亚（东非）（肯尼亚（东非），渠道/项目伙伴）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 A、质量基线 80/100、专属行 50（专属证据密度强）；联系状态 `public_primary_email_recorded`，主口 `sales.kenya@mart-networks.com`；KP 状态 `named_multiple_candidates`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行项目 BOM；现用品牌缺货或 EOL 替换；多站点复制交付；成本档与本地库存压力。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Aunally Maloo、Tasneem Maloo；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 24口 PoE+ 项目机 待核价 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号与月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：本地进口主体、型式批准、关税与外汇路径仍须由对方逐项确认，未核前不承诺落地价。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
