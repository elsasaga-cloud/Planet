---
structured_profile:
  id: A-002
  company: Deca Consulting
  country: 比利时
  rating: A
  biz_model: 技术型 SI/网络咨询（架构-实施-自动化-支持）
  decision_speed: 项目制，慢而稳
  needs: [多品牌货源, OEM/白牌接入层, 深度定制UI/CLI, 项目级供货]
  p1: 深度定制 L2+ 管理型（对齐其 Edgecore 项目）待核价
  stage: 未接触
  volume_potential: 中（项目制，单值高）
  risk_flags: [技术门槛高, 对品质敏感]
  updated: 2026-10-27
---

# A-002 · Deca Consulting · 比利时

## 1. SALES BRIEF
- **是谁**：比利时厂商中立网络咨询公司（Cisco/Edgecore/Palo Alto/Fortinet/SONiC/Proxmox/NetBox），工程师直接对接设计到支持
- **为什么跟**：IPNexia 数据中心案例（Edgecore+SONiC）主导方；技术型客户是我们的主场（CLI/MIB/深度定制）
- **P1**：深度定制管理型 L2+（UI/CLI/MIB 可改）
- **第一问**：When you spec access-layer switches for customer projects, how much customization of the management plane do your clients ask for?
- **最大未知**：接入层采购量、是否自持库存、对二线品牌接受度
- **下一步**：首触邮件 → 技术对话

## 2. 基本事实
| 内容 | 标签 |
|---|---|
| 地址 Haldertstraat 116, 3390 Houwaart；电话 +32 16 89 87 71 | 事实（Edgecore 名录） |
| 官网 deca-consulting.be，自称 vendor-neutral，覆盖 Cisco/Edgecore/SONiC 等 | 事实（官网） |
| 参与 IPNexia SONiC 数据中心改造（2026-01 新闻稿） | 事实（Edgecore/新wire） |
| 其客户 IPNexia 服务 3000+ 比利时企业 | 事实（新闻稿） |
| 以项目制供货为主，可能无大库存 | 【推断】依据：SI 定位 |

## 3. 技术与在用
- 在用：Edgecore 开放交换机+Enterprise SONiC、Cisco、NetBox+Ansible 自动化
- 接入层习惯：无公开；数据中心用 AS7726-32X/AS7326-56X

## 4. 需求与场景
- 【推断】园区/接入层项目需要可控货源+可定制管理面——依据：厂商中立立场
- 【推断】对 CLI/MIB/自动化接口有要求——依据：NetBox/Ansible 工作流

## 5. HR 与规模信号
- 官网强调"experienced engineers direct access"→ 精英小团队【推断】（LinkedIn 员工数待查）

## 6. 联系方式
- **电话**：+32 16 89 87 71（已有）
- **邮箱**：**info@deca-consulting.be**（用户 2026-10-19 提供，官网首页 CONTACT 段同载，双证）
- **网站**：deca-consulting.be

## 7. 关键人（KP）与触达通道
- **Alexander Deca — Chief Network Engineer**（Edgecore IPNexia 案例页 2026-01-15 署名职务）→ 首封可点名
- LinkedIn：linkedin.com/in/alexanderdeca（500+ 连接，布鲁塞尔；其经历栏另挂 NTT，职务以 Edgecore 案例为准，称呼用 Mr. Deca 或 Alexander）
- GitHub：@alexanderdeca（组织 @deca-consulting）——技术人设实锤，首触走技术对话而非销售话术

## 8. 跟进步骤（≤3）
1. **首触**：定制能力一页纸（UI/CLI/MIB/固件）；问定制需求频率；exit：14 天无回复→季度低频
2. **台阶**：寄样/远程 demo（CLI 对比）；问单项目接入层台数；exit：无定制需求→停
3. **台阶**：试订单/项目报备支持；exit：书面拒绝→停

## 9. 调研要点与证据
- deca-consulting.be（服务栈）；Edgecore 新闻稿 2026-01-15 IPNexia；STORDIS 案例页亦提及三方合作

## 10. 产品决策
- **P1**：深度定制 24 口管理型 L2+（Marvell 线）——待核价
- 备选（不进首触）：PoE+ 项目款、10G 汇聚（CENTEC 线）

## 11. SWOT
- S：深度定制=核心卖点，正对其厂商中立模式；W：无 SONiC/数据中心产品；O：其客户群为欧洲政企；T：Edgecore 原厂关系稳固

## 12. 触达与风险红线
- 技术对话为主，少谈价格；不做云管；**停止开发条件**：3 次无回复/书面拒绝
## 13. Qualification
- 技术合格待验证（要求 CLI/MIB 级）；商业合格待首触（量、模式）
## 14. Unknowns
- [ ] 接入层年需求？ [ ] 是否自持库存？ [ ] 定制清单优先级？ [ ] 决策人？
## 15. 首触邮件（英文）
**Subject: Access switches with a customizable management plane — for your client projects**

> Hi Alexander,
>
> I'm Simon with Saga Telecom. We build managed switches (Marvell-based L2+, PoE, industrial) with deep OEM/ODM customization — Web GUI, CLI, MIB, default config, firmware branding.
>
> I saw how Deca and Edgecore modernized IPNexia's backbone — a sharp, automation-first project. For access-layer parts of client projects where you need a customizable management plane and stable supply, we can help.
>
> One question: how often do your client projects ask for management-plane customization (UI/CLI/MIB) on access switches?
>
> If useful, I can share our customization matrix and feature list.
>
> Best regards, Simon | Saga Telecom | https://sagatele.com


## R15 深度核验（2026-10-19）
- **法人定版**：Deca Consulting SRL，企业号 BE0687.819.476，**2018-01-11 成立**，注册地 Haldertstraat 116, 3390 Tielt-Winge (Houwaart)【事实：companyweb.be / pappers.be 工商】
- **双点运营**：官网称比利时 + 西班牙两地运营，服务语言 EN/FR/NL/DE/ES【事实：官网】
- **IPNexia 项目已收官**：其 LinkedIn 2026 年帖称 Cisco VXLAN→Edgecore+SONiC 迁移"已全部完成，leaf/spine 全量切换、业务零中断"，并公开邀约咨询（留 info@ 邮箱）——正处案例外溢获客期，接入层配套话题窗口好【事实：LinkedIn 原帖】
- ⚠️**同名陷阱**：美国 DECA Consulting, Inc.（deca-inc.net，儿童用品工程咨询，俄亥俄）与本档无关，勿混

## 16. 跟进记录
| 日期 | 渠道 | 动作 | 客户反应 | 结论 | 下次动作日期 |
|---|---|---|---|---|---|
| 2026-10-18 | — | 建档 | — | 未联系 | 首触待排 |

## 17. 下次复核
首触后 14 天无回复 → 降频季度复核。

## R18 A类增量加厚（2026-10-19）

- **现行域名与邮件基础设施**：主域名 `deca-consulting.be` 于 2026-10-19 经公共 DNS（8.8.8.8）实查：A 记录 `185.230.63.171, 185.230.63.186, 185.230.63.107`；MX `10 aspmx2.googlemail.com, 1 aspmx.l.google.com, 5 alt1.aspmx.l.google.com, 10 aspmx3.googlemail.com, 5 alt2.aspmx.l.google.com`；邮件平台特征为 **Google Workspace**。判定：**A与MX均存在**。
- **官方渠道快照对账**：仓库留存的 Edgecore 官方渠道快照（2026-10-18，分区 `emea-reseller`）载：地址 **Haldertstraat 116, 3390 Houwaart**；电话 +32-16-89 87 71；渠道定位 SI·VAR·经销商。此项用于补齐主体地址并与档内电话对账；若与本档 R15 后段更新的登记/官网字段冲突，以后段为准。
- **口径边界**：DNS 阳性仅证明域名与收信基础设施在查询时存在，不证明任一具体邮箱可投递、人员仍在职或有采购意愿；KP/邮箱仍以本档 R15 定版为准。结构化底稿见 `batch/contact_research-2026-10-19_R18_A类增量加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`deca-consulting.be`为A与MX均存在；网站IPv4 `185.230.63.171`、`185.230.63.186`等3条（AS58182 wix_com - Wix.com Ltd., IL），未见AAAA；邮件入口 `alt2.aspmx.l.google.com`、`aspmx.l.google.com`等5条（平台特征：Google Workspace）；NS托管特征为wixdns.net。
- **邮件认证与发信系统信号**：SPF已发布（Google Workspace，结尾`~all`）；未见公开DMARC政策。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 58、跨档出现 ≤3 档的专属行 50、≤10 档的稀有行 55、外链来源域 1 个、全档去重邮箱 1 个；启发式审计分 73/100（主体 15/15、联系 18/20、KP 10/15、业务专属度 15/20、证据 8/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `info@deca-consulting.be`（状态 `public_primary_email_recorded`）；KP 状态 `named_single_candidate`，结构化抽到：Alexander Deca。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：首触自我介绍中的 Shenzhen 已删除。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：A-002｜A-002 · Deca Consulting · 比利时（比利时，渠道/项目伙伴）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 73/100、专属行 51（专属证据密度强）；联系状态 `public_primary_email_recorded`，主口 `info@deca-consulting.be`；KP 状态 `named_single_candidate`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行项目 BOM；现用品牌缺货或 EOL 替换；多站点复制交付；成本档与本地库存压力。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Alexander Deca；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 深度定制 L2+ 管理型（对齐其 Edgecore 项目）待核价 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号与月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：欧英市场按具体型号核 CE/UKCA 与进口商义务；UL 无证口径不替代当地符合性确认。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
