---
structured_profile:
  code: A-055
  rating: A
  country: 美国
  role: SI/VAR
  segment: generic
  p1: STC-424XGGPM-280W
  stage: 00-lead
  struct_version: v2-lite
  updated: 2026-10-27
---

# Hardware Nation

> **评级 A** | 美国 · Buford GA | 档案编号 `A-055` | 角色：SI/VAR/集成商 | 状态：00-未触达
> 证据：Edgecore 官方渠道名录（NA-R）+ 2026-10-18 检索 | 来源：https://www.edge-core.com/where-to-buy/NorthAmerica-reseller/

## SALES BRIEF（压缩模型）

- **是谁**：美国·Buford GA 的SI/VAR/集成商；Edgecore 官方渠道名录收录（事实）
- **为什么跟**：在售/集成 Edgecore，说明白牌/开放网络硬件已被接受；用 Saga（STC/STI）同规格更低价+OEM/ODM 做第二货源【推断】
- **P1（首触唯一主推）**：STC-424XGGPM-280W — 24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）
- **第一问（只问一个）**：Which Edgecore models do you move most, and what price tier wins your deals?
- **最大未知**：在售具体型号与月采购量未确认；联系人状态以本档后段 R15/R18 定版为准（见触达名单与 R18 段）
- **下一步**：按本档 R15/R18 定版联系人由用户首触（Agent 不发信）

## 客户概览

Hardware Nation（美国·Buford GA）为 SI/VAR/集成商，列于 Edgecore 官方渠道名录（NA-R）。备注：官方SI+网店。定位：接入层第二货源/OEM 目标（A 级主攻）。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Hardware Nation | 事实（官方名录） |
| 国家/城市 | 美国 / Buford GA | 事实（官方名录） |
| 电话 | 770-924-5847 | 事实（官方名录） |
| 渠道角色 | SI/VAR/集成商（NA-R） | 事实（官方名录口径） |
| 备注 | 官方SI+网店 | 事实（本轮记录） |
| 商业模式 | SI/VAR/集成商，转售/集成 Edgecore 并可能代理多品牌 | 【推断】 |
| 决策链 | 见后段「触达名单」及 R15/R18 定版；本行旧模板口径已失效 | 事实/线索分层 |

> 来源 URL：https://www.edge-core.com/where-to-buy/NorthAmerica-reseller/（2026-10-18 检索）。官方名录只证明「当日页面列出该伙伴」，不证明当前采购意愿/在职人员/邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：他月走量在哪个档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：他现售 Edgecore 哪些料号、PoE 预算/上联速度需求、有没有改标需求。
- 【研发工程师】看：ERPS/PoE+（802.3af/at）/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- 已接受白牌/开放网络硬件【推断自其在 Edgecore 渠道名录】
- Saga 同规格成本档可做第二货源 + OEM 贴牌 + 交期优势
- 风险：认证约束（UL 无；CE/FCC 须在欧美触达前按具体型号核实；轨交/EN50155 非全线）在部分项目型需求处需留证

## 联系方式

- **电话**：770-924-5847（官方名录）
- **邮箱**：**alex@hardwarenation.com**（Crunchbase 企业联系邮箱 + 第三方评论站公开 = 创始人直达）；官网总机 800-398-1262
- **网站**：hardwarenation.com（R2 官网核验 2026-10-18）

## 产品决策（Saga · 单一决策口径）

- **P1**：STC-424XGGPM-280W — 24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）
- 备选不进首触：工业场景→STI 系列；纯千兆成本敏感→STC-424DGGM（¥552 档）
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |

## 触达名单

### KP 实名（R15 深度挖掘·批5 2026-10-19）

- **Alex Cronin** — Co-founder & Infrastructure Architect【Crunchbase / TheOrg；Indeed 公司页记为 CEO】，兼 Big Optics 创始人；直达邮箱已公开（见联系方式段）

- 邮箱：alex@hardwarenation.com（R15 批5 核验 2026-10-19，完整来源见联系方式段）
- LinkedIn/电话：770-924-5847（官方名录）

## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs Edgecore 同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 首触邮件要点（模板素材，用户自行发送）

> Subject: Second-source switching for your Edgecore line
> 观察（在 Edgecore 渠道名录看到你们）→ 相关性（同规格白牌+OEM 贴牌+交期）→ 一个问题（哪个型号走量？）
> 红线：不提「Made in China」；不提「研究过你官网」；一次只问一个问题


### 完整首触邮件（英文 · 用户自行发送 · Agent 不发信）

> Subject: Your Edgecore access switches — a same-spec second source
>
> Dear Purchasing / Procurement Team,
>
> I noticed Hardware Nation carries the Edgecore access line. With the ECS2100 family entering end-of-life (last order date 2026-04-01), many partners are moving to a same-spec second source to keep projects and spares covered.
>
> We manufacture managed access switches — 24×GbE/PoE+ with 4×10G uplinks, 280W/440W PoE budgets, ERPS / IGMP snooping / 802.3af/at PoE+ — and we support OEM branding (logo, packaging, docs) from 10 units.
>
> One question: which access model moves the most volume for you right now?
>
> Best regards, Simon · Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥ | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| STC-424XGGPM-280W | 见 P1 价格快照对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE+（802.3af/at）/IGMP；OEM/ODM；交期快
- **W**：品牌认知度低；认证约束（UL 无；CE/FCC 须按具体型号核实；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：ECS2100 EOL 替换窗口（2026-04-01 前后）；客户双货源策略
- **T**：Edgecore 官方替代（ECS4150 系列）价格竞争；大客户锁价长约

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。

## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求

## 未知项清单

- 邮箱/KP：R2 已核验——KP：Alex Cronin(Alex Rabinovich)(创始合伙人)；邮箱：alex@hardwarenation.com；客服
- 在售型号清单：待首触确认
- 认证敏感度（UL/轨交/E-mark/KC）：未知，涉及轨交/车载需求先声明缺口

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- https://www.edge-core.com/where-to-buy/NorthAmerica-reseller/（2026-10-18 检索，官方渠道名录）；批次：batch/contact_research_2026-10-18_R1_官方渠道全量.json


## R15 深度核验·批5（2026-10-19）

- **硬事实**：Hardware Nation, LLC，**2006 年**成立，佐治亚州 Duluth，约 20-26 人、营收约 $4-6M【第三方库两源】；开放网络/白盒集成商（SONiC 生态、Aviz Networks 伙伴），官方材料列 Edge-Core 为其部署厂商之一。
- **成色**：白牌理念与我方供给最对口的美国标的之一，唯重心在数据中心/服务商而非接入层——首触一问先探其企业接入项目占比。

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。

## 【R2 官网核验 2026-10-18】

- **核验批次**：contact_research-2026-10-18_R2_A级官网核验
- **官网**：hardwarenation.com
- **公开邮箱**：alex@hardwarenation.com；客服
- **关键联系人（KP）**：Alex Cronin(Alex Rabinovich)(创始合伙人)
- **情报要点**：★★白牌/Open Networking/disaggregated集成商(LinkedIn自述)!11-50人;Buford/Duluth GA(地址更正非Elgin)
- **来源**：hardwarenation.com;linkedin;bbb
- **核验状态**：官网/公开渠道核验通过
- **纪律**：首触由用户自理；Agent 不发信不排期。一切价格先按 SmartByte 成本核价再按 +20%/+25%/+30% 报 RMB，外报 USD 按当日/近期汇率。

## 【R3 深挖 2026-10-18】（批次 contact_research-2026-10-18_R3_型号价格待核收尾）

- **①产品**：HardwareNation
  - 发现：Edge-Core品牌页244 SKU在售(DC为主+Enterprise类目)+HN True SONiC/OcNOS/PicOS套餐
  - 结论/对位：对位:Enterprise接入层+SONiC白牌;他们是DC重镇,接入口弱=机会
  - 来源：src=hardwarenation.com
- **纪律**：报价先按 SmartByte 成本核价×1.20/1.25/1.30=RMB 未税 EXW，外报 USD 按当日/近期汇率；首触用户自理。

## R18 A类增量加厚（2026-10-19）

- **现行域名与邮件基础设施**：主域名 `hardwarenation.com` 于 2026-10-19 经公共 DNS（8.8.8.8）实查：A 记录 `104.26.13.147, 104.26.12.147, 172.67.75.216`；MX `0 hardwarenation-com.mail.protection.outlook.com`；邮件平台特征为 **Microsoft 365 / Exchange Online Protection**。判定：**A与MX均存在**。
- **官方渠道快照对账**：仓库留存的 Edgecore 官方渠道快照（2026-10-18，分区 `northamerica-reseller`）载：地址 **2390 Satellite Blvd, Suite P, Buford, GA 30518**；电话 770-924-5847；渠道定位 SI·VAR·经销商/线上电商。此项用于补齐主体地址并与档内电话对账；若与本档 R15 后段更新的登记/官网字段冲突，以后段为准。
- **R18 定点增量**：官方 GitHub 组织 `hardware-nation` 的主页与公开邮箱字段分别为 `hardwarenation.com`、`sales@hardwarenation.com`，自述构建白盒与解耦网络以降低 TCO；组织资料于 2026-08-10 更新，无公开仓库/成员。该销售总口获第二官方平台佐证，但仍非采购 KP。
- **口径边界**：DNS 阳性仅证明域名与收信基础设施在查询时存在，不证明任一具体邮箱可投递、人员仍在职或有采购意愿；KP/邮箱仍以本档 R15 定版为准。结构化底稿见 `batch/contact_research-2026-10-19_R18_A类增量加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`hardwarenation.com`为A与MX均存在；网站IPv4 `172.67.75.216`、`104.26.13.147`等3条（AS13335 CLOUDFLARENET - Cloudflare, Inc., US），AAAA 3条；邮件入口 `hardwarenation-com.mail.protection.outlook.com`（平台特征：Microsoft 365）；NS托管特征为Cloudflare。
- **邮件认证与发信系统信号**：SPF已发布（Microsoft 365、Mailchimp，结尾`-all`）；未见公开DMARC政策；CAA授权CA：pki.goog、digicert.com、letsencrypt.org、ssl.com、comodoca.com。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **GitHub公开技术足迹**：[hardware-nation](https://github.com/hardware-nation)（Organization，官网域互指/官方资料绑定），主页公开邮箱`sales@hardwarenation.com`；无公开仓库，当前主要作为主体绑定证据。技术活动不自动升格采购KP。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 96、跨档出现 ≤3 档的专属行 28、≤10 档的稀有行 30、外链来源域 2 个、全档去重邮箱 2 个；启发式审计分 71/100（主体 12/15、联系 20/20、KP 12/15、业务专属度 9/20、证据 11/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `alex@hardwarenation.com`（状态 `public_primary_email_recorded`）；KP 状态 `named_single_candidate`，结构化抽到：Alex Cronin。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：认证口径已按 U31 改为“UL 无；CE/FCC 按型号核实”；商用 PoE 模板已按 U28 收紧为 802.3af/at PoE+。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：A-055｜Hardware Nation（美国，SI/VAR）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 71/100、专属行 29（专属证据密度中等）；联系状态 `public_primary_email_recorded`，主口 `alex@hardwarenation.com`；KP 状态 `named_single_candidate`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：在手项目的交换机 BOM 与交付节点；存量网络扩容、维保与备件替换；现用品牌价格或交期压力；多站点标准化与批量复制项目。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Alex Cronin；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424XGGPM-280W 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 在手项目型号、数量、最终用户行业与交付节点；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：涉及轨交/车载时，EN50155/E-mark 无证即为硬停项；普通园区项目须与轨交项目分开确认。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
