---
structured_profile:
  code: A-044
  rating: A
  country: 印度
  role: SI/VAR
  segment: generic
  p1: STC-424XGGPM-280W
  stage: 00-lead
  struct_version: v2-lite
  updated: 2026-10-27
---

# Maheshwari Computer Pvt. Ltd.

> **评级 A** | 印度 · Indore | 档案编号 `A-044` | 角色：SI/VAR/集成商 | 状态：00-未触达
> 证据：Edgecore 官方渠道名录（IN-R）+ 2026-10-18 检索 | 来源：https://www.edge-core.com/where-to-buy/indian-reseller/

## SALES BRIEF（压缩模型）

- **是谁**：印度·Indore 的SI/VAR/集成商；Edgecore 官方渠道名录收录（事实）
- **为什么跟**：在售/集成 Edgecore，说明白牌/开放网络硬件已被接受；用 Saga（STC/STI）同规格更低价+OEM/ODM 做第二货源【推断】
- **P1（首触唯一主推）**：STC-424XGGPM-280W — 24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）
- **第一问（只问一个）**：Which Edgecore models do you move most, and what price tier wins your deals?
- **最大未知**：在售具体型号与月采购量未确认；联系人状态以本档后段 R15/R18 定版为准（见触达名单与 R18 段）
- **下一步**：按本档 R15/R18 定版联系人由用户首触（Agent 不发信）

## 客户概览

Maheshwari Computer Pvt. Ltd.（印度·Indore）为 SI/VAR/集成商，列于 Edgecore 官方渠道名录（IN-R）。备注：官方SI。定位：接入层第二货源/OEM 目标（A 级主攻）。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Maheshwari Computer Pvt. Ltd. | 事实（官方名录） |
| 国家/城市 | 印度 / Indore | 事实（官方名录） |
| 电话 | +91 731 4068836 | 事实（官方名录） |
| 渠道角色 | SI/VAR/集成商（IN-R） | 事实（官方名录口径） |
| 备注 | 官方SI | 事实（本轮记录） |
| 商业模式 | SI/VAR/集成商，转售/集成 Edgecore 并可能代理多品牌 | 【推断】 |
| 决策链 | 见后段「触达名单」及 R15/R18 定版；本行旧模板口径已失效 | 事实/线索分层 |

> 来源 URL：https://www.edge-core.com/where-to-buy/indian-reseller/（2026-10-18 检索）。官方名录只证明「当日页面列出该伙伴」，不证明当前采购意愿/在职人员/邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：他月走量在哪个档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：他现售 Edgecore 哪些料号、PoE 预算/上联速度需求、有没有改标需求。
- 【研发工程师】看：ERPS/PoE+（802.3af/at）/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- 已接受白牌/开放网络硬件【推断自其在 Edgecore 渠道名录】
- Saga 同规格成本档可做第二货源 + OEM 贴牌 + 交期优势
- 风险：认证约束（UL 无；CE/FCC 须在欧美触达前按具体型号核实；轨交/EN50155 非全线）在部分项目型需求处需留证

## 联系方式

- **电话**：+91 731 4068836（官方名录）
- **邮箱**：**director@maheshwaricomputers.com**（官网+Crunchbase 双载）；登记邮箱 mcpl007@rediffmail.com（老旧）；电话 0731-4068836-37 / +91-98270-39120
- **网站**：maheshwaricomputers.com（R2 官网核验 2026-10-18）

## 产品决策（Saga · 单一决策口径）

- **P1**：STC-424XGGPM-280W — 24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）
- 备选不进首触：工业场景→STI 系列；纯千兆成本敏感→STC-424DGGM（¥552 档）
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |

## 触达名单

### KP 实名（R15 深度挖掘·批4 2026-10-19）
- **Rajendra Maheshwari — Director（1990 年创始董事）** → director@ 邮箱即其口径
- 董事：Vibha Devi Maheshwari（1998 任）、Sanjeev Kumar Mishra（2025 新任——可能二代/职业经理人接班信号【推断】）

- 邮箱：director@maheshwaricomputers.com；mcpl007@rediffmail.com（R2 官网核验 2026-10-18 已填，禁止编造原则已满足）
- LinkedIn/电话：+91 731 4068836（官方名录）

## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs Edgecore 同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 首触邮件要点（模板素材，用户自行发送）

> Subject: Second-source switching for your Edgecore line
> 观察（在 Edgecore 渠道名录看到你们）→ 相关性（同规格白牌+OEM 贴牌+交期）→ 一个问题（哪个型号走量？）
> 红线：不提「Made in China」；不提「研究过你官网」；一次只问一个问题


### 完整首触邮件（英文 · 用户自行发送 · Agent 不发信）

> Subject: Your Edgecore access switches — a same-spec second source
>
> Dear Purchasing / Procurement Team,
>
> I noticed Maheshwari Computer Pvt. Ltd. carries the Edgecore access line. With the ECS2100 family entering end-of-life (last order date 2026-04-01), many partners are moving to a same-spec second source to keep projects and spares covered.
>
> We manufacture managed access switches — 24×GbE/PoE+ with 4×10G uplinks, 280W/440W PoE budgets, ERPS / IGMP snooping / 802.3af/at PoE+ — and we support OEM branding (logo, packaging, docs) from 10 units.
>
> One question: which access model moves the most volume for you right now?
>
> Best regards, Simon · Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥ | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| STC-424XGGPM-280W | 见 P1 价格快照对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE+（802.3af/at）/IGMP；OEM/ODM；交期快
- **W**：品牌认知度低；认证约束（UL 无；CE/FCC 须按具体型号核实；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：ECS2100 EOL 替换窗口（2026-04-01 前后）；客户双货源策略
- **T**：Edgecore 官方替代（ECS4150 系列）价格竞争；大客户锁价长约

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。

## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求

## 未知项清单

- 邮箱/KP：R2 已核验——KP：—(1990成立35年老牌)；邮箱：director@maheshwaricomputers.com；mcpl007@rediffmail.com
- 在售型号清单：待首触确认
- 认证敏感度（UL/轨交/E-mark/KC）：未知，涉及轨交/车载需求先声明缺口

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- https://www.edge-core.com/where-to-buy/indian-reseller/（2026-10-18 检索，官方渠道名录）；批次：batch/contact_research_2026-10-18_R1_官方渠道全量.json


## R15 深度核验·批4（2026-10-19）
- **老牌定版**：Maheshwari Computers Pvt. Ltd.，CIN U30007MP1990PTC006055，**1990 年**印多尔成立；Crunchbase 自述含「Routing & Switching 产品制造」+IT/网络/电信服务——若有自产/贴牌史则 OEM 话题可探【待首触核】
- ⚠️同名陷阱：Bahadurgarh 的 Maheshwari Computer（gmail，小维修店）无关

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。

## 【R2 官网核验 2026-10-18】

- **核验批次**：contact_research-2026-10-18_R2_A级官网核验
- **官网**：maheshwaricomputers.com
- **公开邮箱**：director@maheshwaricomputers.com；mcpl007@rediffmail.com
- **关键联系人（KP）**：—(1990成立35年老牌)
- **情报要点**：IT/网络/电信/软件+自产Routing&Switching/DC(crunchbase);Acer服务点;Indore
- **来源**：maheshwaricomputers.com;crunchbase
- **核验状态**：官网/公开渠道核验通过
- **纪律**：首触由用户自理；Agent 不发信不排期。一切价格先按 SmartByte 成本核价再按 +20%/+25%/+30% 报 RMB，外报 USD 按当日/近期汇率。

## R18 A类增量加厚（2026-10-19）

- **现行域名与邮件基础设施**：主域名 `maheshwaricomputers.com` 于 2026-10-19 经公共 DNS（8.8.8.8）实查：A 记录 `82.112.229.96`；MX `50 aspmx3.googlemail.com, 30 alt2.aspmx.l.google.com, 20 alt1.aspmx.l.google.com, 10 aspmx.l.google.com, 40 aspmx2.googlemail.com`；邮件平台特征为 **Google Workspace**。判定：**A与MX均存在**。
- **官方渠道快照对账**：仓库留存的 Edgecore 官方渠道快照（2026-10-18，分区 `indian-reseller`）载：地址 **203, Apollo Trade Centre, Geeta Bhavan Square, A.B. Road, INDORE (MP)**；电话 0731-4068836；渠道定位 SI·VAR·经销商。此项用于补齐主体地址并与档内电话对账；若与本档 R15 后段更新的登记/官网字段冲突，以后段为准。
- **口径边界**：DNS 阳性仅证明域名与收信基础设施在查询时存在，不证明任一具体邮箱可投递、人员仍在职或有采购意愿；KP/邮箱仍以本档 R15 定版为准。结构化底稿见 `batch/contact_research-2026-10-19_R18_A类增量加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`maheshwaricomputers.com`为A与MX均存在；网站IPv4 `82.112.229.96`（AS47583 AS-HOSTINGER - Hostinger International Limited, CY），未见AAAA；邮件入口 `aspmx.l.google.com`、`aspmx3.googlemail.com`等5条（平台特征：Google Workspace）；NS托管特征为GoDaddy。
- **邮件认证与发信系统信号**：未见SPF记录；未见公开DMARC政策。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：外部定向复核（官网/厂商/登记或官方披露优先）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 90、跨档出现 ≤3 档的专属行 20、≤10 档的稀有行 23、外链来源域 1 个、全档去重邮箱 2 个；启发式审计分 69/100（主体 15/15、联系 18/20、KP 15/15、业务专属度 8/20、证据 8/20、可执行性 7/10、风险扣分 -2）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `director@maheshwaricomputers.com`（状态 `public_primary_email_recorded`）；KP 状态 `named_multiple_candidates`，结构化抽到：Rajendra Maheshwari、Vibha Devi Maheshwari、Sanjeev Kumar Mishra。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：认证口径已按 U31 改为“UL 无；CE/FCC 按型号核实”；商用 PoE 模板已按 U28 收紧为 802.3af/at PoE+。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部定向结论**：
  - 官网 Team 页现公开 Rahul Gandhi（Networking Sales Head）、Shashikant Karandikar（Technical Sales Head）、Rakesh Verma（Senior Manager–Corporate Sales）、Sarika Rassay（Project Head）、Yogendra Batham（Service Manager）及 Mahendra Joshi（CFO）；这使决策链从只有董事扩展到网络销售与技术销售双入口，但仍无个人公开邮箱，不得拼址。
  - 印度公司数据镜像在 2026 年仍列该公司 Active，董事包括 Rajendra Maheshwari、Vibha Devi Maheshwari，以及 2025-05-19 新任的 Sanjeev Kumar Mishra；Tracxn 单源称 FY2025 营收 ₹63.2Cr，只能作商业数据库线索。官网当前服务重心包含铁路通信、EPC、IP-MPLS 与网络基础设施，通用接入交换只是其项目组合的一部分，轨交相关认证边界须先问清。
- **未闭合项**：专属经营事实偏薄；用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认；风险旗需在报价前处理：铁路/EPC项目认证边界待核。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：A-044｜Maheshwari Computer Pvt. Ltd.（印度，SI/VAR）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 69/100、专属行 24（专属证据仍薄）；联系状态 `public_primary_email_recorded`，主口 `director@maheshwaricomputers.com`；KP 状态 `named_multiple_candidates`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：在手项目的交换机 BOM 与交付节点；存量网络扩容、维保与备件替换；现用品牌价格或交期压力；多站点标准化与批量复制项目。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Rajendra Maheshwari、Vibha Devi Maheshwari、Sanjeev Kumar Mishra；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424XGGPM-280W 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 在手项目型号、数量、最终用户行业与交付节点；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：涉及轨交/车载时，EN50155/E-mark 无证即为硬停项；普通园区项目须与轨交项目分开确认。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：铁路/EPC项目认证边界待核。未闭合：专属经营事实偏薄；用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认；风险旗需在报价前处理：铁路/EPC项目认证边界待核。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
