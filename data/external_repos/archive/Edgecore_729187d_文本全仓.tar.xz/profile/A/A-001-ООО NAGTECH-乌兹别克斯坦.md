---
structured_profile:
  id: A-001
  company: ООО NAGTECH (NAG Uzbekistan)
  country: 乌兹别克斯坦
  rating: A
  biz_model: 分销+集成+自有电商（shop.nag.uz）
  decision_speed: 待观察
  needs: [高性价比L2+/PoE, 现货与交期, 多品牌货源, OEM/贴牌可能性]
  p1: STC-424XGGPM-280W（24口PoE+）待核价
  stage: 未接触
  volume_potential: 中高（网店1.5万SKU+系统集成）
  risk_flags: [价格敏感, 结算方式待谈]
  updated: 2026-10-27
---

# A-001 · ООО NAGTECH (NAG Uzbekistan) · 乌兹别克斯坦

## 1. SALES BRIEF
- **是谁**：塔什干网络设备供应商/集成商，自有网店 shop.nag.uz（1.5 万 SKU），供货电信/IT/政企
- **为什么跟**：进口熟手（Volza 显示 Cisco 防火墙等进口记录），中亚转口辐射塔吉克斯坦，正在扩品牌货源
- **P1**：24 口 PoE+ 商用管理型（对齐其网店网络设备类目）
- **第一问**：How many managed PoE switches do you move per month through the shop vs. project deals?
- **最大未知**：年采购量、现用品牌、结算/物流习惯
- **下一步**：首触邮件 → 索取采购负责人

## 2. 基本事实
| 内容 | 标签 |
|---|---|
| 注册地塔什干 Mirzo Ulugbek 区，7th Sayram 52 | 事实（Edgecore 名录） |
| 网店 shop.nag.uz 在售交换机/路由/光模块/服务器/监控等 | 事实（官网） |
| 电话 +998 55 508-06-60；邮箱 sales@nag.uz | 事实（官网/名录） |
| 进口 Cisco 防火墙等（Volza 海关数据，2024-2025） | 事实（Volza） |
| 向塔吉克斯坦出口（转口辐射） | 事实（Volza） |
| 主打中亚性价比市场、对价格敏感 | 【推断】依据：新兴市场定位+多品牌货源 |

## 3. 技术与在用
- 在售品类：网络/无线/服务器/光传输/监控/UPS（shop.nag.uz 类目）
- 现用交换机品牌：无公开（Edgecore 合作关系见于 where-to-buy）
- 芯片/规格偏好：无公开

## 4. 需求与场景
- 【推断】需要多品牌 L2+/PoE 标品补货架——依据：网店 SKU 广
- 【推断】项目侧需要交期稳定的货源——依据：自称 turn-key 交付能力

## 5. HR 与规模信号
- 有办公室+网店+售后团队（自称保修/维护/维修能力）→ 规模中型【推断】

## 6. 联系方式
- **电话**：+998 55 508-06-60（已有）
- **邮箱**：sales@nag.uz（官网/Facebook/SNR 伙伴页三方一致，2026-10-19 复核）
- **网站**：shop.nag.uz
- **地址**：Tashkent, Mirzo Ulugbek district, 7th Sayram 52（名录）/ pass.7 Sayram 3A（goldenpages）——两址并存，首触核实

## 7. 关键人（KP）与触达通道
- **Vladimir Kuznetsov — Director Sales Department（NAGTECH 销售总监，2022-05 起）兼 NAG LLC Overseas Sales Director**（LinkedIn 实名档案 linkedin.com/in/vladimir-kuznetsov-232031a2，驻塔什干，自述负责中亚区批发业务与营收/毛利 KPI）→ 首触可点名
- 其直达邮箱未公开，**禁止按格式臆造**；通道：sales@nag.uz 点名转交，或 LinkedIn InMail

## 8. 跟进步骤（≤3）
1. **首触**：P1=24口 PoE+ 样机报价；问月走量；exit：14 天无回复→季度低频
2. **台阶**：网店标品+项目机两条线分开谈；问现用品牌；exit：只愿比价无量→停
3. **台阶**：贴牌/OEM 试探（标签/包装/说明书）；exit：无回应→归档

## 9. 调研要点与证据
- Edgecore where-to-buy CIS SI/VAR：https://www.edge-core.com/where-to-buy/cis-reseller/
- shop.nag.uz 自述品类与规模；Volza 进出口记录（Nagtech Llc）

## 10. 产品决策
- **P1**：STC-424XGGPM-280W（24口 PoE+ 280W）——待核价（报价前核价）
- 备选（不进首触）：8 口 PoE 小机（网店零售）、24 口全千兆上联款

## 11. SWOT
- S：我方价格灵活、交期快、可贴牌；W：品牌弱于 Edgecore/TP-Link；O：其扩货源+转口；T：卢布/本币结算风险、比价压价

## 12. 触达与风险红线
- 不承诺 UL/KC；不谈云管；**停止开发条件**：3 次触达无实质回复/只比价/书面拒绝

## 13. Qualification
- 技术合格待验证（需要管理型/PoE 才算）；商业合格待首触信号（量、结算）

## 14. Unknowns
- [ ] 年走量？ [ ] 现用品牌？ [ ] 结算币种/条款？ [ ] 项目 vs 网店占比？ [ ] 采购决策人？

## 15. 首触邮件（英文）
**Subject: Managed PoE switches for shop.nag.uz — in stock, private label OK**

> Hi,
>
> I'm Simon with Saga Telecom. We manufacture managed and PoE switches — 8 to 48 ports, L2+/L2, CCTV and industrial models — with chips in stock and short lead times.
>
> I noticed NAG supplies networking gear across Uzbekistan through shop.nag.uz and turn-key projects. Our switches could fill the price-performance gap in your catalog, and we support private labeling.
>
> One question: roughly how many managed PoE switches do you sell per month through the shop versus project deals?
>
> Happy to send our catalog and a sample quotation.
>
> Best regards, Simon | Saga Telecom | https://sagatele.com


## R15 深度核验（2026-10-19）
- **集团归属**：母集团为俄罗斯 NAG（叶卡捷琳堡，shop.nag.ru 在其伙伴页列明 NAGTECH 为塔什干点）【事实：shop.nag.ru/partners】
- **集团内调货链实锤**：52wmb 提单（2026-08-17，B/L 55302/170826/0063912）显示供货方 TOO NAG Kazakhstan（阿拉木图）→ 买方 ООО NAGTECH——中亚内部调货，采购决策可能部分在集团层【事实：52wmb】
- **自有品牌信号**：SNR.SYSTEMS 官网伙伴页列 NAGTECH（SNR 为 NAG 集团自有设备品牌线）⇒ 有自有品牌运作经验，OEM/贴牌话题有土壤【事实+推断】
- **地址定版**：官网银行信息页载明 100105 Tashkent, Mirzo-Ulugbek district, Sayram 7-tor, 52，税号 309565073（旧档"两址并存"以此为准；3A 为同街另一登记址）【事实：shop.nag.uz】

## 16. 跟进记录
| 日期 | 渠道 | 动作 | 客户反应 | 结论 | 下次动作日期 |
|---|---|---|---|---|---|
| 2026-10-18 | — | 建档 | — | 未联系 | 首触待排 |

## 17. 下次复核
首触后 14 天无回复 → 降频季度复核。

## R18 A类增量加厚（2026-10-19）

- **现行域名与邮件基础设施**：主域名 `nag.uz` 于 2026-10-19 经公共 DNS（8.8.8.8）实查：A 记录 `92.63.207.120`；MX `10 emx.mail.ru`；邮件平台特征为 **Mail.ru**。判定：**A与MX均存在**。
- **官方渠道快照对账**：仓库留存的 Edgecore 官方渠道快照（2026-10-18，分区 `cis-reseller`）载：地址 **52, 7th Sairam Street, Mirzo-Ulugbek District, Tashkent**；电话 +998-55-508 0660；渠道定位 SI·VAR·经销商。此项用于补齐主体地址并与档内电话对账；若与本档 R15 后段更新的登记/官网字段冲突，以后段为准。
- **口径边界**：DNS 阳性仅证明域名与收信基础设施在查询时存在，不证明任一具体邮箱可投递、人员仍在职或有采购意愿；KP/邮箱仍以本档 R15 定版为准。结构化底稿见 `batch/contact_research-2026-10-19_R18_A类增量加厚.json`。首触仍由用户执行，Agent 不发信。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`nag.uz`为A与MX均存在；网站IPv4 `92.63.207.120`（AS202660 BRM-DataCenter - _Uzbektelekom_ Joint Stock Company, UZ），未见AAAA；邮件入口 `emx.mail.ru`（平台特征：Mail.ru/VK WorkSpace）；NS托管特征为nag.uz。
- **邮件认证与发信系统信号**：SPF已发布（授权include `_spf1.nag.ru`、`_spf2.nag.ru`、`_spf3.nag.ru`，结尾`~all`）；DMARC `p=reject`。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **公开服务面（DNS）**：检出`shop.nag.uz`、`support.nag.uz`、`b2b.nag.uz`。子域存在只证明DNS/服务配置，不单独证明页面当前可用或交易活跃。
- **关联/候选域状态**：`snr.systems`=A+MX（Mail.ru/VK WorkSpace）。关联域均按档内上下文人工保留，未经主体归属再核者不据此新增联系方式。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 62、跨档出现 ≤3 档的专属行 55、≤10 档的稀有行 59、外链来源域 2 个、全档去重邮箱 1 个；启发式审计分 73/100（主体 12/15、联系 18/20、KP 10/15、业务专属度 15/20、证据 11/20、可执行性 7/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `sales@nag.uz`（状态 `public_primary_email_recorded`）；KP 状态 `named_single_candidate`，结构化抽到：Vladimir Kuznetsov。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：首触自我介绍中的 Shenzhen 已删除。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：A-001｜A-001 · ООО NAGTECH (NAG Uzbekistan) · 乌兹别克斯坦（乌兹别克斯坦，渠道/项目伙伴）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 B、质量基线 73/100、专属行 56（专属证据密度强）；联系状态 `public_primary_email_recorded`，主口 `sales@nag.uz`；KP 状态 `named_single_candidate`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：现行项目 BOM；现用品牌缺货或 EOL 替换；多站点复制交付；成本档与本地库存压力。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Vladimir Kuznetsov；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424XGGPM-280W（24口PoE+）待核价 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 现行走量型号与月量/年预测；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：本地进口主体、型式批准、关税与外汇路径仍须由对方逐项确认，未核前不承诺落地价。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：用户逐档送达/回复结果未回填；现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
