---
structured_profile:
  code: A-060
  rating: A
  country: 智利/巴拉圭
  role: SI/VAR
  segment: generic
  p1: STC-424XGGPM-280W
  stage: 01-delivery-failed-old-domain
  struct_version: v2-lite
  updated: 2026-10-27
---

# LEDRIUM

> **评级 A** | 智利/巴拉圭 · Santiago/Asunción | 档案编号 `A-060` | 角色：SI/VAR/集成商 | 状态：01-旧域投递最终失败（改官网主域）
> 证据：Edgecore 官方渠道名录（LAT-R）+ 2026-10-18 检索 | 来源：https://www.edge-core.com/where-to-buy/LatinAmerica-reseller/

## SALES BRIEF（压缩模型）

- **是谁**：智利/巴拉圭·Santiago/Asunción 的SI/VAR/集成商；Edgecore 官方渠道名录收录（事实）
- **为什么跟**：在售/集成 Edgecore，说明白牌/开放网络硬件已被接受；用 Saga（STC/STI）同规格更低价+OEM/ODM 做第二货源【推断】
- **P1（首触唯一主推）**：STC-424XGGPM-280W — 24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）
- **第一问（只问一个）**：Which Edgecore models do you move most, and what price tier wins your deals?
- **最大未知**：在售具体型号与月采购量未确认；联系人状态以本档后段 R15/R18 定版为准（见触达名单与 R18 段）
- **下一步**：旧域本次投递已最终失败；由用户改走官网主域 contacto@goledrium.cl 首触，旧 contacto@ledrium.cl 暂停重发（Agent 不发信）

## 客户概览

LEDRIUM（智利/巴拉圭·Santiago/Asunción）为 SI/VAR/集成商，列于 Edgecore 官方渠道名录（LAT-R）。备注：双点。定位：接入层第二货源/OEM 目标（A 级主攻）。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | LEDRIUM | 事实（官方名录） |
| 国家/城市 | 智利/巴拉圭 / Santiago/Asunción | 事实（官方名录） |
| 电话 | +56 9 5093 8289 | 事实（官方名录） |
| 渠道角色 | SI/VAR/集成商（LAT-R） | 事实（官方名录口径） |
| 备注 | 双点 | 事实（本轮记录） |
| 商业模式 | SI/VAR/集成商，转售/集成 Edgecore 并可能代理多品牌 | 【推断】 |
| 决策链 | 见后段「触达名单」及 R15/R18 定版；本行旧模板口径已失效 | 事实/线索分层 |

> 来源 URL：https://www.edge-core.com/where-to-buy/LatinAmerica-reseller/（2026-10-18 检索）。官方名录只证明「当日页面列出该伙伴」，不证明当前采购意愿/在职人员/邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：他月走量在哪个档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：他现售 Edgecore 哪些料号、PoE 预算/上联速度需求、有没有改标需求。
- 【研发工程师】看：ERPS/PoE+（802.3af/at）/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- 已接受白牌/开放网络硬件【推断自其在 Edgecore 渠道名录】
- Saga 同规格成本档可做第二货源 + OEM 贴牌 + 交期优势
- 风险：认证约束（UL 无；CE/FCC 须在欧美触达前按具体型号核实；轨交/EN50155 非全线）在部分项目型需求处需留证

## 联系方式

- **电话**：+56 9 5093 8289（官方名录）
- **邮箱**：contacto@goledrium.cl（官网主域，现行首选）；contacto@ledrium.cl（官方 FB 与旧站同载；2026-10 首次投递经暂缓后最终失败，暂停）
- **网站**：goledrium.cl/ledrium.ai（R2 官网核验 2026-10-18）

## 产品决策（Saga · 单一决策口径）

- **P1**：STC-424XGGPM-280W — 24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）
- 备选不进首触：工业场景→STI 系列；纯千兆成本敏感→STC-424DGGM（¥552 档）
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |

## 触达名单

### KP 实名（R15 深度挖掘·批5 2026-10-19）

- **Pablo Felipe Silva Radnic**【智利官方公报 Diario Oficial 公司登记关联人，职务未标】
- Diego Sandoval Veloso — Gerente de Desarrollo de Nuevos Negocios（新业务发展经理）【LinkedIn，2019 年源——时效待核】

- 邮箱：contacto@goledrium.cl（R15 批5 核验 2026-10-19，完整来源见联系方式段）
- LinkedIn/电话：+56 9 5093 8289（官方名录）

## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs Edgecore 同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 首触邮件要点（模板素材，用户自行发送）

> Subject: Second-source switching for your Edgecore line
> 观察（在 Edgecore 渠道名录看到你们）→ 相关性（同规格白牌+OEM 贴牌+交期）→ 一个问题（哪个型号走量？）
> 红线：不提「Made in China」；不提「研究过你官网」；一次只问一个问题


### 完整首触邮件（英文 · 用户自行发送 · Agent 不发信）

> Subject: Your Edgecore access switches — a same-spec second source
>
> Dear Purchasing / Procurement Team,
>
> I noticed LEDRIUM carries the Edgecore access line. With the ECS2100 family entering end-of-life (last order date 2026-04-01), many partners are moving to a same-spec second source to keep projects and spares covered.
>
> We manufacture managed access switches — 24×GbE/PoE+ with 4×10G uplinks, 280W/440W PoE budgets, ERPS / IGMP snooping / 802.3af/at PoE+ — and we support OEM branding (logo, packaging, docs) from 10 units.
>
> One question: which access model moves the most volume for you right now?
>
> Best regards, Simon · Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥ | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| STC-424XGGPM-280W | 见 P1 价格快照对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE+（802.3af/at）/IGMP；OEM/ODM；交期快
- **W**：品牌认知度低；认证约束（UL 无；CE/FCC 须按具体型号核实；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：ECS2100 EOL 替换窗口（2026-04-01 前后）；客户双货源策略
- **T**：Edgecore 官方替代（ECS4150 系列）价格竞争；大客户锁价长约

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。

## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求

## 未知项清单

- 邮箱/KP：R2 已核验——KP：Guillermo Abraham(CEO);Pablo Silva Radnic(CMO联创);Diego Sandoval(新业务总监);Guillermo Jadue(Brasil CEO)；邮箱：contacto@goledrium.cl；administracion@
- 在售型号清单：待首触确认
- 认证敏感度（UL/轨交/E-mark/KC）：未知，涉及轨交/车载需求先声明缺口

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| 1 | 2026-10-21 | 邮箱 | 用户向 contacto@ledrium.cl 首触 | Delivery incomplete：Gmail 临时问题，仍将重试约 46 小时；未有最终失败通知 | 等最终 DSN 后再决定（用户决定） |
| 2 | 2026-10-24 | 邮箱回执 | 用户转来同一邮件后续通知 | 先显示尚余 19 小时重试，随后 Message not delivered；旧域本次投递最终失败（无 SMTP 细码） | 改走 contacto@goledrium.cl（用户决定） |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- https://www.edge-core.com/where-to-buy/LatinAmerica-reseller/（2026-10-18 检索，官方渠道名录）；批次：batch/contact_research_2026-10-18_R1_官方渠道全量.json


## R15 深度核验·批5（2026-10-19）

- **硬事实**：法定名 Servicios Integrales Tecnológicos Ledrium I SpA，RUT 77.094.387-6，圣地亚哥 Providencia；智利+巴拉圭（亚松森）+巴西（托莱多）三地运营，11-50 人；连接架构/视频智能/大型活动（场馆、音乐节）连接 SI，官网列 Cisco/HPE/Palo Alto 等联盟。Edgecore 名录巴拉圭地址（Comandante Franco 611）与其官网全等。

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。

## 【R2 官网核验 2026-10-18】

- **核验批次**：contact_research-2026-10-18_R2_A级官网核验
- **官网**：goledrium.cl/ledrium.ai
- **公开邮箱**：contacto@goledrium.cl；administracion@
- **关键联系人（KP）**：Guillermo Abraham(CEO);Pablo Silva Radnic(CMO联创);Diego Sandoval(新业务总监);Guillermo Jadue(Brasil CEO)
- **情报要点**：Cisco/HPE/PaloAlto/Facebook Connectivity合作;智利+巴西+巴拉圭三国;2023成立AI平台转型;11-50人
- **来源**：goledrium.cl;linkedin
- **核验状态**：官网/公开渠道核验通过
- **纪律**：首触由用户自理；Agent 不发信不排期。一切价格先按 SmartByte 成本核价再按 +20%/+25%/+30% 报 RMB，外报 USD 按当日/近期汇率。

## 【R3 深挖 2026-10-18】（批次 contact_research-2026-10-18_R3_型号价格待核收尾）

- **①产品**：LEDRIUM
  - 发现：Cisco/HPE/PaloAlto品牌线(无白牌);AI平台转型
  - 结论/对位：对位:品牌替换/降本话术
  - 来源：src=goledrium.cl
- **纪律**：报价先按 SmartByte 成本核价×1.20/1.25/1.30=RMB 未税 EXW，外报 USD 按当日/近期汇率；首触用户自理。

## R18 A类增量加厚（2026-10-19）

- **现行域名与邮件基础设施**：主域名 `goledrium.cl` 于 2026-10-19 经公共 DNS（8.8.8.8）实查：A 记录 `200.111.84.91`；MX `5 alt2.aspmx.l.google.com, 10 alt3.aspmx.l.google.com, 5 alt1.aspmx.l.google.com, 10 alt4.aspmx.l.google.com, 1 aspmx.l.google.com`；邮件平台特征为 **Google Workspace**。判定：**A与MX均存在**。
- **官方渠道快照对账**：R1 官方渠道快照（2026-10-18，分区 `LAT-R`）载：智利/巴拉圭·Santiago/Asunción；电话 +56 9 5093 8289；渠道定位 SI/VAR；名录注记“双点”。详细地址以本档 R15 后段为准。
- **R18 定点增量**：GitHub 组织 `ledrium`（位置 Chile）于 2026-09-02 创建、2026-09-15 更新，blog 指向 `ledrium.ai`；该域当前有 A 与注册商转发 MX，而 `goledrium.cl` 仍有 Google MX。显示新品牌站点/域名正在启用，但在官网互链核实前不替换既有联系域；该组织无公开仓库/成员，未新增 KP。
- **口径边界**：DNS 阳性仅证明域名与收信基础设施在查询时存在，不证明任一具体邮箱可投递、人员仍在职或有采购意愿；KP/邮箱仍以本档 R15 定版为准。结构化底稿见 `batch/contact_research-2026-10-19_R18_A类增量加厚.json`。首触仍由用户执行，Agent 不发信。

## R21 用户首触反馈处理（2026-10-21）

- **暂缓、不是退信定案**：`ledrium.cl` 为自建同机 MX，本次只是临时投递问题；官网主域 `goledrium.cl` 使用 Google MX，可作永久失败后的替代口。`ledrium.ai` 只有注册商转发 MX，不得据此拼 contacto@ledrium.ai。
- **处理决定**：在最终成功/永久失败通知回来前，状态只记“投递暂缓”，不把地址停用、不重复发送；若后续收到永久失败通知，再按新 DSN 升级处理。

## R22 用户首触后续反馈处理（2026-10-24）

- **最终收口**：暂缓通知先推进到“尚余 19 小时”，其后无重试时长的 “Message not delivered” 按同一封旧域邮件的最终失败处理。`ledrium.cl` 仍以自身 A 主机作 MX，自建收信路径已实测走不通；但通知未称邮箱不存在，不把地址本身永久判假。
- **路线切换**：R21 预设条件已经满足，当前唯一邮件首选回到官网 Google MX 域的 `contacto@goledrium.cl`。不要并行重发旧域，也不得把本地名迁移拼成 `contacto@ledrium.ai`。

## R23 存量客户全量加厚（2026-10-25）

- **域名与托管指纹**：主域`goledrium.cl`为A与MX均存在；网站IPv4 `200.111.84.91`（AS27651 AS27651 - ENTEL CHILE S.A., CL），未见AAAA；邮件入口 `aspmx.l.google.com`、`alt3.aspmx.l.google.com`等5条（平台特征：Google Workspace）；NS托管特征为Cloudflare。
- **邮件认证与发信系统信号**：SPF已发布（Google Workspace，结尾`~all`）；DMARC `p=none`。SPF include只说明该域授权过的发信系统，不证明采购量或具体邮箱可投递。
- **关联/候选域状态**：`ledrium.cl`=A+MX（自有域邮件主机（自建或本地托管））；`ledrium.ai`=A+MX（其他托管/本地邮件服务）。关联域均按档内上下文人工保留，未经主体归属再核者不据此新增联系方式。
- **GitHub公开技术足迹**：[ledrium](https://github.com/ledrium)（Organization，官网域互指/官方资料绑定）；无公开仓库，当前主要作为主体绑定证据。技术活动不自动升格采购KP。
- **跟进与证据边界**：用户已表示存量客户基本完成一轮跟进；未逐档回传送达/回复结果的，本轮不虚构已送达和已回复。DNS为2026-10-25经8.8.8.8查询快照，结构化底稿见`batch/contact_research-2026-10-25_R23_存量客户全量加厚.json`。Agent不发信。

## R24 质量复核与纠错加厚（2026-10-25）

- **复核类型**：全量内部证据台账复核（本轮未新增外部公司事实）；范围仍只限现有 157 家，不新增客户、不删档、不重排、不自行改评级。结构化结果见 `batch/contact_research-2026-10-25_R24_档案质量审计与定向复核.json`。
- **R24 前质量快照**：实质行 103、跨档出现 ≤3 档的专属行 34、≤10 档的稀有行 37、外链来源域 2 个、全档去重邮箱 3 个；启发式审计分 61/100（主体 12/15、联系 11/20、KP 10/15、业务专属度 9/20、证据 11/20、可执行性 8/10、风险扣分 0）。该分只用于找薄弱档，不证明每条历史事实都正确。
- **联系/KP 定版**：首选邮箱为 `contacto@goledrium.cl`（状态 `public_primary_email_recorded`）；KP 状态 `named_single_candidate`，结构化抽到：Diego Sandoval Veloso。自动抽取不替代原文的来源、日期和限定语；个人邮箱仅在公开披露且主体一致时保留。
- **本轮纠错**：认证口径已按 U31 改为“UL 无；CE/FCC 按型号核实”；商用 PoE 模板已按 U28 收紧为 802.3af/at PoE+。`$198/¥1212` 与 `docs/sales/P1产品价格快照.md` 的 STC-424XGGPM-280W 旧内部价/成本加价链一致，但只作内部历史参考，正式报价前必须重新核成本、汇率与有效期。
- **外部事实边界**：本档本轮没有新增可核验的外部公司事实；既有官网、厂商名录、登记、新闻稿和第三方材料继续按原段来源与日期分层。R23 的 DNS/GitHub 只证明基础设施或技术活动，不证明采购量、人员在职或交易意愿。
- **未闭合项**：现行采购型号、月量和认证要求未由客户确认。
- **下一证据路径**：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。
- **证据纪律**：未核实内容不得拼造邮箱、人物、职务或交易关系；第三方员工/营收估算只作单源线索，官网自述与审计/登记事实分开；用户“基本跟进完了”仍不转写为逐档已送达或已回复。Agent 不发信。

## R25 运营化加厚与定向复核（2026-10-27）

- **R25定位**：A-060｜LEDRIUM（智利/巴拉圭，SI/VAR）。本轮类型：内部证据运营化合成（本轮不宣称新增外部公司事实）；目标是把既有证据变成可核验的采购问题、决策链和停发规则，不把推断写成客户已确认需求。
- **适配与证据坐标**：R24 证据完整度 C、质量基线 64/100、专属行 35（专属证据密度中高）；联系状态 `public_primary_email_recorded`，主口 `contacto@goledrium.cl`；KP 状态 `named_single_candidate`。档内最晚显式日期 2026-10-25 只作时间坐标，不等于证据发布日期或在职证明。
- **采购触发器（待客户确认）**：在手项目的交换机 BOM 与交付节点；存量网络扩容、维保与备件替换；现用品牌价格或交期压力；多站点标准化与批量复制项目。在对方未确认型号、量级或项目节点前，这些只作访谈假设，不写成现行采购计划。
- **决策链工作图**：已实名候选为 Diego Sandoval Veloso；下一步不是再堆姓名，而是逐人确认谁拥有产品导入、技术验收和 PO 签核权，避免把高管、销售或工程师自动写成采购 KP。
- **触达顺序与停发规则**：只走一条已记录主线，不并行轰炸备址。下一证据路径：以客户回复或询价确认现行采购型号、月量、认证与进口路径；报价前重新核 SmartByte 成本、汇率和有效期。 Agent 不发信、不排期；若主口已拦截/失败，不原样重发或并行轰炸人事、支持、财务口。
- **产品切入顺序**：先以 STC-424XGGPM-280W 对照对方现行走量型号的端口数、上联速率和管理层级，不先发送全量目录；再按真实 BOM 确认 8/16/24/48 口、PoE 总预算与单口上限、SFP/SFP+ 兼容清单；最后才扩展到非 PoE 成本版、长距/安防配套或工业候选，并逐项核工作温度、电源与安装方式；若对方要求 SONiC/ONIE/SAI 或白盒 NOS，先逐型号核支持边界，不用普通管理型产品冒充开放网络平台；商用 PoE 只按 802.3af/at 的端口数与总功率预算表述；若项目明确要求高功率单口供电，单独走工业系适用型号评估。
- **商务核验清单**：1. 在手项目型号、数量、最终用户行业与交付节点；2. 现用品牌、供应痛点与目标到岸价；3. 端口/上联/PoE 总预算与单口上限；4. 管理功能、ERPS/IGMP/SNMP 与光模块兼容清单；5. 进口主体、清关、税费与本地认证持证人；6. 样品验收人、测试标准与决策期限；7. 付款币种、Incoterm、RMA、备件与本地库存责任。任一关键项未确认，报价只能作内部测算。
- **合规与交易闸门**：涉及轨交/车载时，EN50155/E-mark 无证即为硬停项；普通园区项目须与轨交项目分开确认。 UL、EN50155、E-mark、KC 无现成证书时不得虚报；CE/FCC/UKCA 等只能按具体型号与持证主体核实。
- **风险与未闭合项**：风险标志：无 R24 已登记的专项风险（不等于无交易风险）。未闭合：现行采购型号、月量和认证要求未由客户确认。
- **R25结论边界**：运营化条目是基于档内既有证据与本轮定向来源的工作框架，不证明现行采购意愿、人员在职、邮箱可投递或订单量；新增外部事实只以本段逐项来源与限定语为准。
