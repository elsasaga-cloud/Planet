#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""导出重点目标联系方式 CSV（从 Edgecore客户数据库.py 导入，保持单一数据源）。"""
import csv
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from importlib import import_module

mod = import_module("Edgecore客户数据库")

OUT = os.path.join(os.path.dirname(__file__), "..", "docs", "sales", "重点目标联系方式.csv")

def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["公司", "国家/地区", "网站", "邮箱", "电话", "备注"])
        w.writerows(mod.CONTACTS)
    print(f"已导出 {OUT}（{len(mod.CONTACTS)} 条）")

if __name__ == "__main__":
    main()
