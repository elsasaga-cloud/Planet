#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R4 落库：/tmp/r4/log.md → batch JSON + 档案 R4 块。2026-10-18"""
import json, glob, os

ROOT = "/home/user/Edgecore"
LOG = "/tmp/r4/log.md"
NOW = "2026-10-18T00:00:00+08:00"

# tag → 文件名关键词（精确匹配用 glob 校验唯一性）
KEYS = {
 "ATLColombia": "*A-073*", "ATLPanama": "*A-074*", "Upstream": "*A-020*",
 "DONGIL": "*A-041*", "AI-TECH": "*A-040*", "MBUZZ": "*B-019*", "ScaleIL": "*B-020*",
 "Erete": "*B-021*", "NETSOFT": "*B-023*", "SnapperNet": "*B-037*", "UNIQUEST": "*B-042*",
 "AHNNET": "*B-041*", "CTC-TH": "*B-047*",
}

entries = []
for line in open(LOG, encoding="utf-8"):
    line = line.strip()
    if not line or "|" not in line or line.startswith("公司"):
        continue
    parts = line.split("|")
    tag = parts[0]
    dim = parts[1] if len(parts) > 1 else ""
    find = parts[2] if len(parts) > 2 else ""
    concl = parts[3] if len(parts) > 3 else ""
    src = parts[4] if len(parts) > 4 else ""
    f = None
    pat = KEYS.get(tag)
    if pat:
        for sub in ("A", "B"):
            hits = glob.glob(os.path.join(ROOT, "profile", sub, pat + "*.md"))
            if len(hits) == 1:
                f = os.path.relpath(hits[0], ROOT)
                break
    entries.append({"tag": tag, "dim": dim, "findings": find, "conclusion": concl, "src": src, "profile": f})

by_file = {}
for e in entries:
    if e["profile"]:
        by_file.setdefault(e["profile"], []).append(e)

n = 0
for f, es in by_file.items():
    p = os.path.join(ROOT, f)
    txt = open(p, encoding="utf-8").read()
    if "【R4 待核收尾+B级抽样 2026-10-18】" in txt:
        continue
    block = "\n## 【R4 待核收尾+B级抽样 2026-10-18】（批次 contact_research-2026-10-18_R4_待核B级与报价表）\n\n"
    for e in es:
        block += "- **%s**：%s\n  - 发现：%s\n  - 结论：%s\n  - 来源：%s\n" % (e["dim"], e["tag"], e["findings"], e["conclusion"], e["src"])
    block += "- **纪律**：对位报价见 docs/sales/对位报价表_20强_2026-10-18.md；三档=SmartByte 成本×1.20/1.25/1.30（先核价）；USD 按当日汇率；PoE=af/at 不支持 bt 90W；首触用户自理。\n"
    open(p, "w", encoding="utf-8").write(txt.rstrip() + "\n" + block)
    n += 1

batch = {
    "batch_id": "contact_research-2026-10-18_R4_待核B级与报价表",
    "generated_at": NOW,
    "mode": "R4:①待核精查 ②B级抽样核验 ③20强对位报价表",
    "discipline": "只读;不发信;先核价;PoE不支持bt;首触用户自理",
    "entries": entries,
    "quote_sheet": "docs/sales/对位报价表_20强_2026-10-18.md",
    "unlocked": ["ATLColombia=atlcorp.co(VAD)", "DONGIL=edongil.com(强对应)", "Upstream清算确认→剔除", "MBUZZ=Edgecore ME&Africa VAD", "ScaleIL=Edgecore EMEA分销", "Erete=Edgecore土耳其总代", "SnapperNet=Edgecore NZ分销", "UNIQUEST=KOSPI半导体分销", "AHNNET=TAP/旁路专业商(光旁路竞合)", "CTC-TH=ITOCHU系SI"],
    "flags": ["ATLPanama对应性不成立(物流)", "NETSOFT(BD)同名存疑(软件公司)", "UNIQUEST大体量审慎", "CTC-TH大集团系审慎"],
    "remaining_pending": ["AI-TECH对应性"],
    "stats": {"entries": len(entries), "profile_blocks_appended": n},
}
out = os.path.join(ROOT, "batch", "contact_research-2026-10-18_R4_待核B级与报价表.json")
json.dump(batch, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("stats:", batch["stats"])
print("未挂档案:", [e["tag"] for e in entries if not e["profile"]])
