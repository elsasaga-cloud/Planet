#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R1 官方渠道全量批 → profile/*.md + batch JSON 快照。

数据源：Edgecore 官方 Where-to-Buy 12 页（2026-10-18 检索）+ 站外检索补充。
编号纪律：A/B/C 顺位追加、不重排、不插号（延续既有 A-001..A-006 / B-001..B-004 / C-001..C-003）。
大陆公司直接删除、全库不留档（U22）。
"""
import json, os, re, datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RETRIEVED = "2026-10-18"
SRC = {
    "EMEA-D": "https://www.edge-core.com/where-to-buy/emea-distributors/",
    "EMEA-R": "https://www.edge-core.com/where-to-buy/emea-reseller/",
    "ASIA-D": "https://www.edge-core.com/where-to-buy/asia-distributors/",
    "ASIA-R": "https://www.edge-core.com/where-to-buy/asia-reseller/",
    "IN-D":   "https://www.edge-core.com/where-to-buy/indian-distributors/",
    "IN-R":   "https://www.edge-core.com/where-to-buy/indian-reseller/",
    "NA-D":   "https://www.edge-core.com/where-to-buy/NorthAmerica-distributors/",
    "NA-R":   "https://www.edge-core.com/where-to-buy/NorthAmerica-reseller/",
    "NA-O":   "https://www.edge-core.com/where-to-buy/NorthAmerica-online/",
    "LAT-D":  "https://www.edge-core.com/where-to-buy/LatinAmerica-distributors/",
    "LAT-R":  "https://www.edge-core.com/where-to-buy/LatinAmerica-reseller/",
    "CIS-D":  "https://www.edge-core.com/where-to-buy/cis-distributors/",
    "CIS-R":  "https://www.edge-core.com/where-to-buy/cis-reseller/",
    "SEARCH": "web_search 2026-10-18（站外检索）",
}

# name|country|city|phone|role|grade|seg|src|note
DATA = """
Fionis GmbH|奥地利|Goessendorf|+43 3135 40 960-0|SI/VAR|A|generic|EMEA-R|官方SI
Alyseo|法国|Montreuil|+33 1 83 35 10 10|SI/VAR|A|generic|EMEA-R|官方SI
CELERIS Informatique|法国|Nanterre|01 71 12 60 23|SI/VAR|A|generic|EMEA-R|官方SI
Pine Networks|法国|Garches|+33 1 88 94 77 04|SI/VAR|A|generic|EMEA-R|官方SI
primeLine Solutions GmbH|德国|Bad Oeynhausen|+49 5731 8694-400|SI/VAR|A|generic|EMEA-R|官方SI
KTI Distribution GmbH|德国|Bielefeld|+49 521 96680-0|分销|B|generic|EMEA-R|原Avanis同址更名待核
Syserso Networks GmbH|德国|Hannover|+49 511 740192-0|分销|B|generic|EMEA-D|官方分销
DELTA Computer Products GmbH|德国|Reinbek|+49 40 300 672-0|分销|B|generic|EMEA-R|官方
Xantaro Deutschland GmbH|德国|Hamburg|+49 40 4134980|SI/VAR|B|generic|EMEA-R|偏高端集成
ALLNET France|法国|96 rue Lamarck|+33 4 48 23 02 90|分销|B|generic|EMEA-D|官方分销
LaserNetworks Kft|匈牙利|Veresegyház|1-44-54-129|SI/VAR|A|generic|EMEA-R|官方SI
Active Solution & Systems S.r.l.|意大利|San Donato Milanese|+39 02 514843|SI/VAR|A|generic|EMEA-R|官方SI
Soliton Telmec Limited|肯尼亚|Nairobi|+254 709 499000|SI/VAR|A|isp|EMEA-R|运营商方向
ODDnet|摩洛哥|Casablanca|+212 520 275 227|SI/VAR|A|generic|EMEA-R|官方SI
Distri X BV|荷兰|Rotterdam|+31 85-0204141|SI/VAR|A|generic|EMEA-R|官方SI
FiberUnlimited B.V.|荷兰|Nijkerk|+31 85 076 1501|SI/VAR|A|fiber|EMEA-R|FTTH方向
Xentech B.V.|荷兰|Zaandam|+31 85 002 0796|SI/VAR|A|generic|EMEA-R|官方SI
Infradata Group|荷兰|Leiden|+31 71-7501525|SI/VAR|B|generic|EMEA-R|规模中大
TELCARIA|西班牙|Leganés (Madrid)|+34 910261014|SI/VAR|A|generic|EMEA-R|PT/ES双列
Datanet Systems|罗马尼亚|Bucharest|+40 21 3178787|SI/VAR|B|generic|EMEA-R|规模中
Upstream ICT Alliance|塞尔维亚|Beograd|+381 11 4051779|SI/VAR|A|generic|EMEA-R|官方SI
Aero-IT distribucija d.o.o.|斯洛文尼亚|Logatec|+386 40 130902|SI/VAR|A|generic|EMEA-R|官方SI
Kontron d.o.o.|斯洛文尼亚|Kranj|+386 4 207 20 00|SI/VAR|B|industrial|EMEA-R|工业集团分支
Miro Distribution|南非|Samrand|+27 12 657 0960|分销|B|generic|EMEA-R|官方
WISI Communicaciones S.A.|西班牙|Mejorada del Campo|+34 91 679 42 80|SI/VAR|B|generic|EMEA-R|广电背景待核
Direktronik AB|瑞典|Stockholm|+46 8 52400700|分销|B|generic|EMEA-R|官方
Vinnergi AB|瑞典|Linköping|+46 101 02 44 00|SI/VAR|A|generic|EMEA-R|官方SI
Mart Networks Rwanda|卢旺达|Kigali|+250 788180100|SI/VAR|B|generic|EMEA-R|A-006同集团分支
Mart Networks Tanzania|坦桑尼亚|Dar es Salaam|+255 784 444490|SI/VAR|B|generic|EMEA-R|A-006同集团分支
MART NETWORKS UGANDA|乌干达|Kampala|+256 703 834115|SI/VAR|B|generic|EMEA-R|A-006同集团分支
Core Technologies LLC|阿联酋|Sharjah|+971 52 99 44456|SI/VAR|A|generic|EMEA-R|官方SI
Evollabs Tech FZ-LLC|阿联酋|Dubai|+971 4 529 9011|SI/VAR|A|generic|EMEA-D|官方SI
MBUZZ|沙特/阿联酋|Riyadh/Dubai|+966 53 037 8192|分销|B|generic|EMEA-D|双点办公
ScaleIL LTD|以色列|Raanana|052-665-2070|分销|B|generic|EMEA-D|官方分销
Erete Bilgi Sistemleri|土耳其|Istanbul|+90 212 212 8103|分销|B|generic|EMEA-D|官方分销
NOKTA ELEKTRONIK|土耳其|Istanbul|+90 212 222 8780|分销|B|generic|EMEA-D|官方分销
NETSOFT SOLUTIONS|巴基斯坦|Lahore|+92 323 406 1842|分销|B|generic|EMEA-D|官方分销
STARCOM Technologies|巴基斯坦|Karachi|+92 21 3566 1550|分销|B|generic|EMEA-D|官方分销
Astute Electronics Ltd.|英国|Stevenage|+44 1438 909 909|SI/VAR|B|generic|EMEA-R|规模中
M2M Enterprise|英国|London|+44 208 676 6067|SI/VAR|A|generic|EMEA-R|官方SI
Utopia Technology Limited|英国|Manchester|0333 241 2526|SI/VAR|A|generic|EMEA-R|官方SI
Vesper Technologies Ltd|英国|Stockport|+44 161 947 4321|SI/VAR|A|generic|EMEA-R|官方SI
MCS IT Distribution Ltd.|塞浦路斯|Limassol|+357 25 101 565|分销|B|generic|EMEA-D|官方分销
PROFIcomms s.r.o.|捷克|Brno|+420 548 210406|分销|B|generic|EMEA-D|官方分销
SAPPLY Pty Ltd|澳大利亚|Artarmon NSW|+61 2 9439 8887|SI/VAR|A|generic|ASIA-R|官方SI
C. F. KING Enterprise|文莱|Bandar Seri Begawan|+673 2237382|SI/VAR|A|generic|ASIA-R|官方SI
Positron Multiverse Co., Ltd|柬埔寨|Phnom Penh|+855 23 884 242|SI/VAR|A|generic|ASIA-R|官方SI
Mekong Link Co. LTD|柬埔寨|Phnom Penh|+855 23902239|分销|B|generic|ASIA-D|官方分销
SKYWARE PROTECH LIMITED|中国香港|Tsuen Wan|+852 31060868|SI/VAR|A|generic|ASIA-R|HK合规可攻
PT. Gwen Tekno Pratama|印尼|Bandung|+62 22 73512118|SI/VAR|A|generic|ASIA-R|官方SI
PT Trinet Prima Solusi|印尼|Jakarta|+62 21 3483 1212|SI/VAR|A|generic|ASIA-R|官方SI
PT Converion Solution Informatica|印尼|Jakarta|+62 21 806 22278|分销|B|generic|ASIA-D|官方分销
PT. Sysware Indonesia|印尼|Jakarta|+62 21 29569443|分销|B|generic|ASIA-D|官方分销
PT. Krida Hasta Tama|印尼|Jakarta|+62 21 564 4843|分销|B|generic|ASIA-D|官方分销
PT Blue Power Technology|印尼|Jakarta|（官网）|分销|B|generic|SEARCH|自述Edgecore授权分销
Algorithmic Digital Solutions Inc.|菲律宾|Quezon City|+63 968 8777 100|SI/VAR|A|generic|ASIA-R|官方SI
BANBROS COMMERCIAL., INC.|菲律宾|San Juan City|+63 2 7051700|分销|B|generic|ASIA-D|官方分销
DataOne Solutions Sdn Bhd|马来西亚|Puchong|+60 3 8604 5978|SI/VAR|A|generic|ASIA-R|官方SI
Tech Trad Solution Sdn Bhd|马来西亚|Kuala Lumpur|+60 3 2303 5899|SI/VAR|A|generic|ASIA-R|官方SI
VEMAX TECHNOLOGY|马来西亚|Kuching|+60 16 8747515|SI/VAR|A|generic|ASIA-R|官方SI
VESC Solution Sdn. Bhd.|马来西亚|Petaling Jaya|1700 81 5648|SI/VAR|A|generic|ASIA-R|官方SI
E-TECH IT Sdn Bhd|马来西亚|Shah Alam|+60 3 7846-2338|分销|B|generic|ASIA-D|官方分销
Loi Heng International|缅甸|Yangon|01 246221|分销|B|generic|ASIA-D|官方分销
TrustForce Myanmar|缅甸|Yangon|+95 9 952252591|分销|B|generic|ASIA-D|官方分销
Snapper Network Distributors Ltd|新西兰|Auckland|+64 9 415 4182|分销|B|generic|ASIA-R|官方
Computer Dynamics Limited|新西兰|Auckland|+64 9 415 9002|分销|B|generic|ASIA-D|官方
AsiaPac Distribution Pte Ltd|新加坡|Singapore|+65 6270 8281|分销|B|generic|ASIA-R|官方
ComWorth Solutions Pte Ltd|新加坡|Singapore|+65 6748 2260|SI/VAR|A|generic|ASIA-R|官方SI
Starview Technologies Pte Ltd|新加坡|Singapore|+65 3157 5338|分销|B|generic|ASIA-D|官方分销
AHNNET CO., Ltd.|韩国|Seongnam|+82 31 698 2020|SI/VAR|B|generic|ASIA-R|官方SI
AI TECH CO., Ltd|韩国|Seoul|+82 2 557 6366|SI/VAR|A|generic|ASIA-R|官方SI
DONGIL TECH Co., Ltd|韩国|Suwon|+82 31 216 7122|SI/VAR|A|generic|ASIA-R|官方SI
DS&G Co., Ltd.|韩国|Seoul|+82 2 6949 1850|SI/VAR|A|generic|ASIA-R|官方SI
INFO-A Inc|韩国|Seoul|+82 2 469 7550|SI/VAR|A|generic|ASIA-R|官方SI
LANOASIS Co., Ltd.|韩国|Seoul|+82 2 3272 7911|SI/VAR|A|generic|ASIA-R|官方SI
NEWGENS Co., Ltd.|韩国|Gwacheon|+82 2 6247 3901|SI/VAR|A|generic|ASIA-R|官方SI
Opasnet Co., Ltd.|韩国|Seoul|+82 2 2193 8600|SI/VAR|A|generic|ASIA-R|官方SI
TRENTO SYSTEMS Inc.|韩国|Daejeon|+82 42-710-5600|SI/VAR|A|generic|ASIA-R|官方SI
UNIQUEST CORP.|韩国|Seongnam|+82 31 798 9988|SI/VAR|B|generic|ASIA-R|规模中
STN Infotech Co., Ltd.|韩国|Gwacheon|+82 2-507-8088|分销|B|generic|ASIA-D|官方分销
COMMVERGE TECHNOLOGIES HOLDINGS (ASIA)|中国台北|Taipei|+886 2 8502 7258|SI/VAR|B|generic|ASIA-R|台湾合规可攻
HPI CORPORATION|中国台湾|New Taipei City|+886 2 2298 2958|SI/VAR|A|generic|ASIA-R|台湾合规可攻
ISON Technology|中国台湾|Linkou|+886 2 26036619|SI/VAR|A|generic|ASIA-R|台湾合规可攻
SilverShine Technology Inc.|中国台北|Taipei|+886 2 8792 6128|SI/VAR|A|generic|ASIA-R|台湾合规可攻
PETACOM TECHNOLOGY CO., LTD.|中国台北|Taipei|+886 2 2719 1128|分销|B|generic|ASIA-D|台湾合规可攻
Xander international corp.|中国台湾|New Taipei City|+886 2 2219 1600|分销|B|generic|ASIA-D|台湾合规可攻
CTC GLOBAL (THAILAND) LTD.|泰国|Bangkok|+66 2 059 0411|SI/VAR|B|generic|ASIA-R|官方SI
DATA IN MOTION CO., LTD.|泰国|Bangkok|+66 2 255 6691|SI/VAR|A|generic|ASIA-R|官方SI
Success Network|泰国|Bangkok|+66 81 659 4477|SI/VAR|A|generic|ASIA-R|官方SI
Throughwave (Thailand) Co., Ltd.|泰国|Bangkok|+66 2 210 0968|SI/VAR|A|generic|ASIA-R|官方SI
Easy Net Co.,Ltd.|泰国|Bangkok|+66 81 722 6111|分销|B|generic|ASIA-D|官方分销
SWS Group Company Limited|泰国|Bangkok|+66 2 016 3006|分销|B|generic|ASIA-D|官方分销
FPT INFORMATION SYSTEM CORPORATION|越南|Hanoi|+84 24 35626000|SI/VAR|B|generic|ASIA-R|大集成商低攻
NDC JOINT STOCK COMPANY|越南|Ho Chi Minh City|+84 28 35200096|SI/VAR|A|generic|ASIA-R|官方SI
NETCOM Co., Ltd.|越南|Hanoi|+84 4 35737747|SI/VAR|A|generic|ASIA-R|官方SI
SSS Vietnam Joint Stock Company|越南|Hanoi|+84 948398837|分销|B|generic|ASIA-D|官方分销
PalC Networks Pvt. Ltd.|印度|Bangalore|+91 80 40905088|分销|B|generic|IN-D|官方分销
Saimaa Technologies LLP|印度|Mumbai|+91 9820919959|分销|B|generic|IN-D|官方分销
Sheeltron Digital Systems Pvt. Ltd.|印度|Bangalore|+91 80 67572222|分销|B|generic|IN-D|官方分销
COMPUTERS NETWORK & TELECOM|印度|Gurgaon|+91 124 4125747|SI/VAR|A|generic|IN-R|官方SI
Khushi Communications Pvt. Ltd.|印度|New Delhi|+91 11 4161 5459|SI/VAR|A|generic|IN-R|官方SI
KRUPAM SOLUTIONS LLP|印度|Ahmedabad|+91 7405375321|SI/VAR|A|generic|IN-R|官方SI
Maheshwari Computer Pvt. Ltd.|印度|Indore|+91 731 4068836|SI/VAR|A|generic|IN-R|官方SI
Micromap Electronic Systems Pvt.|印度|New Delhi|+91 80 48964250|SI/VAR|A|generic|IN-R|官方SI
Ovin Technologies|印度|Pune|+91 89561 36940|SI/VAR|A|generic|IN-R|官方SI
Ravi and Singh Communication|印度|New Delhi|+91 11 40558635|SI/VAR|A|generic|IN-R|官方SI
Sapphire Micro Systems|印度|Mumbai|+91 22 28472160|SI/VAR|A|generic|IN-R|官方SI
SEC Communications Pvt Ltd.|印度|Bangalore|+91 80 42286554|SI/VAR|A|generic|IN-R|官方SI
Team5 Technologies Pvt. Ltd.|印度|Bangalore|+91 9738413329|SI/VAR|A|generic|IN-R|官方SI
Green Cube Technologies Pvt. Ltd.|尼泊尔|Kathmandu|01-4787059|分销|B|generic|IN-D|官方分销
E.C.I. NETWORKS INC.|加拿大|Dorval QC|1-800-967-1672|分销|B|generic|NA-D|官方分销
FONEX Data Systems Inc.|加拿大|St-Laurent QC|1-514-333-6639|分销|B|generic|NA-D|官方分销
info-logic ebm|加拿大|St-Bruno QC|1 450 653-7575|分销|B|generic|NA-D|官方分销
Planiselect Inc.|加拿大|Laval QC|450-663-3973|分销|B|generic|NA-D|官方分销
Nine-One-One Communication Supply|加拿大|Calgary AB|(800) 665-9911|SI/VAR|A|generic|NA-R|官方SI
Solimedia Technology Inc.|加拿大|Vancouver BC|604 568 9797|SI/VAR|A|generic|NA-R|官方SI
Tuangru|加拿大|Vancouver BC|1-866-612-3637|SI/VAR|B|generic|NA-R|官方SI
Advanced HPC|美国|San Diego CA|(858) 716-8262|SI/VAR|B|generic|NA-R|HPC集成
AMAX|美国|Fremont CA|(800) 800-6328|SI/VAR|B|generic|NA-R|ODM/集成规模中大
ASA Computers|美国|Fremont CA|800-732-5727|SI/VAR|B|generic|NA-R|官方SI
Blue Chip Tek, Inc.|美国|Santa Clara CA|408-731-7700|SI/VAR|B|generic|NA-R|官方SI
Blue Core Networks|美国|Marlboro MA|800 708-2785|SI/VAR|A|generic|NA-R|官方SI
Cambridge Computer|美国|Waltham MA|781 250 3000|SI/VAR|A|generic|NA-R|官方SI
Champion One|美国|Beachwood OH|216-831-1800|SI/VAR|B|fiber|NA-R|光模块背景
Colfax Direct|美国|Sunnyvale CA|(408) 730 2275|SI/VAR|A|generic|NA-R|官方SI+网店
Datainterfaces.com|美国|Alamo CA|888-959-3282|SI/VAR|B|generic|NA-R|官方SI
Dorado Software|美国|El Dorado Hills CA|916-673-1100|SI/VAR|B|generic|NA-R|网管软件背景待核
Hardware Nation|美国|Buford GA|770-924-5847|SI/VAR|A|generic|NA-R|官方SI+网店
IWNetworks|美国|Fremont CA|(510) 248-4448|SI/VAR|B|generic|NA-R|官方SI
KGPCo|美国|Faribault MN|1-800-328-5142|SI/VAR|B|generic|NA-R|电信渠道规模中大
Microcom Technologies|美国|Calabasas CA|818.880.8008|SI/VAR|B|generic|NA-R|官方SI
Myriad Supply|美国|New York NY|866-725-1025|SI/VAR|A|generic|NA-R|官方SI+网店
PA Computer Connections|美国|Greensburg PA|724-838-7526|SI/VAR|A|generic|NA-R|官方SI
Racklive|美国|Fremont CA|1-650-230-8060|SI/VAR|B|generic|NA-R|机架集成
Redapt, Inc|美国|Redmond WA|425-882-0400|SI/VAR|B|generic|NA-R|规模中大
Sotel Systems|美国|Maryland Heights MO|(866) 467-6835|SI/VAR|A|generic|NA-R|官方SI
Will Jaya|美国|Rowland Heights CA|(844) 996-0699|SI/VAR|A|generic|NA-R|官方SI
CTD|美国|Greenville SC|1-864-527-9600|分销|B|generic|NA-D|官方分销
Global Convergence, Inc.|美国|Oldsmar FL|(813) 925-6021|分销|B|generic|NA-D|官方分销
Network Distributors|美国|San Jose CA|1-408-392-0066|分销|B|generic|NA-D|官方分销
Adaptive Technology Solutions|美国|（官网）|（官网）|网店|B|generic|SEARCH|自述Edgecore授权网店
BCD|阿根廷|Rosario|+54 341 4093700|SI/VAR|A|generic|LAT-R|官方SI
E.C.I. Networks Tecnologia|巴西|São Paulo|+55 11 97768 5210|SI/VAR|B|generic|LAT-R|ECI网络巴西
ON Distribuidora|巴西|Cotia SP|+55 11 4617-6565|分销|B|generic|LAT-D|官方分销
OpenGlobe|巴西|São Paulo|+55 11 99604 0880|分销|B|generic|LAT-D|官方分销
Seger Technology|巴西|São Paulo|+55 11 2924-8670|分销|B|generic|LAT-D|官方分销
VPX Systems|巴西|Florianópolis|+55 11 5506-1326|分销|B|generic|LAT-D|官方分销
Fixar Telecom / FONPERU|秘鲁|Lima|+51 1 255-8587|SI/VAR|A|generic|LAT-R|同址双名待核
LEDRIUM|智利/巴拉圭|Santiago/Asunción|+56 9 5093 8289|SI/VAR|A|generic|LAT-R|双点
Whitestack|智利|Santiago|（官网）|SI/VAR|B|generic|LAT-R|OpenStack背景待核
ATL Colombia SAS|哥伦比亚|Bogotá|+57 310 2514279|SI/VAR|A|generic|LAT-R|官方SI
Comstar SAS|哥伦比亚|Bogotá|+57 601 742 3580|SI/VAR|A|generic|LAT-R|官方SI
Costa Rica Cloud Technology|哥斯达黎加|San José|+506 4000 0644|SI/VAR|A|generic|LAT-R|官方SI
E.C.I. Networks|墨西哥|Naucalpan|+52 55 4339-1771|SI/VAR|B|generic|LAT-R|ECI网络墨西哥
ATL Panama SA|巴拿马|Panama City|+507 6988-5973|SI/VAR|A|generic|LAT-R|官方SI
Teledata|乌拉圭|Montevideo|+598 24013864|SI/VAR|A|generic|LAT-R|官方SI
META LLC|亚美尼亚|Yerevan|+374 93003333|分销|B|generic|CIS-D|官方分销
Redinet CJSC|亚美尼亚|Yerevan|+374 10 249106|分销|B|generic|CIS-D|官方分销
ROMSAT|乌克兰|Kyiv|+380 44 499 7969|分销|B|generic|CIS-D|官方分销
Wireless Professional Solutions|澳大利亚|（wisp.net.au）|（官网）|分销|B|wisp|SEARCH|自述澳洲官方分销
Geotechnology IT Group|波兰|Warsaw|22 395 88 30|SI/VAR|B|generic|SEARCH|edgestore.pl自述Edgecore伙伴
Michaelis Consult GmbH|德国|（官网）|（官网）|SI/VAR|B|generic|SEARCH|IP Infusion名录reseller
PLVision|荷兰/乌克兰|Eindhoven|（官网）|软件伙伴|B|generic|SEARCH|SONiC Lite伙伴带硬件
ASBISc Enterprises PLC|塞浦路斯|Limassol|+357 25858500|分销|C|generic|EMEA-D|27国巨型分销情报级
ASBIS Middle East FZE|阿联酋|Dubai|+971 4 2531282|分销|C|generic|EMEA-D|ASBIS系情报级
ASBIS Poland|波兰|Warsaw|+48 22 537 1500|分销|C|generic|EMEA-D|ASBIS系情报级
Allnet GmbH|德国|Unterfoehring|+49 89 5586-0|分销|C|generic|EMEA-D|欧洲大型分销情报级
ADN Deutsche Advanced Network Distribution|德国|Dortmund|+49 231 8098-0|SI/VAR|C|generic|EMEA-R|欧洲大型分销情报级
Exclusive Networks|荷兰|Rotterdam|+31 10 248 7200|SI/VAR|C|generic|EMEA-R|跨国大集团PASS
Telent Technology Services|英国|Warwick|0845 230 7777|SI/VAR|C|generic|EMEA-R|英国大型集成商PASS
ITOCHU Techno-Solutions Corp|日本|Tokyo|+81 3 5437 4875|分销|C|generic|ASIA-D|日本大商社PASS
MACNICA INC.|日本|Yokohama|+81 45 939 3838|分销|C|generic|ASIA-D|日本大商社PASS
MITSUI KNOWLEDGE INDUSTRY CO.|日本|Tokyo|+81 3 5859 7550|SI/VAR|C|generic|ASIA-R|日本大商社PASS
NEC Networks & System Integration|日本|Tokyo|+81 3 5445 6111|SI/VAR|C|generic|ASIA-R|NEC系大SI PASS
VSTECS Singapore Pte Ltd|新加坡|Singapore|+65 6275 8835|分销|C|generic|ASIA-D|跨国大分销PASS
Anixter Inc.|美国|Glenview IL|(800) 264-8377|SI/VAR|C|generic|NA-R|全球大分销PASS
Avnet|美国|Phoenix AZ|480-643-2000|分销|C|generic|NA-D|全球大分销PASS
TD SYNNEX|美国|Fremont CA|800-237-8931|分销|C|generic|NA-D|全球大分销PASS
Tech Data (TD SYNNEX系)|美国|Tempe AZ|800-237-8931|分销|C|generic|NA-D|全球大分销PASS
CDW Corporation|美国|Vernon Hills IL|800-800-4239|网店|C|generic|NA-O|北美大网店PASS
Insight Enterprises|美国|Tempe AZ|800-587-8358|网店|C|generic|NA-O|北美大网店PASS
SHI International|美国|Somerset NJ|888-764-8888|SI/VAR|C|generic|NA-R|北美大SI PASS
World Wide Technology (WWT)|美国|St. Louis MO|800-432-7008|SI/VAR|C|generic|NA-R|北美大SI PASS
ePlus inc.|美国|Herndon VA|(888) 482-1111|SI/VAR|C|generic|NA-R|北美大SI PASS
GDT|美国|Dallas TX|(214) 857-6500|SI/VAR|C|generic|NA-R|北美大SI PASS
TESSCO Technologies|美国|Hunt Valley MD|+1 800 472 7373|分销|C|generic|NA-R|北美大型无线分销PASS
ASI (ASI Computer Technologies)|美国|Fremont CA|(510) 226-8000|分销|C|generic|NA-D|北美大型分销PASS
"""


def slug(name):
    return re.sub(r'[/\\:*?"<>|（）()]+', "", name).strip().replace(" ", "-")


P1 = {
    "generic": ("STC-424XGGPM-280W", "24×PoE+ 4×10G 上联 280W 管理型（旧价$198参考；核价后¥1212档）"),
    "poe": ("STC-424XGGPM-280W", "24×PoE+ 280W，CCTV/项目机"),
    "cctv": ("STC-424XGGPM-280W", "24×PoE+ 280W，CCTV/项目机"),
    "industrial": ("STI-42424XGGPM", "24×PoE 导轨工业 L2+ 4×10G（核价后 ¥2640 档）"),
    "isp": ("STC-424XGGM", "24×GE+4×10G L2+，ISP 接入（核价后 ¥852 档）"),
    "wisp": ("STC-424DGGM", "24×GE+4×SFP AC 爆款（核价后 ¥552 档）"),
    "fiber": ("STC-424XGGM", "24×GE+4×10G，FTTH/光纤接入（核价后 ¥852 档）"),
}
ROLE_LABEL = {"SI/VAR": "SI/VAR/集成商", "分销": "分销商", "网店": "在线销售", "软件伙伴": "软件/生态伙伴"}

records = []
for line in DATA.strip().splitlines():
    parts = line.split("|")
    if len(parts) < 9:
        continue
    name, country, city, phone, role, grade, seg, src, note = parts
    records.append(dict(name=name, country=country, city=city, phone=phone, role=role,
                        grade=grade, seg=seg, src=src, note=note))

# 批次 JSON 快照
os.makedirs(os.path.join(ROOT, "batch"), exist_ok=True)
batch_path = os.path.join(ROOT, "batch", "contact_research_2026-10-18_R1_官方渠道全量.json")
json.dump({"round": "R1", "date": RETRIEVED, "sources": SRC,
           "note": "Edgecore官方Where-to-Buy 12页全量+站外检索；大陆公司已全库删除(U22)",
           "records": records}, open(batch_path, "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)

# 编号顺位追加（既有 A-001..006 / B-001..004 / C-001..003 冻结）
counters = {"A": 6, "B": 4, "C": 3}
os.makedirs(os.path.join(ROOT, "profile", "A"), exist_ok=True)
os.makedirs(os.path.join(ROOT, "profile", "B"), exist_ok=True)
os.makedirs(os.path.join(ROOT, "profile", "C"), exist_ok=True)

made = 0
THICK = """
### 完整首触邮件（英文 · 用户自行发送 · Agent 不发信）

> Subject: Your Edgecore access switches — a same-spec second source
>
> Dear {name},
>
> I noticed {company} carries the Edgecore access line. With the ECS2100 family entering end-of-life (last order date 2026-04-01), many partners are moving to a same-spec second source to keep projects and spares covered.
>
> We manufacture managed access switches — 24×GbE/PoE+ with 4×10G uplinks, 280W/440W PoE budgets, ERPS / IGMP snooping / PoE++ ready — and we support OEM branding (logo, packaging, docs) from 10 units.
>
> One question: which access model moves the most volume for you right now?
>
> Best regards, Simon · Saga Telecom

（红线：一次只问一个问题；不提「Made in China」；不提「研究过你官网」；发前核价）

## P1 报价参考（核价后生效 · USD 按当日/近期汇率）

| 型号 | 成本¥ | ×1.20 | ×1.25 | ×1.30 |
|---|---|---|---|---|
| {p1_name} | 见 P1 价格快照对应行 | 核价后报 | 核价后报 | 核价后报 |

口径：RMB 未税 EXW 默认；外报 USD = 对应 RMB ÷ 当日/近期汇率；价格有效期 15 天；旧价仅历史参考。

## EOL 切入（获客方法论 #4 · 主话术）

- 「Edgecore ECS2100 系列 2026-04-01 后停收单（官方 EOL），Saga 同规格在产档可做第二货源」——对位表见 `docs/sales/EOL替换矩阵.md`
- 「AS4610-30T 官方无替代（Not Available）」为强话术；SONiC/ONIE 需求不接

## 三根刺（反问清单）

1. 你现在走量最大的接入型号是哪款？月量大概什么档位？
2. 你更在意价格档，还是交期/改款灵活性？
3. 有没有 OEM 贴牌（丝印/彩盒/手册）需求？

## SWOT（精准不夸大）

- **S**：同规格成本档更低；ERPS/PoE++/IGMP 全线；OEM/ODM；交期快
- **W**：品牌认知度低；认证缺口（UL/CE 有；EN50155 轨交/E-mark/KC 无）；无 SONiC 开放生态
- **O**：ECS2100 EOL 替换窗口（2026-04-01 前后）；客户双货源策略
- **T**：Edgecore 官方替代（ECS4150 系列）价格竞争；大客户锁价长约

## Qualification（三问定级）

1. 月采购量 ≥10 台？ 2. 有真实项目/客户 BOM？ 3. 接受 15 天报价有效期？
→ 三问两是维持 A/B 推进；否则降频季度复核。

## 触达红线

不提「Made in China」；不提「研究过你官网」；一次只问一个问题；不承诺未核验的交期/认证；轨交/车载需求先声明认证缺口。
"""
for r in records:
    g = r["grade"]
    counters[g] += 1
    code = f"{g}-{counters[g]:03d}"
    p1_name, p1_desc = P1.get(r["seg"], P1["generic"])
    fname = f"{code}-{slug(r['name'])}-{slug(r['country'])}.md"
    path = os.path.join(ROOT, "profile", g, fname)
    src_url = SRC.get(r["src"], r["src"])
    thick_block = THICK.format(name="Purchasing / Procurement Team", company=r["name"], p1_name=p1_name) if g in ("A", "B") else ""
    md = f"""---
structured_profile:
  code: {code}
  rating: {g}
  country: {r['country']}
  role: {r['role']}
  segment: {r['seg']}
  p1: {p1_name}
  stage: 00-lead
  struct_version: v2-lite
  updated: {RETRIEVED}
---

# {r['name']}

> **评级 {g}** | {r['country']} · {r['city']} | 档案编号 `{code}` | 角色：{ROLE_LABEL.get(r['role'], r['role'])} | 状态：00-未触达
> 证据：Edgecore 官方渠道名录（{r['src']}）+ {RETRIEVED} 检索 | 来源：{src_url}

## SALES BRIEF（压缩模型）

- **是谁**：{r['country']}·{r['city']} 的{ROLE_LABEL.get(r['role'], r['role'])}；Edgecore 官方渠道名录收录（事实）
- **为什么跟**：在售/集成 Edgecore，说明白牌/开放网络硬件已被接受；用 Saga（STC/STI）同规格更低价+OEM/ODM 做第二货源【推断】
- **P1（首触唯一主推）**：{p1_name} — {p1_desc}
- **第一问（只问一个）**：Which Edgecore models do you move most, and what price tier wins your deals?
- **最大未知**：在售具体型号与月采购量未确认；邮箱/KP 未定位
- **下一步**：官网核验邮箱/KP 后由用户首触（Agent 不发信）

## 客户概览

{r['name']}（{r['country']}·{r['city']}）为 {ROLE_LABEL.get(r['role'], r['role'])}，列于 Edgecore 官方渠道名录（{r['src']}）。备注：{r['note']}。定位：接入层第二货源/OEM 目标（A 级主攻）。

## 基本事实（事实/【推断】/【假设】分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | {r['name']} | 事实（官方名录） |
| 国家/城市 | {r['country']} / {r['city']} | 事实（官方名录） |
| 电话 | {r['phone']} | 事实（官方名录） |
| 渠道角色 | {ROLE_LABEL.get(r['role'], r['role'])}（{r['src']}） | 事实（官方名录口径） |
| 备注 | {r['note']} | 事实（本轮记录） |
| 商业模式 | {ROLE_LABEL.get(r['role'], r['role'])}，转售/集成 Edgecore 并可能代理多品牌 | 【推断】 |
| 决策链 | 未确认 | 【假设】 |

> 来源 URL：{src_url}（{RETRIEVED} 检索）。官方名录只证明「当日页面列出该伙伴」，不证明当前采购意愿/在职人员/邮箱可投递。

## 换个身份看（我是【分部销售经理/售前工程师/研发工程师】）

- 【分部销售经理】看：他月走量在哪个档位、价格敏感点、要不要区域保护。
- 【售前工程师】看：他现售 Edgecore 哪些料号、PoE 预算/上联速度需求、有没有改标需求。
- 【研发工程师】看：ERPS/PoE++/IGMP/SNMP 兼容点是否够他的项目。

## 为什么要跟

- 已接受白牌/开放网络硬件【推断自其在 Edgecore 渠道名录】
- Saga 同规格成本档可做第二货源 + OEM 贴牌 + 交期优势
- 风险：认证缺口（UL/CE 已有；轨交/EN50155 非全线）在部分项目型需求处需留证

## 联系方式

- **电话**：{r['phone']}（官方名录）
- **邮箱**：—（待官网 info/sales 页核验；MX/DNS 级验证后再入库）
- **网站**：—（待补）

## 产品决策（Saga · 单一决策口径）

- **P1**：{p1_name} — {p1_desc}
- 备选不进首触：工业场景→STI 系列；纯千兆成本敏感→STC-424DGGM（¥552 档）
- 报价口径：`¥xxx CNY 未税 EXW（核价后报价，15 天有效）` 或按当日/近期汇率折 `$xx USD EXW`（用户 2026-10-18 指令）

## 决策链

| 角色 | 姓名/来源 | 关注点 | 状态 |
|---|---|---|---|
| 采购 | 未知 | 价格/交期 | 【假设】待定位 |
| 技术把关 | 未知 | 规格/兼容 | 【假设】待定位 |

## 触达名单

- 邮箱：—（待官网核验后填，禁止编造）
- LinkedIn/电话：{r['phone']}（官方名录）

## 付款/贸易

- 术语：EXW 默认；FOB/CIF 按客户谈
- 收款：T/T 默认（用户既有贸易惯例）
- 价格有效期 15 天；阶梯价 MOQ≥10 / 50 / 100（按量谈）

## 跟进步骤（最多 3 次 · 用户执行）

1. **首触**：一句话自我介绍 + 第一问（见 SALES BRIEF）；成功标准=回复型号/量；退出=14 天无回复
2. **二触**：带一页规格对照（Saga vs Edgecore 同位型号）+ 交期/MOQ 三根刺；成功标准=索取报价；退出=只比价不给信息
3. **三触**：小批量试单提议（10 台起，贴牌可选）；成功标准=试单；退出=书面拒绝或 3 次无实质回复→停止开发

## 首触邮件要点（模板素材，用户自行发送）

> Subject: Second-source switching for your Edgecore line
> 观察（在 Edgecore 渠道名录看到你们）→ 相关性（同规格白牌+OEM 贴牌+交期）→ 一个问题（哪个型号走量？）
> 红线：不提「Made in China」；不提「研究过你官网」；一次只问一个问题

{thick_block}
## Unknowns（首触后逐项消除）

- [ ] 走量型号与月采购量
- [ ] 现用品牌组合与痛点（交期/MOQ/改款）
- [ ] 采购决策人与邮箱
- [ ] 是否有 OEM/贴牌需求

## 未知项清单

- 邮箱/KP：待官网核验
- 在售型号清单：待首触确认
- 认证敏感度（UL/轨交/E-mark/KC）：未知，涉及轨交/车载需求先声明缺口

## 跟进记录

| # | 日期 | 渠道 | 动作 | 结果 | 下次动作日期 |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

## 复盘

（成交/丢失后回填：赢输原因、价格档、对标型号）

## 来源

- {src_url}（{RETRIEVED} 检索，官方渠道名录）；批次：batch/contact_research_2026-10-18_R1_官方渠道全量.json

## 下次复核

首触后 14 天无回复 → 降频季度复核（不编造日期）。
"""
    open(path, "w", encoding="utf-8").write(md)
    made += 1

print(f"batch → {os.path.relpath(batch_path, ROOT)}")
print(f"profiles generated: {made} (A+B+C 顺位追加)")
