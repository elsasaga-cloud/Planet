#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R5 落库：/tmp/r5/log.md → batch JSON + 档案 R5 块。编号前缀精确匹配。"""
import json, glob, os
ROOT = "/home/user/Edgecore"
LOG = "/tmp/r5/log.md"
NOW = "2026-10-18T00:00:00+08:00"
# tag → 编号前缀（绝对精确，避免子串假命中）
IDS = {"AI-TECH": "A-040", "PalC": "B-052", "Sheeltron": "B-054", "SSS-VN": "B-051",
       "EasyNet-TH": "B-048", "ON-BR": "B-078", "FONEX": "B-057", "STN-KR": "B-043",
       "GreenCube-NP": "B-055", "VPX": "B-081"}

def find(pid):
    hits = glob.glob(os.path.join(ROOT, "profile", pid[0], pid + "-*.md"))
    return os.path.relpath(hits[0], ROOT) if len(hits) == 1 else None

entries = []
for line in open(LOG, encoding="utf-8"):
    line = line.strip()
    if not line or "|" not in line or line.startswith("公司"):
        continue
    p = line.split("|")
    tag = p[0]
    f = find(IDS[tag]) if tag in IDS else None
    entries.append({"tag": tag, "dim": p[1] if len(p) > 1 else "", "findings": p[2] if len(p) > 2 else "",
                    "conclusion": p[3] if len(p) > 3 else "", "src": p[4] if len(p) > 4 else "", "profile": f})

by_file = {}
for e in entries:
    if e["profile"]:
        by_file.setdefault(e["profile"], []).append(e)

n = 0
for f, es in by_file.items():
    pth = os.path.join(ROOT, f)
    txt = open(pth, encoding="utf-8").read()
    if "【R5 B级批量+首触多语种 2026-10-18】" in txt:
        continue
    block = "\n## 【R5 B级批量+首触多语种 2026-10-18】（批次 contact_research-2026-10-18_R5_B级批量与多语种首触）\n\n"
    for e in es:
        block += "- **%s**：%s\n  - 发现：%s\n  - 结论：%s\n  - 来源：%s\n" % (e["dim"], e["tag"], e["findings"], e["conclusion"], e["src"])
    block += "- **纪律**：首触邮件多语种版见 docs/sales/首触邮件多语种_2026-10-18.md（EN/ES/PT/TR/KO）；首触用户自理；一次一问；不提产地/不提研究过官网；报价先核价×1.20/1.25/1.30。\n"
    open(pth, "w", encoding="utf-8").write(txt.rstrip() + "\n" + block)
    n += 1

batch = {
    "batch_id": "contact_research-2026-10-18_R5_B级批量与多语种首触",
    "generated_at": NOW,
    "mode": "R5:①AI-TECH候选锁定 ②B级批量核验10家 ③多语种首触邮件",
    "discipline": "只读;不发信;首触用户自理;一次一问;不提产地;先核价",
    "entries": entries,
    "first_touch_sheet": "docs/sales/首触邮件多语种_2026-10-18.md",
    "languages": ["EN", "ES", "PT", "TR", "KO"],
    "unlocked": ["PalC=Edgecore IN+SONiC", "Sheeltron=Edgecore IN(₹592Cr)", "SSS-VN=Edgecore VN+Aruba白金", "EasyNet-TH=Edgecore TH", "ON-BR=Edgecore BR", "FONEX=Edgecore OLT三方伙伴+LambdaGain", "STN-KR=Edgecore KR", "GreenCube-NP=Edgecore NP", "VPX=Edgecore+IP Infusion US/CA/LatAm"],
    "ai_tech_status": "候选锁定aitech24.co.kr(iCraft系网络方案商)但与名录地址不符=部分存疑;触达前人工核",
    "b_sample_total": 18,
    "stats": {"entries": len(entries), "profile_blocks_appended": n},
}
out = os.path.join(ROOT, "batch", "contact_research-2026-10-18_R5_B级批量与多语种首触.json")
json.dump(batch, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("stats:", batch["stats"])
print("未挂:", [e["tag"] for e in entries if not e["profile"]])
