#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R3 落库：/tmp/r3/log.md → batch JSON + 档案 R3 块追加。2026-10-18"""
import json, re, glob, os

ROOT = "/home/user/Edgecore"
LOG = "/tmp/r3/log.md"
NOW = "2026-10-18T00:00:00+08:00"

MANUAL = {
 "RaviSingh": "profile/A/A-062-Ravi-and-Singh-Communication-印度.md",
 "CRCT": "profile/A/A-081-Costa-Rica-Cloud-Technology-哥斯达黎加.md",
 "DataInMotion": "profile/A/A-051-DATA-IN-MOTION-CO.,-LTD.-泰国.md",
 "VESC": "profile/A/A-038-VESC-Solution-Sdn.-Bhd.-马来西亚.md",
 "HardwareNation": "profile/A/A-071-Hardware-Nation-美国.md",
 "Solimedia": "profile/A/A-067-Solimedia-Technology-Inc.-加拿大.md",
 "ColfaxDirect": "profile/A/A-070-Colfax-Direct-美国.md",
 "VEMAX": "profile/A/A-037-VEMAX-TECHNOLOGY-马来西亚.md",
 "Sapphire": "profile/A/A-063-Sapphire-Micro-Systems-印度.md",
 "PT-Gwen": "profile/A/A-032-PT.-Gwen-Tekno-Pratama-印尼.md",
 "PT-Trinet": "profile/A/A-033-PT-Trinet-Prima-Solusi-印尼.md",
 "Starview": "profile/B/B-040-Starview-Technologies-Pte-Ltd-新加坡.md",
 "DSG": "profile/A/A-042-DS&G-Co.,-Ltd.-韩国.md",
 "INFO-A": "profile/A/A-043-INFO-A-Inc-韩国.md",
 "Micromap": "profile/A/A-060-Micromap-Electronic-Systems-Pvt.-印度.md",
 "SuccessNetwork": "profile/A/A-052-Success-Network-泰国.md",
 "Positron": "profile/A/A-030-Positron-Multiverse-Co.,-Ltd-柬埔寨.md",
 "NETCOM": "profile/A/A-055-NETCOM-Co.,-Ltd-越南.md",
 "FONPERU": "profile/A/A-077-Fixar-Telecom--FONPERU-秘鲁.md",
 "LEDRIUM": "profile/A/A-078-LEDRIUM-智利巴拉圭.md",
 "DONGIL": "profile/A/A-041-DONGIL-TECH-Co.,-Ltd-韩国.md",
 "FibRSol主体": "profile/A/A-062-Ravi-and-Singh-Communication-印度.md",
 "LANOASIS-UNICLASS": "profile/A/A-044-LANOASIS-Co.,-Ltd.-韩国.md",
 "NDC": "profile/A/A-054-NDC-JOINT-STOCK-COMPANY-越南.md",
}

# 修正：用 ls 实测文件名覆盖不确定项
fix = glob.glob(os.path.join(ROOT, "profile/A/*DATA*IN*MOTION*")) + glob.glob(os.path.join(ROOT, "profile/A/*Hardware*Nation*")) + glob.glob(os.path.join(ROOT, "profile/A/*Colfax*")) + glob.glob(os.path.join(ROOT, "profile/A/*INFO-A*")) + glob.glob(os.path.join(ROOT, "profile/A/*Micromap*")) + glob.glob(os.path.join(ROOT, "profile/A/*Success*")) + glob.glob(os.path.join(ROOT, "profile/A/*NETCOM*")) + glob.glob(os.path.join(ROOT, "profile/A/*Solimedia*")) + glob.glob(os.path.join(ROOT, "profile/A/*Sapphire*"))
for f in fix:
    b = os.path.basename(f)
    if "DATA" in b and "MOTION" in b: MANUAL["DataInMotion"] = os.path.relpath(f, ROOT)
    if "Hardware" in b: MANUAL["HardwareNation"] = os.path.relpath(f, ROOT)
    if "Colfax" in b: MANUAL["ColfaxDirect"] = os.path.relpath(f, ROOT)
    if "INFO-A" in b: MANUAL["INFO-A"] = os.path.relpath(f, ROOT)
    if "Micromap" in b: MANUAL["Micromap"] = os.path.relpath(f, ROOT)
    if "Success" in b: MANUAL["SuccessNetwork"] = os.path.relpath(f, ROOT)
    if "NETCOM" in b: MANUAL["NETCOM"] = os.path.relpath(f, ROOT)
    if "Solimedia" in b: MANUAL["Solimedia"] = os.path.relpath(f, ROOT)
    if "Sapphire" in b: MANUAL["Sapphire"] = os.path.relpath(f, ROOT)

entries = []
for line in open(LOG, encoding="utf-8"):
    line = line.strip()
    if not line or "|" not in line or line.startswith("#"):
        continue
    parts = line.split("|")
    tag = parts[0]
    dim = parts[1] if len(parts) > 1 else ""
    find = parts[2] if len(parts) > 2 else ""
    concl = parts[3] if len(parts) > 3 else ""
    src = parts[4] if len(parts) > 4 else ""
    entries.append({"tag": tag, "dim": dim, "findings": find, "conclusion": concl, "src": src})

# 按 tag 追加 R3 块（同一档案多 tag 合并）
by_file = {}
for e in entries:
    f = MANUAL.get(e["tag"])
    e["profile"] = f
    if f:
        by_file.setdefault(f, []).append(e)

n = 0
for f, es in by_file.items():
    p = os.path.join(ROOT, f)
    txt = open(p, encoding="utf-8").read()
    if "【R3 深挖 2026-10-18】" in txt:
        continue
    block = "\n## 【R3 深挖 2026-10-18】（批次 contact_research-2026-10-18_R3_型号价格待核收尾）\n\n"
    for e in es:
        block += "- **%s**：%s\n  - 发现：%s\n  - 结论/对位：%s\n  - 来源：%s\n" % (e["dim"], e["tag"], e["findings"], e["conclusion"], e["src"])
    block += "- **纪律**：报价先按 SmartByte 成本核价×1.20/1.25/1.30=RMB 未税 EXW，外报 USD 按当日/近期汇率；首触用户自理。\n"
    open(p, "w", encoding="utf-8").write(txt.rstrip() + "\n" + block)
    n += 1

batch = {
    "batch_id": "contact_research-2026-10-18_R3_型号价格待核收尾",
    "generated_at": NOW,
    "mode": "R3三线:①20强在售型号对位 ②各国价格带 ③待核收尾",
    "discipline": "只读公开渠道;不发信;EOL/价格情报先核价再报;首触用户自理",
    "entries": entries,
    "price_anchors": {
        "ECS2100-28P": "USD 339.92-439.99 (CDW/compsource); 28PP 452-587",
        "ECS4100-52P": "USD 398.95-769.98; 12T 299-307.99",
        "AS4610-30P": "USD 1884-2218; 30T 2815 CAD",
        "AS4610-54T": "USD 1725-2142; 54P 2984-4099",
        "USW-Pro-48-PoE(对标)": "USD 1099 (Ubiquiti 48口L3 PoE++ 600W)",
        "DGS-1100-24PV2(对标)": "PHP 16150 (菲律宾)",
        "MikroTik CRS328-24P(对标)": "CAD 665 / USD 477建议价",
        "Planet GS-4210-16T2S": "VND 3,230,000 (越南)",
    },
    "eol_update": {
        "AS4610-54T": "EOL 2025-06-30 → AS4625-54T",
        "AS4610-54P": "EOL 2025-06-30 → AS4625-54P",
        "AS4610-30T": "EOL 2025-06-30 → Not Available（无替代！）",
    },
    "unlocked_checks": ["FibRSol主体锁定", "LANOASIS↔UNICLASS锁定", "NDC=ndcjsc.com锁定", "DONGIL同名不同司确认"],
    "remaining_pending": ["AI-TECH对应性", "ATL Colombia同名", "ATL Panama候选", "Upstream清算中", "DONGIL(名录)官网"],
    "stats": {"entries": len(entries), "profile_blocks_appended": n},
}
out = os.path.join(ROOT, "batch", "contact_research-2026-10-18_R3_型号价格待核收尾.json")
json.dump(batch, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("batch:", out)
print("stats:", batch["stats"])
missing = [e["tag"] for e in entries if not e["profile"]]
print("未挂档案:", missing)
