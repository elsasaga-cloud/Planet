#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""仓库结构自检：对齐 mikrotik-info 范式（仅结构，不校验其内容）。"""
import os
import re

ROOT = os.path.join(os.path.dirname(__file__), "..")

REQUIRED_FILES = [
    "AGENT-CONSTITUTION.md",
    "AGENT-README.md",
    "README.md",
    "宪法-对话记录.md",
    ".gitignore",
    "docs/requirements/用户要求总账.md",
    "docs/rules/客户档案结构与内容规则.md",
    "docs/evidence/来源规则与资料地图.md",
    "docs/audit/全仓审计.md",
    "profile/00-索引.md",
    "batch/Edgecore渠道名录_R1_2026-10-18.json",
]

REQUIRED_DIRS = ["profile/A", "profile/B", "profile/C", "batch", "docs/audit", "docs/evidence",
                 "docs/history", "docs/requirements", "docs/rules", "docs/sales", "scripts", "tests"]

def test_structure():
    for f in REQUIRED_FILES:
        assert os.path.isfile(os.path.join(ROOT, f)), f"缺少文件: {f}"
    for d in REQUIRED_DIRS:
        assert os.path.isdir(os.path.join(ROOT, d)), f"缺少目录: {d}"

def test_a_profiles_17_sections():
    """A 类档案应包含 17 节骨架的节标题。"""
    a_dir = os.path.join(ROOT, "profile", "A")
    names = [n for n in os.listdir(a_dir) if n.endswith(".md")]
    assert names, "A 类档案为空"
    for n in names:
        text = open(os.path.join(a_dir, n), encoding="utf-8").read()
        assert text.startswith("---") and "structured_profile" in text, f"{n} 缺 YAML"
        for sec in ["SALES BRIEF", "基本事实", "联系方式", "跟进步骤", "跟进记录", "下次复核"]:
            assert sec in text, f"{n} 缺节: {sec}"
        assert re.search(r"【推断】|事实", text), f"{n} 缺事实分层"

def test_profile_frontmatter_not_fenced():
    """A/B/C 档案须用标准 YAML frontmatter，禁止把代码围栏塞进 YAML 头。"""
    for grade in ("A", "B", "C"):
        profile_dir = os.path.join(ROOT, "profile", grade)
        names = [n for n in os.listdir(profile_dir) if n.endswith(".md")]
        assert names, f"{grade} 类档案为空"
        for n in names:
            text = open(os.path.join(profile_dir, n), encoding="utf-8").read()
            lines = text.splitlines()
            assert lines[:2] == ["---", "structured_profile:"], f"{n} YAML 头不是标准 frontmatter"
            try:
                end = lines.index("---", 1)
            except ValueError:
                assert False, f"{n} YAML 头缺结束标记"
            frontmatter = lines[2:end]
            assert frontmatter, f"{n} YAML 头为空"
            assert not any(line.startswith("```") for line in frontmatter), f"{n} YAML 头内含代码围栏"
            assert all(
                not line.strip() or re.match(r"^  [A-Za-z_][A-Za-z0-9_]*:.*$", line)
                for line in frontmatter
            ), f"{n} YAML 字段缩进不规范"

def test_conversation_log_timestamped():
    text = open(os.path.join(ROOT, "宪法-对话记录.md"), encoding="utf-8").read()
    assert re.search(r"20\d\d-\d\d-\d\d \d\d:\d\d:\d\d", text), "宪法记录缺时间戳"
    assert "对话 #1" in text, "宪法记录缺对话条目"

if __name__ == "__main__":
    test_structure()
    test_a_profiles_17_sections()
    test_profile_frontmatter_not_fenced()
    test_conversation_log_timestamped()
    print("✅ 结构自检全部通过")
