# R3 台账（2026-10-18）三线：①20强在售型号深挖对位报价 ②各国价格带 ③待核11项收尾
# 格式：公司|维度|发现|对位/结论|src
RaviSingh|①产品|Cisco 9400/9300转售+Fibrsol OLT/ONU+Mikrotik/Huawei/Ubiquiti/Tenda+光纤熔接/GPON;KP扩充Ajay Jha(CEO)/Harpreet Singh(全国销售高级经理)/Umesh Lakhera;⚠️Delhi HC诉讼vs Sify(2024,塔租发票)做电信塔工程,51-200人|对位:AS4610系(替换Cat9300话术)+ECS2100替代+PoE++;FTTH配纤|src=indiamart;exportersindia;rocketreach;legitquest
CRCT|①产品|官网无具体型号(LinkedIn描述);Open Networking/SDN/HCI/OpenStack|对位:AS4610/AS7326白牌+SONiC系;中美洲首家|src=linkedin
DataInMotion|①②产品+价格|MikroTik泰铢价表:RB260GS 1600฿/CRS等;多品牌白牌|对位:接入层PoE报泰铢区位;ECS2100替代|src=datainmotion.co.th
VESC|①产品|Edgecore全线类目(L3/L2/Web-Smart/Industrial/ON)+IgniteNet+Planet Industrial;★Reddit证据:IgniteNet Fusion贴牌Edgecore(FNS-10P=ESC2100-10P,28口=ECS4120-28T/P)|对位:ECS4120同门替代话术(Edgecore ODM贴牌自证)|src=vesc.com.my;reddit
HardwareNation|①产品|Edge-Core品牌页244 SKU在售(DC为主+Enterprise类目)+HN True SONiC/OcNOS/PicOS套餐|对位:Enterprise接入层+SONiC白牌;他们是DC重镇,接入口弱=机会|src=hardwarenation.com
Solimedia|②价格|MikroTik CAD零售价表:CRS326-24G $284.69/CRS328-24P(24口PoE) $665.24/CRS354-48P $1357.65/CSS326 $216.02|对位:北美PoE24/48口价格带锚点|src=solimedia.net
ColfaxDirect|②价格|★AS4610-54T实价$1725-2142.50;AS4610-54P(PoE) $2984.00|对位:AS4610系美区零售锚点,替代报价直接参考|src=colfaxdirect.com
VEMAX|①②产品+价格|Grandstream GWN交换机线(7700非网管/7800管理)+Wi-Tek云管PoE(WI-PCES306G €61.80/310GF €138.60欧区参考)|对位:PoE入门款价格带;政府/ITSP渠道|src=vemax.com.my;rts-bg;grandstream blog
Sapphire|①②产品+价格|网络交换机转售D-Link/Cisco/TP-Link+CCTV;印度价格带:DGS-1210-28P ₹27800/DGS-1210-24 ₹8500-13750/DES-1210-28P ₹9000/CBS110-24T ₹20000/C9300-48T-E ₹315000/TP-Link SG1024D ₹6000|对位:STC-2426P对位DGS-1210-28P价盘;Cat替换话术|src=tradeindia;indiamart;sapphire-india
PT-Gwen|①产品|Sangfor全线(NGAF/HCI/SD-WAN/IAM)+Ruckus;★Platinum Partner+2020/2021 Global Partner Award连续;KP扩充Yusa Arifki Heriawan(CCNA/Ruijie WLAN认证+Sangfor SCTA);政府/大学客户(UNG)|对位:缺交换机线=接入口;配Sangfor防火墙带STC/STI;Ruijie=又一中国品牌经验|src=gwen.id;sangfor;businesswire;linkedin
PT-Trinet|①产品|方案商:Campus/DC/SD-WAN/Open SDN/DDI/ADC+GPON/光纤骨干;VMware替代/MSP;无强品牌绑定|对位:Open SDN配套白牌接入层|src=trinetprimasolusi.net
Starview|①产品|★★Edgecore授权分销(专页+2025-11 newsletter主推ECS5500-12T/12P:10G L2+/Lite L3 PoE++多千兆Wi-Fi 7)+IP Infusion VAD(AS5835-54T OcNOS)+自产光模块(可重编程)|对位:★ECS5500=STI PoE++线直接对标;竞合双性(原厂分销vs白牌互补);光模块可配套|src=starviewtech.net;linkedin
DSG|①产品|Supermicro韩国首家总代+NVIDIA Solution Provider(Blackwell/GB200);服务器/存储/GPU/HPC;交换机仅Supermicro SSE系(SSE-C4632 SONiC);⚠️风险注记:2026-03 NYT Supermicro出口违规起诉案|对位:服务器配套ToR/接入白牌;合规敏感需低调|src=dsngsystem.co.kr;platformalliance;nytimes
INFO-A|①产品|Edgecore韩国名录内伙伴(电话+82 2 469 7550);SMB→open networking定位;OMSWK社区|对位:Open Networking白牌线|src=edge-core;twitter
Micromap|①产品|Motorola对讲机/中继(XiR R8200 ₹195000)/WPC政府授权/1998老店51-200人/OFC/微波/5G自研——无线通信为主非交换机|对位弱:工业无线/中继配套|src=micromap.co.in;micromaponline
SuccessNetwork|①产品|★Planet L3/L2+全线主力(SGS-6341堆叠/GSW-2620VHP 24口PoE)+Wi-Tek户外PoE/太阳能+ORing工业+TVT CCTV|对位:STC对位Planet GSW系直接替换话术;PoE++强需求|src=success-network.co.th
Positron|①产品|SI全案(桌面机/服务器/UPS/ATM/POS/布线/router/switch/PABX/酒店赌场银行方案);IBM/ManageEngine/QNAP|对位:酒店PABX配PoE接入;方案内嵌|src=positronmultiverse.com
NETCOM|①产品|★planet.com.vn=NETCOM运营!Planet越南总代(2000起);SGS-6341/GS-4210/IGS工业系;越南价GS-4210-16T2S 3230000VND≈$122|对位:STC对位Planet GS-4210系;越南总代体系可借道|src=planet.com.vn;tnc.com.vn
FONPERU|①产品|★★商店页全套在售Edgecore:ECS4120-52T/28FV2(-I)/28T+ECS4100-52P/52T/28P/28TC/28T/12PH/12T+ECS2100-10P/10PE/10T+AS4630-54PE+Pica8 PicOS——ECS系列完整对位清单!官方分销商|对位:逐型号给出STC/STI对位报价;ECS2100停产缺口(他们店还有10P/10PE=尾货)|src=fonperu.com
LEDRIUM|①产品|Cisco/HPE/PaloAlto品牌线(无白牌);AI平台转型|对位:品牌替换/降本话术|src=goledrium.cl
②ECS系美区价格|②价格|ECS4100-52P $769.98(compsource)/$398.95(eBay新);ECS2100-28P $339.92-439.99(CDW);ECS2100-28PP $452.54-586.99;ECS4100-12T $299-307.99(CDW)|对位:STC-2426P成本+20%须低于$339锚点|src=compsource;cdw;ebay
②AS4610系价格+EOL|②价格|★AS4610-30P $2218(superwarehouse)/$1884(provantage);AS4610-30T $2815CAD(Solimedia);AS4610-54T $1725-2142(Colfax);AS4610-54P $2984-4099;★2025-06-30 AS4610系EOL公告:54T→AS4625-54T/54P→AS4625-54P/30T→Not Available无替代!|★EOL矩阵更新:AS4610-30T无替代=最强话术(我们的STC-2426T补位);54P替代AS4625|src=superwarehouse;provantage;edge-core eol
②竞品价格Ubiquiti/Ruckus/Aruba|②价格|USW-24-PoE $379/USW-Pro-24-PoE $699/USW-Pro-48-PoE $1099(48口L3 PoE++600W)/Ruckus ICX $835-1000起/Aruba 6100-48G-PoE墨西哥$4736智利$5.8-7.2M CLP;菲律宾:DGS-1100-24PV2 ₱16150/RG-S2928G-24P ₱23935/USW-Pro-24 ₱56400|对位:STI-4848P对标USW-Pro-48($1099)破价;拉美Aruba高价=溢价空间|src=store.ui.com;trustradius;compratecno;pcx.com.ph
DONGIL|③待核|dongiltech.co.kr=동일기연KOSDAQ 032960 EMC/压电/医疗器械商(1986,201-500人,中国威海工厂)≠名录DONGIL TECH(网络,+82-31-216-7122);电话反查无命中|结论:同名不同司确认;名录DONGIL TECH官网仍未定位维持待核(范围缩小)|src=dongiltech.co.kr;fss;kind
FibRSol主体|③解锁|fibrsol.com=FibRSol Global Network Limited(CIN U74999DL2017PLC327281,Public 2017);董事Suresh Singh/Pradeep Pandey/Ajay Kumar Jha;★R.S.Communication为其官网Where to Buy列名分销商(D-76 Sector-63 Noida,8130049241)——主体锁定!|解除待核;触达走FibRSol渠道体系|src=fibrsol.com;zaubacorp
LANOASIS-UNICLASS|③解锁|uniclass.co.kr=lanoasis家族站;历史:2012-06 UNICLASS KOREA BRANCH→2017-06 EdgeCore KOREA BRANCH;产品线EDGECORE(L3/L2/Web-smart Pro)+ACRONET自有KVM品牌(2022)+Raritan+Legrand;26人150亿韩元|解除待核:LANOASIS=Edgecore韩国分支渠道(UNICLASS关联品牌)已锁定|src=lanoasis.com/page/history;uniclass.co.kr;jobkorea
NDC|③解锁|edge-core名录(Estar Bldg 147-149 Vo Van Tan District 3 HCMC,(028)35200096)=ndcjsc.com(N.D.C JSC,20+年ICT/电信基建);≠Tan Binh电信设备商|解除待核:已锁定ndcjsc.com|src=edge-core;ndcjsc.com
