# Christopher Fikes

> **评级 A**　|　美国 · Silsbee, TX　|　档案编号 `A-311`　|　优先级 ★★★　|　状态：02-已双向对话（2 轮）；截至 2026-10-12 无新回复
>
> **触达状态（Stage）**：02-replied　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-311
rating: A
country: 美国
biz_org: 公司/工作室（有官网）
business_model: 培训交付
decision_speed: moderate
price_sensitivity: medium
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: true, l2plus: true, voice: true, oem: false, hotel: false, training: true}
p1: STC-424XGGPM-280W
stage: 02-replied
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；培训交付
- **商业模式**：培训交付
- **为什么值得跟**：有明确交换/供电需求（交换专长），三星重点
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — Fikes Media 美 TX MikroTik 顾问+培训双收录（function not vendors+/mikrotik-consulting 路径）：顾问对照单元（$180 锚点一致）；地方政府/K12 守界句；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Which switch do you currently put on the bench for the VLAN/PoE lab demos?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：按 R69 已有“参数包已留档；无回复即冻结”规则暂停主动跟进。无新采购或评估信号，不发第三次无差别催促或第三封通用跟进；若客户主动询问或出现明确商业 SMB/DC 选型窗口，再重启。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Christopher Fikes（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 美国 / Silsbee, TX | 事实 |
| 网站 | https://www.fikesmedia.com | 事实 |
| 类型 | 集成商/顾问（MikroTik 认证） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | MikroTik 认证顾问，持 MTCRE | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 培训交付 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Christopher Fikes:Christopher Fikes(美国／Silsbee, TX;**【人名司名同体=CSV 公司名即本人谱位,official-self-published 级金谱】**;类型: 集成商/顾问(MikroTik 认证);培训交付谱;档站 https://www.fikesmedia.com;fikesmedia.com=德州东部顾问铺谱;**地方政府/K12 守界句**;A-311 供位旧差(STC-424 vs CONSULT-OEM)→本波 push≡p1 归位)
- 【推断】R66 第 21 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-08, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：MikroTik 认证顾问，持 MTCRE）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、万兆上行/骨干、L2+ 交换管理（VLAN/ERPS/QinQ）、VoIP/Voice VLAN、教学教具
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - 万兆上行/骨干：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖
  - VoIP/Voice VLAN：【推断】依据 CSV 信号/深挖
  - 教学教具：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：sales@fikesmedia.com
  - 状态：02-已双向对话(2 轮)
- **电话**：+1 409.877.4220
- 来源等级：official-company（R41–R48 联系方式台账口径）
- **原始联系字段**：sales@fikesmedia.com（官网联系页Sales；支持support@fikesmedia.com）；+1 409.877.4220（销售Option 1/支持Option 2）
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Christopher Fikes**(MikroTik 认证培训师/顾问(档谱:CSV 公司名字段即本人))— 档谱+档站自署 〔已有(公司官方公开件/登记册自曝);源:https://www.fikesmedia.com〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Christopher Fikes | MikroTik 认证培训师/顾问(档谱:CSV 公司名字段即本人) | 档谱+档站自署 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.fikesmedia.com |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 声明边界+商业段接入层评估位

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行 L2+）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：简短一封：只做商业 SMB/Enterprise 段的接入层高性价比选型（您的 function-not-vendors 理念对味；公立段不经由我们）。
- **要问的问题**：您商业客户的接入层选型里有评估新硬件的流程吗？
- **随附证明**：一页规格（英）+ TCO 对照示例。

### 第 2 次跟进 · DC 咨询场景 DAC/SFP+万兆件

- **推什么**：STC-424XGGPM-440W（Saga） + DAC/SFP（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：其数据中心咨询（ToR/VXLAN）场景的万兆件与互连配件。
- **要问的问题**：DC/汇聚场景需要高性价比万兆件吗？
- **随附证明**：万兆件一页+配件价卡。

### 第 3 次跟进 · 参数包留档收口

- **推什么**：—（参数包）
- **切入点**：全品类参数包留档供选型引用；无回复即冻结。
- **要问的问题**：（无需回）参数留档。
- **随附证明**：全品类参数一页。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-10-09**；原始记录：`batch/A类加厚_2026-10-09_R69_跟进增厚批1.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：美国德州顾问+培训师双收录位（Fikes Media）
- **产品线与在售品牌**：企业网/DC 网设计/VoIP/咨询；MTCRE+MikroTik 咨询页在站。
- **目标行业与场景**：德州东南部 SMB/企业（公立两域划出）。
- **团队与规模**：主理人咨询商。
- **决策链与对接人**：本人即决策（短链）
- **技术与认证**：MTCRE（CSV 9-23 名录）；20+ 年公共部门网络经验。
- **采购与供应链信号**：**功能导向+压 TCO 方法论=白盒对频**：商业客户的接入层/汇聚件评估位+其 DC 咨询的 DAC/SFP 件。
- **近期动态与线索**：咨询页米名 mikrotik-consulting=把 MikroTik 咨询当产品卖，懂成本控制话术。
- **与我方契合点**：商业段 24 口 PoE 接入层评估位+万兆上行件+DAC/SFP。
- **风险与注意**：地方政/K-12 段绝不谈（他的主粮仓）；与 IP ArchiTechs 同规：他是咨询选型人，不给渠道返点话术。
- **跟进实况**：02-replied 已双向对话 2 轮；参数包已留档
- **报价纪律**：无回复即冻结

### R54 原文证据摘录（全部保留）

- **【业务定位】**德州 Silsbee 的网络咨询/集成：**「Lower Technology Cost And Get More — It's about function, not vendors.」**——功能导向降 TCO 咨询；方案=企业网/数据中心网（VXLAN/ToR）/开放语音/咨询。
  > Lower Technology Cost And Get More — It's about function, not vendors. ‖ Datacenter Networking — High speed throughput, top of rack connectivity, VXLAN, or a custom solution.
  > 来源：https://www.fikesmedia.com/
- **【目标行业与场景】**三大客群自述：**Local Government（图书馆/市政厅/警局——公立面划出）/K-12 And Higher Education（公立教育面划出）**/SMB and Enterprise（商业面可做）——他 20+ 年公共部门背景（CSV），我们只做商业段。
  > Local Government — From the local library to city hall and your hometown police department ‖ K-12 And Higher Education ‖ SMB and Enterprise
  > 来源：https://www.fikesmedia.com/
- **【决策链与对接人】**sales@fikesmedia.com 官网联系页 Sales+支持 support@（CSV 9-27 official-company）；+1 409.877.4220（Option 1 销售）。
  > （CSV 2026-09-27 记录）官网联系页给销售 sales@fikesmedia.com、支持 support@、+1 409.877.4220；official-company
  > 来源：https://www.fikesmedia.com/
- **【背景】**美国德州 Silsbee，Fikes Media；MikroTik 顾问+认证培训双收录（function not vendors+/mikrotik-consulting 路径）。
  > Fikes Media 美 TX MikroTik 顾问+培训双收录（function not vendors+/mikrotik-consulting 路径）
  > 来源：https://mikrotik.com/consultants
- **【联系通道】**邮箱 sales@fikesmedia.com；电话 +1 409.877.4220。
  > 域 fikesmedia.com 存活=可投递到域（MX/DNS 级核验口径）
  > 来源：https://fikesmedia.com/
- **【跟进实况】**已双向对话 2 轮；全品类参数包已留档供选型引用。
  > 已双向对话(2 轮)（档案状态行）
  > 来源：—（用户侧邮件实况）

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第21波50户.json`；价格均为 EXW 快照。

- **①背景再核**：Christopher Fikes(美国／Silsbee, TX;**【人名司名同体=CSV 公司名即本人谱位,official-self-published 级金谱】**;类型: 集成商/顾问(MikroTik 认证);培训交付谱;档站 https://www.fikesmedia.com;fikesmedia.com=德州东部顾问铺谱;**地方政府/K12 守界句**;A-311 供位旧差(STC-424 vs CONSULT-OEM)→本波 push≡p1 归位)
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Christopher Fikes(MikroTik 认证培训师/顾问(档谱:CSV 公司名字段即本人),official-self-published·谱/leads-only(直发需 opt-in))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-08, 15天有效))
- **⑤在乎与偏好**：MTCSWE/交换认证谱=对口窗

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**国家/城市: %s;网站: %s;类型: 集成商/顾问(MikroTik 认证)(档案基础画像行=事实)
  > 国家/城市: %s;网站: %s;类型: 集成商/顾问(MikroTik 认证)(档案基础画像行=事实)
  > 来源：https://www.fikesmedia.com
- **【近期动态与线索】**档定首触角: 顾问对照单元($180 锚点一致);**地方政府/K12 守界句**
  > 档定首触角: 顾问对照单元($180 锚点一致);**地方政府/K12 守界句**
  > 来源：https://www.fikesmedia.com
- **【目标行业与场景】**档定值得跟: 有明确交换/供电需求(交换专长 MTCSWE),且有具体人直联
  > 档定值得跟: 有明确交换/供电需求(交换专长 MTCSWE),且有具体人直联
  > 来源：https://www.fikesmedia.com

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Christopher Fikes(美国／Silsbee, TX;**【人名司名同体=CSV 公司名即本人谱位,official-self-published 级金谱】**;类型: 集成商/顾问(MikroTik 认证);培训交付谱;档站 https://www.fikesmedia.com;fikesmedia.com=德州东部顾问铺谱;**地方政府/K12 守界句**;A-311 供位旧差(STC-424 vs CONSULT-OEM)→本波 push≡p1 归位)
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：培训交付谱(MTCSWE 谱链)
- **团队与规模**：单铺/工作室谱
- **决策链与对接人**：**Christopher Fikes(MikroTik 认证培训师/顾问(档谱:CSV 公司名字段即本人),official-self-published·谱/leads-only(直发需 opt-in))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 21 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Dear Chris,(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Fikes Media 美 TX MikroTik 顾问+培训双收录（function not vendors+/mikrotik-consulting 路径）：顾问对照单元（$180 锚点一致）；地方政府/K12 守界句 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：MTCSWE/交换认证谱=对口窗
- **W**：单铺谱
- **O**：Christopher Fikes 本人直达位
- **T**：MikroTik 官方课链

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**本户特别红线/停止条件**

- 教师红线：不打学员名单、不经培训语境推销

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Chris,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **回复状态**：截至 2026-10-12 无新回复（用户报告并经 Gmail 核对）；保留既有双向沟通阶段。
- **后续节奏**：本户现按既有“无回复即冻结”暂停；不发第三次无差别催促或第三封通用跟进。只有明确采购/评估信号或客户主动联系时重启，不补造日期。
<!-- R71-FOLLOWUP-END -->
