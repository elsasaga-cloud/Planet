# Microstar sp. z o. o.

> **评级 A**　|　波兰 · Warsaw　|　档案编号 `A-082`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-082
rating: A
country: 波兰
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: false, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STI-288GP
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（交换专长、PoE/监控/门禁、工业/楼宇），且有具体人直联
- **P1（首触唯一主推）**：STI-288GP（工业非管理 8口 PoE） — Microstar 华沙 Perle 分销（站维护页）：Perle 旁并架（$74.8 锚点一致）维护期电话并行；$74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Microstar sp. z o. o.（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 波兰 / Warsaw | 事实 |
| 网站 | microstar.com.pl | 事实 |
| 类型 | 分销/集成商（Perle 授权） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Perle Systems（工业 PoE 交换机 / 媒体转换 / 串口设备联网） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Microstar sp. z o. o:Microstar sp. z o.o.(波兰 Warszawa,Gizów 6, 01-249;+48 22 836 52 73;传真 +48 22 836 53 78;microstar.com.pl 波兰电脑/电子批发档;ATTO Technology 波兰分销名录页具名联系人;排噪:巴西 Microstar(CB Insights,圣保罗维修)/丹麦 Microstar Logistics(美 Keg 物流)/波兰 Agrosimex 肥料 Microstar Complex 均非本体)
- 【推断】R66 第 11 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Perle Systems（工业 PoE 交换机 / 媒体转换 / 串口设备联网））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：piotr.pieczerak@microstar.com.pl
  - 状态：既有/公开
- **电话**：+48 22 8365273
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：+48 22 8365273 / piotr.pieczerak@microstar.com.pl（具名联系人 Piotr Pieczerak（atto.com 厂商名录收录）。⚠️波兰法人，勿与克罗地亚 Microstar 合并）
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Piotr Pieczerak**(具名联系人(ATTO 分销名录口径;直邮 piotr.pieczerak@microstar.com.pl))— atto.com 分销名录页具名+直邮 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://www.atto.com/microstar-sp-z-o-o/〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Piotr Pieczerak | 具名联系人(ATTO 分销名录口径;直邮 piotr.pieczerak@microstar.com.pl) | atto.com 分销名录页具名+直邮 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://www.atto.com/microstar-sp-z-o-o/ |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STI-288GP（工业非管理 8口 PoE）），备选型不进邮件。

### 第 1 次跟进 · 品类空缺补位（Perle 价位段的工业 PoE）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：与 Piotr 直聊：Perle 同款 8 口宽温 DIN PoE 的价位段能不能多一个利润更高的货架位。
- **要问的问题**：Perle 8 口 PoE 的走量型号是哪个？要不要加一个对照位？
- **随附证明**：同规格对照 + 到岸价目 + 交期（英文）。

### 第 2 次跟进 · 工业非管理 PoE 第二来源（项目配套）

- **推什么**：STI-240GE（Saga） PoE 版（4G + 2×SFP，DIN，-40~75°C）
- **切入点**：他系统集成项目的零散点位：4 口小机随柜配套，起订灵活混批，先试一单看动销。
- **要问的问题**：项目配套的小口数工业 PoE 现在什么渠道拿？
- **随附证明**：混批价目 + 宽温报告 + DIN 图。

### 第 3 次跟进 · 管理型 10G（楼宇/机房段+项目注册）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：楼宇/机房段的上行升级单：管理型 VLAN/ERPS 模板+项目注册制，给他把大项目的网络段整包。
- **要问的问题**：楼宇项目的网络段有没有在投标中的？
- **随附证明**：项目注册政策 + VLAN/ERPS 模板 + 实测。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第5批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：华沙独立法人的 IT 分销/集成公司（Perle 授权渠道）；⚠️ 与库内另一家 Microstar（克罗地亚/斯洛文尼亚，Westermo 渠道）不是一家，建档与发件都别混。
- **产品线与在售品牌**：Perle 工业 PoE/媒体转换/串口联网（CSV 记录）；官网维护中，货架细节待站恢复或电话确认。
- **目标行业与场景**：波兰工业与楼宇项目的串口联网/边缘连接配套。
- **团队与规模**：sp. z o.o. 有限责任公司，Gizów 6 注册办公，规模小型。
- **决策链与对接人**：具名联系人 Piotr Pieczerak（+48 22 836 52 73 / piotr.pieczerak@microstar.com.pl）。
- **技术与认证**：系统集成定位（本地登记页）；Perle 授权分销商（CSV 记录）。
- **采购与供应链信号**：分销+集成混合：渠道分销走量+项目配套毛利；维护期网站说明线上投入弱，电话/邮件直达有效。
- **近期动态与线索**：官网维护模式（2026-09-28 抓取）——可能改版中；上线改版完成时往往是重排供应商货架的节点。
- **与我方契合点**：Perle 同规格工业 PoE 的价差对话 + 串口联网旁的交换配套段。
- **风险与注意**：同名混淆风险：建档/报价单上写全「Microstar sp. z o.o., Gizów 6, Warszawa」；别用库内另一家 Microstar 的信息套他。

### R54 原文证据摘录（全部保留）

- **【近期动态与线索】**官网当前全站维护模式，无业务内容可取——货架还转不转要看线下。
  > Serwis w trakcie prac konserwacyjnych. Przerwa techniczna powinna się wkrótce skończyć. Przepraszamy za niedogodności i dziękujemy za cierpliwość.
  > 来源：https://www.microstar.com.pl/
- **【决策链与对接人】**第三方厂商目录（atto，疑为 Perle 渠道页镜像）：地址/电话/具名邮箱与 CSV 记录一致，交叉印证通过。
  > Microstar sp. z o.o. — Gizow 6, 01-249 Warsaw, Poland · Tel: +48 22 836-52-73 · Email: piotr.pieczerak@microstar.com.pl
  > 来源：https://www.atto.com/microstar-sp-z-o-o/
- **【业务定位】**本地商业登记聚合页：主业「计算机与互联网」，专长「系统集成」——华沙老牌集成分销。
  > podstawowa branża to komputery i internet, natomiast specjalizacja to integracja systemów. Siedziba firmy znajduje się pod adresem ul. Gizów 6, 01-249 Warszawa.
  > 来源：https://efipo.pl/warszawa/microstar-sp-z-oo

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第11波.json`；价格均为 EXW 快照。

- **①背景再核**：Microstar sp. z o.o.(波兰 Warszawa,Gizów 6, 01-249;+48 22 836 52 73;传真 +48 22 836 53 78;microstar.com.pl 波兰电脑/电子批发档;ATTO Technology 波兰分销名录页具名联系人;排噪:巴西 Microstar(CB Insights,圣保罗维修)/丹麦 Microstar Logistics(美 Keg 物流)/波兰 Agrosimex 肥料 Microstar Complex 均非本体)
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Piotr Pieczerak(具名联系人(ATTO 分销名录口径;直邮 piotr.pieczerak@microstar.com.pl),leads-only·待 opt-in(LinkedIn/谱面带核))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：具名直邮已获(Pieczerak)

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Microstar sp. z o.o., Gizów 6, 01-249 Warsaw, Poland;Tel: +48 22 836-52-73;Email: piotr.pieczerak@microstar.com.pl(ATTO Technology 分销名录页)
  > Microstar sp. z o.o., Gizów 6, 01-249 Warsaw, Poland;Tel: +48 22 836-52-73;Email: piotr.pieczerak@microstar.com.pl(ATTO Technology 分销名录页)
  > 来源：https://www.atto.com/microstar-sp-z-o-o/
- **【业务定位】**MICROSTAR — Gizów 6, 01-249 Warszawa(Wola);22 836 52 73;Computers(名录口径一致)
  > MICROSTAR — Gizów 6, 01-249 Warszawa(Wola);22 836 52 73;Computers(名录口径一致)
  > 来源：https://www.yelp.com/biz/microstar-warszawa
- **【近期动态与线索】**2026-10-08 R66 11 波:身份锁定=华沙 microstar.com.pl 本体(巴西/美同名件排录);波次二=波兰 KRS/CEIDG 登记册按号反查董事层
  > 2026-10-08 R66 11 波:身份锁定=华沙 microstar.com.pl 本体(巴西/美同名件排录);波次二=波兰 KRS/CEIDG 登记册按号反查董事层
  > 来源：https://ekrs.ms.gov.pl/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Microstar sp. z o.o.(波兰 Warszawa,Gizów 6, 01-249;+48 22 836 52 73;传真 +48 22 836 53 78;microstar.com.pl 波兰电脑/电子批发档;ATTO Technology 波兰分销名录页具名联系人;排噪:巴西 Microstar(CB Insights,圣保罗维修)/丹麦 Microstar Logistics(美 Keg 物流)/波兰 Agrosimex 肥料 Microstar Complex 均非本体)
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：波兰华沙电脑/网通件批发商
- **团队与规模**：(KRS 谱波次二补)
- **决策链与对接人**：**Piotr Pieczerak(具名联系人(ATTO 分销名录口径;直邮 piotr.pieczerak@microstar.com.pl),leads-only·待 opt-in(LinkedIn/谱面带核))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 11 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Pieczerak 具名直邮(leads-only;opt-in 律);KRS 反查点名

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STI-288GP（工业非管理 8口 PoE） | 主场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Microstar 华沙 Perle 分销（站维护页）：Perle 旁并架（$74.8 锚点一致）维护期电话并行 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：工业非管理 8口 PoE af/at，250m 延伸供电，冗余 DC44–57V（过压/反接保护），DIN 轨，3 年保
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：具名直邮已获(Pieczerak)
- **W**：实体规模谱面薄
- **O**：KRS 登记册反查可破
- **T**：同名噪声高

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Hi Piotr,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
