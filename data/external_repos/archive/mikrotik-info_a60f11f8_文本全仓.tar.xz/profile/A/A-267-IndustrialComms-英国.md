# IndustrialComms

> **评级 A**　|　英国　|　档案编号 `A-267`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-267
rating: A
country: 英国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: false, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（交换专长、PoE/监控/门禁、工业/楼宇），三星重点
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — IndustrialComms 英尔工业网络专店（Belden/Hirschmann/Ruggedcom/Beijer）：私营工业段替补窄位（$180 锚点一致）；公用事业段守界标注；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | IndustrialComms（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 英国 | 事实 |
| 网站 | https://www.industrialcomms.com | 事实 |
| 类型 | 专业分销 | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | EtherWAN | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】IndustrialComms:IndustrialComms / Industrial Communication Products Ltd(英国 Toddington(Bedfordshire);**2008 创 18 年;2-10 人;工业级通信件 B2B 专营(UK&Eire 工业/公用事业)**;**CEO Graham Bull(Advantech 2021 XII 分件官方引语=O)**;品牌谱 **Hirschmann/RuggedCom/Advantech/Siemens Scalance/ATOP(IEC 61850 变电站+EN50155 轨交谱)**;SHDSL/VDSL/以太延长谱;水电交通=公用守界注
- 【推断】R66 第 20 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：EtherWAN）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：sales@industrialcomms.com
  - 状态：既有/公开
- **电话**：—
- 来源等级：official-company（R41–R48 联系方式台账口径）
- **原始联系字段**：sales@industrialcomms.com（官网联系页正文）；原入口：官网+LinkedIn
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Graham Bull**(CEO(Advantech 2021 分件官方引语))— designsolutionsmag.co.uk 件(引语) 〔已有(公司官方公开件/登记册自曝);源:https://designsolutionsmag.co.uk/advantech-chooses-industrialcomms-as-uk-distributor/〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Graham Bull | CEO(Advantech 2021 分件官方引语) | designsolutionsmag.co.uk 件(引语) | official-self-published·谱/leads-only(直发需 opt-in) | https://designsolutionsmag.co.uk/advantech-chooses-industrialcomms-as-uk-distributor/ |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 工业非管理低价档一页（报价单空档位）

- **推什么**：STI-280GE（Saga）（工业非管理 8×电口 + 2×上联光，宽温）
- **切入点**：英语一封：其高端锚牌报价之外，现场只需非管理宽温件时的价位档第二来源（CE/宽温/振动参数一体）。
- **要问的问题**：客户预算卡死但现场就要宽温非管理件时，你们的报价空档谁来填？
- **随附证明**：工业件一页 + 参数包。

### 第 2 次跟进 · 仓储/交通监控 24 口商业款

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行 L2+）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：Warehouse Logistics/Transport 客户的监控房 24 口商业 PoE（工业件之外的商业线空档）。
- **要问的问题**：仓储/交通监控项目的大口数 PoE 目前指向哪款？
- **随附证明**：24 口一页价卡。

### 第 3 次跟进 · 工业 SFP 窄线

- **推什么**：工业级 SFP/SFP+（宽温）目录
- **切入点**：宽温光配件窄线低价档（锚牌光件价高）。
- **要问的问题**：宽温 SFP 有补价位档需求吗？
- **随附证明**：工业 SFP 一页价卡。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第14批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：英国工业连接专业分销（Belden/Hirschmann/Siemens/Ruggedcom 现墙+EtherWAN/Atop 底仓关系）——**锚牌最密的一户**：1/3 价第二来源直击。
- **产品线与在售品牌**：工业以太交换/HMI/光纤接续/OT 安全/电源；六行业页。
- **目标行业与场景**：水务/电力/交通/工厂自动化/仓储物流/油气/海事——全是对口严酷环境。
- **团队与规模**：中型专业分销（专家热线话术）。
- **决策链与对接人**：sales@industrialcomms.com（页尾正文+表单，CSV 9-27）。
- **技术与认证**：EtherWAN/Atop 分销（CSV 渠道记录）；Belden 系现墙。
- **采购与供应链信号**：锚牌价位高：仓库物流/交通监控的现场非管理件与低价位档=补报价单空档；**Hirschmann/Ruggedcom 排位不碰**。
- **近期动态与线索**：换站 Shopify 化+伙伴墙更新=货架重构期，评估窗口。
- **与我方契合点**：工业非管理宽温 8 口低价档+24 口商业款（仓储/监控房）+SFP 工业件。
- **风险与注意**：锚牌密集禁替位话术；以「报价单空档价位档」自我定位。

### R54 原文证据摘录（全部保留）

- **【业务定位】**英国&爱尔兰工业网络方案伙伴（现站为 Shopify 新公司名 Industrial Communication Products Ltd）：自述供水务、交通与工业客户供工业联网/光纤/以太/无线/电源方案。
  > Your Trusted UK & Ireland Partner for Industrial Networking Solutions ‖ We supply high-quality industrial networking, fibre-optic, Ethernet, wireless and power solutions to utilities, transportation providers, and industrial clients across the UK.
  > 来源：https://www.industrialcomms.com/
- **【产品线与在售品牌】**现官网伙伴墙：**Belden/Hirschmann/Beijer Electronics/Siemens/RUGGEDCOM/EKS**；行业页六块 Water/Power/Transport/Factory Automation/Warehouse Logistics/Oil&Gas+Marine。EtherWAN（Phoenix Contact 系）与 Atop 英国分销身份来自 2026-09-22/23 渠道核验记录（CSV）。
  > （伙伴墙）belden · hirschmann · beijer · siemens · ruggedcom · eks fibre ‖ （CSV 2026-09-22/23 记录）EtherWAN、Atop 英国分销商
  > 来源：https://www.industrialcomms.com/
- **【决策链与对接人】**sales@industrialcomms.com 官网页尾正文+表单双入口（CSV 9-27 official-company）；技术热线 +44 0203 086 9569。
  > sales@industrialcomms.com ‖ +44 0203 086 9569 ‖ Our team at IndustrialComms will provide technical support to help you choose the right product
  > 来源：https://www.industrialcomms.com/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第20波50户.json`；价格均为 EXW 快照。

- **①背景再核**：IndustrialComms / Industrial Communication Products Ltd(英国 Toddington(Bedfordshire);**2008 创 18 年;2-10 人;工业级通信件 B2B 专营(UK&Eire 工业/公用事业)**;**CEO Graham Bull(Advantech 2021 XII 分件官方引语=O)**;品牌谱 **Hirschmann/RuggedCom/Advantech/Siemens Scalance/ATOP(IEC 61850 变电站+EN50155 轨交谱)**;SHDSL/VDSL/以太延长谱;水电交通=公用守界注
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Graham Bull(CEO(Advantech 2021 分件官方引语),official-self-published·谱/leads-only(直发需 opt-in))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：变电站/轨交认证件谱=OT 强契

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**「IndustrialComms CEO, Graham Bull, said: IndustrialComms is pleased to have access to the comprehensive range of Advantech industrial communication products」(Advantech 2021 分约件引语)
  > 「IndustrialComms CEO, Graham Bull, said: IndustrialComms is pleased to have access to the comprehensive range of Advantech industrial communication products」(Advantech 2021 分约件引语)
  > 来源：https://designsolutionsmag.co.uk/advantech-chooses-industrialcomms-as-uk-distributor/
- **【联系方式与基础画像】**Toddington, Beds;founded 2008;2-10 employees;020 3086 9569;**specialist distributor: Hirschmann/RuggedCom/Advantech/Siemens Scalance/ATOP(IEC 61850-3 substation+EN 50155 rail)**;UKs leading b2b supplier of Industrial Grade Communication Products(linkedin/facebook 件)
  > Toddington, Beds;founded 2008;2-10 employees;020 3086 9569;**specialist distributor: Hirschmann/RuggedCom/Advantech/Siemens Scalance/ATOP(IEC 61850-3 substation+EN 50155 rail)**;UKs leading b2b supplier of Industrial Grade Communication Products(linkedin/facebook 件)
  > 来源：https://uk.linkedin.com/company/industrial-communication-products-ltd

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：IndustrialComms / Industrial Communication Products Ltd(英国 Toddington(Bedfordshire);**2008 创 18 年;2-10 人;工业级通信件 B2B 专营(UK&Eire 工业/公用事业)**;**CEO Graham Bull(Advantech 2021 XII 分件官方引语=O)**;品牌谱 **Hirschmann/RuggedCom/Advantech/Siemens Scalance/ATOP(IEC 61850 变电站+EN50155 轨交谱)**;SHDSL/VDSL/以太延长谱;水电交通=公用守界注
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：英国贝德福德 18 年工业通信件专营分销
- **团队与规模**：2-10 人;2008 创
- **决策链与对接人**：**Graham Bull(CEO(Advantech 2021 分件官方引语),official-self-published·谱/leads-only(直发需 opt-in))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 20 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Graham Bull 直达(opt-in 律;水电公用守界)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | IndustrialComms 英尔工业网络专店（Belden/Hirschmann/Ruggedcom/Beijer）：私营工业段替补窄位（$180 锚点一致）；公用事业段守界标注 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：变电站/轨交认证件谱=OT 强契
- **W**：专营分销谱
- **O**：Bull CEO 直达位
- **T**：一线牌链竞谱

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Graham,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
