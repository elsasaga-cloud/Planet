# Silco Fire Protection & Security

> **评级 A**　|　美国　|　档案编号 `A-127`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-127
rating: A
country: 美国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；人工指定
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — Silco 多州消防安防 45,000 客户：随单柜+看门狗免回访（$180 锚点一致）；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Silco Fire Protection & Security（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 美国 | 事实 |
| 网站 | https://silcofs.com | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】波 27·A-127:美国谱: **守档准由·原 R56 谱基增厚**:Silco Fire & Security（俄亥俄）：消防安防区域领先商——消防全谱（报警/喷淋/应急照明/厨房抑制/BDA/群通知）+安防（报警/监控/门禁/K-12 校安/自动门转闸）；**45,000+ 客户、1,000+ Google 评价 4.9 星**；服务 OH/KY/IN/W-PA/底特律；技师多执照；Top Workplace 7 年;R66 第 27 波谱:我司 STC-424XGGPM-280W($165 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第13批.json,先报价不回、档案铺位、持续关注新一季,OK。
- 【推断】R66 第 27 波守档准由谱
- 【假设】档案铺位谱,持续关注新一季

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电
  - PoE 接入供电：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@silcofs.com
  - 状态：既有/公开
- **电话**：—
- 来源等级：official（R41–R48 联系方式台账口径）
- **原始联系字段**：info@silcofs.com [Publicly listed; delivery not tested]; https://silcofs.com
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。

## 关键人（KP）与触达通道

- 关键人未定位：首封信件以 info/通用邮箱开场并向其索要正确联系人。

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（监控/门禁项目接入层）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：4.5 万客户底盘的项目流：监控/门禁接入层 24 口 PoE++ 成本对照+分支库存方案，算给他听每月走量。
- **要问的问题**：监控/门禁项目的接入层现在批发价多少？每月走几台？
- **随附证明**：走量测算 + 阶梯价目 + 分支备货方案（英文）。

### 第 2 次跟进 · 工业级非管理 PoE（自动门/道闸电机点位）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：道闸/转闸门/车库门的联网点位：宽温 DIN PoE 扛冬夏，减少应急上门次数（他 2 小时应急成本高）。
- **要问的问题**：出入口机电点位的坏机率与应急上门成本？
- **随附证明**：宽温报告 + 坏机替换测算 + DIN 图。

### 第 3 次跟进 · 管理型 PoE（多站点分段标准件）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：K-12 校园与连锁物业的安防网分段模板：VLAN/ERPS 标准件+附合规声明包。
- **要问的问题**：校园/连锁项目的网段模板统一了吗？
- **随附证明**：VLAN/ERPS 模板 + 合规声明包 + 收敛实测（英文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第7批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：俄亥俄头部消防+安防服务商：4.5 万客户的检测/监控订阅底盘，安防线（监控/门禁/K-12/出入口机电）是增长极，Allied 代理（CSV 记录）。
- **产品线与在售品牌**：消防（灭火器/报警/喷淋/厨房抑制/BDA/群呼）+安防（报警/监控/门禁/K-12/门机电）双线；监控订阅（RMR）。
- **目标行业与场景**：商业楼宇/连锁物业/学校的消防合规+安防一体化；48 小时上门/2 小时应急的 SLA 承诺。
- **团队与规模**：45,000+ 客户底盘、8 分支电话、多执照技师（一人多照同场多检）。
- **决策链与对接人**：info@silcofs.com（CSV 9-27 核验：条款页公开邮箱为主入口）。
- **技术与认证**：消防持照体系+Allied 代理（CSV 记录）。
- **采购与供应链信号**：4.5 万客户底盘=存量维保费+新装批量：门禁/监控 IP 化意味着每个项目都有 PoE 接入层；多分支=分仓交付需求。
- **近期动态与线索**：服务承诺营销（48h/2h/24×7 真人接听）+连续 Top Workplace——扩张期。
- **与我方契合点**：安防线的项目接入层与室外门机电点位：24 口 PoE/工业件随项目批量+分支备货；消防联动段不碰（生命安全），只做非联动的监控/门禁段。
- **风险与注意**：K-12 学校单（公立）附合规声明走商业条款内；BDA/应急通信属生命安全系统，交换件只做监控/门禁网络段。

### R54 原文证据摘录（全部保留）

- **【团队与规模】**官网：连续 7 年员工投票 Top Workplace；Google 评价 1,000+ 条均分 4.9 星；俄亥俄州内 45,000+ 客户。
  > Silco has been voted Top Workplace 7 years running by our employees · over 1,000 reviews on Google with an average of a 4.9 star rating · more than 45,000 customers across Ohio rely on Silco
  > 来源：https://silcofs.com/
- **【业务定位】**官网抬头：消防与安防服务的领导者——检测/安装/维修/监控/维护全包。
  > The Leader in Fire & Security Services — install, inspect, repair, monitor, and maintain their life safety systems.
  > 来源：https://silcofs.com/
- **【产品线与在售品牌】**安防线含 K-12 学校安防专项+自动门/道闸/转闸门+BDA 双向放大（应急通信）——门禁与监控全部 IP 化。
  > Security alarm installation & monitoring · Video surveillance · Access control · School security (K-12) · Automatic gates · Automatic doors · Automatic turnstiles · Bi-directional amplifier (BDA) · Mass notification systems
  > 来源：https://silcofs.com/
- **【目标行业与场景】**服务半径五州：俄亥俄/肯塔基/东印第安纳/西宾州/底特律大区，分支覆盖 Akron/Cincy/Cleveland/Columbus/Dayton/Toledo/Louisville/Michigan。
  > We proudly serve Ohio, Kentucky, Southeast Indiana, Western Pennsylvania, and the greater Detroit area（分支电话表：Akron · Cincinnati · Cleveland · Columbus · Dayton · Toledo · Louisville, KY · Michigan）
  > 来源：https://silcofs.com/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第27波50户.json`；价格均为 EXW 快照。

- **①背景再核**：波 27·A-127:美国谱: **守档准由·原 R56 谱基增厚**:Silco Fire & Security（俄亥俄）：消防安防区域领先商——消防全谱（报警/喷淋/应急照明/厨房抑制/BDA/群通知）+安防（报警/监控/门禁/K-12 校安/自动门转闸）；**45,000+ 客户、1,000+ Google 评价 4.9 星**；服务 OH/KY/IN/W-PA/底特律；技师多执照；Top Workplace 7 年;R66 第 27 波谱:我司 STC-424XGGPM-280W($165 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第13批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **②芯片/型号**：STC-424XGGPM-280W·24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog)
- **③KP 深挖**：**守档准由;R66 第 27 波点名(谱面无实名)**
- **④Saga 对标**：STC-424XGGPM-280W vs PLANET/当批价差窗
- **⑤在乎与偏好**：美国 谱;CE/UKCA;持续关注新一季

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**Silco Fire & Security（俄亥俄）：消防安防区域领先商——消防全谱（报警/喷淋/应急照明/厨房抑制/BDA/群通知）+安防（报警/监控/门禁/K-12 校安/自动门转闸）；**45,000+ 客户、1,000+ Google 评价 4.9 星**；服务 OH/KY/IN/W-PA/底特律；技师多执照；
  > Silco Fire & Security（俄亥俄）：消防安防区域领先商——消防全谱（报警/喷淋/应急照明/厨房抑制/BDA/群通知）+安防（报警/监控/门禁/K-12 校安/自动门转闸）；**45,000+ 客户、1,000+ Google 评价 4.9 星**；服务 OH/KY/IN/W-PA/底特律；技师多执照；
  > 来源：https://silcofs.com/
- **【联系方式与基础画像】**CSV 入口:info@silcofs.com [Publicly listed; delivery not tested]; https://silcofs.com
  > CSV 入口:info@silcofs.com [Publicly listed; delivery not tested]; https://silcofs.com
  > 来源：https://silcofs.com/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：波 27·A-127:美国谱: **守档准由·原 R56 谱基增厚**:Silco Fire & Security（俄亥俄）：消防安防区域领先商——消防全谱（报警/喷淋/应急照明/厨房抑制/BDA/群通知）+安防（报警/监控/门禁/K-12 校安/自动门转闸）；**45,000+ 客户、1,000+ Google 评价 4.9 星**；服务 OH/KY/IN/W-PA/底特律；技师多执照；Top Workplace 7 年;R66 第 27 波谱:我司 STC-424XGGPM-280W($165 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第13批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **产品线与在售品牌**：Allied Telesis（Marvell Prestera 接入层）
- **目标行业与场景**：美国 谱;集成商/代理（Allied Telesis）
- **团队与规模**：美国谱·守档准由
- **决策链与对接人**：**守档准由;R66 第 27 波点名(谱面无实名)**
- **技术与认证**：STC-424XGGPM-280W 对口谱;$165 USD EXW 锚
- **采购与供应链信号**：B2B 批口谱
- **近期动态与线索**：2026-10-08 R66 27 波谱名牌(A 类补全批)
- **与我方契合点**：STC-424XGGPM-280W(24-port Gigabit PoE access switch) 档案铺位窗
- **风险与注意**：具名缺(守档准由)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Silco 多州消防安防 45,000 客户：随单柜+看门狗免回访（$180 锚点一致） |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：R56 谱基在册
- **W**：具名缺(守档准由)
- **O**：STC-424XGGPM-280W $165 USD EXW 价差窗
- **T**：谱链节奏;先报价不回则档案铺位

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ❓ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 具名决策人(波次二)
  - [ ] 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Silco Fire Protection & Se Team,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $165 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Datasheet + CE pack on request.

Best regards
Saga / SmartByte ODM
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
