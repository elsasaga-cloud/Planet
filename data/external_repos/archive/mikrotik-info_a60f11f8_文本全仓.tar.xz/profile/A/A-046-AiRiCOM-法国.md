# AiRiCOM

> **评级 A**　|　法国　|　档案编号 `A-046`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-046
rating: A
country: 法国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: false, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STI-288GP
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（工业/楼宇），三星重点
- **P1（首触唯一主推）**：STI-288GP（工业非管理 8口 PoE） — AIRICOM IoT/M2M 分销：工业路由项目现场随单温宽 PoE；Red Lion/N-Tron 盘错位（$74.8 锚点一致）；$74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | AiRiCOM（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 法国 | 事实 |
| 网站 | airicom.com | 事实 |
| 类型 | 分销（HMS：Red Lion / N-Tron） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Red Lion, N-Tron | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】波 26·A-046:法国谱: **守档准由·原 R56 谱基增厚**:AIRICOM（法国）：IoT/M2M 专家分销——Milesight（LoRaWAN 传感器/网关/4G-5G 工业路由）、HMS 全家（Intesis 空调网关/Ewon/Anybus 协议转换）、Watteco、Advantech；OT 网安目录；KNX 空调网关跨界线；CSV 载 Red Lion/N-Tron;R66 第 26 波谱:我司 STI-288GP($74.8 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第5批.json,先报价不回、档案铺位、持续关注新一季,OK。
- 【推断】R66 第 26 波守档准由谱
- 【假设】档案铺位谱,持续关注新一季

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Red Lion, N-Tron）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：marketing@airicom.fr
  - 状态：既有/公开
- **电话**：—
- 来源等级：official-company（R41–R48 联系方式台账口径）
- **原始联系字段**：marketing@airicom.fr（官网 404 页正文注明可邮件联系）；airicom.com
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。

## 关键人（KP）与触达通道

- 关键人未定位：首封信件以 info/通用邮箱开场并向其索要正确联系人。

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STI-288GP（工业非管理 8口 PoE）），备选型不进邮件。

### 第 1 次跟进 · 24 口 PoE++（IoT 项目配套）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：他网关/摄像头/LoRaWAN 设备售出的每个项目都要配交换机：24 口 PoE++ 直接做他的项目套餐配件，先跟着他的 IoT 设备卖。
- **要问的问题**：你们网关项目一般配什么价位/段位的 PoE 交换机？
- **随附证明**：与 Moxa EDS 同档位规格-价格对照表（英文）+ 法国本土发货的物流时效一页说明。

### 第 2 次跟进 · 工业非管理 PoE（远程柜/变电站）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：Ewon/Moxa 类远程柜要 DIN 宽温 PoE：用宽压+看门狗，替他省去配套的工业开关高价。
- **要问的问题**：远程柜里 PoE 供电现在走哪个系列、贵不贵？
- **随附证明**：宽温报告 + DIN 安装图 + 一台测试机。

### 第 3 次跟进 · 管理型 + 上架他的新目录

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：他目录在扩（Cybersécurité OT 新品上架）：把管理型 PoE + ERPS 在他新目录里占位，项目注册 + 两年供货承诺封盘。
- **要问的问题**：新目录还有几个交换机空位、哪个价格档他们卖不动？
- **随附证明**：管理型规格书（英文）+ 项目注册条款 + 价格保护函。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第3批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：法国工业 IoT/M2M 技术分销商（VAD），Boufféré+Paris 双址；为我们的同类二供角色天然载体。
- **产品线与在售品牌**：Milesight（IoT/LoRaWAN）、Watteco、HMS 三大件（Intesis 协议网关/Ewon 远程访问/Anybus）、Advantech；CSV 记录其亦为 Moxa 法国渠道伙伴（主营 Moxa 工业网络）。
- **目标行业与场景**：工业数据采集、楼宇空调 KNX 集成、LoRaWAN、4G/5G 备份链路与 OT 安全。
- **团队与规模**：20+ 年技术分销型公司，工程师式售前（logotyp Votre expert en…）。
- **决策链与对接人**：marketing@airicom.fr（官网注明可邮件），技术经理会看规格表。
- **技术与认证**：Moxa 与 HMS 渠道认证（CSV 既有记录）——与工业以太网产品线强相关。
- **采购与供应链信号**：多品牌组合商：货架上的品类越细，新品牌上架的边际成本越低；他对 PoE 交换机类目常年有搭配需求（LoRaWAN 网关/Wi‑Fi 桥/摄像机同时供电）。
- **近期动态与线索**：首页最新主推「Catalogue Cybersécurité OT」与 Milesight 新款——目录在扩，正是加品目窗口。
- **与我方契合点**：Moxa 是他主牌但全系价格带偏高：我方可做「同规格二供」补 PoE 非管理/管理段位，用项目注册制度切入。
- **风险与注意**：Moxa 关系是其基本盘——对话只瞄「第二来源位置」开场，先不碰 Moxa 主牌关系；样品一次给到位。

### R54 原文证据摘录（全部保留）

- **【业务定位】**全站定位为 IoT 与 M2M 专家分销商。
  > Airicom - Votre expert en IoT et M2M
  > 来源：https://airicom.com/
- **【产品线与在售品牌】**供应商墙列出 Milesight、HMS（Intesis/Ewon/Anybus）、Watteco、Advantech——工业网关/协议转换与 LoRaWAN 设备为主。
  > （Fournisseurs 徽标区：Milesight｜Intesis｜Ewon｜Anybus｜Watteco｜Advantech）
  > 来源：https://airicom.com/
- **【目标行业与场景】**产品大类直接含工业 4G/5G 路由器与 OT 网络安全——工业网络边沿硬件是明确类目。
  > Routeurs 4G/5G industriels · Cybersécurité OT · Gateway LoRaWAN · Convertisseurs de protocole
  > 来源：https://airicom.com/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第26波50户.json`；价格均为 EXW 快照。

- **①背景再核**：波 26·A-046:法国谱: **守档准由·原 R56 谱基增厚**:AIRICOM（法国）：IoT/M2M 专家分销——Milesight（LoRaWAN 传感器/网关/4G-5G 工业路由）、HMS 全家（Intesis 空调网关/Ewon/Anybus 协议转换）、Watteco、Advantech；OT 网安目录；KNX 空调网关跨界线；CSV 载 Red Lion/N-Tron;R66 第 26 波谱:我司 STI-288GP($74.8 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第5批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **②芯片/型号**：STI-288GP·industrial unmanaged 8-port PoE switch (IP67 DIN-rail, 802.3af/at)
- **③KP 深挖**：**守档准由;R66 第 26 波点名(谱面无实名)**
- **④Saga 对标**：STI-288GP vs PLANET/当批价差窗
- **⑤在乎与偏好**：法国 谱;CE/UKCA;持续关注新一季

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**AIRICOM（法国）：IoT/M2M 专家分销——Milesight（LoRaWAN 传感器/网关/4G-5G 工业路由）、HMS 全家（Intesis 空调网关/Ewon/Anybus 协议转换）、Watteco、Advantech；OT 网安目录；KNX 空调网关跨界线；CSV 载 Red Lion/N-Tron
  > AIRICOM（法国）：IoT/M2M 专家分销——Milesight（LoRaWAN 传感器/网关/4G-5G 工业路由）、HMS 全家（Intesis 空调网关/Ewon/Anybus 协议转换）、Watteco、Advantech；OT 网安目录；KNX 空调网关跨界线；CSV 载 Red Lion/N-Tron
  > 来源：https://airicom.com/
- **【联系方式与基础画像】**CSV 入口:marketing@airicom.fr（官网 404 页正文注明可邮件联系）；airicom.com
  > CSV 入口:marketing@airicom.fr（官网 404 页正文注明可邮件联系）；airicom.com
  > 来源：https://airicom.com/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：波 26·A-046:法国谱: **守档准由·原 R56 谱基增厚**:AIRICOM（法国）：IoT/M2M 专家分销——Milesight（LoRaWAN 传感器/网关/4G-5G 工业路由）、HMS 全家（Intesis 空调网关/Ewon/Anybus 协议转换）、Watteco、Advantech；OT 网安目录；KNX 空调网关跨界线；CSV 载 Red Lion/N-Tron;R66 第 26 波谱:我司 STI-288GP($74.8 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第5批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **产品线与在售品牌**：Red Lion, N-Tron
- **目标行业与场景**：法国 谱;分销（HMS：Red Lion / N-Tron）
- **团队与规模**：法国谱·守档准由
- **决策链与对接人**：**守档准由;R66 第 26 波点名(谱面无实名)**
- **技术与认证**：STI-288GP 对口谱;$74.8 USD EXW 锚
- **采购与供应链信号**：B2B 批口谱
- **近期动态与线索**：2026-10-08 R66 26 波谱名牌(A 类补全批)
- **与我方契合点**：STI-288GP(industrial unmanaged 8-port PoE switch) 档案铺位窗
- **风险与注意**：具名缺(守档准由)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STI-288GP（工业非管理 8口 PoE） | 主场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | AIRICOM IoT/M2M 分销：工业路由项目现场随单温宽 PoE；Red Lion/N-Tron 盘错位（$74.8 锚点一致） |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：工业非管理 8口 PoE af/at，250m 延伸供电，冗余 DC44–57V（过压/反接保护），DIN 轨，3 年保
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：R56 谱基在册
- **W**：具名缺(守档准由)
- **O**：STI-288GP $74.8 USD EXW 价差窗
- **T**：谱链节奏;先报价不回则档案铺位

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ❓ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 具名决策人(波次二)
  - [ ] 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear AiRiCOM Team,

We build a industrial unmanaged 8-port PoE switch (IP67 DIN-rail, 802.3af/at). Reference: $74.8 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Datasheet + CE pack on request.

Best regards
Saga / SmartByte ODM
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
