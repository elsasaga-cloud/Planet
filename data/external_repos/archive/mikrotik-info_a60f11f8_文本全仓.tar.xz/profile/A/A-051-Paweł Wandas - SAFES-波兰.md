# Paweł Wandas / SAFES

> **评级 A**　|　波兰 · Kraków　|　档案编号 `A-051`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-051
rating: A
country: 波兰
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: true, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（交换认证 MTCSWE），且有具体人直联
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — SAFES 波高端物业/酒店 IT 全托管（PMS+SOC）：单店客房 Wi-Fi+安防 24 口 PoE 随单（$180 锚点一致）；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Paweł Wandas / SAFES（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 波兰 / Kraków | 事实 |
| 网站 | safes.pl | 事实 |
| 类型 | 集成商/顾问（MikroTik 认证） | 事实（CSV 名录口径） |
| 关键人 | Paweł Wandas | 事实 |
| 反向信号（资质/品牌） | MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCTCE+MTCINE+MTCIPv6E+MTCSE+MTCSWE+MTCEWE | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】波 26·A-051:波兰谱: **守档准由·原 R56 谱基增厚**:SAFES（波兰）：20 年 IT 外包商——波兰及境外**高端物业（酒店/资产）全托管 non-stop**：服务器/机房代管、LAN/WAN/Wi-Fi 基础设施、Cybersecurity 线（SOC 24/7、Zero Trust 架构、**PMS 酒店系统防护**）、enova365 ERP 授权伙伴；Paweł Wandas MTCNA+MTCRE+MTCWE+MTCTCE+MTCINE+MTCIPv6E 六证;R66 第 26 波谱:我司 STC-424XGGPM-280W($165 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第6批.json,先报价不回、档案铺位、持续关注新一季,OK。
- 【推断】R66 第 26 波守档准由谱
- 【假设】档案铺位谱,持续关注新一季

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCTCE+MTCINE+MTCIPv6E+MTCSE+MTCSWE+MTCEWE）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、万兆上行/骨干、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 万兆上行/骨干：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：biuro@safes.pl
  - 状态：既有/公开
- **电话**：+48 412 412 324
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：+48 412 412 324 / biuro@safes.pl
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。

## 关键人（KP）与触达通道

- **Paweł Wandas**（本人直达；角色=业主/顾问本人，依据名录）

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 PoE++（托管酒店/物业项目替换件）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：托管 7×24 模式：换件仓库的逻辑——24 口 PoE++ 拿来做他的备用库存 + 项目替换机，性价比立现。
- **要问的问题**：替换件仓库现用哪个系列、备机放几台？
- **随附证明**：功率实测 + SNMP/MIB 明细 + 英文对照页。

### 第 2 次跟进 · 工业非管理 PoE（楼层/天花/室外点位）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：运维商最怕的楼层吊顶/地下机槽点位：宽温宽压、免配置，坏了一台热换。
- **要问的问题**：楼层/室外小型节点一年换几台、上门成本多大？
- **随附证明**：宽温报告 + DIN 安装图 + 单机热换说明。

### 第 3 次跟进 · 管理型 + Zero Trust/VLAN 托管包

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：与 SOC/Zero Trust 话术对齐：管理型 VLAN 分段+SNMP 明细+ACL，写进他的托管方案里能涨服务费。
- **要问的问题**：客户托管包里 802.1X/VLAN 分段你们怎么卖、谁交付？
- **随附证明**：VLAN/ERPS/ACL 配置模板 + SNMP 对接说明 + ERPS 收敛实测。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第3批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：Kraków 的托管 IT/网络安全服务商，面向酒店与高级物业，LAN/Zero Trust 话术清晰；工程侧做 LAN/WAN/Wi-Fi 代维。
- **产品线与在售品牌**：按项目选型（MikroTik 栈为主，顾问 Paweł Wandas 墙上全证）。
- **目标行业与场景**：酒店、商业楼宇、高级物业的全年无休设备托管——PoE 交换机是典型运维包里的硬件。
- **团队与规模**：服务/SOC 支持团队制，但决策集中。
- **决策链与对接人**：Paweł Wandas（+48 412 412 324 / biuro@safes.pl）。
- **技术与认证**：公司顾问墙上顾问持 MTCNA 至 MTCEWE/MTCSWE 全证（来源：CSV 既有 MikroTik 名录记录）；熟 The Dude/SNMP 运维文化，能看懂 SNMP/MIB 与资产发现类参数。
- **采购与供应链信号**：7×24 服务包模式：备件/换机库存是硬指标——「备用库存+快速热换」正是他们的购买逻辑。
- **近期动态与线索**：官网主打 SOC/Zero Trust 话术——客户项目多要求 VLAN 分段/802.1X，管理型 PoE 能写进他的托管方案。
- **与我方契合点**：酒店项目 PoE 运维、SOC 管理面安全、SNMP 细节——直接命中管理型；备件模式适合他的 7×24 运维。
- **风险与注意**：运维商对供货连续与更换件仓库敏感：讲备件比讲便宜更能成单。

### R54 原文证据摘录（全部保留）

- **【业务定位】**SAFES 自述：20 年为波兰与海外的高级物业/场馆做托管 IT 与网络安全，7×24。
  > Przejmujemy pełną odpowiedzialność za systemy IT… Od 20 lat obsługujemy obiekty premium w Polsce i za granicą – w trybie non-stop.
  > 来源：https://safes.pl/
- **【目标行业与场景】**基础设施服务项明确 LAN/WAN/Wi‑Fi 网络、服务器/虚拟化、高可用——托管型服务即其接口。
  > Infrastruktura IT… Sieci LAN/WAN/Wi-Fi · Serwery i wirtualizacja · Wysoka dostępność
  > 来源：https://safes.pl/
- **【技术与认证】**明确 SOC 与 Zero Trust 架构语言——安全分层是他给客户的答案。
  > Security Operations Center · Architektura Zero Trust · Ochrona PMS
  > 来源：https://safes.pl/
- **【产品线与在售品牌】**另有 enova365 ERP 的授权实施线（商业软件+网络安全+托管 IT 混合的工程有限公司）。
  > Autoryzowany Partner enova365
  > 来源：https://safes.pl/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第26波50户.json`；价格均为 EXW 快照。

- **①背景再核**：波 26·A-051:波兰谱: **守档准由·原 R56 谱基增厚**:SAFES（波兰）：20 年 IT 外包商——波兰及境外**高端物业（酒店/资产）全托管 non-stop**：服务器/机房代管、LAN/WAN/Wi-Fi 基础设施、Cybersecurity 线（SOC 24/7、Zero Trust 架构、**PMS 酒店系统防护**）、enova365 ERP 授权伙伴；Paweł Wandas MTCNA+MTCRE+MTCWE+MTCTCE+MTCINE+MTCIPv6E 六证;R66 第 26 波谱:我司 STC-424XGGPM-280W($165 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第6批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **②芯片/型号**：STC-424XGGPM-280W·24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog)
- **③KP 深挖**：**守档准由;R66 第 26 波点名(谱面无实名)**
- **④Saga 对标**：STC-424XGGPM-280W vs PLANET/当批价差窗
- **⑤在乎与偏好**：波兰 谱;CE/UKCA;持续关注新一季

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**SAFES（波兰）：20 年 IT 外包商——波兰及境外**高端物业（酒店/资产）全托管 non-stop**：服务器/机房代管、LAN/WAN/Wi-Fi 基础设施、Cybersecurity 线（SOC 24/7、Zero Trust 架构、**PMS 酒店系统防护**）、enova365 ERP 授权伙伴；Paw
  > SAFES（波兰）：20 年 IT 外包商——波兰及境外**高端物业（酒店/资产）全托管 non-stop**：服务器/机房代管、LAN/WAN/Wi-Fi 基础设施、Cybersecurity 线（SOC 24/7、Zero Trust 架构、**PMS 酒店系统防护**）、enova365 ERP 授权伙伴；Paw
  > 来源：https://safes.pl/
- **【联系方式与基础画像】**CSV 入口:+48 412 412 324 / biuro@safes.pl
  > CSV 入口:+48 412 412 324 / biuro@safes.pl
  > 来源：https://safes.pl/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：波 26·A-051:波兰谱: **守档准由·原 R56 谱基增厚**:SAFES（波兰）：20 年 IT 外包商——波兰及境外**高端物业（酒店/资产）全托管 non-stop**：服务器/机房代管、LAN/WAN/Wi-Fi 基础设施、Cybersecurity 线（SOC 24/7、Zero Trust 架构、**PMS 酒店系统防护**）、enova365 ERP 授权伙伴；Paweł Wandas MTCNA+MTCRE+MTCWE+MTCTCE+MTCINE+MTCIPv6E 六证;R66 第 26 波谱:我司 STC-424XGGPM-280W($165 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第6批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **产品线与在售品牌**：MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCTCE+MTCINE+MTCIPv6E+MTCSE+MTCSWE+MTCEWE
- **目标行业与场景**：波兰 谱;集成商/顾问（MikroTik 认证）
- **团队与规模**：波兰谱·守档准由
- **决策链与对接人**：**守档准由;R66 第 26 波点名(谱面无实名)**
- **技术与认证**：STC-424XGGPM-280W 对口谱;$165 USD EXW 锚
- **采购与供应链信号**：B2B 批口谱
- **近期动态与线索**：2026-10-08 R66 26 波谱名牌(A 类补全批)
- **与我方契合点**：STC-424XGGPM-280W(24-port Gigabit PoE access switch) 档案铺位窗
- **风险与注意**：具名缺(守档准由)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | SAFES 波高端物业/酒店 IT 全托管（PMS+SOC）：单店客房 Wi-Fi+安防 24 口 PoE 随单（$180 锚点一致） |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：R56 谱基在册
- **W**：具名缺(守档准由)
- **O**：STC-424XGGPM-280W $165 USD EXW 价差窗
- **T**：谱链节奏;先报价不回则档案铺位

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 具名决策人(波次二)
  - [ ] 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Paweł Wandas Team,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $165 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Datasheet + CE pack on request.

Best regards
Saga / SmartByte ODM
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
