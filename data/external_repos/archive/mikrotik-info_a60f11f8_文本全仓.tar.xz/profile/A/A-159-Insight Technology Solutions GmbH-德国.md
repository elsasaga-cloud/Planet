# Insight Technology Solutions GmbH

> **评级 A**　|　德国 · Raunheim　|　档案编号 `A-159`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-159
rating: A
country: 德国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: STC-28DGGPM
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；人工指定
- **P1（首触唯一主推）**：STC-28DGGPM（8口 PoE 接入盒） — Insight 德国：全球超大目录 VAR 规模排除纪律建档不出信；$99 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Insight Technology Solutions GmbH（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 德国 / Raunheim | 事实 |
| 网站 | https://insightportal.de | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Insight Technology Solutions GmbH:Insight Technology Solutions GmbH(德国 Raunheim,Am Prime-Parc 9(旧 Garching Parkring 35);**HRB 103112 AG Darmstadt;DE812242281;1988 创(原名 Corporate Software GmbH)**;**137 人/€122M;Insight Enterprises Inc.(NASDAQ:NSIT)全资=美资全球整合商;16×Microsoft Gold 谱(安全含)**
- 【推断】R66 第 14 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电
  - PoE 接入供电：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info.de@insight.com
  - 状态：既有/公开
- **电话**：—
- 来源等级：official（R41–R48 联系方式台账口径）
- **原始联系字段**：info.de@insight.com [Publicly listed; delivery not tested]; https://insightportal.de
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Thomas Kühlewein**(Geschäftsführer(2020-10 起德国区))— 官网 Impressum+de.insight.com 法人公告 〔已有(公司官方公开件/登记册自曝);源:https://insightportal.de/impressum〕
  - **Glynis Ann Bryan**(Geschäftsführer(现任谱))— insightportal.de Impressum 〔已有(公司官方公开件/登记册自曝);源:https://insightportal.de/impressum〕
  - **James Morgado**(Geschäftsführer(谱面留痕))— de.insight.com Impressum 件(留痕) 〔已有(公司官方公开件/登记册自曝);源:https://de.insight.com/de_DE/knowledge-base/impressum.html〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Thomas Kühlewein | Geschäftsführer(2020-10 起德国区) | 官网 Impressum+de.insight.com 法人公告 | official-self-published·谱/leads-only(直发需 opt-in) | https://insightportal.de/impressum |
| Glynis Ann Bryan | Geschäftsführer(现任谱) | insightportal.de Impressum | official-self-published·谱/leads-only(直发需 opt-in) | https://insightportal.de/impressum |
| James Morgado | Geschäftsführer(谱面留痕) | de.insight.com Impressum 件(留痕) | official-self-published·谱/leads-only(直发需 opt-in) | https://de.insight.com/de_DE/knowledge-base/impressum.html |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-28DGGPM（8口 PoE 接入盒）），备选型不进邮件。

### 第 1 次跟进 · 利基类目提案（工业宽温 PoE 上架）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：大卖场缺的利基类目：宽温工业 PoE 上架提案+类目空缺说明——零冲突切口。
- **要问的问题**：工业宽温 PoE 这个类目，你们货架还空着——试用位怎么谈？
- **随附证明**：类目空缺说明 + 分销条款 + 规格表（德文）。

### 第 2 次跟进 · 24 口 CCTV/PoE（接入层第二来源）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：接入层第二来源提案：同规格成本对照+到岸梯价。
- **要问的问题**：接入层第二来源的报价要不要挂进品类？
- **随附证明**：规格对照 + 梯价（德文）。

### 第 3 次跟进 · 管理型 PoE（品类扩展收口）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：若类目动销：管理型扩品；若三轮无回响即归档（大体系不强求）。
- **要问的问题**：管理型要不要随类目一起扩？
- **随附证明**：VLAN/ERPS 速查 + 扩展条款（德文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第8批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：全球大体系 Insight 的德国实体（Raunheim）：企业 IT 大卖场+电商平台，Allied Resell（CSV 记录）。⚠️ 规模与采购链风险 CSV 已保留不改级。
- **产品线与在售品牌**：全线厂牌（微软/Lenovo/HP/外设）+Smarter Working 方案+企业采购门户。
- **目标行业与场景**：德国大中型企业客户的整批 IT 采购。
- **团队与规模**：跨国集团德国法人（大体系）。
- **决策链与对接人**：info.de@insight.com（CSV 9-27：德国法人 Impressum；不混 AT/CH）。
- **技术与认证**：Allied Resell（CSV 记录）。
- **采购与供应链信号**：品类采购制+供应商准入流程：现实路径是「接入层第二来源+利基类目（工业 PoE）」而非正面替位。
- **近期动态与线索**：电商促销位常态排期。
- **与我方契合点**：利基类目（工业宽温/大功率 PoE++）上架提案+项目第二来源报价——低期望，轻投入。
- **风险与注意**：大体系回复周期长、压价狠：只投产品利润可承受的单；不做账期让步超越政策（中立贸易商立场）。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网为大型分销电商门面：Smarter Working Solutions 品牌+Surface/Lenovo/HP/Jabra 等轮播促销——大体系电商运营。
  > （站点轮播）Microsoft Surface Pro for Business · Lenovo P4 Workstations · HP EliteBook 8 G2i · Premium-Headsets Powered by EPOS AI · Jabra Evolve3（Insightportal – Smarter Working Solutions，页标题）
  > 来源：https://insightportal.de/
- **【决策链与对接人】**CSV 9-27：德国法人 Impressum 公开 info.de@insight.com 与 Raunheim 地址——不混用奥地利或瑞士分支（CSV 原话）。
  > 德国法人 Impressum 公开邮箱和 Raunheim 地址；不混用奥地利或瑞士分支。规模/采购链风险保留，本轮仅补联系，不改等级（CSV 2026-09-27 记录）
  > 来源：https://insightportal.de/impressum
- **【采购与供应链信号】**电商流+企业促销位经营模式=上架决策在品类采购；大体系对小微品牌要多轮供应商准入。
  > Insightportal – Smarter Working Solutions（站点为促销电商流形态，产品位按品类排期）
  > 来源：https://insightportal.de/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第18波30户.json`；价格均为 EXW 快照。

- **①背景再核**：Insight Technology Solutions GmbH(德国 Raunheim,Am Prime-Parc 9(旧 Garching Parkring 35);**HRB 103112 AG Darmstadt;DE812242281;1988 创(原名 Corporate Software GmbH)**;**137 人/€122M;Insight Enterprises Inc.(NASDAQ:NSIT)全资=美资全球整合商;16×Microsoft Gold 谱(安全含)**
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Thomas Kühlewein(Geschäftsführer(2020-10 起德国区),official-self-published·谱/leads-only(直发需 opt-in));Glynis Ann Bryan(Geschäftsführer(现任谱),official-self-published·谱/leads-only(直发需 opt-in));James Morgado(Geschäftsführer(谱面留痕),official-self-published·谱/leads-only(直发需 opt-in))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：上市母台 38 年谱

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Geschäftsführer: Thomas Kühlewein, Glynis Ann Bryan;HRB 103112 AG Darmstadt;DE812242281;Am Prime-Parc 9, 65479 Raunheim(insightportal.de Impressum)
  > Geschäftsführer: Thomas Kühlewein, Glynis Ann Bryan;HRB 103112 AG Darmstadt;DE812242281;Am Prime-Parc 9, 65479 Raunheim(insightportal.de Impressum)
  > 来源：https://insightportal.de/impressum
- **【联系方式与基础画像】**THOMAS KÜHLEWEIN ÜBERNIMMT DIE GESCHÄFTSFÜHRUNG… Oktober 2020 法人公告;Insight Enterprises (NASDAQ: NSIT);16 Microsoft Gold Competencies;137 Mitarbeiter/€122M(de.insight.com 新闻室+DDW 件)
  > THOMAS KÜHLEWEIN ÜBERNIMMT DIE GESCHÄFTSFÜHRUNG… Oktober 2020 法人公告;Insight Enterprises (NASDAQ: NSIT);16 Microsoft Gold Competencies;137 Mitarbeiter/€122M(de.insight.com 新闻室+DDW 件)
  > 来源：https://de.insight.com/de_DE/about/newsroom/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Insight Technology Solutions GmbH(德国 Raunheim,Am Prime-Parc 9(旧 Garching Parkring 35);**HRB 103112 AG Darmstadt;DE812242281;1988 创(原名 Corporate Software GmbH)**;**137 人/€122M;Insight Enterprises Inc.(NASDAQ:NSIT)全资=美资全球整合商;16×Microsoft Gold 谱(安全含)**
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：德国 Raunheim 38 年美资全球 IT 整合商
- **团队与规模**：137 人;€122M;1988 创
- **决策链与对接人**：**Thomas Kühlewein(Geschäftsführer(2020-10 起德国区),official-self-published·谱/leads-only(直发需 opt-in));Glynis Ann Bryan(Geschäftsführer(现任谱),official-self-published·谱/leads-only(直发需 opt-in));James Morgado(Geschäftsführer(谱面留痕),official-self-published·谱/leads-only(直发需 opt-in))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 14 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Kühlewein 德区 GF(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-28DGGPM（8口 PoE 接入盒） | 主场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Insight 德国：全球超大目录 VAR 规模排除纪律建档不出信 |
| 备选2 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：8口 GE(7)+SFP，PoE af/at 240W，DC 随附电源，L2+ 全特性（VLAN/ERPS<20ms/QinQ/Private VLAN/sFlow），PoE 看门狗自动冷重启
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：上市母台 38 年谱
- **W**：大实体谱
- **O**：Kühlewein 德区 GF 直达位
- **T**：自家链栈=不占

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Guten Tag Herr Kühlewein,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
