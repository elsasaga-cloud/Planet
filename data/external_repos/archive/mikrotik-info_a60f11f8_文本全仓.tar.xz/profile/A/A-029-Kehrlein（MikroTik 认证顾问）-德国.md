# Kehrlein（MikroTik 认证顾问）

> **评级 A**　|　德国 · München　|　档案编号 `A-029`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-029
rating: A
country: 德国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（PoE/监控/门禁），且有具体人直联
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — Kehrlein 全十证 NDA 级顾问：实验室评测机+技术档案，不打探其客户名单；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Kehrlein（MikroTik 认证顾问）（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 德国 / München | 事实 |
| 网站 | kehrlein.de | 事实 |
| 类型 | 集成商/顾问（MikroTik 认证） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | MikroTik 认证顾问 MTCRE 等 | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】德国 Kehrlein Consulting（München Perlacher Straße 40 + Haßfurt Sonnenhang 1；info@kehrlein.de；+49 89 69387111 / +49 9521 9580741）。官网自曝 Sandro Kehrlein = Official MikroTik Consultant since 2007，九证 MTCNA/MTCRE/MTCWE/MTCTCE/MTCUME/MTCINE/MTCIPv6E/MTCSE/MTCSWE/MTCEWE，兼 SAFe ASPC；kontakt.php 联系页在册。
- 【推断】R69 第 1 波 KP 猎获（本人官网自曝）
- 【假设】单人顾问位 KP 本人锁定；邮箱官网在册

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：MikroTik 认证顾问 MTCRE 等）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电
  - PoE 接入供电：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@kehrlein.de
  - 状态：既有/公开
- **电话**：+49 89 69387111
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：+49 89 69387111 / info@kehrlein.de
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Sandro Kehrlein**(本人/创始人（Official MikroTik Consultant since 2007）)— info@kehrlein.de（官网 JSON-LD 在册）；+49 89 69387111（München）/ +49 9521 9580741（Haßfurt） 〔已有(公司官方公开件/登记册自曝);源:https://www.kehrlein.de/en/〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Sandro Kehrlein | 本人/创始人（Official MikroTik Consultant since 2007） | info@kehrlein.de（官网 JSON-LD 在册）；+49 89 69387111（München）/ +49 9521 9580741（Haßfurt） | official-self-published（官网自曝） | https://www.kehrlein.de/en/ |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE 入门款

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：按他的设计口径给料：整机功率预算、逐口实测、PoE 看门狗、端口隔离；请他用自己的方法复测（他是评审型客户）。
- **要问的问题**：他设计高可用接入层时，PoE 交换机的硬门槛是什么？
- **随附证明**：测试方法说明 + 实测原始数据 + 可上他测试台的样机。

### 第 2 次跟进 · 工业级非管理 PoE（现场点位）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：给客户设计时总有非机房点位；宽温 DIN 免配置，减少设计复杂度与维护面。
- **要问的问题**：他的方案里现场点位一般怎么做冗余与供电？
- **随附证明**：宽温/宽压报告 + 双电源设计图 + 样品。

### 第 3 次跟进 · 管理型 PoE（高可用实测）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：他讲 MLAG/VRRP/ERPS：用我们的管理型做接入层环网与双上行，给他可复现的收敛时间与丢包数据。
- **要问的问题**：他的高可用设计里，接入层环网收敛目标是多少？
- **随附证明**：ERPS 收敛实测 + 双上行拓扑验证 + CLI/MIB 文档。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第2批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：慕尼黑（另设 Haßfurt 点位）的 IT 咨询顾问：网络与基础设施（高可用方向、全球远程+现场、24×7）、IT 管理与敏捷转型（SAFe 认证讲师）。
- **产品线与在售品牌**：MikroTik/RouterOS 专家（官网自述 Official MikroTik Consultant · Since 2007）；其余为方法论与开源/自选厂商，无代理绑定。
- **目标行业与场景**：企业网络设计/审计/高可用改造、IT 组织转型；客户遍及德语区与海外（全球远程）。
- **团队与规模**：个人顾问（+15 年管理经验，可做 interim manager），决策链 = 本人。
- **决策链与对接人**：Sandro Kehrlein（info@kehrlein.de；+49 89 69387111；另有 +49 9521 9580741）。
- **技术与认证**：MikroTik 官方顾问（2007 起），官网列 10 证：MTCNA/MTCRE/MTCWE/MTCTCE/MTCUME/MTCINE/MTCIPv6E/MTCSE/**MTCSWE**/MTCEWE；技术栈含 MPLS/VRF、VXLAN、**MLAG/VRRP**、WireGuard、CAPsMAN、自动化与监控、安全审计。
- **采购与供应链信号**：设计/审计角色 → 他能写入规格（spec-in）；本人不囤货，但项目设备清单由他出。
- **近期动态与线索**：官网 2026 年在线（英德双语），列 SAFe ASPC 等 8 项敏捷认证；提供 TeamViewer QuickSupport 远程支持入口。
- **与我方契合点**：他谈 MLAG/VRRP/ERPS 级的高可用：我们的管理型 PoE（ERPS、双上行、VLAN）正好是他设计里的接入层元件；工业款补现场点位。
- **风险与注意**：技术天花板高、只认数据：任何「支持/不支持」都要有文档或实测；不打价格战，打可验证性。

### R54 原文证据摘录（全部保留）

- **【技术与认证】**官网明列 MikroTik 官方顾问身份、10 项认证与技术栈清单。
  > Official MikroTik Consultant · Since 2007；MTCNA · MTCRE · MTCWE · MTCTCE · MTCUME · MTCINE · MTCIPv6E · MTCSE · MTCSWE · MTCEWE；Technologies: Routing (BGP, OSPF, VRF, MPLS), Firewalling, Switching, VLAN, DNS, Tunneling (GRE, EoIP, VXLAN), VPN (IPsec, L2TP, OpenVPN, WireGuard), PPPoE, Wireless & CAPsMAN, Hotspot & Captive Portals, QoS, IPv6, Load Balancing, High Availability (VRRP, MLAG), Security Audits, Monitoring, Backup, Network Automation
  > 来源：https://www.kehrlein.de/en/
- **【业务定位】**网络/基础设施咨询的定位与交付方式（24×7、远程+现场）。
  > IT consulting, IT services and support with a focus on high-availability network solutions — worldwide, remote and on-site, individually tailored and 24×7. Specialised in MikroTik and RouterOS.
  > 来源：https://www.kehrlein.de/en/
- **【目标行业与场景】**双重身份（网络顾问 + IT 管理/敏捷），可做 interim manager 与监事席位。
  > Strategic IT consulting, IT organisational development and transformation … Available as an interim manager and for advisory board and supervisory board mandates — backed by more than 15 years of leadership and management experience.
  > 来源：https://www.kehrlein.de/en/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-09_R69_R56_KP第1波.json`；价格均为 EXW 快照。


### R55 证据摘录（全部保留 · 含数量）

- **【证据】**Sandro Kehrlein — Official MikroTik Consultant since 2007 · MTCNA MTCRE MTCWE MTCTCE MTCUME MTCINE MTCIPv6E MTCSE MTCSWE MTCEWE · Advanced SAFe Practice Consultant (ASPC)
  > Sandro Kehrlein — Official MikroTik Consultant since 2007 · MTCNA MTCRE MTCWE MTCTCE MTCUME MTCINE MTCIPv6E MTCSE MTCSWE MTCEWE · Advanced SAFe Practice Consultant (ASPC)
  > 来源：https://www.kehrlein.de/en/
- **【证据】**KEHRLEIN CONSULTING · Perlacher Straße 40 · D-81539 München · Sonnenhang 1 · D-97437 Haßfurt · Tel.: +49 89 69387111 / +49 9521 9580741
  > KEHRLEIN CONSULTING · Perlacher Straße 40 · D-81539 München · Sonnenhang 1 · D-97437 Haßfurt · Tel.: +49 89 69387111 / +49 9521 9580741
  > 来源：https://www.kehrlein.de/kontakt.php
- **【证据】**telephone +498969387111 · email info@kehrlein.de（官网 JSON-LD）
  > telephone +498969387111 · email info@kehrlein.de（官网 JSON-LD）
  > 来源：https://www.kehrlein.de/en/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：MikroTik 认证顾问（since 2007）+ SAFe 咨询
- **决策链与对接人**：KP 本人锁定（单人顾问）
- **产品线与在售品牌**：MikroTik/RouterOS 咨询与培训
- **团队与规模**：单人（两地办公 München/Haßfurt）
- **技术与认证**：MikroTik 九证 + SAFe ASPC
- **采购与供应链信号**：顾问代采/培训采购线
- **近期动态与线索**：官网活跃（WireGuard/BGP 专长自述）

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Kehrlein 全十证 NDA 级顾问：实验室评测机+技术档案，不打探其客户名单 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：有明确交换/供电需求（PoE/监控/门禁），且有具体人直联

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
info@kehrlein.de
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
