# DACC Europe Ltd

> **评级 A**　|　英国 · London　|　档案编号 `A-106`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-106
rating: A
country: 英国
biz_org: 个体顾问（无官网）
business_model: 顾问项目制
decision_speed: fast
price_sensitivity: high
volume_potential: 1  # 1-5
needs: {poe: true, industrial: true, tenG: false, l2plus: false, voice: true, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：个体顾问（无官网）；顾问项目制
- **商业模式**：顾问项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；信息待人工补齐（见备注）
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — DACC 伦敦布线/DC 厂商中立：RISQS 铁路红线不触；私营银行/制药段+电话先行（$180 锚点一致）；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | DACC Europe Ltd（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 英国 / London | 事实 |
| 网站 | —（无公开站点） | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 个体顾问（无官网） | 【推断】 |
| 商业模式 | 顾问项目制 | 【推断】 |
| 团队规模 | 一人/微型 | 【推断】 |
| 决策链 | 短（本人即决策） | 【推断】 |
| ⚠️ 信息缺口 | 本条**抓不到邮箱**，需人工补齐邮箱或改为电话单独跟进后再进群发名单 | 事实 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】波 R67 批4·A-106:英谱: **DACC Europe Ltd 深挖(Companies House/globaldatabase/northdata/companycheck/crunchbase 五源互证)**:Company Number 03297031,1996-12-30 创(**29 年**),SIC 61100 Wired telecommunications activities(有线通信);注册 154 Cannon Workshops 3 Cannon Drive London E14 4AS(**金丝雀码头**)+northdata 注 Eastleigh 旧营业地 Highfield Court Tollgate Chandler's Ford SO53 3TY;**业务=computer cabling systems 供应安装+structured cabling/infrastructure/mechanical & electrical services(Crunchbase);IT spend $3.7M(Aberdeen 估)**;员工 19(globaldatabase)/51-100(crunchbase 窗注);**现金 £652,230 增 71.78%(2023-12 年报);总资 £12M/留资 £1.4M;UK funding £5k(2015)**;**KP 金谱:Jasvinderpal Singh Matharu(f1961-12=64 岁,**二度任**:1999-02 首任→2015-06 退→2019-02 复任至今,Companies House 直证)+Marin Krastev Shkodrov(f1975-09=50 岁,2014-06 任,Director+Company Secretary 双职,金丝雀码头谱)+Simon James(Director)+Andrew Shaw(CXO)+Michael Shaw(CXO)**=5 人谱(globaldatabase);**往变:11 directors(2023-12 confirmation statement);网 dacceurope.com;age 29 年;+44 0207 538 8701**;**谱位=布线与基础设施/机电服务(Telecommunications Services/Tv Broadcast 双 SIC 歧)——布线集成商 LDN 金丝雀码头谱**;**给我方挂念:布线集成的交换机件直采口=Signal=Shkodrov+Matharu 双董事直门**。
- 【推断】R67 推土机深挖 批4 具名 KP 金谱(Matharu 二度任+金丝雀码头谱)
- 【假设】STC-424XGGPM-280W($165 USD EXW (2026-10-08, 15天有效))Matharu/Shkodrov 双董事布线集成交换器件直采载线引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、VoIP/Voice VLAN
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - VoIP/Voice VLAN：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：—
  - 状态：缺失（leads-only 口径：人工补录前**不进群发**，与旧批次纪律一致）
- **电话**：+44 (0) 207 538 8701
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：+44 (0) 207 538 8701；⚠️ 无直接邮箱：域名 dacceurope.com｜具名 Chris Yearwood（Director of Operations）、Jon H（Head of Railway Division Comms）。**有铁路通信部门** → 工业/轨交场景强对口，值得人工解锁 @dacceurope.com 姓名邮箱
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Jasvinderpal Singh Matharu**(Director( Companies House 直证二度任:1999-02 首任→2015-06 退→2019-02 复任至今;DOB Dec 1961=64 岁;Surrey Weybridge 谱))— jmatharu@dacceuro.com(推断,送完核)/+44 0207 538 8701 台口转 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://find-and-update.company-information.service.gov.uk/company/03297031/officers〕
  - **Marin Krastev Shkodrov**(Director+Company Secretary(双职 Companies House 直证;2014-06-10 任;DOB Sep 1975=50 岁;金丝雀码头 E14 谱))— mshkodrov@dacceuro.com(推断) 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://find-and-update.company-information.service.gov.uk/company/03297031/officers〕
  - **Andrew Shaw**(CXO(globaldatabase 拍谱;Shaw 家族谱(Marcus/Michael 同谱)=二线谱))— ashaw@dacceuro.com(推断) 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://uk.globaldatabase.com/company/dacc-europe-limited〕
  - **Tony Grace**(Commercial & Sales Director)— dacceurope.com Our leadership 官网自署 〔已有(公司官方公开件/登记册自曝);源:https://www.dacceurope.com/〕
  - **David Long**(Technical Director)— dacceurope.com Our leadership 官网自署 〔已有(公司官方公开件/登记册自曝);源:https://www.dacceurope.com/〕
  - **Ricky Akers**(Projects Director)— dacceurope.com Our leadership 官网自署 〔已有(公司官方公开件/登记册自曝);源:https://www.dacceurope.com/〕
  - **Lee Millar**(Service Delivery Director)— dacceurope.com Our leadership 官网自署 〔已有(公司官方公开件/登记册自曝);源:https://www.dacceurope.com/〕
  - **Photis Patsalide**((原)Director(2022-07~2024-01 已退,留痕))— Companies House 军官名件 〔已有(公司官方公开件/登记册自曝);源:https://find-and-update.company-information.service.gov.uk/company/03297031/officers〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Jasvinderpal Singh Matharu | Director( Companies House 直证二度任:1999-02 首任→2015-06 退→2019-02 复任至今;DOB Dec 1961=64 岁;Surrey Weybridge 谱) | jmatharu@dacceuro.com(推断,送完核)/+44 0207 538 8701 台口转 | Companies House 直证 O 级;邮箱推断 G 级 | https://find-and-update.company-information.service.gov.uk/company/03297031/officers |
| Marin Krastev Shkodrov | Director+Company Secretary(双职 Companies House 直证;2014-06-10 任;DOB Sep 1975=50 岁;金丝雀码头 E14 谱) | mshkodrov@dacceuro.com(推断) | Companies House 直证 O 级;邮箱推断 G 级 | https://find-and-update.company-information.service.gov.uk/company/03297031/officers |
| Andrew Shaw | CXO(globaldatabase 拍谱;Shaw 家族谱(Marcus/Michael 同谱)=二线谱) | ashaw@dacceuro.com(推断) | globaldatabase O/G 级;邮箱推断 G 级 | https://uk.globaldatabase.com/company/dacc-europe-limited |
| Tony Grace | Commercial & Sales Director | dacceurope.com Our leadership 官网自署 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.dacceurope.com/ |
| David Long | Technical Director | dacceurope.com Our leadership 官网自署 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.dacceurope.com/ |
| Ricky Akers | Projects Director | dacceurope.com Our leadership 官网自署 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.dacceurope.com/ |
| Lee Millar | Service Delivery Director | dacceurope.com Our leadership 官网自署 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.dacceurope.com/ |
| Photis Patsalide | (原)Director(2022-07~2024-01 已退,留痕) | Companies House 军官名件 | official-self-published·谱/leads-only(直发需 opt-in) | https://find-and-update.company-information.service.gov.uk/company/03297031/officers |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（楼宇/DC 布线项目有源配套）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：顺着布线主业：布完线总要配接入层，24 口 PoE++ 进他的「公正选型」货比清单，随布线单配套。
- **要问的问题**：布线项目的有源接入层现在固定配哪个牌子？选型流程怎么走？
- **随附证明**：规格对照 + 到岸价目 + 英国交付说明（英文）。

### 第 2 次跟进 · 工业级非管理 PoE（轨旁/车站通信柜，非安全场景）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：Railway Division 的轨旁/站房通信柜：宽温 DIN PoE 带摄像头/无线回传，明确只做非安全类通信段。
- **要问的问题**：轨旁通信柜里的以太网交换用什么？冷启动与宽温指标在这。
- **随附证明**：宽温/-40 冷启动报告 + 适用场景说明（非安全段）+ DIN 图。

### 第 3 次跟进 · 管理型 10G（DC 接入层+项目注册）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：Data Centre Division：管理型（ERPS/VLAN/10G 上行）做 DC 接入层候选，配项目注册与价格保护。
- **要问的问题**：DC 项目的接入层有没有在比的型号？项目注册政策发你。
- **随附证明**：VLAN/ERPS 模板 + 项目注册政策 + 10G 实测（英文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第6批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：码头区 25 年布线+网络基建集成商：商业改造/数据中心/跨国银行搬迁的幕后工，Railway Division 是工业场景钥匙（RISQS 入网资质）。
- **产品线与在售品牌**：结构化布线/机电/数据中心方案/托管服务/铁路通信五线；Allied 代理（CSV 记录）；自述厂商中立。
- **目标行业与场景**：蓝筹企业办公室搬迁、大型 DC 布线、药企/汽车/银行（卢森堡/法兰克福/布鲁塞尔案例墙）、铁路通信工程。
- **团队与规模**：七人领导班子的成熟公司；UK/欧洲/UAE/美国多地运营（官网）。
- **决策链与对接人**：+44 (0) 207 538 8701；具名 Chris Yearwood（COO）、Jon H（Head of Railway Division Comms）（CSV 9-27 记录）；官网领导层名单可拼邮。
- **技术与认证**：FORS+RISQS（铁路行业双认证，含金量高）+ISO9001/14001；Allied 代理（CSV 记录）。
- **采购与供应链信号**：布线项目带动有源设备配套：DC/办公楼网络段随布线单下；铁路分部=轨旁/车站通信柜的工业交换需求。
- **近期动态与线索**：2017 年以来年均增长（官网计数）+多国办公室——扩张期。
- **与我方契合点**：厂商中立+铁路/DC 双分部：工业宽温 PoE（轨旁/车库箱体）+DC 接入层，先送对照资料给他「公正选型」的货比流程。
- **风险与注意**：铁路有 EN50155/入网测试规矩：我们只排非安全类轨旁通信与站房场景，别夸到信号系统；厂商中立意味着也要经得起比测。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网：伦敦码头区老牌集成商，主营结构化布线与配套网络基础设施。
  > Located in the heart of the London Docklands, we are a long-established integrator specialising in structured cabling and associated network infrastructure.
  > 来源：https://www.dacceurope.com/
- **【技术与认证】**两大专项分部：FORS & RISQS 双认证的 Railway Division 与 Data Centre Division；全公司 ISO9001/14001。
  > …the creation of specialist divisions within our company, such as our FORS & RISQS approved Railway Division and our Data Centre Division. The entire company is certified to ISO9001, demonstrating our commitment to quality, and to ISO14001
  > 来源：https://www.dacceurope.com/
- **【采购与供应链信号】**官网自述「完全厂商中立」：不偏任何品牌、按客户需求公正选型——对第二品牌天然开放。
  > As a fully manufacturer-independent company, we pride ourselves on offering impartial and tailored solutions that best serve our clients’ unique requirements.
  > 来源：https://www.dacceurope.com/
- **【决策链与对接人】**官网领导层全列：CEO/FD/COO/商务/技术/项目/交付七人班子，Chris Yearwood（COO）与 CSV 具名一致。
  > Marin Shkodrov — Chief Executive Officer · Jazz Matharu — Financial Director · Chris Yearwood — Chief Operations Officer · Tony Grace — Commercial & Sales Director · David Long — Technical Director · Ricky Akers — Projects Director · Lee Millar — Service Delivery Director
  > 来源：https://www.dacceurope.com/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R67_R56_推土机批4.json`；价格均为 EXW 快照。

- **①背景再核**：1996 创 29 年;Canary Wharf E14 金丝雀码头+旧 Eastleigh;SHAB 2023-12 档活
- **②芯片/型号**：布线/基础设施/机电服务;PoE 24 口载线
- **③KP 深挖**：Matharu 二度任 64+Shkodrov 双职 50+James/Shaw CXO 5 人谱
- **④Saga 对标**：布线集成链 → 24 口 PoE 直采载;金丝雀码头谱
- **⑤在乎与偏好**：29 年谱;金丝雀码头 E14 谱;Telecom SIC

### R55 证据摘录（全部保留 · 含数量）

- **【法体登册】**DACC Europe Limited Company No 03297031;Incorporated 30 December 1996;SIC 61100 Wired telecommunications activities;154 Cannon Workshops 3 Cannon Drive London E14 4AS;+44 0207 538 8701
  > DACC Europe Limited Company No 03297031;Incorporated 30 December 1996;SIC 61100 Wired telecommunications activities;154 Cannon Workshops 3 Cannon Drive London E14 4AS;+44 0207 538 8701
  > 来源：https://find-and-update.company-information.service.gov.uk/company/03297031
- **【二度任金谱】**MATHARU, Jasvinderpal Singh(DOB Dec 1961)Director appointed 1999-02-10,resigned 2015-06-01,reappointed 2019-02-27=二度任;SHKODROV, Marin Krastev(DOB Sep 1975)Director+Company Secretary 2014-06-10 in role
  > MATHARU, Jasvinderpal Singh(DOB Dec 1961)Director appointed 1999-02-10,resigned 2015-06-01,reappointed 2019-02-27=二度任;SHKODROV, Marin Krastev(DOB Sep 1975)Director+Company Secretary 2014-06-10 in role
  > 来源：https://find-and-update.company-information.service.gov.uk/company/03297031/officers
- **【财务】**Latest financial report submitted 2023-12-31: Cash £652,230 increased 71.78% yoy;Total-Assets £12M;Working-Capital £1M;19 employees(staff increase 0%);11 directors;Age 29
  > Latest financial report submitted 2023-12-31: Cash £652,230 increased 71.78% yoy;Total-Assets £12M;Working-Capital £1M;19 employees(staff increase 0%);11 directors;Age 29
  > 来源：https://uk.globaldatabase.com/company/dacc-europe-limited
- **【公司谱】**DACC Europe specializes in structured cabling, infrastructure, and mechanical, and electrical services;Private London;51-100 employees;Information Technology/Mechanical Engineering/Network Hardware;+44 0207 538 8701;IT spend projected $3.7M
  > DACC Europe specializes in structured cabling, infrastructure, and mechanical, and electrical services;Private London;51-100 employees;Information Technology/Mechanical Engineering/Network Hardware;+44 0207 538 8701;IT spend projected $3.7M
  > 来源：https://www.crunchbase.com/organization/dacc-europe

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：DACC Europe Ltd(03297031,1996 创 29 年,有线电信 SIC):伦敦 E14 金丝雀码头布线/基础设施/机电服务商
- **产品线与在售品牌**：Computer cabling systems 供装+structured cabling/infrastructure/mechanical & electrical services;IT spend $3.7M
- **目标行业与场景**：伦敦金丝雀码头 E14 区域商用办公+数据中心布线/机电;有线通信 SIC
- **团队与规模**：19(globaldatabase)/51-100(crunchbase)双窗注;5 人董事谱;29 年
- **决策链与对接人**：Jasvinderpal Singh Matharu(Director 二度任 64 岁)+Marin Krastev Shkodrov(Director+Secretary 双职 50 岁)+Simon James+Andrew Shaw(CXO)+Michael Shaw(CXO)
- **技术与认证**：SIC 61100/61900 Wired telecom;Companies House 登实;UK funding £5k 2015
- **采购与供应链信号**：£652,230 现金增 71.78%(2023-12);£12M 总资产/£1.4M 留资;布线集成→交换机件直采谱
- **近期动态与线索**：董事二度任(Matharu 2019 复任);Eastleigh 旧营业地;现金大幅增 71.78% 新保
- **与我方契合点**：Matharu/Shkodrov 双董事直门 → 24 口 PoE(布线集成交换器件直采)载线
- **风险与注意**：**营收 IT spend $3.7M 估单源注;Matharu 二度任=2019 复任谱钉;员数 19/51-100 两窗注;报名墙东、北史注**

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | DACC 伦敦布线/DC 厂商中立：RISQS 铁路红线不触；私营银行/制药段+电话先行（$180 锚点一致） |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：29 年+金丝雀码头
- **W**：营收 IT spend $3.7M 单源估注
- **O**：现金 £652k 增 71.78%=新保
- **T**：员数 19/51-100 两窗注

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**本户特别红线/停止条件**

- 一人/个体=单点与节奏风险

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ❓ 缺邮箱 |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] MikroTik 谱位在售线需官网核
  - [ ] Matharu 直邮推档
  - [ ] 员数 19 vs 51-100 两窗差精确次年订

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Jasvinderpal Matharu Team,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $165 USD EXW (2026-10-08, 15 days valid) — a value unit for structured cabling and infrastructure deployment lines in commercial properties. Datasheet + CE pack on request.

Best regards
Saga / SmartByte ODM
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
