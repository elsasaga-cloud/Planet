# Brian Vargyas

> **评级 A**　|　美国 · Naperville / Chicago, IL　|　档案编号 `A-098`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-098
rating: A
country: 美国
biz_org: 个体顾问（无官网）
business_model: 顾问项目制
decision_speed: fast
price_sensitivity: high
volume_potential: 1  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: true, oem: false, hotel: false, training: false}
p1: STC-28DGGPM
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：个体顾问（无官网）；顾问项目制
- **商业模式**：顾问项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；信息待人工补齐（见备注）
- **P1（首触唯一主推）**：STC-28DGGPM（8口 PoE 接入盒） — Vargyas 美 MTCNA 单证 LinkedIn 渠道：破冰薄档如实（$99 锚点一致）；$99 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Brian Vargyas（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 美国 / Naperville / Chicago, IL | 事实 |
| 网站 | —（无公开站点） | 事实 |
| 类型 | 集成商/顾问（MikroTik 认证） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | MikroTik 认证，持 MTCNA | 事实（名录/自报口径） |
| 组织性质 | 个体顾问（无官网） | 【推断】 |
| 商业模式 | 顾问项目制 | 【推断】 |
| 团队规模 | 一人/微型 | 【推断】 |
| 决策链 | 短（本人即决策） | 【推断】 |
| ⚠️ 信息缺口 | 本条**抓不到邮箱**，需人工补齐邮箱或改为电话单独跟进后再进群发名单 | 事实 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】波 27·A-098:美国谱: **守档准由·原 R56 谱基增厚**:Brian Vargyas（美国）：MTCNA 单证顾问；无官网（CSV：LinkedIn 链接截断）；电话 630-929-3610 / 888-929-3610;R66 第 27 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第10批.json,先报价不回、档案铺位、持续关注新一季,OK。
- 【推断】R66 第 27 波守档准由谱
- 【假设】档案铺位谱,持续关注新一季

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：MikroTik 认证，持 MTCNA）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、VoIP/Voice VLAN
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - VoIP/Voice VLAN：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：—
  - 状态：缺失（leads-only 口径：人工补录前**不进群发**，与旧批次纪律一致）
- **电话**：630-929-3610、888-929-3610
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：630-929-3610 / 888-929-3610；⚠️ 无邮箱：LinkedIn linkedin.com/in/brianvargyas/｜Vargyas Consulting, LLC（Naperville）。另在 MikroTik 官方论坛与 Baltic Networks 同台讲 60GHz PtMP → 属 MikroTik 圈子活跃者，值得 LinkedIn 私信
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。

## 关键人（KP）与触达通道

- 关键人未定位：首封信件以 info/通用邮箱开场并向其索要正确联系人。

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-28DGGPM（8口 PoE 接入盒）），备选型不进邮件。

### 第 1 次跟进 · 品类空缺补位（分销货架工业 PoE/管理型）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C） / STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：渠道对话：他的 WISP 货架上「宽温 DIN PoE」与「24 口万兆上行接入层」是明显价位空档，直接给分销价目与毛利结构。
- **要问的问题**：货架上工业 PoE 这段现在是谁家的？毛利多少？
- **随附证明**：分销价目 + 同档对照 + 渠道政策（英文）。

### 第 2 次跟进 · 工业非管理 PoE（塔站/室外配套量）

- **推什么**：STI-240GE（Saga） PoE 版（4G + 2×SFP，DIN，-40~75°C）
- **切入点**：塔站/热点的万能配套件：4 口小机混批+组合装（配防雷/电源），按他的客群动销测算摆数据。
- **要问的问题**：塔站配套件一个月走多少？混批政策发你看看？
- **随附证明**：混批价目 + 组合装方案 + 宽温报告。

### 第 3 次跟进 · 管理型 10G（汇聚段+培训实验台双钩）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：货架扩展+他讲师身份：管理型（ERPS/L3 卸载）进汇聚段货架，同时放一台进他实验台做课程对照。
- **要问的问题**：汇聚段要不要加一款高性价比管理型？实训课要不要对照机？
- **随附证明**：ERPS/L3 实测 + 实验机成本价 + 课程素材。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第5批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：芝加哥西郊 Baltic Networks 创始人：WISP 设备分销+无线方案集成+认证培训三栖（CSV 记「电话与 Baltic 同号段」实为同一人）。
- **产品线与在售品牌**：Baltic Networks 分销货架（MikroTik/Ubiquiti 等 WISP 全线，历史页面口径）+M2M/监控方案+培训课程。
- **目标行业与场景**：美加 WISP/热点商/数字标牌/M2M 远程监控与安防客户群——渠道末端工程师密集。
- **团队与规模**：2005 年至今的伊利诺伊老牌 WISP 分销，公司化运营。
- **决策链与对接人**：630-929-3610 / 888-929-3610（CSV 记录；LinkedIn linkedin.com/in/brianvargyas）。
- **技术与认证**：MTCNA+认证讲师（MUM 档案与 CSV 记录）；无线/热点/Dude/M2M 蜂窝方案专家。
- **采购与供应链信号**：分销商自有货架+培训实验台+集成项目三条消耗线；对新品牌持渠道商本能的开放度。
- **近期动态与线索**：MUM 两届全国演讲者（2010/2015）——圈内脸熟级人物；近期公开动态少，按公司口径触达。
- **与我方契合点**：分销货架的工业 PoE/管理型价位补位；他讲课时实验台可做对照演示；无「同芯片」话术约束（MikroTik 生态）。
- **风险与注意**：老江湖不吃推销话术：只谈货架空缺与毛利结构；先报价目+渠道政策。

### R54 原文证据摘录（全部保留）

- **【业务定位】**MUM 凤凰城 2010 演讲档案：Brian Vargyas——Baltic Networks 老板、8+ 年 RouterOS、MikroTik 认证讲师。
  > Brian Vargyas, Owner, Baltic Networks – Over 8 years experience using RouterOS – Specialization in Wireless, Hotspot and the Dude – MikroTik Certified Trainer
  > 来源：https://mum.mikrotik.com/presentations/US10/Brian.pdf
- **【技术与认证】**MUM 美国 2015 演讲：「RouterOS 3G/4G 方案」——蜂窝回传/物联网方向深耕者。
  > 3G/4G Solutions with RouterOS — Brian Vargyas – Baltic Networks USA — MikroTik User Meeting USA 2015
  > 来源：https://mum.mikrotik.com/presentations/US15/brian.pdf
- **【团队与规模】**Crunchbase：Baltic Networks 2005 年创立，伊利诺伊 Lisle，做高性价比无线/有线组网与 M2M 方案——他是创始人（第三方页）。
  > Baltic Networks, founded in 2005, provides cost effective wireless and wired networking and machine-to-machine (M2M) solutions… Lisle, Illinois, United States
  > 来源：https://www.crunchbase.com/organization/baltic-networks

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第27波50户.json`；价格均为 EXW 快照。

- **①背景再核**：波 27·A-098:美国谱: **守档准由·原 R56 谱基增厚**:Brian Vargyas（美国）：MTCNA 单证顾问；无官网（CSV：LinkedIn 链接截断）；电话 630-929-3610 / 888-929-3610;R66 第 27 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第10批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **②芯片/型号**：STC-28DGGPM·8-port PoE access box (802.3af/at, watchdog)
- **③KP 深挖**：**守档准由;R66 第 27 波点名(谱面无实名)**
- **④Saga 对标**：STC-28DGGPM vs PLANET/当批价差窗
- **⑤在乎与偏好**：美国 谱;CE/UKCA;持续关注新一季

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**Brian Vargyas（美国）：MTCNA 单证顾问；无官网（CSV：LinkedIn 链接截断）；电话 630-929-3610 / 888-929-3610
  > Brian Vargyas（美国）：MTCNA 单证顾问；无官网（CSV：LinkedIn 链接截断）；电话 630-929-3610 / 888-929-3610
  > 来源：仓内:A类深挖_2026-09-28_R56_第10批.json
- **【联系方式与基础画像】**CSV 入口:630-929-3610 / 888-929-3610；⚠️ 无邮箱：LinkedIn linkedin.com/in/brianvargyas/｜Vargyas Consulting, LLC（Naperville）。另在 MikroTi
  > CSV 入口:630-929-3610 / 888-929-3610；⚠️ 无邮箱：LinkedIn linkedin.com/in/brianvargyas/｜Vargyas Consulting, LLC（Naperville）。另在 MikroTi
  > 来源：仓内:A类深挖_2026-09-28_R56_第10批.json

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：波 27·A-098:美国谱: **守档准由·原 R56 谱基增厚**:Brian Vargyas（美国）：MTCNA 单证顾问；无官网（CSV：LinkedIn 链接截断）；电话 630-929-3610 / 888-929-3610;R66 第 27 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第10批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **产品线与在售品牌**：MikroTik 认证，持 MTCNA
- **目标行业与场景**：美国 谱;集成商/顾问（MikroTik 认证）
- **团队与规模**：美国谱·守档准由
- **决策链与对接人**：**守档准由;R66 第 27 波点名(谱面无实名)**
- **技术与认证**：STC-28DGGPM 对口谱;$99 USD EXW 锚
- **采购与供应链信号**：B2B 批口谱
- **近期动态与线索**：2026-10-08 R66 27 波谱名牌(A 类补全批)
- **与我方契合点**：STC-28DGGPM(8-port PoE access box) 档案铺位窗
- **风险与注意**：具名缺(守档准由)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-28DGGPM（8口 PoE 接入盒） | 主场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Vargyas 美 MTCNA 单证 LinkedIn 渠道：破冰薄档如实（$99 锚点一致） |
| 备选2 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：8口 GE(7)+SFP，PoE af/at 240W，DC 随附电源，L2+ 全特性（VLAN/ERPS<20ms/QinQ/Private VLAN/sFlow），PoE 看门狗自动冷重启
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：R56 谱基在册
- **W**：具名缺(守档准由)
- **O**：STC-28DGGPM $99 USD EXW 价差窗
- **T**：谱链节奏;先报价不回则档案铺位

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**本户特别红线/停止条件**

- 一人/个体=单点与节奏风险

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ❓ |
| 触达通道 | ❓ 缺邮箱 |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 具名决策人(波次二)
  - [ ] 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Brian Vargyas Team,

We build a 8-port PoE access box (802.3af/at, watchdog). Reference: $99 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Datasheet + CE pack on request.

Best regards
Saga / SmartByte ODM
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
