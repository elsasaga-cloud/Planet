# Roelof Daleboudt

> **评级 A**　|　荷兰 · Coevorden　|　档案编号 `A-315`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-315
rating: A
country: 荷兰
biz_org: 个体顾问（无官网）
business_model: 顾问项目制
decision_speed: fast
price_sensitivity: high
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: true, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: CONSULT-OEM
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：个体顾问（无官网）；顾问项目制
- **商业模式**：顾问项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；信息待人工补齐（见备注）
- **P1（首触唯一主推）**：OEM/白牌合作探询（无量产型号首推） — IP Central 荷 MikroTik 顾问 Roelof Daleboudt（AS207942；2025-08 并入 NiceCloud 注）：个人箱窄针（$180 锚点一致）；Ruckus/HP-E 栈共存句；—（合作探询，无量产报价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Roelof Daleboudt（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 荷兰 / Coevorden | 事实 |
| 网站 | —（无公开站点） | 事实 |
| 类型 | 集成商/顾问（MikroTik 认证） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | MikroTik 认证顾问，持 MTCRE | 事实（名录/自报口径） |
| 组织性质 | 个体顾问（无官网） | 【推断】 |
| 商业模式 | 顾问项目制 | 【推断】 |
| 团队规模 | 一人/微型 | 【推断】 |
| 决策链 | 短（本人即决策） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Roelof Daleboudt:Roelof Daleboudt(荷兰／Coevorden;**【人名司名同体=CSV 公司名即本人谱位,official-self-published 级金谱】**;类型: 集成商/顾问(MikroTik 认证);培训交付谱;档站 —（无公开站点）;个体顾问无官网档(个人箱在档);Ruckus/HP-E 栈共存句;建档供位待用户补邮箱)
- 【推断】R66 第 21 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-08, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：MikroTik 认证顾问，持 MTCRE）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、万兆上行/骨干
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - 万兆上行/骨干：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：roelof.daleboudt@ip-central.nl
  - 状态：既有/公开
- **电话**：088-4723636、2025-08-01、088 0400 900
- 来源等级：official-company（R41–R48 联系方式台账口径）
- **原始联系字段**：roelof.daleboudt@ip-central.nl（IP Central品牌页隐私政策公布）；088-4723636；2025-08-01并入NiceCloud后可参考info@nicecloud.nl / 088 0400 900
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Roelof Daleboudt**(MikroTik 认证培训师/顾问(档谱:CSV 公司名字段即本人))— 档谱+档站自署 〔已有(公司官方公开件/登记册自曝);源:仓内 profile/A/A-315-*(R54/R66 档谱基础画像行)〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Roelof Daleboudt | MikroTik 认证培训师/顾问(档谱:CSV 公司名字段即本人) | 档谱+档站自署 | official-self-published·谱/leads-only(直发需 opt-in) | 仓内 profile/A/A-315-*(R54/R66 档谱基础画像行) |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（OEM/白牌合作探询（无量产型号首推）），备选型不进邮件。

### 第 1 次跟进 · 总口核对接+RUCKUS 项目旁位一页

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行 L2+）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：先表单/电话到 NiceCloud 总口请转网络团队：RUCKUS/三供项目的 24 口 PoE 价位档第二来源（IP Central 并入致意一句）。
- **要问的问题**：RUCKUS/AP 项目的接入层 PoE 目前有价位档第二来源吗？
- **随附证明**：一页报价（荷/英）。

### 第 2 次跟进 · 备件小批

- **推什么**：STI-280GE（Saga） 等小批
- **切入点**：托管现场备件池小批。
- **要问的问题**：备件池走常备价吗？
- **随附证明**：小批价卡一页。

### 第 3 次跟进 · 价卡留档收口

- **推什么**：—（价卡留档）
- **切入点**：全品类价卡留档；无回复即冻结。
- **要问的问题**：（无需回）价卡留档。
- **随附证明**：全品类一页价卡。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第16批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：IP Central 已并入兹沃勒 NiceCloud（迁移 404 如实标注；KPN/RUCKUS/Aruba 锚牌 MSP——第二来源只做价位档）。
- **产品线与在售品牌**：全托管/增援式 MSP；KPN 连接+微软云+RUCKUS 无线。
- **目标行业与场景**：兹沃勒区域组织（PEC 赞助=本地深耕）。
- **团队与规模**：中型 MSP（双模式+多认证墙）。
- **决策链与对接人**：首选 info@nicecloud.nl / 088 0400 900（CSV 候选；表单有 Cloudflare 校验）；roelof.daleboudt@ip-central.nl 为隐私政策公开信、意愿核后再用。
- **技术与认证**：Roelof MTCRE（CSV 9-23 名录）；自有 AS207942 背景。
- **采购与供应链信号**：RUCKUS Big Dog 无线项目旁的接入层 PoE 价位档（AP/摄像/话机三供）+备件。
- **近期动态与线索**：10/29–30 Bedrijven Contact Dagen Zwolle 参展=本地市场活跃期。
- **与我方契合点**：24 口 PoE 价位档（RUCKUS 项目旁位）+备件小批。
- **风险与注意**：RUCKUS/Aruba 双锚不替位；个人隐私政策邮箱慎用——先总口核实对接。

### R54 原文证据摘录（全部保留）

- **【近期动态与线索】****站点迁移异常实锤**：ip-central.nl 本轮 302 跳至 nicecloud.nl/ipcentral 并返回 404（2025-08-01 并入 NiceCloud 的 CSV 记录一致）——其品牌页隐私政策公布的 roelof.daleboudt@ip-central.nl 属公开渠道但意愿待核，首选 NiceCloud 总口。
  > （2026-09-28 实测）ip-central.nl → nicecloud.nl/ipcentral = 404「Deze pagina kunnen we niet vinden」‖（CSV 2026-09-27 记录）2025-08-01 并入 NiceCloud 后可参考 info@nicecloud.nl / 088 0400 900
  > 来源：https://www.nicecloud.nl/
- **【产品线与在售品牌】**NiceCloud（兹沃勒 MSP）伙伴墙：**KPN/微软 Solutions Partner/RUCKUS Big Dog/Fortinet/HPE Aruba/Dell Gold**；PEC Zwolle 足球俱乐部赞助商；全托管+IT 团队增援双模式。
  > Erkend door & partner van — kpn · Microsoft Solutions Partner · Ruckus Big Dog · fortinet · HP-Enterprise（Aruba）· dell金 ‖ Verbonden met de regio — sponsor én leverancier van PEC Zwolle
  > 来源：https://www.nicecloud.nl/
- **【技术与认证】**Roelof 持 MTCRE，IP Central 自有 AS207942（RIPE: Roelof Daleboudt trading as IP Central，Coevorden——CSV 记录）；并入 NiceCloud 后其网络/BGP 资历并入该 MSP。
  > （CSV 2026-09-27 记录）IP Central（RIPE: Roelof Daleboudt trading as IP Central, AS207942, Coevorden）；2025-08-01 并入 NiceCloud
  > 来源：https://www.nicecloud.nl/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第21波50户.json`；价格均为 EXW 快照。

- **①背景再核**：Roelof Daleboudt(荷兰／Coevorden;**【人名司名同体=CSV 公司名即本人谱位,official-self-published 级金谱】**;类型: 集成商/顾问(MikroTik 认证);培训交付谱;档站 —（无公开站点）;个体顾问无官网档(个人箱在档);Ruckus/HP-E 栈共存句;建档供位待用户补邮箱)
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Roelof Daleboudt(MikroTik 认证培训师/顾问(档谱:CSV 公司名字段即本人),official-self-published·谱/leads-only(直发需 opt-in))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-08, 15天有效))
- **⑤在乎与偏好**：MTCSWE/交换认证谱=对口窗

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**国家/城市: %s;网站: %s;类型: 集成商/顾问(MikroTik 认证)(档案基础画像行=事实)
  > 国家/城市: %s;网站: %s;类型: 集成商/顾问(MikroTik 认证)(档案基础画像行=事实)
  > 来源：仓内 profile/A/A-315-*(R54/R66 档谱基础画像行)
- **【近期动态与线索】**档定首触角: 个人箱窄针($180 锚点一致);Ruckus/HP-E 栈共存句;**p1=CONSULT-OEM 谱(无量产报价)**
  > 档定首触角: 个人箱窄针($180 锚点一致);Ruckus/HP-E 栈共存句;**p1=CONSULT-OEM 谱(无量产报价)**
  > 来源：仓内 profile/A/A-315-*(R54/R66 档谱基础画像行)
- **【目标行业与场景】**档定值得跟: 【人工定级】A——自动规则已跳过(档注)
  > 档定值得跟: 【人工定级】A——自动规则已跳过(档注)
  > 来源：仓内 profile/A/A-315-*(R54/R66 档谱基础画像行)

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Roelof Daleboudt(荷兰／Coevorden;**【人名司名同体=CSV 公司名即本人谱位,official-self-published 级金谱】**;类型: 集成商/顾问(MikroTik 认证);培训交付谱;档站 —（无公开站点）;个体顾问无官网档(个人箱在档);Ruckus/HP-E 栈共存句;建档供位待用户补邮箱)
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：培训交付谱(MTCSWE 谱链)
- **团队与规模**：单铺/工作室谱
- **决策链与对接人**：**Roelof Daleboudt(MikroTik 认证培训师/顾问(档谱:CSV 公司名字段即本人),official-self-published·谱/leads-only(直发需 opt-in))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 21 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Geachte heer Daleboudt,(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | OEM/白牌合作探询（无量产型号首推） | 主场景 | —（合作探询，无量产报价） | IP Central 荷 MikroTik 顾问 Roelof Daleboudt（AS207942；2025-08 并入 NiceCloud 注）：个人箱窄针（$180 锚点一致）；Ruckus/HP-E 栈共存句 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：OEM/白牌合作：中性包装、贴客户型号、ODM 规格，MOQ 与认证另谈
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：MTCSWE/交换认证谱=对口窗
- **W**：单铺谱
- **O**：Roelof Daleboudt 本人直达位
- **T**：MikroTik 官方课链

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**本户特别红线/停止条件**

- 一人/个体=单点与节奏风险

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Geachte heer Daleboudt,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
