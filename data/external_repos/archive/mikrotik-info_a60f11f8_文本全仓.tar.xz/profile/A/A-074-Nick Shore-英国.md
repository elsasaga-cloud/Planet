# Nick Shore

> **评级 A**　|　英国 · Debenham　|　档案编号 `A-074`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-074
rating: A
country: 英国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: true, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: STC-28DGGPM
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（交换专长），且有具体人直联
- **P1（首触唯一主推）**：STC-28DGGPM（8口 PoE 接入盒） — Shore 英双证个人 CV 页：WhatsApp 破冰薄档如实（$99 锚点一致）；$99 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Nick Shore（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 英国 / Debenham | 事实 |
| 网站 | shore.me.uk | 事实 |
| 类型 | 集成商/顾问（MikroTik 认证） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | MikroTik 认证顾问 MTCNA+MTCRE | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】波 27·A-074:英国谱: **守档准由·原 R56 谱基增厚**:Nick Shore（英国）：MTCNA+MTCRE 双证顾问；shore.me.uk 为其家庭主页+个人简历+IMAP 邮件+付iverse 社交页（个人站，非商务站）;R66 第 27 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第8批.json,先报价不回、档案铺位、持续关注新一季,OK。
- 【推断】R66 第 27 波守档准由谱
- 【假设】档案铺位谱,持续关注新一季

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：MikroTik 认证顾问 MTCNA+MTCRE）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、万兆上行/骨干
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - 万兆上行/骨干：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：nick@shore.me.uk
  - 状态：既有/公开
- **电话**：+44 7588 286095
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：+44 7588 286095 / nick@shore.me.uk
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。

## 关键人（KP）与触达通道

- 关键人未定位：首封信件以 info/通用邮箱开场并向其索要正确联系人。

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-28DGGPM（8口 PoE 接入盒）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（手上项目配套）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：轻量问候式：他还在接零星咨询——24 口 PoE++ 作为「手上项目需要接入层时的一个可靠便宜选项」，附英文资料备着。
- **要问的问题**：您手上项目如果缺接入层，愿不愿意试一台？
- **随附证明**：规格书（英文 PDF）+ 英国交付说明。

### 第 2 次跟进 · 工业级非管理 PoE（WISP/室外点）

- **推什么**：STI-240GE（Saga） PoE 版（4G + 2×SFP，DIN，-40~75°C）
- **切入点**：情怀+实用：WISP 塔站/室外点的宽温免维护小机——聊聊他 Suffolk WISP 年代的供电痛点。
- **要问的问题**：当年塔站交换机坏机率高吗？现在这种宽温免配置的会不会省心点？
- **随附证明**：宽温报告 + 样机。

### 第 3 次跟进 · 管理型 PoE + 人脉引荐

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：请他看 L2/L3 实测数据（他看得懂）；若认可，请他向相熟的英国 MikroTik 经销商/顾问引荐——这是本户真正的产出。
- **要问的问题**：如果您觉得数据靠谱，方便引荐一两家您觉得合适我们聊聊的英国同行吗？
- **随附证明**：ERPS/收敛实测 + 引荐话术包（英文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第4批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：英国 MikroTik 元老级顾问：Multithread 前 MD（已半退休），现按项目制接临时咨询——影响力与资历远大于当前业务量。
- **产品线与在售品牌**：咨询服务（BGP/OSPF/VPN/防火墙/WISP 设计）；早年亲手做过硬件分销（linitx.com 创始团队成员）。
- **目标行业与场景**：ISP/WISP 与企业广域网；NHS 网络基础设施（历史项目）；Suffolk 本地 WISP 圈。
- **团队与规模**：个人；Debenham（Suffolk 乡村）。
- **决策链与对接人**：Nick Shore 本人（+44 7588 286095 / nick@shore.me.uk；另有 Fediverse 账号 shore.me.uk/social/nick）。
- **技术与认证**：MTCNA+MTCRE（CSV 名录记录）；RB112 时代入行，对 MikroTik 硬件生态史如数家珍。
- **采购与供应链信号**：半退休=偶发项目的小批量选型；真正价值在他的英国 MikroTik 渠道人脉（linitx 系）。
- **近期动态与线索**：2025 起「mostly retired」+在做商业导师（Help to Grow 项目）——别按活跃顾问的频率打扰。
- **与我方契合点**：他做过的项目=接入层与 WISP 设备选型；更大价值=引荐+背书：向英国 MikroTik 圈介绍我们时他一句话顶十封邮件。
- **风险与注意**：低频联系人：一年 1–2 封高质量问候即可；别发推销模板信，尊重前辈身份。

### R54 原文证据摘录（全部保留）

- **【近期动态与线索】**本人 CV 页自述 2025 年夏天（55 岁）已「基本退休」，目前只接临时性商务/技术咨询——活跃度明显下降，如实标注。
  > In the summer of 2025, at the grand old age of 55, I decided to do something different, and I retired (mostly). · I'm also still available for business and technical consultancy on an ad-hoc project basis.
  > 来源：https://shore.me.uk/cv/
- **【团队与规模】**履历：Multithread 1999–2025（技术顾问→CTO→2021 起任董事总经理）；早年还参与运营 linitx.com（英国 MikroTik 分销老店，2003 年起）。
  > 2021-2025 Multithread Consultants - Managing Director · 1999-2014 - Technical Consultant │ linitx.com - 2003 onwards
  > 来源：https://shore.me.uk/cv/
- **【技术与认证】**MikroTik 专页自述：在还没有实体 RouterBOARD 之前就开始用 RouterOS，给 Suffolk 本地 WISP 搭过 mini-ITX 路由，并在英国卖过 RB112，「我们甚至用 MikroTik 建过一个 WISP」。
  > I started using Mikrotik RouterOS before there were actual physical RouterBoards ! · we built some mini ITX based routers using RouterOS for a local WISP in Suffolk · We even built a WISP using Mikrotik.
  > 来源：https://shore.me.uk/mikrotik/
- **【业务定位】**专页技能清单：静态/BGP/OSPF 路由、IPsec/WireGuard VPN、防火墙、DHCP/DNS、Winbox/ssh/ROMON 管理——老一代 WISP 全栈。
  > Routing — Static, BGP, OSPF · VPNs — IPSec, Wireguard · Management — Winbox, ssh, ROMON
  > 来源：https://shore.me.uk/mikrotik/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第27波50户.json`；价格均为 EXW 快照。

- **①背景再核**：波 27·A-074:英国谱: **守档准由·原 R56 谱基增厚**:Nick Shore（英国）：MTCNA+MTCRE 双证顾问；shore.me.uk 为其家庭主页+个人简历+IMAP 邮件+付iverse 社交页（个人站，非商务站）;R66 第 27 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第8批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **②芯片/型号**：STC-28DGGPM·8-port PoE access box (802.3af/at, watchdog)
- **③KP 深挖**：**守档准由;R66 第 27 波点名(谱面无实名)**
- **④Saga 对标**：STC-28DGGPM vs PLANET/当批价差窗
- **⑤在乎与偏好**：英国 谱;CE/UKCA;持续关注新一季

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**Nick Shore（英国）：MTCNA+MTCRE 双证顾问；shore.me.uk 为其家庭主页+个人简历+IMAP 邮件+付iverse 社交页（个人站，非商务站）
  > Nick Shore（英国）：MTCNA+MTCRE 双证顾问；shore.me.uk 为其家庭主页+个人简历+IMAP 邮件+付iverse 社交页（个人站，非商务站）
  > 来源：https://shore.me.uk/
- **【联系方式与基础画像】**CSV 入口:+44 7588 286095 / nick@shore.me.uk
  > CSV 入口:+44 7588 286095 / nick@shore.me.uk
  > 来源：https://shore.me.uk/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：波 27·A-074:英国谱: **守档准由·原 R56 谱基增厚**:Nick Shore（英国）：MTCNA+MTCRE 双证顾问；shore.me.uk 为其家庭主页+个人简历+IMAP 邮件+付iverse 社交页（个人站，非商务站）;R66 第 27 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第8批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **产品线与在售品牌**：MikroTik 认证顾问 MTCNA+MTCRE
- **目标行业与场景**：英国 谱;集成商/顾问（MikroTik 认证）
- **团队与规模**：英国谱·守档准由
- **决策链与对接人**：**守档准由;R66 第 27 波点名(谱面无实名)**
- **技术与认证**：STC-28DGGPM 对口谱;$99 USD EXW 锚
- **采购与供应链信号**：B2B 批口谱
- **近期动态与线索**：2026-10-08 R66 27 波谱名牌(A 类补全批)
- **与我方契合点**：STC-28DGGPM(8-port PoE access box) 档案铺位窗
- **风险与注意**：具名缺(守档准由)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-28DGGPM（8口 PoE 接入盒） | 主场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Shore 英双证个人 CV 页：WhatsApp 破冰薄档如实（$99 锚点一致） |
| 备选2 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：8口 GE(7)+SFP，PoE af/at 240W，DC 随附电源，L2+ 全特性（VLAN/ERPS<20ms/QinQ/Private VLAN/sFlow），PoE 看门狗自动冷重启
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：R56 谱基在册
- **W**：具名缺(守档准由)
- **O**：STC-28DGGPM $99 USD EXW 价差窗
- **T**：谱链节奏;先报价不回则档案铺位

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ❓ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 具名决策人(波次二)
  - [ ] 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Nick Shore Team,

We build a 8-port PoE access box (802.3af/at, watchdog). Reference: $99 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Datasheet + CE pack on request.

Best regards
Saga / SmartByte ODM
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
