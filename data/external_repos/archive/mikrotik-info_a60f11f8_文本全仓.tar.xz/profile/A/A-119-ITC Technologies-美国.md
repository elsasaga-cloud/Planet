# ITC Technologies

> **评级 A**　|　美国 · Maybrook, NY　|　档案编号 `A-119`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-119
rating: A
country: 美国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: true, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；信息待人工补齐（见备注）
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — ITC 纽约 SMB 托管（监控+VoIP 双主线）：随单柜 value 位（$180 锚点一致）；无公开邮箱；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | ITC Technologies（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 美国 / Maybrook, NY | 事实 |
| 网站 | https://www.itc-technologies.com | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |
| ⚠️ 信息缺口 | 本条**抓不到邮箱**，需人工补齐邮箱或改为电话单独跟进后再进群发名单 | 事实 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】波 27·A-119:美国谱: **守档准由·原 R56 谱基增厚**:ITC Technologies（Independent Telecommunications Corporation，纽约 Maybrook）：中小企托管 IT 商——托管 IT/**视频监控（commercial-grade HD/UHD）**/VoIP 电话系统/网络安全/云/业务连续性；“We manage your technology so you can manage your business”；客户见证含 Senior Independent Living Community 养老社区;R66 第 27 波谱:我司 STC-424XGGPM-280W($165 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第12批.json,先报价不回、档案铺位、持续关注新一季,OK。
- 【推断】R66 第 27 波守档准由谱
- 【假设】档案铺位谱,持续关注新一季

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、VoIP/Voice VLAN
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - VoIP/Voice VLAN：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：—
  - 状态：缺失（leads-only 口径：人工补录前**不进群发**，与旧批次纪律一致）
- **电话**：+1 845-561-4440
- 来源等级：lead（R41–R48 联系方式台账口径）
- **原始联系字段**：No published email found; itc-technologies.com; +1 845-561-4440; form: https://www.itc-technologies.com/contact/; LinkedIn: https://www.linkedin.com/company/itccommunications
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。

## 关键人（KP）与触达通道

- 关键人未定位：首封信件以 info/通用邮箱开场并向其索要正确联系人。

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（监控项目接入层）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：他卖 ultra-HD 监控：几十路摄像头项目标配 24 口 PoE++，一页报价+对照。
- **要问的问题**：（电话/表单/LinkedIn）监控项目的接入层用什么？
- **随附证明**：一页报价 + 规格对照 + 质保说明（英文）。

### 第 2 次跟进 · 工业级非管理 PoE（养老社区室外/车库点）

- **推什么**：STI-240GE（Saga） PoE 版（4G + 2×SFP，DIN，-40~75°C）
- **切入点**：养老社区的花园/车库/外围摄像头：4 口宽温小机随项目配。
- **要问的问题**：养老社区外围点位怎么做？
- **随附证明**：宽温报告 + DIN 图 + 备件包价。

### 第 3 次跟进 · 管理型 PoE（多站点分段标准件）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：多站点（养老/连锁 SMB）的 VLAN 分段+ERPS 模板标准件。
- **要问的问题**：多站点客户的网络分段有没有标准模板？
- **随附证明**：VLAN/ERPS 模板 + 评估样机（英文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第6批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：纽约上州 Maybrook 的 SMB 电信+IT 服务商（原 ITC Communications 更名）：托管 IT/监控/VoIP/网安四线，Allied 代理（CSV 记录）。
- **产品线与在售品牌**：Managed IT/商用视频监控/VoIP/网络安全；防火墙路由宽带设备随项目配套。
- **目标行业与场景**：上州 SMB、养老社区（多站点监控/护士呼叫网络）、营销公司等专业服务。
- **团队与规模**：小型服务商（更名后的 ITC Technologies 品牌）。
- **决策链与对接人**：⚠️ 无公开邮箱：+1 845-561-4440；官网表单；LinkedIn 公司页可找业务人员（CSV 9-27 记录）。
- **技术与认证**：Allied 代理（CSV 记录）。
- **采购与供应链信号**：SMB 项目制小批量+养老社区多站点复购；价格敏感。
- **近期动态与线索**：更名+新域名刚启用——品牌更新期正适合递「新供应商资料」。
- **与我方契合点**：监控项目的 24 口接入层+养老社区多站点标准件。
- **风险与注意**：无邮箱：电话+表单+LinkedIn 三路轻触达；更名期沟通落款双品牌（ITC Communications/Technologies）都认得。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网：ITC（Independent Telecommunications Corporation）为中小企业提供全套技术方案——「我们管技术，你管业务」。
  > ITC (Independent Telecommunications Corporation) offers a vast range of technology solutions for today’s small and midsize businesses… We manage your technology so that you can manage your business.
  > 来源：https://www.itc-technologies.com/
- **【产品线与在售品牌】**四条线：Managed IT（含防火墙/路由/移动设备）/商用视频监控（HD 与 ultra-HD）/VoIP 话机系统/网络安全。
  > Our business solutions include managed IT services that proactively address problems… including firewalls, routers, mobile devices, and more. ‖ ITC offers commercial-grade video surveillance solutions that use the latest in high-definition and ultra-HD technology.
  > 来源：https://www.itc-technologies.com/
- **【目标行业与场景】**客户证言：Focus Media（营销公司）、Senior Independent Living Community（养老社区）IT 总监、Clearfly——SMB 与养老社区是基本盘。
  > ‘Superior customer service and the latest technology! My firm, Focus Media, is demanding and I am super-pleased with ITC!’ — Josh Sommers · ‘I’ve been very happy… They’ll build a system based on your needs.’ — Jason, IT Director, Senior Independent Living Community
  > 来源：https://www.itc-technologies.com/
- **【近期动态与线索】**LinkedIn 公司页公开宣布启用新域名（旧名 ITC Communications）——更名/品牌更新期（CSV 9-27 记录）。
  > LinkedIn 公司页公开宣布新域名，匹配 Maybrook NY；旧名 ITC Communications（CSV 2026-09-27 记录）
  > 来源：https://www.linkedin.com/company/itccommunications

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第27波50户.json`；价格均为 EXW 快照。

- **①背景再核**：波 27·A-119:美国谱: **守档准由·原 R56 谱基增厚**:ITC Technologies（Independent Telecommunications Corporation，纽约 Maybrook）：中小企托管 IT 商——托管 IT/**视频监控（commercial-grade HD/UHD）**/VoIP 电话系统/网络安全/云/业务连续性；“We manage your technology so you can manage your business”；客户见证含 Senior Independent Living Community 养老社区;R66 第 27 波谱:我司 STC-424XGGPM-280W($165 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第12批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **②芯片/型号**：STC-424XGGPM-280W·24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog)
- **③KP 深挖**：**守档准由;R66 第 27 波点名(谱面无实名)**
- **④Saga 对标**：STC-424XGGPM-280W vs PLANET/当批价差窗
- **⑤在乎与偏好**：美国 谱;CE/UKCA;持续关注新一季

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**ITC Technologies（Independent Telecommunications Corporation，纽约 Maybrook）：中小企托管 IT 商——托管 IT/**视频监控（commercial-grade HD/UHD）**/VoIP 电话系统/网络安全/云/业务连续性；“We manage y
  > ITC Technologies（Independent Telecommunications Corporation，纽约 Maybrook）：中小企托管 IT 商——托管 IT/**视频监控（commercial-grade HD/UHD）**/VoIP 电话系统/网络安全/云/业务连续性；“We manage y
  > 来源：https://www.itc-technologies.com/
- **【联系方式与基础画像】**CSV 入口:No published email found; itc-technologies.com; +1 845-561-4440; form: https://www.itc-technologies.com/contact/; Linked
  > CSV 入口:No published email found; itc-technologies.com; +1 845-561-4440; form: https://www.itc-technologies.com/contact/; Linked
  > 来源：https://www.itc-technologies.com/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：波 27·A-119:美国谱: **守档准由·原 R56 谱基增厚**:ITC Technologies（Independent Telecommunications Corporation，纽约 Maybrook）：中小企托管 IT 商——托管 IT/**视频监控（commercial-grade HD/UHD）**/VoIP 电话系统/网络安全/云/业务连续性；“We manage your technology so you can manage your business”；客户见证含 Senior Independent Living Community 养老社区;R66 第 27 波谱:我司 STC-424XGGPM-280W($165 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第12批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **产品线与在售品牌**：Allied Telesis（Marvell Prestera 接入层）
- **目标行业与场景**：美国 谱;集成商/代理（Allied Telesis）
- **团队与规模**：美国谱·守档准由
- **决策链与对接人**：**守档准由;R66 第 27 波点名(谱面无实名)**
- **技术与认证**：STC-424XGGPM-280W 对口谱;$165 USD EXW 锚
- **采购与供应链信号**：B2B 批口谱
- **近期动态与线索**：2026-10-08 R66 27 波谱名牌(A 类补全批)
- **与我方契合点**：STC-424XGGPM-280W(24-port Gigabit PoE access switch) 档案铺位窗
- **风险与注意**：具名缺(守档准由)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | ITC 纽约 SMB 托管（监控+VoIP 双主线）：随单柜 value 位（$180 锚点一致）；无公开邮箱 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：R56 谱基在册
- **W**：具名缺(守档准由)
- **O**：STC-424XGGPM-280W $165 USD EXW 价差窗
- **T**：谱链节奏;先报价不回则档案铺位

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ❓ |
| 触达通道 | ❓ 缺邮箱 |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 具名决策人(波次二)
  - [ ] 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear ITC Technologies Team,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $165 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Datasheet + CE pack on request.

Best regards
Saga / SmartByte ODM
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
