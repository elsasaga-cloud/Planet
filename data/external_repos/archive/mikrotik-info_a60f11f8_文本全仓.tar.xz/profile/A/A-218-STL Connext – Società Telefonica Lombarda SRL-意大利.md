# STL Connext – Società Telefonica Lombarda SRL

> **评级 A**　|　意大利 · Brescia　|　档案编号 `A-218`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-218
rating: A
country: 意大利
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: true, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；信息待人工补齐（见备注）
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — STL 伦巴第电话+布线双主业：reti dati 随单+Voice VLAN（$180 锚点一致）；PA/PNRR 守界；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | STL Connext – Società Telefonica Lombarda SRL（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 意大利 / Brescia | 事实 |
| 网站 | https://stlconnext.it | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |
| ⚠️ 信息缺口 | 本条**抓不到邮箱**，需人工补齐邮箱或改为电话单独跟进后再进群发名单 | 事实 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】STL Connext – Società Telefonica Lombarda SRL:STL CONNEXT / Società Telefonica Lombarda Srl(意大利 Brescia;**33 年谱(员工轨 1991-92 起);更名谱 Società Telefonica Lombarda → STL CONNEXT(2023 前后)**;**Daniele Pozzi Direttore Operativo(1991 起 8 职级贯谱=in-house 33 年升谱!)+Marco Presti Direttore operativo(前 Responsabile acquisti 采购谱 KPI)+Matteo Ceruti Sales Manager+Massimo Braghini 技术**)
- 【推断】R66 第 19 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、VoIP/Voice VLAN
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - VoIP/Voice VLAN：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@stlconnext.it
  - 状态：待核·未验证投递（不进群发）
- **电话**：—
- 来源等级：official-pdf-historical（R41–R48 联系方式台账口径）
- **原始联系字段**：info@stlconnext.it（旧官方PDF公开；历史入口待核；未验证投递）；原入口：见 alliedtelesis.com 伙伴页
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Daniele Pozzi**(Direttore Operativo(1991 起 33 年贯谱;LI 谱面条))— linkedin.com/in/daniele-pozzi 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://www.linkedin.com/in/daniele-pozzi-04b6441a3/〕
  - **Marco Presti**(Direttore operativo(前 Responsabile acquisti 1995-2017=采购谱 KPI))— RocketReach 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://rocketreach.co/marco-presti-email_229046824〕
  - **Matteo Ceruti**(Sales Manager(销售直达))— RocketReach 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://rocketreach.co/marco-presti-email_229046824〕
  - **Massimo Braghini**(Impiegato tecnico(技术谱))— RocketReach 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://rocketreach.co/marco-presti-email_229046824〕
  - **Enrica Ballini / Francesca Tufano**(客账/行政谱(支持位))— LI 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://www.linkedin.com/〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Daniele Pozzi | Direttore Operativo(1991 起 33 年贯谱;LI 谱面条) | linkedin.com/in/daniele-pozzi 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://www.linkedin.com/in/daniele-pozzi-04b6441a3/ |
| Marco Presti | Direttore operativo(前 Responsabile acquisti 1995-2017=采购谱 KPI) | RocketReach 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://rocketreach.co/marco-presti-email_229046824 |
| Matteo Ceruti | Sales Manager(销售直达) | RocketReach 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://rocketreach.co/marco-presti-email_229046824 |
| Massimo Braghini | Impiegato tecnico(技术谱) | RocketReach 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://rocketreach.co/marco-presti-email_229046824 |
| Enrica Ballini / Francesca Tufano | 客账/行政谱(支持位) | LI 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://www.linkedin.com/ |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 核实邮箱+24 口 CCTV/PoE（布线网络项目接入层）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：先电话/表单确认当前邮箱，随之：布线网络项目的 24 口 PoE++ 对照现用件。
- **要问的问题**：布线网络项目的接入层现在配什么？
- **随附证明**：规格对照 + 一页报价（意）。

### 第 2 次跟进 · 工业级非管理 PoE（厂房/车库户外点位）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：厂房/车库/户外点位：宽温 DIN PoE+备件包（h24 支持语境）。
- **要问的问题**：户外点位坏机率+上门成本怎么算？
- **随附证明**：宽温报告 + 备件包价。

### 第 3 次跟进 · 管理型 PoE（网络栈分段标准件）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：他招 L2-L7 人才：技术对话直给 VLAN/ERPS/L3 模板+样机评估。
- **要问的问题**：分段模板要不要进你们的工程库？
- **随附证明**：VLAN/ERPS 模板 + 样机。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第11批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：布雷西亚 40 年通信与网络集成商（STL→Connext 焕新）：UC/连接/布线网络/托管云一体，Allied Resell（CSV 记录）。
- **产品线与在售品牌**：ERMES AI 自有产品+UC/电话/连接/布线网络/托管云/安全/移动+三级支持套餐。
- **目标行业与场景**：伦巴第企业客户（正路）；公立行政为轻口径存在（划线提示）。
- **团队与规模**：中型（h24 支持组织）。
- **决策链与对接人**：info@stlconnext.it（历史 PDF 待核，CSV 口径：先电话/表单核可达；勿与同址 SOTECH 串发）。
- **技术与认证**：Allied Resell（CSV 记录）。
- **采购与供应链信号**：布线网络自营话+L2-L7 招聘口径=技术对话可深入 IP 层；h24 支持=坏机率与备件敏感；品牌焕新期=供应商更新窗口。
- **近期动态与线索**：45 周年+Connext 焕新活动+系统工程师招聘中。
- **与我方契合点**：布线网络项目的接入层 24 口与室外/工业件——网络堆栈是他正在加码的岗。
- **风险与注意**：公立行政轻口径→商业段为主；历史邮箱先电话核；与 A-216 同址勿合并勿串发。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网：40+ 年企业通信商，2024/25 完成 Connext 品牌焕新——方案自 **ERMES AI 虚拟助理**到统一通信、连接、电话、**布线与网络**、托管云、安全、移动八件。
  > Da oltre 40 anni, operiamo nello sviluppo, progettazione, commercializzazione e gestione di soluzioni e servizi per le comunicazioni aziendali. ‖ ERMES AI · Unified Communications · Connettività · Telefonia · Cablaggio e networking（Progettiamo e realizziamo reti dati di ogni dimensione e tipo）· Servizi gestiti & Cloud · Sicurezza · Mobile
  > 来源：https://stlconnext.it/
- **【近期动态与线索】**正在招聘 **Sistemista VoIP & Network：L2 到 L7 传输栈**——网络实施是其招聘口径的一线；45 周年庆活动=品牌焕新营销期。
  > Sistemista VoIP & Network — gestione ed evoluzione di infrastrutture di comunicazione IP complesse… stack trasmissivo, dal Layer 2 al Layer 7 ‖ Il Team di STL festeggia il rebranding（45 周年）
  > 来源：https://stlconnext.it/
- **【产品线与在售品牌】**支持体系产品化：ASSISTENZA FULL RISK/PLUS/LIGHT 三级+h24 承诺；服务企业与⚠️公立行政（轻口径），PNRR 投资咨询在 FAQ。
  > Aiutiamo imprese e pubblica amministrazione… ‖ ASSISTENZA FULL RISK / PLUS / LIGHT · assistenza h24 · consulenza… investimenti tecnologici resi disponibili dal PNRR（FAQ）
  > 来源：https://stlconnext.it/
- **【决策链与对接人】**CSV 9-27：info@stlconnext.it 仅 2023 官方案例 PDF 页末公开（历史入口待核）；当前联系页正文仅电话+39 030 2685411、地址 Via Achille Grandi 43/B 与表单——⚠️与同址 A-216 SOTECH 非同一客户不合并（CSV 原话）。
  > 2023年官网案例PDF正文末尾确认邮箱；当前联系页正文仅电话…搜索无果（CSV 2026-09-27 记录）；（SOTECH 备注）和STL Connext共地址不是同一客户证明；不合并
  > 来源：https://stlconnext.it/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第19波50户.json`；价格均为 EXW 快照。

- **①背景再核**：STL CONNEXT / Società Telefonica Lombarda Srl(意大利 Brescia;**33 年谱(员工轨 1991-92 起);更名谱 Società Telefonica Lombarda → STL CONNEXT(2023 前后)**;**Daniele Pozzi Direttore Operativo(1991 起 8 职级贯谱=in-house 33 年升谱!)+Marco Presti Direttore operativo(前 Responsabile acquisti 采购谱 KPI)+Matteo Ceruti Sales Manager+Massimo Braghini 技术**)
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Daniele Pozzi(Direttore Operativo(1991 起 33 年贯谱;LI 谱面条),leads-only·待 opt-in(LinkedIn/谱面带核));Marco Presti(Direttore operativo(前 Responsabile acquisti 1995-2017=采购谱 KPI),leads-only·待 opt-in(LinkedIn/谱面带核));Matteo Ceruti(Sales Manager(销售直达),leads-only·待 opt-in(LinkedIn/谱面带核));Massimo Braghini(Impiegato tecnico(技术谱),leads-only·待 opt-in(LinkedIn/谱面带核));Enrica Ballini / Francesca Tufano(客账/行政谱(支持位),leads-only·待 opt-in(LinkedIn/谱面带核))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：Presti 采购谱=KPI 直达+更名窗

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Daniele Pozzi: Direttore Operativo STL CONNEXT(2018-01 至今;履 Società Telefonica Lombarda 1991-2017 共 8 级谱);Marco Presti(前 acquisti 1995-2017→direttore operativo 2023);Matteo Ceruti Sales Manager(LI/RR 谱面条)
  > Daniele Pozzi: Direttore Operativo STL CONNEXT(2018-01 至今;履 Società Telefonica Lombarda 1991-2017 共 8 级谱);Marco Presti(前 acquisti 1995-2017→direttore operativo 2023);Matteo Ceruti Sales Manager(LI/RR 谱面条)
  > 来源：https://www.linkedin.com/in/daniele-pozzi-04b6441a3/
- **【联系方式与基础画像】**Brescia;**更名谱: Società Telefonica Lombarda Srl → STL CONNEXT(2023-02 前后;员工履档谱条)**;33 年电信工程谱
  > Brescia;**更名谱: Società Telefonica Lombarda Srl → STL CONNEXT(2023-02 前后;员工履档谱条)**;33 年电信工程谱
  > 来源：https://www.stlconnext.it/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：STL CONNEXT / Società Telefonica Lombarda Srl(意大利 Brescia;**33 年谱(员工轨 1991-92 起);更名谱 Società Telefonica Lombarda → STL CONNEXT(2023 前后)**;**Daniele Pozzi Direttore Operativo(1991 起 8 职级贯谱=in-house 33 年升谱!)+Marco Presti Direttore operativo(前 Responsabile acquisti 采购谱 KPI)+Matteo Ceruti Sales Manager+Massimo Braghini 技术**)
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：意大利布雷西亚 33 年电信工程屋(更名谱)
- **团队与规模**：中型谱;33 年
- **决策链与对接人**：**Daniele Pozzi(Direttore Operativo(1991 起 33 年贯谱;LI 谱面条),leads-only·待 opt-in(LinkedIn/谱面带核));Marco Presti(Direttore operativo(前 Responsabile acquisti 1995-2017=采购谱 KPI),leads-only·待 opt-in(LinkedIn/谱面带核));Matteo Ceruti(Sales Manager(销售直达),leads-only·待 opt-in(LinkedIn/谱面带核));Massimo Braghini(Impiegato tecnico(技术谱),leads-only·待 opt-in(LinkedIn/谱面带核));Enrica Ballini / Francesca Tufano(客账/行政谱(支持位),leads-only·待 opt-in(LinkedIn/谱面带核))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 19 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Presti 运营位(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | STL 伦巴第电话+布线双主业：reti dati 随单+Voice VLAN（$180 锚点一致）；PA/PNRR 守界 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：Presti 采购谱=KPI 直达+更名窗
- **W**：中实体谱
- **O**：Presti/Pozzi 双运营位
- **T**：区域链竞谱

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Gentile Sig. Presti,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
