# Daten- und Telekommunikations-GmbH Dessau

> **评级 A**　|　德国 · Dessau-Roßlau　|　档案编号 `A-147`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-147
rating: A
country: 德国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STC-28DGGPM
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；人工指定
- **P1（首触唯一主推）**：STC-28DGGPM（8口 PoE 接入盒） — DATEL Dessau：Stadtwerke 全资市政 ISP——公共红线建档不出信；$99 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Daten- und Telekommunikations-GmbH Dessau（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 德国 / Dessau-Roßlau | 事实 |
| 网站 | https://www.datel-dessau.de | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Daten- und Telekommunikations-GmbH Dessau:Daten- und Telekommunikations-GmbH Dessau(「DATEL」;Dessau-Roßlau,Albrechtstr. 48;**HRB 15048 Stendal;€50k;1997-12-22 创;USt DE192067013;402 人/€274.6M(集团谱口径)**;**Stadtwerke Dessau 子公司=地方 FTTH/电视/固定网运营商(B2C+市政);谱面对其自营城集团+自家市民服务;距接入链=FTTH 谱**;datel-dessau.de
- 【推断】R66 第 14 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：datel-vertrieb@dvv-dessau.de
  - 状态：既有/公开
- **电话**：—
- 来源等级：official（R41–R48 联系方式台账口径）
- **原始联系字段**：datel-vertrieb@dvv-dessau.de [Publicly listed; delivery not tested]; https://www.datel-dessau.de
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Dino Wolfgang Höll**(Geschäftsführer(现任;登记谱 2018+))— implisense/webvalid 登记册谱 〔已有(公司官方公开件/登记册自曝);源:https://app.implisense.com/en/companies/daten-und-telekommunikations-gmbh-dessau-dessau-rosslau--DEJ5ILDOVM07〕
  - **Torsten Henze**(Einzelprokura(独代理,2022-12-12 在册))— webvalid 登记公告谱 〔已有(公司官方公开件/登记册自曝);源:https://www.webvalid.de/company/Daten-+und+Telekommunikations-GmbH+Dessau,+Dessau-Ro%C3%9Flau/HRB+15048〕
  - **Fred Kitzing**(Einzelprokura(2022-12-12 在册))— webvalid 登记公告谱 〔已有(公司官方公开件/登记册自曝);源:https://www.webvalid.de/company/Daten-+und+Telekommunikations-GmbH+Dessau,+Dessau-Ro%C3%9Flau/HRB+15048〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Dino Wolfgang Höll | Geschäftsführer(现任;登记谱 2018+) | implisense/webvalid 登记册谱 | official-self-published·谱/leads-only(直发需 opt-in) | https://app.implisense.com/en/companies/daten-und-telekommunikations-gmbh-dessau-dessau-rosslau--DEJ5ILDOVM07 |
| Torsten Henze | Einzelprokura(独代理,2022-12-12 在册) | webvalid 登记公告谱 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.webvalid.de/company/Daten-+und+Telekommunikations-GmbH+Dessau,+Dessau-Ro%C3%9Flau/HRB+15048 |
| Fred Kitzing | Einzelprokura(2022-12-12 在册) | webvalid 登记公告谱 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.webvalid.de/company/Daten-+und+Telekommunikations-GmbH+Dessau,+Dessau-Ro%C3%9Flau/HRB+15048 |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-28DGGPM（8口 PoE 接入盒）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（企业互联项目 CPE/接入层）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：顺 Vernetzung 服务：企业站点互联配套的 24 口接入层成本对照——商业客户配套段（不含电网/市政自用敏感段）。
- **要问的问题**：Vernetzung 项目里给客户配的接入件现在用什么？
- **随附证明**：规格对照 + 口径边界说明 + 报价（德文）。

### 第 2 次跟进 · 工业级非管理 PoE（园区户外/管道点位）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：工业园户外交接箱与厂区点位：宽温 DIN PoE 免维护。
- **要问的问题**：园区户外点位的交换坏机率？
- **随附证明**：宽温报告 + DIN 图 + 备件包价（德文）。

### 第 3 次跟进 · 管理型 PoE（商用接入管理件）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：商用接入管理件（SNMP 全 MIB/ERPS）进他的工程评估——从单点试装开始。
- **要问的问题**：商用接入段要不要先装一台进监控栈试？
- **随附证明**：MIB 库 + ERPS 实测 + 样机（德文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第8批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：德绍 Stadtwerke 旗下区域运营商：商业光纤/DSL+互联服务，Allied Resell（CSV 记录）。⚠️ 市政公用集团——采购受公用程序约束。
- **产品线与在售品牌**：Business/SoHo Fibre、Business DSL、企业互联 Vernetzung、邮件/托管、SLA 服务。
- **目标行业与场景**：德绍-罗斯劳 11 个工业园的企业线路+站点互联；自用 POP/机房与基站。
- **团队与规模**：市政集团旗下中型运营商（服务/工程师建制公开）。
- **决策链与对接人**：datel-vertrieb@dvv-dessau.de；具名 Nils Schumacher（CSV 9-27）。
- **技术与认证**：Allied Resell（CSV 记录）。
- **采购与供应链信号**：⚠️ 市政公用=大额采购走招标；商用小件（企业互联项目的 CPE/接入层）是现实入口；Vernetzung 服务=他给客户配网时要交换件。
- **近期动态与线索**：光纤扩区持续（11 园区清单在更新）。
- **与我方契合点**：企业互联（Vernetzung）项目里的 CPE/接入层件+自用 POP 的商用接入——从小项目做起。
- **风险与注意**：首封写清只谈其商业客户配套与自用段；等招标概念是他世界的常识，别催大单；德文资料。

### R54 原文证据摘录（全部保留）

- **【业务定位】**⚠️ 官网自述：德绍市政公用（Stadtwerke Dessau）集团旗下的区域电信运营商——1997 年起做电信、2011 年起自建光纤。
  > Die DATEL bietet in Dessau-Roßlau seit 1997 leistungsstarke Telekommunikationslösungen an ‖ dank unserer Einbindung in den Stadtwerke Dessau Konzern auch Angebote zur Energieversorgung, Elektromobilität u.v.m. ‖ Seit 2011 baut die DATEL ihr Netz kontinuierlich… aus
  > 来源：https://www.datel-dessau.de/geschaeftskunden/
- **【产品线与在售品牌】**商业产品：对称 Business Fibre/SoHo Fibre/Business DSL/企业互联 Vernetzung/Pro Mail/托管——SLA 与 24/365 故障台是卖点。
  > Business Produkte: Business Fibre（Symmetrische Glasfaser）· SoHo Fibre · Business DSL · Vernetzung（Wir vernetzten Ihr Unternehmen）· Pro Mail · Webhosting — garantierte Bandbreiten… 24 h Servicehotline… Premium Service Level Agreement
  > 来源：https://www.datel-dessau.de/geschaeftskunden/
- **【目标行业与场景】**光纤工业园清单：机场的工业区/货车制造园/生物制药园/三式联运物流中心（船厂 Roßlau）等 11 个工商地块已覆盖。
  > Gewerbegebiete erschlossen: Dessau-Mitte · Dessau-Ost · Industriegebiet Flugplatz · WBD Industriepark Waggonbau · Rodleben Biopharmapark · Trimodales Logistikzentrum（Deutsche Hydrierwerk, Industriehafen, Schiffswerft Roßlau）…
  > 来源：https://www.datel-dessau.de/geschaeftskunden/
- **【决策链与对接人】**官网企划页公开：服务工程师队直拨+销售团队邮箱（CSV 9-27 具名 Nils Schumacher，Sales Manager/Sonderkunden）。
  > DATEL Service- & Technikerteam — 0340 899-2781 · datel-vertrieb@dvv-dessau.de ‖ 故障台 24 h/365 d（0340 899 2000；Premium 0800 899 2770）
  > 来源：https://www.datel-dessau.de/geschaeftskunden/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第18波30户.json`；价格均为 EXW 快照。

- **①背景再核**：Daten- und Telekommunikations-GmbH Dessau(「DATEL」;Dessau-Roßlau,Albrechtstr. 48;**HRB 15048 Stendal;€50k;1997-12-22 创;USt DE192067013;402 人/€274.6M(集团谱口径)**;**Stadtwerke Dessau 子公司=地方 FTTH/电视/固定网运营商(B2C+市政);谱面对其自营城集团+自家市民服务;距接入链=FTTH 谱**;datel-dessau.de
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Dino Wolfgang Höll(Geschäftsführer(现任;登记谱 2018+),official-self-published·谱/leads-only(直发需 opt-in));Torsten Henze(Einzelprokura(独代理,2022-12-12 在册),official-self-published·谱/leads-only(直发需 opt-in));Fred Kitzing(Einzelprokura(2022-12-12 在册),official-self-published·谱/leads-only(直发需 opt-in))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：城网运营谱

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Geschäftsführer: Dino Wolfgang Höll(implisense);12.12.2022: Ausgeschieden GF Zänger, Thomas;Einzelprokura: Henze, Torsten + Kitzing, Fred(webvalid 件)
  > Geschäftsführer: Dino Wolfgang Höll(implisense);12.12.2022: Ausgeschieden GF Zänger, Thomas;Einzelprokura: Henze, Torsten + Kitzing, Fred(webvalid 件)
  > 来源：https://app.implisense.com/en/companies/daten-und-telekommunikations-gmbh-dessau-dessau-rosslau--DEJ5ILDOVM07
- **【联系方式与基础画像】**Albrechtstr. 48, 06844 Dessau-Roßlau;HRB 15048 Stendal;gegründet 22.12.1997;€50,000;Stadtwerke Dessau 子公司;FTTH 1.000 Mbit/s + WebTV/BasisTV(viaductus/implisense 件)
  > Albrechtstr. 48, 06844 Dessau-Roßlau;HRB 15048 Stendal;gegründet 22.12.1997;€50,000;Stadtwerke Dessau 子公司;FTTH 1.000 Mbit/s + WebTV/BasisTV(viaductus/implisense 件)
  > 来源：https://www.viaductus.de/firma/DE-W1215-HRB-15048-daten-und-telekommunikations-gmbh-dessau-dessau-rosslau

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Daten- und Telekommunikations-GmbH Dessau(「DATEL」;Dessau-Roßlau,Albrechtstr. 48;**HRB 15048 Stendal;€50k;1997-12-22 创;USt DE192067013;402 人/€274.6M(集团谱口径)**;**Stadtwerke Dessau 子公司=地方 FTTH/电视/固定网运营商(B2C+市政);谱面对其自营城集团+自家市民服务;距接入链=FTTH 谱**;datel-dessau.de
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：德国 SA 市政 FTTH/电视运营商(Stadtwerke 子)
- **团队与规模**：集团 402 人;1997 创
- **决策链与对接人**：**Dino Wolfgang Höll(Geschäftsführer(现任;登记谱 2018+),official-self-published·谱/leads-only(直发需 opt-in));Torsten Henze(Einzelprokura(独代理,2022-12-12 在册),official-self-published·谱/leads-only(直发需 opt-in));Fred Kitzing(Einzelprokura(2022-12-12 在册),official-self-published·谱/leads-only(直发需 opt-in))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 14 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Höll GF+Henze/Kitzing Prokurist(opt-in 律;市政守界)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-28DGGPM（8口 PoE 接入盒） | 主场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | DATEL Dessau：Stadtwerke 全资市政 ISP——公共红线建档不出信 |
| 备选2 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：8口 GE(7)+SFP，PoE af/at 240W，DC 随附电源，L2+ 全特性（VLAN/ERPS<20ms/QinQ/Private VLAN/sFlow），PoE 看门狗自动冷重启
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：城网运营谱
- **W**：电网子内治守界
- **O**：Höll GF 直达位
- **T**：大牌骨干链竞谱

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Guten Tag Herr Höll,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
