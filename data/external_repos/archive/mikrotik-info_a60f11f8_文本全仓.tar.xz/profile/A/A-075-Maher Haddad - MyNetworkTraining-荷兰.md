# Maher Haddad / MyNetworkTraining

> **评级 A**　|　荷兰 · Hilversum　|　档案编号 `A-075`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-075
rating: A
country: 荷兰
biz_org: 公司/工作室（有官网）
business_model: 培训交付
decision_speed: moderate
price_sensitivity: medium
volume_potential: 2  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: false, oem: false, hotel: false, training: true}
p1: STC-28DGGPM
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；培训交付
- **商业模式**：培训交付
- **为什么值得跟**：有明确交换/供电需求（交换专长），且有具体人直联
- **P1（首触唯一主推）**：STC-28DGGPM（8口 PoE 接入盒） — MyNetworkTraining 在线平台 7 万学员：视频课诚实第二厂牌样本；师者红线+平台中立不付背书（$99 锚点一致）；$99 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Which switch do you currently put on the bench for the VLAN/PoE lab demos?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Maher Haddad / MyNetworkTraining（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 荷兰 / Hilversum | 事实 |
| 网站 | mynetworktraining.com | 事实 |
| 类型 | 集成商/顾问（MikroTik 认证） | 事实（CSV 名录口径） |
| 关键人 | Maher Haddad | 事实 |
| 反向信号（资质/品牌） | MikroTik 认证顾问 10 证全拿 | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 培训交付 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】波 27·A-075:荷兰谱: **守档准由·原 R56 谱基增厚**:MyNetworkTraining（荷兰，Maher Haddad）：全球在线网络课程平台——**70K+ 学员、80+ 课**（HotMart/Teachable 体系，$19.99/月）；课程谱：MikroTik MTCNA/ISP Core/L3 硬件卸载、Cisco CCNA、Juniper、FortiGate、**OPNsense 官方课**、Ubiquiti、IPv6 Forum 认证工程师；Haddad 十证全;R66 第 27 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第8批.json,先报价不回、档案铺位、持续关注新一季,OK。
- 【推断】R66 第 27 波守档准由谱
- 【假设】档案铺位谱,持续关注新一季

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：MikroTik 认证顾问 10 证全拿）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、教学教具
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 教学教具：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@mynetworktraining.com
  - 状态：既有/公开
- **电话**：+31 6 22488675
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：+31 6 22488675 / info@mynetworktraining.com
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。

## 关键人（KP）与触达通道

- **Maher Haddad**（本人直达；角色=业主/顾问本人，依据名录）

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-28DGGPM（8口 PoE 接入盒）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（拍摄实验台+学员推荐配置）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：他的 LAB 哲学：24 口 PoE++ + 4×10G 上行的真实硬件做新课拍摄台，课程「推荐配置」挂我们型号=7 万学员的长尾带货。
- **要问的问题**：新开课缺不缺实验硬件？我们可以提供拍摄样机。
- **随附证明**：样机+规格书（英文）+ 带货合作说明。

### 第 2 次跟进 · 工业级非管理 PoE（工业/监控课场景）

- **推什么**：STI-240GE（Saga） PoE 版（4G + 2×SFP，DIN，-40~75°C）
- **切入点**：补足课程场景：室外/工业 PoE 主题微课用宽温 DIN 小机演示（监控/摄像头供电课的天然教具）。
- **要问的问题**：有没有计划做工业网络或监控方向的课？
- **随附证明**：演示样机 + 微课素材建议（英文）。

### 第 3 次跟进 · 管理型 PoE（L3 卸载联合实测课）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：直打他已开的课：L3 硬件卸载 across 品牌实测对比（MikroTik vs 我们），课程上线同时挂购买指引——他出内容我们出机和数据。
- **要问的问题**：L3 卸载课要不要加一个非 MikroTik 对照组？数据我们出。
- **随附证明**：卸载实测数据（可公开）+ 联合课件授权。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第4批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：荷兰在线网络培训平台（Hotmart/Teachable 系分销）：低价订阅跑量模式，多厂商课程超市，MikroTik 是核心类目之一。
- **产品线与在售品牌**：80+ 门课：MikroTik（MTCNA/ISP 核心网/L3 卸载）、Cisco CCNA、Juniper JNCIA、FortiGate/OPNsense、Ubiquiti、IPv6 Forum。
- **目标行业与场景**：全球自学工程师（7 万学员）——课程里用什么设备，学员就买什么练；带货效应直接。
- **团队与规模**：Maher Haddad 个人品牌+平台运营；学员量级大但公司本体小。
- **决策链与对接人**：Maher 本人（+31 6 22488675 / info@mynetworktraining.com）；10 证+讲师。
- **技术与认证**：10 证全拿+认证讲师，20+ 年 IT（CSV 名录记录）；课程含 Switching/L3 卸载——交换内容是他卖点。
- **采购与供应链信号**：线上课主要用虚拟实验，但「L3 硬件卸载」类课必须真机：拍摄用机+学员推荐配置=小而持续的采购+巨大的推荐位。
- **近期动态与线索**：课程库持续更新（2026 年版新课在上）；低价订阅模式靠新课叠加保增长。
- **与我方契合点**：他的 L3 卸载课正是我们 10G 管理型的教科书场景：送拍摄样机+联合实测素材，一次合作长期曝光。
- **风险与注意**：免费曝光换真机是双赢，但要落地成「课程里出现+购买链接」才算数；别只寄样机不跟后续。

### R54 原文证据摘录（全部保留）

- **【业务定位】**在线培训平台：多厂商网络课订阅制，70K+ 全球学员、80+ 门课、$19.99/月起。
  > Access all courses from just $19.99 USD/month · 70K+ Students worldwide · 80+ courses · Different vendor courses
  > 来源：https://mynetworktraining.com/
- **【产品线与在售品牌】**MikroTik 课群含 MTCNA 实验课（RouterOS 7 & Winbox 4）、ISP 核心网搭建（BGP/OSPF/VLAN/MPLS/VPLS/PBR）。
  > MikroTik Network Associate with LABS (RouterOS 7 & Winbox 4) · ISP Core Network Setup with MikroTik — BGP, OSPF, VLAN, MPLS, VPLS and PBR protocols using MikroTik RouterOS
  > 来源：https://mynetworktraining.com/
- **【技术与认证】**平台上有一门「MikroTik RouterOS 三层硬件卸载与 VLAN」专门课——硬件卸载必须真机演示，他懂 L3 offload 的价值。
  > MikroTik RouterOS Layer 3 Hardware Offloading with VLANs（在售课程）
  > 来源：https://mynetworktraining.com/
- **【目标行业与场景】**课程方法论自述「理论+大量 LAB、能配到真实网络里」；厂商覆盖面 FortiGate/OPNsense/Cisco/Juniper/Ubiquiti/Huawei/LigoWave。
  > All our courses are based on Theory and a lot of LABs to understand each topic and to be able to configure it in your real network
  > 来源：https://mynetworktraining.com/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第27波50户.json`；价格均为 EXW 快照。

- **①背景再核**：波 27·A-075:荷兰谱: **守档准由·原 R56 谱基增厚**:MyNetworkTraining（荷兰，Maher Haddad）：全球在线网络课程平台——**70K+ 学员、80+ 课**（HotMart/Teachable 体系，$19.99/月）；课程谱：MikroTik MTCNA/ISP Core/L3 硬件卸载、Cisco CCNA、Juniper、FortiGate、**OPNsense 官方课**、Ubiquiti、IPv6 Forum 认证工程师；Haddad 十证全;R66 第 27 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第8批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **②芯片/型号**：STC-28DGGPM·8-port PoE access box (802.3af/at, watchdog)
- **③KP 深挖**：**守档准由;R66 第 27 波点名(谱面无实名)**
- **④Saga 对标**：STC-28DGGPM vs PLANET/当批价差窗
- **⑤在乎与偏好**：荷兰 谱;CE/UKCA;持续关注新一季

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**MyNetworkTraining（荷兰，Maher Haddad）：全球在线网络课程平台——**70K+ 学员、80+ 课**（HotMart/Teachable 体系，$19.99/月）；课程谱：MikroTik MTCNA/ISP Core/L3 硬件卸载、Cisco CCNA、Juniper、FortiGate
  > MyNetworkTraining（荷兰，Maher Haddad）：全球在线网络课程平台——**70K+ 学员、80+ 课**（HotMart/Teachable 体系，$19.99/月）；课程谱：MikroTik MTCNA/ISP Core/L3 硬件卸载、Cisco CCNA、Juniper、FortiGate
  > 来源：https://mynetworktraining.com/
- **【联系方式与基础画像】**CSV 入口:+31 6 22488675 / info@mynetworktraining.com
  > CSV 入口:+31 6 22488675 / info@mynetworktraining.com
  > 来源：https://mynetworktraining.com/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：波 27·A-075:荷兰谱: **守档准由·原 R56 谱基增厚**:MyNetworkTraining（荷兰，Maher Haddad）：全球在线网络课程平台——**70K+ 学员、80+ 课**（HotMart/Teachable 体系，$19.99/月）；课程谱：MikroTik MTCNA/ISP Core/L3 硬件卸载、Cisco CCNA、Juniper、FortiGate、**OPNsense 官方课**、Ubiquiti、IPv6 Forum 认证工程师；Haddad 十证全;R66 第 27 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R56_第8批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **产品线与在售品牌**：MikroTik 认证顾问 10 证全拿
- **目标行业与场景**：荷兰 谱;集成商/顾问（MikroTik 认证）
- **团队与规模**：荷兰谱·守档准由
- **决策链与对接人**：**守档准由;R66 第 27 波点名(谱面无实名)**
- **技术与认证**：STC-28DGGPM 对口谱;$99 USD EXW 锚
- **采购与供应链信号**：B2B 批口谱
- **近期动态与线索**：2026-10-08 R66 27 波谱名牌(A 类补全批)
- **与我方契合点**：STC-28DGGPM(8-port PoE access box) 档案铺位窗
- **风险与注意**：具名缺(守档准由)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-28DGGPM（8口 PoE 接入盒） | 主场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | MyNetworkTraining 在线平台 7 万学员：视频课诚实第二厂牌样本；师者红线+平台中立不付背书（$99 锚点一致） |
| 备选2 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：8口 GE(7)+SFP，PoE af/at 240W，DC 随附电源，L2+ 全特性（VLAN/ERPS<20ms/QinQ/Private VLAN/sFlow），PoE 看门狗自动冷重启
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：R56 谱基在册
- **W**：具名缺(守档准由)
- **O**：STC-28DGGPM $99 USD EXW 价差窗
- **T**：谱链节奏;先报价不回则档案铺位

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**本户特别红线/停止条件**

- 教师红线：不打学员名单、不经培训语境推销

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 具名决策人(波次二)
  - [ ] 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Maher Haddad Team,

We build a 8-port PoE access box (802.3af/at, watchdog). Reference: $99 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Datasheet + CE pack on request.

Best regards
Saga / SmartByte ODM
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
