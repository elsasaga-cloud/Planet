# Timeless Technology

> **评级 A**　|　芬兰 · Pori　|　档案编号 `A-256`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-256
rating: A
country: 芬兰
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: false, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（交换专长、PoE/监控/门禁、工业/楼宇），且有具体人直联
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — Timeless 芬兰技术进口商（Perle 交换线在墙+Milesight LoRaWAN）：Perle 旁替补窄口（$180 锚点一致）；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Timeless Technology（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 芬兰 / Pori | 事实 |
| 网站 | https://timeless.fi | 事实 |
| 类型 | 分销/集成商（Perle 授权） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Perle Systems（工业 PoE 交换机 / 媒体转换 / 串口设备联网） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Timeless Technology:Timeless Technology / Timeless Group Oy(芬兰 Pori,Keulantie 1 D 30, 28190;**Y-tunnus 3139264-1;FI31392641;史 2012,现体 2020-06-01(aputoiminimi=Timeless Technology+Mansimar);1-2 人(2024)**;**ICT/工业 IoT/测量技术增值进口分销;CEO Kari Ruhanen(官方 viralliset tiedot PDF 自署=O 金谱;Yrittäjä 谱);Profitap 网络可视线谱;Suomen Yrittäjät 会员**
- 【推断】R66 第 20 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Perle Systems（工业 PoE 交换机 / 媒体转换 / 串口设备联网））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@timeless.fi
  - 状态：既有/公开
- **电话**：+358 44 9988 238
- 来源等级：official（R41–R48 联系方式台账口径）
- **原始联系字段**：info@timeless.fi（官网正文公开）；原入口：+358 44 9988 238
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Kari Ruhanen**(CEO/Yrittäjä(官方公司信息 PDF 自署+itewiki 双源))— timeless.fi 官方 PDF(O) 〔已有(公司官方公开件/登记册自曝);源:https://timeless.fi/wp-content/uploads/2023/12/Timeless-Technology-viralliset-tiedot-2023.pdf〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Kari Ruhanen | CEO/Yrittäjä(官方公司信息 PDF 自署+itewiki 双源) | timeless.fi 官方 PDF(O) | official-self-published·谱/leads-only(直发需 opt-in) | https://timeless.fi/wp-content/uploads/2023/12/Timeless-Technology-viralliset-tiedot-2023.pdf |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 目录低价位档：工业非管理+收发器一页

- **推什么**：STI-280GE（Saga）（工业非管理 8×电口 + 2×上联光）+ 收发器
- **切入点**：芬兰语/英语短件：在 Perle/Cailabs 高端的之下补一个友善价位的工业非管理档与收发器窄线（分销条件+CE 一体）。
- **要问的问题**：目录里在高端之外有没有一个更友善的工业非管理价位档需求？
- **随附证明**：工业件一页（芬/英）+ CE/EMC。

### 第 2 次跟进 · 商业/LoRa 现场回传接入位

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行 L2+）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：其工业 IoT 项目落回传位时的 24 口 PoE/接入层（Milesight 网关回传旁位）。
- **要问的问题**：IoT 项目的回传/汇聚位接入层现在怎么配？
- **随附证明**：24 口一页价卡。

### 第 3 次跟进 · SFP 配件窄线

- **推什么**：SFP/SFP+ 目录
- **切入点**：光配件窄线低价档；不回即冻结。
- **要问的问题**：—
- **随附证明**：配件一页价卡。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第13批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：芬兰增值进口商（ICT/工业 IoT/测量三域）：**Perle 为主推活跃牌——深绑，只做价位档空档**。
- **产品线与在售品牌**：Perle 全线+Cailabs 高端光纤+Milesight/ControlByWeb IoT+Profitap TAP 等九系。
- **目标行业与场景**：芬兰工业/资产监控/机房高端客群。
- **团队与规模**：小型精品进口商（新闻频率高=活跃）。
- **决策链与对接人**：info@timeless.fi（官网正文，CSV 9-27）。
- **技术与认证**：Perle 授权（CSV+官网产品页双证）。
- **采购与供应链信号**：Perle/Cailabs 高端价带之下：工业非管理低价档+商业 24 口接入层为其价带空档——从「补目录低价位」切入最稳。
- **近期动态与线索**：Perle 三新闻连发=其 Perle 线正在强化——切勿替位，只旁位。
- **与我方契合点**：工业非管理 8 口低价档（CNY 到岸）；LoRa 现场回传箱的 24 口/8 口接入位；SFP 配件。
- **风险与注意**：Cailabs/Milesight 等高端位不碰；报价走 CNY+到岸总价、别低质量印象。

### R54 原文证据摘录（全部保留）

- **【业务定位】**波里的芬兰增值进口商：ICT+工业 IoT+测量技术三域（lisäarvoa tuottavana teknisenä maahantuojana）。
  > Timeless Technology toimii lisäarvoa tuottavana teknisenä maahantuojana, joka on erikoistunut ICT, teollinen IoT ja mittaustekniikka tuotteisiin.
  > 来源：https://timeless.fi/
- **【产品线与在售品牌】**九系产品：**Perle Systems（路由/交换/控制台/终端/收发器/Ethernet Extender）**、Cailabs AROONA（MM→SM 光纤变换）、Milesight LoRaWAN、ControlByWeb PLC、Eos GNSS、Profitap TAP、Tempmate、Plug and Track、TITAN——工业链路全栈档位高。
  > Perle Systems reitittimet, kytkimet, konsolipalvelimet, päätepalvelimet, mediamuuntimet ja Ethernet Extenderit ‖ Cailabs AROONA kuitumuuntimet ‖ Milesight LoRaWAN ‖ Profitap verkko-TAPit
  > 来源：https://timeless.fi/
- **【近期动态与线索】**2026-08/09 高频 Perle 新闻三件（IOLAN SCR/PerleCLOUD·PerleVIEW/IRG7000 工业 5G）——Perle 是其主推活跃牌。
  > Perle IOLAN SCR – turvallinen konsolipalvelin（22/09/2026）‖ PerleCLOUD ja PerleVIEW（09/09/2026）‖ Perle IRG7000 – teollinen 5G-reititin（24/08/2026）
  > 来源：https://timeless.fi/
- **【决策链与对接人】**info@timeless.fi 官网公司页正文（CSV 9-27：official）；Pori 地址与 +358 44 998823… 座机同一。
  > （CSV 2026-09-27 记录）info@timeless.fi（官网正文）；Pori 与电话匹配
  > 来源：https://timeless.fi/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第20波50户.json`；价格均为 EXW 快照。

- **①背景再核**：Timeless Technology / Timeless Group Oy(芬兰 Pori,Keulantie 1 D 30, 28190;**Y-tunnus 3139264-1;FI31392641;史 2012,现体 2020-06-01(aputoiminimi=Timeless Technology+Mansimar);1-2 人(2024)**;**ICT/工业 IoT/测量技术增值进口分销;CEO Kari Ruhanen(官方 viralliset tiedot PDF 自署=O 金谱;Yrittäjä 谱);Profitap 网络可视线谱;Suomen Yrittäjät 会员**
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Kari Ruhanen(CEO/Yrittäjä(官方公司信息 PDF 自署+itewiki 双源),official-self-published·谱/leads-only(直发需 opt-in))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：CEO 官方 PDF 自署=O 金谱

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】****CEO: Kari Ruhanen**(Timeless-Technology-viralliset-tiedot-2023.pdf 官方自署);itewiki 谱: Kari Ruhanen CEO Yrittäjä(双源一致)
  > **CEO: Kari Ruhanen**(Timeless-Technology-viralliset-tiedot-2023.pdf 官方自署);itewiki 谱: Kari Ruhanen CEO Yrittäjä(双源一致)
  > 来源：https://timeless.fi/wp-content/uploads/2023/12/Timeless-Technology-viralliset-tiedot-2023.pdf
- **【联系方式与基础画像】**Timeless Group Oy;aputoiminimet: Timeless Technology + Mansimar;Keulantie 1 D 30, 28190 Pori;Y-tunnus 3139264-1;+358 44 9988238;info@timeless.fi;tilikaudella 05/2024: 1 työntekijä=小微谱注;ICT/teollinen IoT/mittaustekniikka maahantuoja(timeless.fi/finder.fi/fonecta 件)
  > Timeless Group Oy;aputoiminimet: Timeless Technology + Mansimar;Keulantie 1 D 30, 28190 Pori;Y-tunnus 3139264-1;+358 44 9988238;info@timeless.fi;tilikaudella 05/2024: 1 työntekijä=小微谱注;ICT/teollinen IoT/mittaustekniikka maahantuoja(timeless.fi/finder.fi/fonecta 件)
  > 来源：https://timeless.fi/yritys/
- **【近期动态与线索】**Profitap verkkoVisibility 谱;Suomen Yrittäjät jäsenyys;perustettu 2012(itewiki 历史)→2020-06-01 现体(finder.fi 件)
  > Profitap verkkoVisibility 谱;Suomen Yrittäjät jäsenyys;perustettu 2012(itewiki 历史)→2020-06-01 现体(finder.fi 件)
  > 来源：https://www.itewiki.fi/timeless-technology

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Timeless Technology / Timeless Group Oy(芬兰 Pori,Keulantie 1 D 30, 28190;**Y-tunnus 3139264-1;FI31392641;史 2012,现体 2020-06-01(aputoiminimi=Timeless Technology+Mansimar);1-2 人(2024)**;**ICT/工业 IoT/测量技术增值进口分销;CEO Kari Ruhanen(官方 viralliset tiedot PDF 自署=O 金谱;Yrittäjä 谱);Profitap 网络可视线谱;Suomen Yrittäjät 会员**
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：芬兰 Pori 1-2 人 ICT/IoT 进口商
- **团队与规模**：1-2 人;谱史 2012
- **决策链与对接人**：**Kari Ruhanen(CEO/Yrittäjä(官方公司信息 PDF 自署+itewiki 双源),official-self-published·谱/leads-only(直发需 opt-in))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 20 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Kari Ruhanen 单铺直达(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Timeless 芬兰技术进口商（Perle 交换线在墙+Milesight LoRaWAN）：Perle 旁替补窄口（$180 锚点一致） |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：CEO 官方 PDF 自署=O 金谱
- **W**：微实体谱
- **O**：Ruhanen 唯一直达位
- **T**：区域链竞谱

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Mr. Ruhanen,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
