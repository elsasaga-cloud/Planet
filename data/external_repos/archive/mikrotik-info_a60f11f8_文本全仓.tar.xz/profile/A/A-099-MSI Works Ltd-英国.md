# MSI Works Ltd

> **评级 A**　|　英国 · London　|　档案编号 `A-099`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-099
rating: A
country: 英国
biz_org: 个体顾问（无官网）
business_model: 顾问项目制
decision_speed: fast
price_sensitivity: high
volume_potential: 1  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: true, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：个体顾问（无官网）；顾问项目制
- **商业模式**：顾问项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；信息待人工补齐（见备注）
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — MSI Works 英小体 Allied 信号（Wix 表单无邮箱）：手机破冰（$180 锚点一致）；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | MSI Works Ltd（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 英国 / London | 事实 |
| 网站 | —（无公开站点） | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 个体顾问（无官网） | 【推断】 |
| 商业模式 | 顾问项目制 | 【推断】 |
| 团队规模 | 一人/微型 | 【推断】 |
| 决策链 | 短（本人即决策） | 【推断】 |
| ⚠️ 信息缺口 | 本条**抓不到邮箱**，需人工补齐邮箱或改为电话单独跟进后再进群发名单 | 事实 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】MSI WORKS LTD(英国;MSI WORKS LTD(伦敦 3rd Floor, 86-90 Paul Street, EC2A 4NE;公司号 15643579;2024-04-13 注册新实体(2 年谱);私有有限责任公司 ACTIVE)
- 【推断】R66 5-6 波:英国登记册(Companies House)/官网/LinkedIn 具名 KP 金谱
- 【假设】24 口 value PoE 谱链窗口=($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、VoIP/Voice VLAN
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - VoIP/Voice VLAN：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：—
  - 状态：缺失（leads-only 口径：人工补录前**不进群发**，与旧批次纪律一致）
- **电话**：+44 7584 631601、+44 (0)207 0888205
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：+44 7584 631601；⚠️ 无邮箱：msi-works.com 为 Wix 纯表单｜**Allied Telesis Platinum Partner（最高级）**，主业楼宇系统集成 BMS/IoT/OT 数据，PoE 接入层需求真实。具名 John Dente（LinkedIn /in/john-dente-9b5a2276/）；电话 +44 (0)207 0888205
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **David James Salisbury**(Managing Director(2024-12-30 任命))— Companies House 军官名单 〔已有(公司官方公开件/登记册自曝);源:https://find-and-update.company-information.service.gov.uk/company/15643579/officers〕
  - **John Robert Dente**(Director(2024-04-13))— Companies House 军官名单 〔已有(公司官方公开件/登记册自曝);源:https://find-and-update.company-information.service.gov.uk/company/15643579/officers〕
  - **John Paul Hubbard**(Director(2024-12-30))— Companies House 军官名单 〔已有(公司官方公开件/登记册自曝);源:https://find-and-update.company-information.service.gov.uk/company/15643579/officers〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| David James Salisbury | Managing Director(2024-12-30 任命) | Companies House 军官名单 | official-self-published·谱/leads-only(直发需 opt-in) | https://find-and-update.company-information.service.gov.uk/company/15643579/officers |
| John Robert Dente | Director(2024-04-13) | Companies House 军官名单 | official-self-published·谱/leads-only(直发需 opt-in) | https://find-and-update.company-information.service.gov.uk/company/15643579/officers |
| John Paul Hubbard | Director(2024-12-30) | Companies House 军官名单 | official-self-published·谱/leads-only(直发需 opt-in) | https://find-and-update.company-information.service.gov.uk/company/15643579/officers |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（楼宇 OT 接入层）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：楼宇 OT/IoT 接入：传感器/控制器/摄像头密集的楼层，24 口 PoE++ 单端口成本对照 Allied 同档——先递测算不谈替换。
- **要问的问题**：楼层 OT 接入层现在单价到什么位？（电话/表单递测算）
- **随附证明**：单端口测算 + 规格对照 + 英国交付说明（英文）。

### 第 2 次跟进 · 工业级非管理 PoE（吊顶/井道零散点位）

- **推什么**：STI-240GE（Saga） PoE 版（4G + 2×SFP，DIN，-40~75°C）
- **切入点**：吊顶、管井、设备间的零散 OT 点位：4 口宽温小机即装，减少弱电间占用。
- **要问的问题**：井道/吊顶点位的供电交换现在怎么做？
- **随附证明**：宽温报告 + 安装图 + 备件包价。

### 第 3 次跟进 · 管理型 PoE（OT/IT 分段模板）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：他做 OT/IoT/IT 合一：VLAN 分段+ACL 边界+ERPS 冗余的 OT 网模板，配上他的 HUBi 做标准化交付。
- **要问的问题**：OT 网分段现在按什么标准模板做？
- **随附证明**：VLAN/ERPS 模板 + 分段参考架构 + 实测（英文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第5批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：伦敦楼宇主系统集成商（MSI）：把 OT（BMS/能耗）/IoT/IT 三张网合成一张，做楼宇节能与数据平台，Allied Telesis Platinum 伙伴（CSV 记录）。
- **产品线与在售品牌**：系统集成服务+自有 HUBi 平台（数据映射/本体/实时分析）；Allied Telesis 网络层（CSV 记录）。
- **目标行业与场景**：商业楼宇/园区新建与改造：传感器/BMS/仪表 densely 接入的 OT 网络——大量工业 PoE 与分段需求。
- **团队与规模**：精专 MSI 团队（自述组合经验 100+ 年）；Wix 站、纯表单、无公开邮箱。
- **决策链与对接人**：+44 7584 631601（CSV 记录；网站仅表单）。
- **技术与认证**：Allied Telesis **Platinum Partner**（CSV 记录）；楼宇自动化/能耗协议栈。
- **采购与供应链信号**：楼宇项目随楼层/系统批量上 OT 网络件；PoE 传感器与控制器接入是日常。
- **近期动态与线索**：能效/碳叙事正热（英国 ESG 合规驱动），楼宇改造项目景气。
- **与我方契合点**：OT 网接入层的工业 PoE 与商用 24 口；BMS 网段的 VLAN 隔离模板——Platinum 场内做「同生态成本补位」。
- **风险与注意**：Platinum 忠诚度高：别正面替换 Allied，主打「同规格成本对照+OT 场景适配」让数据说话；触达只有电话/表单。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网抬头：以 Master Systems Integrator 为内核的楼宇性能公司。
  > INNOVATION FROM EXPERTISE — A business with Master Systems Integration at its core…
  > 来源：https://www.msi-works.com/
- **【目标行业与场景】**从既有楼到新楼的能效与碳减排：数据+控制驱动可验证 ROI，不限牺牲用户体验。
  > Reliable building performance by a highly experienced MSI — From existing buildings to new construction we have developed methods to reduce energy and carbon whilst not sacrificing the user experience.
  > 来源：https://www.msi-works.com/
- **【技术与认证】**OT/IoT/IT 数据一体化的自建平台（HUBi）：团队「MSI 组合经验 100+ 年」——楼宇 OT 网络的搬运工。
  > All the OT, IOT and IT data in one place allows you to not only make savings but recommendations on improving the building… driven by the collective knowledge of an MSI with in excess of 100 years of experience.
  > 来源：https://www.msi-works.com/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-07_R66_R56_KP第5_6波.json`；价格均为 EXW 快照。

- **①背景再核**：MSI WORKS LTD(伦敦 3rd Floor, 86-90 Paul Street, EC2A 4NE;公司号 15643579;2024-04-13 注册新实体(2 年谱);私有有限责任公司 ACTIVE
- **②芯片/型号**：(新实体谱面待 R66 波次二;MikroTik 库档信号)
- **③KP 深挖**：**David James Salisbury = Managing Director(2024-12-30 任命,官方谱面)+ John Robert Dente = Director(2024-04-13 任命,1962-10 生)+ John Paul Hubbard = Director(2024-12-30 任命,1988-12 生);Companies House 免费军官名单(official-self-published 级金谱);新实体谱面(2 年谱),管理 MD 与双 Director 三员全实名**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：新实体 MD+双 Director 三员实名

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**SALISBURY, David James — Director · Occupation: Managing Director · Appointed 30 December 2024;DENTE, John Robert — Director Appointed 13 April 2024 (born October 1962);HUBBARD, John Paul — Director Appointed 30 December 2024 (born December 1988)
  > SALISBURY, David James — Director · Occupation: Managing Director · Appointed 30 December 2024;DENTE, John Robert — Director Appointed 13 April 2024 (born October 1962);HUBBARD, John Paul — Director Appointed 30 December 2024 (born December 1988)
  > 来源：https://find-and-update.company-information.service.gov.uk/company/15643579/officers
- **【业务定位】**MSI WORKS LTD · Company number 15643579 · 3rd Floor, 86-90 Paul Street, London EC2A 4NE · Incorporated 2024-04 · Private limited Company · 3 officers / 0 resignations
  > MSI WORKS LTD · Company number 15643579 · 3rd Floor, 86-90 Paul Street, London EC2A 4NE · Incorporated 2024-04 · Private limited Company · 3 officers / 0 resignations
  > 来源：https://find-and-update.company-information.service.gov.uk/company/15643579
- **【近期动态与线索】**2026-10-07 R66 波次:2 年谱新实体;2024-12 MD Salisbury 上任=谱面定型期
  > 2026-10-07 R66 波次:2 年谱新实体;2024-12 MD Salisbury 上任=谱面定型期
  > 来源：https://find-and-update.company-information.service.gov.uk/company/15643579/officers

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：MSI WORKS LTD(伦敦 3rd Floor, 86-90 Paul Street, EC2A 4NE;公司号 15643579;2024-04-13 注册新实体(2 年谱);私有有限责任公司 ACTIVE
- **产品线与在售品牌**：(新实体谱面待 R66 波次二;MikroTik 库档信号)
- **目标行业与场景**：英国 IT/电信谱面
- **团队与规模**：2024 新实体
- **决策链与对接人**：**David James Salisbury = Managing Director(2024-12-30 任命,官方谱面)+ John Robert Dente = Director(2024-04-13 任命,1962-10 生)+ John Paul Hubbard = Director(2024-12-30 任命,1988-12 生);Companies House 免费军官名单(official-self-published 级金谱);新实体谱面(2 年谱),管理 MD 与双 Director 三员全实名**
- **技术与认证**：(谱面待补)
- **采购与供应链信号**：(谱面待补)
- **近期动态与线索**：2026-10-07 R66 波次点名
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：2 年谱新实体;管理 MD Salisbury=首击位(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | MSI Works 英小体 Allied 信号（Wix 表单无邮箱）：手机破冰（$180 锚点一致） |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：新实体 MD+双 Director 三员实名
- **W**：2 年谱新实体
- **O**：MD Salisbury 直达位
- **T**：新实体谱面未定型

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**本户特别红线/停止条件**

- 一人/个体=单点与节奏风险

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ❓ 缺邮箱 |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 新实体谱面全谱(波次二)
  - [ ] MikroTik 谱面份证

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Hi David,

I came across MSI WORKS LTD while mapping UK network and IT suppliers. Behind every deployment sits a switching layer that has to stay cheap, PoE-healthy and well documented.

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog) with full documentation. Reference: $180 USD EXW (2026-10-07, 15天有效), a value unit that rides along with each deployment.

Could you point me to the colleague who carries the hardware purchasing line, so we route the right spec to the right desk?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
