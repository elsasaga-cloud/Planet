# NiTo IT Systeme GmbH

> **评级 A**　|　德国 · Berlin　|　档案编号 `A-170`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-170
rating: A
country: 德国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；人工指定
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — NiTo 电商商：Allied 独牌实版旁 value 上架位（$180 锚点一致）；einkauf@ 采购口；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | NiTo IT Systeme GmbH（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 德国 / Berlin | 事实 |
| 网站 | https://nitoit.de | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】NiTo IT Systeme GmbH:NiTo IT Systeme GmbH →【**2026-06-22 更名:IPTGA Projekt Konzept GmbH**】(柏林,Storkower Str. 115A, 10407;**HRB 216686 B AG Charlottenburg;DE329092725;2020-04-14 创**;谱型=柏林小微 IT 咨询屋(安全/可扩展方案/软件编程/接口;媒体/IT 管理;Videokonferenz/视频软件线)**档名 NiTo 已过时实体,谱带应台账对位现名 IPTGA**;**GF 换位谱全接:Oldenburg(2020)→Silvia Müller(2023)→Torsten Uwe Müller(2025-12)→Joel Can Müller(2026-06)**
- 【推断】R66 第 14 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电
  - PoE 接入供电：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：einkauf@nitoit.de【已停用:2026-10-04 退信 not-found】
  - 状态：R62-退信-not-found
- **电话**：2026-10-04
- 来源等级：official（R41–R48 联系方式台账口径）
- **原始联系字段**：einkauf@nitoit.de【已停用:2026-10-04 退信 not-found 发不过去】 [Publicly listed; delivery not tested]; https://nitoit.de
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Torsten Uwe Müller**(Geschäftsführer(**2025-12-02 起在职**;*1963,Berlin))— webvalid/creditreform 2025-12-02 登记公告 〔已有(公司官方公开件/登记册自曝);源:https://firmeneintrag.creditreform.de/10407/2012948573/NITO_IT_SYSTEME_GMBH〕
  - **Joel Can Müller**(Geschäftsführer(2026-06 更名时谱=IPTGA 名下;族谱 Jr 代))— webvalid 2026-06-22 登记公告谱 〔已有(公司官方公开件/登记册自曝);源:https://www.webvalid.de/company/NiTo+IT+Systeme+GmbH,+Berlin/HRB+216686〕
  - **Silvia Müller**(原 Geschäftsführer(2023-01~2025-12;Impressum 遗留自署=滞后谱))— nitoit.de Impressum(留痕)+登记公告 〔已有(公司官方公开件/登记册自曝);源:https://nitoit.de/impressum/〕
  - **Nils Christian Oldenburg**(原 Geschäftsführer(2020 创铺至 2023-01))— 登记公告+it-in-germany 件(留痕) 〔已有(公司官方公开件/登记册自曝);源:https://www.it-in-germany.de/firma/NiTo+IT+Systeme+GmbH/6041748/64641/deu〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Torsten Uwe Müller | Geschäftsführer(**2025-12-02 起在职**;*1963,Berlin) | webvalid/creditreform 2025-12-02 登记公告 | official-self-published·谱/leads-only(直发需 opt-in) | https://firmeneintrag.creditreform.de/10407/2012948573/NITO_IT_SYSTEME_GMBH |
| Joel Can Müller | Geschäftsführer(2026-06 更名时谱=IPTGA 名下;族谱 Jr 代) | webvalid 2026-06-22 登记公告谱 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.webvalid.de/company/NiTo+IT+Systeme+GmbH,+Berlin/HRB+216686 |
| Silvia Müller | 原 Geschäftsführer(2023-01~2025-12;Impressum 遗留自署=滞后谱) | nitoit.de Impressum(留痕)+登记公告 | official-self-published·谱/leads-only(直发需 opt-in) | https://nitoit.de/impressum/ |
| Nils Christian Oldenburg | 原 Geschäftsführer(2020 创铺至 2023-01) | 登记公告+it-in-germany 件(留痕) | official-self-published·谱/leads-only(直发需 opt-in) | https://www.it-in-germany.de/firma/NiTo+IT+Systeme+GmbH/6041748/64641/deu |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 类目空缺提案（工业宽温 DIN PoE）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：你货架上 Allied 无工业宽温：宽温 DIN PoE 做补位 SKU——网店挂位提案。
- **要问的问题**：工业宽温 PoE 这个类目你们网店还空着——挂位怎么谈？
- **随附证明**：类目空缺说明 + 分销价目 + 宽温报告（德文）。

### 第 2 次跟进 · 24 口 CCTV/PoE（商用高段位补位）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：PoE++ 大功率+4×10G 上行档位：与 Allied 同档商用高段位作补位价。
- **要问的问题**：客户要大功率 PoE++ 时另一个选项要不要？
- **随附证明**：规格对照 + 梯价（德文）。

### 第 3 次跟进 · 管理型 PoE（项目第二来源）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：项目第二来源：管理型（ERPS/L3）当客户比价时的备选报价。
- **要问的问题**：项目比价的第二来源报价要不要挂？
- **随附证明**：VLAN/ERPS 速查 + 第二来源价目（德文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第9批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：柏林 Allied 专卖网店+安装+自研小软件，Allied Integrate/Resell（CSV 记录）。
- **产品线与在售品牌**：Allied Telesis 全线（网店）+订单管理软件+工单系统。
- **目标行业与场景**：柏林中小企业的 Allied 装机与软件。
- **团队与规模**：小型。
- **决策链与对接人**：einkauf@nitoit.de（CSV 9-27：采购箱直投）。
- **技术与认证**：Allied Integrate/Resell（CSV 记录）。
- **采购与供应链信号**：⚠️ Allied 专卖深度绑定：同生态成本对照不能谈替位——只有两类活：①他货架缺位类目（工业宽温/大功率 PoE++ 档）②项目第二来源。
- **近期动态与线索**：PayPal 小店常态。
- **与我方契合点**：货架类目空档提案（工业宽温 DIN PoE——Allied 无真正工业宽温线）+商用高段位补位。
- **风险与注意**：话里别提替位 Allied：全程“补位/类目空档”定位；量小但决策快。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网自述：网店直售 Allied Telesis 防火墙/路由/媒体控制/交换/WLAN AP+安装服务——Allied 专卖型小店（深度绑定）。
  > Nito IT Webshop… Von Firewall und Router über Mediacontroller und Switche bis hin zum WLAN-Accesspoint bieten wir Qualitätsprodukte aus dem Hause Allied Telesis einschließlich eines gewünschten Installationsservices an.
  > 来源：https://nitoit.de/
- **【产品线与在售品牌】**另有自研 KMU 订单管理软件（报价/订单/送货单/发票）+工单支持系统——软件+硬件双小业。
  > eine Auftragsverwaltungssoftware (Angebot, Auftrag, Lieferschein, Rechnung) für KMU und andere Unternehmer ‖ Ticket-System… eindeutige Nummer
  > 来源：https://nitoit.de/
- **【决策链与对接人】**CSV 9-27：官网直接公开采购邮箱 einkauf@nitoit.de（优于销售/通用入口）；用途明确但不等于验证采购意愿。
  > 官网直接公开采购邮箱（Einkauf），优先于同页销售/通用入口；另有 vertrieb@nitoit.de、kontakt@nitoit.de。邮箱用途明确，但不代表已验证采购意愿（CSV 2026-09-27 记录）
  > 来源：https://nitoit.de/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第18波30户.json`；价格均为 EXW 快照。

- **①背景再核**：NiTo IT Systeme GmbH →【**2026-06-22 更名:IPTGA Projekt Konzept GmbH**】(柏林,Storkower Str. 115A, 10407;**HRB 216686 B AG Charlottenburg;DE329092725;2020-04-14 创**;谱型=柏林小微 IT 咨询屋(安全/可扩展方案/软件编程/接口;媒体/IT 管理;Videokonferenz/视频软件线)**档名 NiTo 已过时实体,谱带应台账对位现名 IPTGA**;**GF 换位谱全接:Oldenburg(2020)→Silvia Müller(2023)→Torsten Uwe Müller(2025-12)→Joel Can Müller(2026-06)**
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Torsten Uwe Müller(Geschäftsführer(**2025-12-02 起在职**;*1963,Berlin),official-self-published·谱/leads-only(直发需 opt-in));Joel Can Müller(Geschäftsführer(2026-06 更名时谱=IPTGA 名下;族谱 Jr 代),official-self-published·谱/leads-only(直发需 opt-in));Silvia Müller(原 Geschäftsführer(2023-01~2025-12;Impressum 遗留自署=滞后谱),official-self-published·谱/leads-only(直发需 opt-in));Nils Christian Oldenburg(原 Geschäftsführer(2020 创铺至 2023-01),official-self-published·谱/leads-only(直发需 opt-in))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：更名锚+GF 年换谱

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**02.12.2025: Nicht mehr GF: Silvia Müller;GF: Torsten Uwe Müller, *15.06.1963, Berlin;22.06.2026: Firma geändert alt NiTo IT Systeme GmbH → neu IPTGA Projekt Konzept GmbH;GF: Joel Can Müller(webvalid/creditreform 登记公告件)
  > 02.12.2025: Nicht mehr GF: Silvia Müller;GF: Torsten Uwe Müller, *15.06.1963, Berlin;22.06.2026: Firma geändert alt NiTo IT Systeme GmbH → neu IPTGA Projekt Konzept GmbH;GF: Joel Can Müller(webvalid/creditreform 登记公告件)
  > 来源：https://www.webvalid.de/company/NiTo+IT+Systeme+GmbH,+Berlin/HRB+216686
- **【联系方式与基础画像】**Storkower Str. 115A, 10407 Berlin;HRB 216686 B Berlin-Charlottenburg;DE329092725;gegründet 14.04.2020(nitoit.de Impressum=Silvia Müller 遗留滞后谱)
  > Storkower Str. 115A, 10407 Berlin;HRB 216686 B Berlin-Charlottenburg;DE329092725;gegründet 14.04.2020(nitoit.de Impressum=Silvia Müller 遗留滞后谱)
  > 来源：https://nitoit.de/impressum/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：NiTo IT Systeme GmbH →【**2026-06-22 更名:IPTGA Projekt Konzept GmbH**】(柏林,Storkower Str. 115A, 10407;**HRB 216686 B AG Charlottenburg;DE329092725;2020-04-14 创**;谱型=柏林小微 IT 咨询屋(安全/可扩展方案/软件编程/接口;媒体/IT 管理;Videokonferenz/视频软件线)**档名 NiTo 已过时实体,谱带应台账对位现名 IPTGA**;**GF 换位谱全接:Oldenburg(2020)→Silvia Müller(2023)→Torsten Uwe Müller(2025-12)→Joel Can Müller(2026-06)**
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：柏林 6 年微 IT 咨询(已更名 IPTGA)
- **团队与规模**：微实体谱;2020 创
- **决策链与对接人**：**Torsten Uwe Müller(Geschäftsführer(**2025-12-02 起在职**;*1963,Berlin),official-self-published·谱/leads-only(直发需 opt-in));Joel Can Müller(Geschäftsführer(2026-06 更名时谱=IPTGA 名下;族谱 Jr 代),official-self-published·谱/leads-only(直发需 opt-in));Silvia Müller(原 Geschäftsführer(2023-01~2025-12;Impressum 遗留自署=滞后谱),official-self-published·谱/leads-only(直发需 opt-in));Nils Christian Oldenburg(原 Geschäftsführer(2020 创铺至 2023-01),official-self-published·谱/leads-only(直发需 opt-in))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 14 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Torsten Müller 现任(现名 IPTGA 谱;opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | NiTo 电商商：Allied 独牌实版旁 value 上架位（$180 锚点一致）；einkauf@ 采购口 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：更名锚+GF 年换谱
- **W**：微实体谱
- **O**：Müller 族谱直达位
- **T**：大牌件链竞谱

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Guten Tag Herr Müller,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
