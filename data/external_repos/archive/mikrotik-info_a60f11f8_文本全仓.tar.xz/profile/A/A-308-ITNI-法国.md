# ITNI

> **评级 A**　|　法国 · Saint-Denis　|　档案编号 `A-308`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-308
rating: A
country: 法国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: true, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；信息待人工补齐（见备注）
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — ITNI 法 Saint-Denis（CSV: AT Integrate Elite 三证；官网壳页+先电话反诈规则）：低信号窄针（$180 锚点一致）；薄证注；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | ITNI（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 法国 / Saint-Denis | 事实 |
| 网站 | https://www.itni.fr | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】ITNI:ITNI SAS(法国 Saint-Denis,103-105 Rue Charles Michels, 93200;**SIREN 505346312;2008-07-18 创 18 年;SAS cap €700k;100-199 人;CA €113.3M(2020)=法电信电子件批发大户(4652Z)**;**Président: Jean Marie Tawil(1962 生,2015-11-06 起;verif/corporama/lejournaldesentreprises 三源 O)**;5 支局(Ambares-et-Lagrave/Les Ulis 等);LEI 谱;entreprise familiale 注;Importateur+Exportateur important 谱
- 【推断】R66 第 21 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-08, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、VoIP/Voice VLAN
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - VoIP/Voice VLAN：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：contact@itni.fr
  - 状态：既有/公开
- **电话**：+33 1 48 13 99 99
- 来源等级：official-company（R41–R48 联系方式台账口径）
- **原始联系字段**：contact@itni.fr（官网首页；官网提示供应商往来须先电话，首次触达建议电话+邮件并用）；+33 1 48 13 99 99
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Jean Marie Tawil**(Président(2015-11 起;三源一致))— verif.com/corporama 双件 〔已有(公司官方公开件/登记册自曝);源:https://corporama.com/fr/societe/itni/505346312〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Jean Marie Tawil | Président(2015-11 起;三源一致) | verif.com/corporama 双件 | official-self-published·谱/leads-only(直发需 opt-in) | https://corporama.com/fr/societe/itni/505346312 |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 电话先行

- **推什么**：—
- **切入点**：电话开场点明：看到贵司官网的反诈声明，所以先打电话再发邮件——介绍我们与 24 口 PoE 第二来源意图，随后邮件一页。
- **要问的问题**：（电话）可否告知采购/网络负责人邮箱以便随件？
- **随附证明**：通话记录+随后一页报价（法）。

### 第 2 次跟进 · 电话+邮件并用：24 口一页

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行 L2+）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：Allied 项目的接入层第二来源价位档（RMA/连续性）。
- **要问的问题**：项目的接入层报价空档怎么填？
- **随附证明**：一页报价（法）。

### 第 3 次跟进 · 无回响即冻结

- **推什么**：—
- **切入点**：价卡留档不再追。
- **要问的问题**：（无需回）价卡留档。
- **随附证明**：全品类一页价卡。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第16批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：巴黎北 Allied Elite 级集成商（**反诈规约=先电话后邮件**，否则一律当钓鱼）。
- **产品线与在售品牌**：（极简站；Allied Integrate/Elite/Resell 三级在册，CSV）。
- **目标行业与场景**：法国企业网项目客群。
- **团队与规模**：中型（客户 Extranet 体系）。
- **决策链与对接人**：电话 01 48 13 99 99 **先行**，contact@itni.fr 随后（CSV 9-27）。
- **技术与认证**：Allied 三级伙伴（CSV）。
- **采购与供应链信号**：先电话建立真实人味后，其项目的接入层第二来源可谈。
- **近期动态与线索**：反诈意识极高=商务信誉型客户，规矩对了反而好谈。
- **与我方契合点**：24 口 PoE 第二来源+备件。
- **风险与注意**：**绝不可以冷邮件为首次触达**（其自设判据=钓鱼）；电话时直接引用其反诈立场开场。

### R54 原文证据摘录（全部保留）

- **【业务定位】**圣但尼的 Allied Integrate/Integrate Elite/Resell 集成商（CSV 伙伴等级）；官网为极简一页+客户 Extranet 入口。
  > Bienvenue sur la page d'accueil de la société ITNI ‖ ITNI met à la disposition de ses clients un Extranet sécurisé.
  > 来源：https://www.itni.fr/
- **【风险与注意】**官网反诈声明明写：**「ITNI 从不未先电话就要求开供应商户或以邮件下单，收到此类邮件即为假」**——供应商陌拜**必须先电话**、邮件随后，否则会被当钓鱼邮件处理。
  > ITNI ne demande pas d'ouverture de compte fournisseur, ni ne passe de commande par mail sans appel téléphonique au préalable. Si vous recevez ce type de message, il s'agit d'un faux.
  > 来源：https://www.itni.fr/
- **【决策链与对接人】**contact@itni.fr 官网首页正文+01 48 13 99 99（CSV 9-27 official-company）；**触达顺序=电话先行、邮件并用**（官网提示+CSV 建议一致）。
  > （CSV 2026-09-27 记录）官网反诈提示供应商往来须先电话——建议电话+邮件并用；official-company
  > 来源：https://www.itni.fr/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第21波50户.json`；价格均为 EXW 快照。

- **①背景再核**：ITNI SAS(法国 Saint-Denis,103-105 Rue Charles Michels, 93200;**SIREN 505346312;2008-07-18 创 18 年;SAS cap €700k;100-199 人;CA €113.3M(2020)=法电信电子件批发大户(4652Z)**;**Président: Jean Marie Tawil(1962 生,2015-11-06 起;verif/corporama/lejournaldesentreprises 三源 O)**;5 支局(Ambares-et-Lagrave/Les Ulis 等);LEI 谱;entreprise familiale 注;Importateur+Exportateur important 谱
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Jean Marie Tawil(Président(2015-11 起;三源一致),official-self-published·谱/leads-only(直发需 opt-in))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-08, 15天有效))
- **⑤在乎与偏好**：€113M 进出口大户=件链窗

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Dirigeant: Jean Marie TAWIL(Président;né 1962;depuis 06/11/2015)(corporama/e-pro/verif 件)
  > Dirigeant: Jean Marie TAWIL(Président;né 1962;depuis 06/11/2015)(corporama/e-pro/verif 件)
  > 来源：https://corporama.com/fr/societe/itni/505346312
- **【联系方式与基础画像】**SIREN 505 346 312;103 Rue Charles Michels, 93200 Saint-Denis;SAS 2008;capital €700.000;100-199 salariés;CA €113.278.828(2020);4652Z 电信电子批发;5 établissements;Importateur/Exportateur important(corporama/lejournaldesentreprises 件)
  > SIREN 505 346 312;103 Rue Charles Michels, 93200 Saint-Denis;SAS 2008;capital €700.000;100-199 salariés;CA €113.278.828(2020);4652Z 电信电子批发;5 établissements;Importateur/Exportateur important(corporama/lejournaldesentreprises 件)
  > 来源：https://www.lejournaldesentreprises.com/entreprise/itni

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：ITNI SAS(法国 Saint-Denis,103-105 Rue Charles Michels, 93200;**SIREN 505346312;2008-07-18 创 18 年;SAS cap €700k;100-199 人;CA €113.3M(2020)=法电信电子件批发大户(4652Z)**;**Président: Jean Marie Tawil(1962 生,2015-11-06 起;verif/corporama/lejournaldesentreprises 三源 O)**;5 支局(Ambares-et-Lagrave/Les Ulis 等);LEI 谱;entreprise familiale 注;Importateur+Exportateur important 谱
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：法国圣但尼 €113M 电信件批发大户
- **团队与规模**：100-199 人;2008 创
- **决策链与对接人**：**Jean Marie Tawil(Président(2015-11 起;三源一致),official-self-published·谱/leads-only(直发需 opt-in))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 21 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Jean-Marie Tawil 直达(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | ITNI 法 Saint-Denis（CSV: AT Integrate Elite 三证；官网壳页+先电话反诈规则）：低信号窄针（$180 锚点一致）；薄证注 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：€113M 进出口大户=件链窗
- **W**：批发大户谱
- **O**：Tawil 直达位
- **T**：一线链竞谱

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Monsieur Tawil,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
