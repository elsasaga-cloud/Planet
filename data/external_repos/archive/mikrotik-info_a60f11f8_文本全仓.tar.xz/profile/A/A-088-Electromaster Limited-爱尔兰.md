# Electromaster Limited

> **评级 A**　|　爱尔兰 · Tallaght, Dublin　|　档案编号 `A-088`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-088
rating: A
country: 爱尔兰
biz_org: 个体顾问（无官网）
business_model: 顾问项目制
decision_speed: fast
price_sensitivity: high
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: false, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STC-28DGGPM
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：个体顾问（无官网）；顾问项目制
- **商业模式**：顾问项目制
- **为什么值得跟**：有明确交换/供电需求（交换专长、PoE/监控/门禁、工业/楼宇），三星重点
- **P1（首触唯一主推）**：STC-28DGGPM（8口 PoE 接入盒） — Electromaster 爱尔兰：域名流落+NO-MX 触达降级（站被占如实标注；先电话名录核验）；$99 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Electromaster Limited（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 爱尔兰 / Tallaght, Dublin | 事实 |
| 网站 | —（无公开站点） | 事实 |
| 类型 | 分销/集成商（Perle 授权） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Perle Systems（工业 PoE 交换机 / 媒体转换 / 串口设备联网） | 事实（名录/自报口径） |
| 组织性质 | 个体顾问（无官网） | 【推断】 |
| 商业模式 | 顾问项目制 | 【推断】 |
| 团队规模 | 一人/微型 | 【推断】 |
| 决策链 | 短（本人即决策） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Electromaster Limited:Electromaster Limited(库档英国;**R66 检索排噪:爱尔兰 Cork 同名 Electromaster Ltd(163563)=DISSOLVED 2022,不采信;UK 本体未证;守档准由**
- 【推断】R66 第 7-8 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Perle Systems（工业 PoE 交换机 / 媒体转换 / 串口设备联网））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@electromaster.ie【已停用:2026-10-04 退信 not-found(46h|20h retry 后 Message not delivered)】
  - 状态：R62-退信-not-found
- **电话**：2026-10-04
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：info@electromaster.ie【已停用:2026-10-04 退信 not-found(46h|20h retry 后 Message not delivered) 发不过去】（Golden Pages 与 HiFi 名录均收录；都柏林 Tallaght）
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。

## 关键人（KP）与触达通道

- 关键人未定位：首封信件以 info/通用邮箱开场并向其索要正确联系人。

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-28DGGPM（8口 PoE 接入盒）），备选型不进邮件。

### 第 1 次跟进 · 存续核实 + 工业 PoE 价位段试探

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：先电话确认公司是否仍在正常经营；若活，按 Perle 同规格价差递一页资料。
- **要问的问题**：（电话）还在做工业联网类分销吗？
- **随附证明**：一页规格单（英文）+ 同规格对照。

### 第 2 次跟进 · 4 口工业 PoE（楼宇安装配套）

- **推什么**：STI-240GE（Saga） PoE 版（4G + 2×SFP，DIN，-40~75°C）
- **切入点**：楼宇安装项目的零散 PoE 点位：4 口小机随项目配套，低起订混批低风险试单。
- **要问的问题**：楼宇项目的 PoE 补充件现在哪个渠道拿？
- **随附证明**：混批价目 + 宽温报告。

### 第 3 次跟进 · 管理型 10G（项目段扩展）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：若试单走通再谈管理型与项目注册；走不通即标记归档。
- **要问的问题**：有没有整层/整栋网络段的配套机会？
- **随附证明**：项目注册政策 + VLAN/ERPS 模板。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第5批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：都柏林老牌电子/影音安装分销商（Perle 授权渠道，CSV 记录）；当前官网域名已失守，公司线上状态存疑——先电话核实存续。
- **产品线与在售品牌**：历史货架：影音安装件（Lumene/Norstone/Vogel's）+ Perle 工业联网（CSV 记录）。
- **目标行业与场景**：爱尔兰楼宇/商业安装项目的配套分销。
- **团队与规模**：小型本地分销（Whitestown Business Park 单元）。
- **决策链与对接人**：info@electromaster.ie / +353 1 466 7400（第三方名录；CSV 同记 Golden Pages/HiFi 名录收录）。
- **技术与认证**：Perle 授权分销商（CSV 记录）。
- **采购与供应链信号**：若公司仍在运营：楼宇安装配套件持续需求；域名失守说明经营收缩可能。
- **近期动态与线索**：域名显示为博彩内容（2026-09-28 抓取）——存续核实为第一优先。
- **与我方契合点**：活着则按 Perle 价位段补位走分销阶梯；失联则归档不追。
- **风险与注意**：邮件可能无人收或以失效域名入黑名单；电话确认后再决定投入——绝不要引用那个博彩页面。

### R54 原文证据摘录（全部保留）

- **【近期动态与线索】**⚠️ 域名 electromaster.ie 当前内容已被换成「加密货币赌场测评」站——原始公司网站失联（域名易主/被占），如实标注。
  > Best Crypto Casinos UK 2026 – Top Bitcoin Casino Sites（electromaster.ie 当前页面标题）
  > 来源：https://electromaster.ie/
- **【决策链与对接人】**爱尔兰音箱/安装业名录（第三方页）：Tallaght 都柏林 24 区 Whitestown 工业园，电话与 info@ 邮箱记录与 CSV 一致。
  > Electromaster Ltd. Dublin — Address: Unit 1, Whitestown Business Park Whitestown Drive Tallaght Dublin 24 · Phone: 014667400 · Email: info@electromaster.ie
  > 来源：http://hifi.ie/stockist/electromaster-ltd-dublin/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-07_R66_R56_KP第7_8波.json`；价格均为 EXW 快照。

- **①背景再核**：Electromaster Limited(库档英国;**R66 检索排噪:爱尔兰 Cork 同名 Electromaster Ltd(163563)=DISSOLVED 2022,不采信;UK 本体未证;守档准由**
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**守档准由;R66 波次二点名**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：消排同名(爱尔兰注销)

### R55 证据摘录（全部保留 · 含数量）

- **【风险与注意】**Electromaster Limited (Cork, Co. 163563) — DISSOLVED 29 Aug 2022 · +353 21 494 6740 · James Dunne(同名排噪,不代表库档 UK 本体)
  > Electromaster Limited (Cork, Co. 163563) — DISSOLVED 29 Aug 2022 · +353 21 494 6740 · James Dunne(同名排噪,不代表库档 UK 本体)
  > 来源：https://www.solocheck.ie/Irish-Company/Electromaster-Limited-163563
- **【业务定位】**2026-10-07 R66 波次:同名 Ireland 实体注销排噪;UK 本体待谱面二波
  > 2026-10-07 R66 波次:同名 Ireland 实体注销排噪;UK 本体待谱面二波
  > 来源：https://find-and-update.company-information.service.gov.uk
- **【近期动态与线索】**R66 守档准由:同名实体已注销;本体待谱面锁定
  > R66 守档准由:同名实体已注销;本体待谱面锁定
  > 来源：https://find-and-update.company-information.service.gov.uk

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Electromaster Limited(库档英国;**R66 检索排噪:爱尔兰 Cork 同名 Electromaster Ltd(163563)=DISSOLVED 2022,不采信;UK 本体未证;守档准由**
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：(库档英国本体待谱面锁定)
- **团队与规模**：(待谱面锁定)
- **决策链与对接人**：**守档准由;R66 波次二点名**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-07 R66 7-8 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：同名噪声排(波次二锁定)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-28DGGPM（8口 PoE 接入盒） | 主场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Electromaster 爱尔兰：域名流落+NO-MX 触达降级（站被占如实标注；先电话名录核验） |
| 备选2 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：8口 GE(7)+SFP，PoE af/at 240W，DC 随附电源，L2+ 全特性（VLAN/ERPS<20ms/QinQ/Private VLAN/sFlow），PoE 看门狗自动冷重启
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：消排同名(爱尔兰注销)
- **W**：同名实体已注销
- **O**：UK 本体波次二点名
- **T**：同名噪声

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**本户特别红线/停止条件**

- 一人/个体=单点与节奏风险

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ❓ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Hi team,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
