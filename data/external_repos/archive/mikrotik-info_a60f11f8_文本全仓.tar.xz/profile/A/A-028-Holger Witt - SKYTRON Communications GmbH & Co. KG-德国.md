# Holger Witt / SKYTRON Communications GmbH & Co. KG

> **评级 A**　|　德国 · Karlsbad　|　档案编号 `A-028`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-028
rating: A
country: 德国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: true, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（光纤接入），且有具体人直联
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — SKYTRON 活动/市政 WLAN+监控：24 口 PoE 一台到位+10G 回传（Event 峰值问题开场）；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Holger Witt / SKYTRON Communications GmbH & Co. KG（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 德国 / Karlsbad | 事实 |
| 网站 | skytron.business | 事实 |
| 类型 | 集成商/顾问（MikroTik 认证） | 事实（CSV 名录口径） |
| 关键人 | Holger Witt | 事实 |
| 反向信号（资质/品牌） | MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCTCE+MTCUME+MTCINE+MTCIPv6E+MTCSE+MTCEWE | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】SKYTRON Communications GmbH & Co. KG:SKYTRON Communications GmbH & Co. KG(德国 Karlsbad,Im Stöckmädle 13, 76307 Karlsbad-Ittersbach;HRA 503745 AG Mannheim;Komplementär: SKYTRON-Verwaltungs GmbH;USt DE813487271;谱型=德国 ISP(高速网为工业/手工业/自由职业/公部门/私客;Richtfunk/WLAN/Glasfaser/VDSL/VoIP/LoRaWAN/Rechenzentrum;200+ 市镇 Baden-Württemberg 谱)
- 【推断】R66 第 7-8 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCTCE+MTCUME+MTCINE+MTCIPv6E+MTCSE+MTCEWE）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、万兆上行/骨干
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - 万兆上行/骨干：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：h.witt@skytron.de
  - 状态：既有/公开
- **电话**：+49 7248 4528-130
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：+49 7248 4528-130 / h.witt@skytron.de
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Andreas Kramski**(Geschäftsführer)— skytron.business/myskytron Impressum 自署 〔已有(公司官方公开件/登记册自曝);源:https://skytron.business/informationen/impressum/〕
  - **Peter Benz**(Geschäftsführer / CEO(LinkedIn 谱))— Impressum+LinkedIn 双源 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://www.skytron.business/informationen/impressum/〕
  - **Torsten Oertle**(Key-Account-Manager)— LinkedIn 公司员工页自曝 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://de.linkedin.com/company/skytron-de〕
  - **H. Witt**(员工邮箱谱(CSV 入档 h.witt@skytron.de;信具名待核))— h.witt@skytron.de (CSV 入档,猜测 leads-only) 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://www.skytron.de〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Andreas Kramski | Geschäftsführer | skytron.business/myskytron Impressum 自署 | official-self-published·谱/leads-only(直发需 opt-in) | https://skytron.business/informationen/impressum/ |
| Peter Benz | Geschäftsführer / CEO(LinkedIn 谱) | Impressum+LinkedIn 双源 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://www.skytron.business/informationen/impressum/ |
| Torsten Oertle | Key-Account-Manager | LinkedIn 公司员工页自曝 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://de.linkedin.com/company/skytron-de |
| H. Witt | 员工邮箱谱(CSV 入档 h.witt@skytron.de;信具名待核) | h.witt@skytron.de (CSV 入档,猜测 leads-only) | leads-only·待 opt-in(LinkedIn/谱面带核) | https://www.skytron.de |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE 入门款

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：客户侧「托管交换机 + 企业 WLAN + 视频监控」打包：24 口 PoE++ 一台覆盖一层/一栋，讲整机功率预算与看门狗（减少上门）。
- **要问的问题**：他们的企业客户项目里，接入层交换机现在谁供货？
- **随附证明**：功率实测 + 与 CRS328-24P/UniFi 同规格对照 + 测试机。

### 第 2 次跟进 · 工业级非管理 PoE（塔站/室外箱）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：自建网塔站与室外箱：宽温宽压、DIN、免配置；他们自己就是运营商，最懂现场故障成本。
- **要问的问题**：塔站/室外箱设备现在用什么、坏得最多的是哪一类？
- **随附证明**：宽温/宽压报告 + 双电源 + 备件政策。

### 第 3 次跟进 · 管理型 PoE（冗余与高可用）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：他卖「介质冗余」：给他 ERPS/环网切换实测数据与 VLAN/QoS 模板，把我们的交换机写进他高可用方案的设备清单。
- **要问的问题**：他们的冗余方案里，接入层交换机要不要支持 ERPS？切换指标多少？
- **随附证明**：ERPS 切换实测（丢包/恢复时间）+ VLAN/QoS 模板 + 招标参数条目。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第2批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：SKYTRON Communications GmbH & Co. KG（2000 年成立的微波/无线电先驱，现为全栈电信服务商）：自建基础设施，做企业互联网、WLAN、电话、IT 安全、云/数据中心与 IoT/LoRaWAN。
- **产品线与在售品牌**：自建 Richtfunk/Glasfaser/VDSL 接入与自有网络；方案页明列 **managed Switchen** 与 Enterprise WLAN、视频监控；未公开具体品牌。
- **目标行业与场景**：企业多点组网（Standortvernetzung）、园区/停车场监控（Campus-Vernetzung）、城市公共 WiFi 与活动 WiFi、高可用（微波做冗余链路、SD-WAN 多线捆绑）、工业 IoT。
- **团队与规模**：中型区域服务商（团队含多领域专家，Karlsbad 基地，服务德国西南部），决策链为技术负责人。
- **决策链与对接人**：Holger Witt（h.witt@skytron.de；+49 7248 4528-130），持 10 证含 MTCEWE。
- **技术与认证**：MTCNA+MTCRE+MTCWE+MTCTCE+MTCUME+MTCINE+MTCIPv6E+MTCSE+MTCEWE（10 证）——从路由到企业无线全覆盖。
- **采购与供应链信号**：自建网络 + 客户项目双线采购：网内设备按运营商标准选（稳定性/备件），客户项目按方案选（要能写进标书）。
- **近期动态与线索**：官网 2026 年在线：把微波定位为「介质冗余」（与光纤并行）并推 SD-WAN 捆绑；新增 LoRaWAN/IoT 板块与可视化 Dashboard。
- **与我方契合点**：客户侧「managed Switchen + Enterprise WLAN + 视频监控」就是 24 口 PoE 与工业款的场景；网内侧塔站/机箱需要宽温工业设备；高可用话术直接对上 ERPS。
- **风险与注意**：他对链路冗余要求高：任何冗余参数都要有实测数据（切换时间、丢包），不能只给规格表。

### R54 原文证据摘录（全部保留）

- **【产品线与在售品牌】**能力页明确写 WLAN & Netzwerk 含托管交换机、企业无线、公共/活动 WiFi 与视频监控。
  > WLAN & Netzwerk — Von managed Switchen bis hin zu zuverlässigem Enterprise WLAN bieten wir maßgeschneiderte Lösungen. Unser Angebot umfasst auch öffentliches WLAN für Städte, Event-WLAN für Veranstaltungen und Videoüberwachungssysteme.
  > 来源：https://skytron.business/
- **【业务定位】**公司沿革与自有基础设施（2000 年起的微波先驱）。
  > Wir sind ein Unternehmen, das im Jahr 2000 als Richtfunk-Pioniere gestartet ist … Unsere Kunden profitieren davon, dass wir unsere eigene Infrastruktur zur Privat- und Firmenkundenanbindung betreiben
  > 来源：https://skytron.business/
- **【目标行业与场景】**高可用叙事：微波做介质冗余 / SD-WAN 多线捆绑。
  > In der Kundenpraxis dient Richtfunk als hochwertige Medienredundanz, die parallel zu anderen Leitungen wie Glasfaser eingesetzt wird … Alternativ bieten wir Backup-Lösungen über SD-WAN an, die mehrere Internetanschlüsse bündeln
  > 来源：https://skytron.business/
- **【目标行业与场景】**园区/多点组网与监控场景。
  > Wir bieten die ideale Lösung für die Vernetzung Ihrer Unternehmensstandorte. Darüber hinaus ermöglichen wir auch Campus-Vernetzungen, beispielsweise für die Überwachung des Firmenparkplatzes.
  > 来源：https://skytron.business/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-07_R66_R56_KP第7_8波.json`；价格均为 EXW 快照。

- **①背景再核**：SKYTRON Communications GmbH & Co. KG(德国 Karlsbad,Im Stöckmädle 13, 76307 Karlsbad-Ittersbach;HRA 503745 AG Mannheim;Komplementär: SKYTRON-Verwaltungs GmbH;USt DE813487271;谱型=德国 ISP(高速网为工业/手工业/自由职业/公部门/私客;Richtfunk/WLAN/Glasfaser/VDSL/VoIP/LoRaWAN/Rechenzentrum;200+ 市镇 Baden-Württemberg 谱)
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Andreas Kramski(Geschäftsführer,official-self-published·谱/leads-only(直发需 opt-in));Peter Benz(Geschäftsführer / CEO(LinkedIn 谱),leads-only·待 opt-in(LinkedIn/谱面带核));Torsten Oertle(Key-Account-Manager,leads-only·待 opt-in(LinkedIn/谱面带核));H. Witt(员工邮箱谱(CSV 入档 h.witt@skytron.de;信具名待核),leads-only·待 opt-in(LinkedIn/谱面带核))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：ISP 200+ 市镇谱

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Geschäftsführer: Andreas Kramski, Peter Benz · HRA 503745 (AG Mannheim) · Komplementär: SKYTRON-Verwaltungs GmbH · DE 813 487 271
  > Geschäftsführer: Andreas Kramski, Peter Benz · HRA 503745 (AG Mannheim) · Komplementär: SKYTRON-Verwaltungs GmbH · DE 813 487 271
  > 来源：https://myskytron.skytron.de/pages/kontakt.php
- **【决策链与对接人】**Peter Benz Geschäftsführer - CEO · Torsten Oertle Key-Account-Manager bei SKYTRON(LinkedIn 公司页)
  > Peter Benz Geschäftsführer - CEO · Torsten Oertle Key-Account-Manager bei SKYTRON(LinkedIn 公司页)
  > 来源：https://de.linkedin.com/company/skytron-de
- **【业务定位】**über 200 versorgten Ortschaften Baden-Württemberg;Internetprovider, Richtfunk, WLAN, Firewall, IT-Security, VoIP, Glasfaser, VDSL, Rechenzentrum, LoraWAN und IoT
  > über 200 versorgten Ortschaften Baden-Württemberg;Internetprovider, Richtfunk, WLAN, Firewall, IT-Security, VoIP, Glasfaser, VDSL, Rechenzentrum, LoraWAN und IoT
  > 来源：https://de.linkedin.com/company/skytron-de

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：SKYTRON Communications GmbH & Co. KG(德国 Karlsbad,Im Stöckmädle 13, 76307 Karlsbad-Ittersbach;HRA 503745 AG Mannheim;Komplementär: SKYTRON-Verwaltungs GmbH;USt DE813487271;谱型=德国 ISP(高速网为工业/手工业/自由职业/公部门/私客;Richtfunk/WLAN/Glasfaser/VDSL/VoIP/LoRaWAN/Rechenzentrum;200+ 市镇 Baden-Württemberg 谱)
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：德国巴登-符腾堡 ISP(200+ 市镇,Richtfunk/WLAN/VoIP)
- **团队与规模**：(规模;LinkedIn 48 followers)
- **决策链与对接人**：**Andreas Kramski(Geschäftsführer,official-self-published·谱/leads-only(直发需 opt-in));Peter Benz(Geschäftsführer / CEO(LinkedIn 谱),leads-only·待 opt-in(LinkedIn/谱面带核));Torsten Oertle(Key-Account-Manager,leads-only·待 opt-in(LinkedIn/谱面带核));H. Witt(员工邮箱谱(CSV 入档 h.witt@skytron.de;信具名待核),leads-only·待 opt-in(LinkedIn/谱面带核))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-07 R66 7-8 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Kramski/Benz 双 GF(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | SKYTRON 活动/市政 WLAN+监控：24 口 PoE 一台到位+10G 回传（Event 峰值问题开场） |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：ISP 200+ 市镇谱
- **W**：Benz/Kramski 双 GF 谱面重叠
- **O**：Kramski 直达位(h.witt CSV 谱)
- **T**：公共/运营商大牌

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Hi Herr Kramski,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
