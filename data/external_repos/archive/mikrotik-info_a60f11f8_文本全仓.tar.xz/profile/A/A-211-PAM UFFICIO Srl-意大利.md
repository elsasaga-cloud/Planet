# PAM UFFICIO Srl

> **评级 A**　|　意大利 · Messina　|　档案编号 `A-211`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-211
rating: A
country: 意大利
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: true, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；信息待人工补齐（见备注）
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — PAM 墨西拿办公用品 IT 支线：低信号窄位（$180 锚点一致）；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | PAM UFFICIO Srl（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 意大利 / Messina | 事实 |
| 网站 | http://www.pamufficio.it | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】PAM UFFICIO Srl:PAM UFFICIO SRL(意大利 Messina,C.da Filangeri snc(Pistunina);**P.IVA 01261820839;REA ME-113569;1983-07-29 创 43 年;2-5 人;€626-714k(2024;utile €107k,-24% trend)**;办公设备+IT 铺;**MePA 60 项 abilitazioni 大谱(网络设备段已含)**;Amministratore Unico 位在册(atoka 打码条)→公开谱面未点名=**守档准由**)
- 【推断】R66 第 19 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、VoIP/Voice VLAN
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - VoIP/Voice VLAN：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@pamufficio.it
  - 状态：待核·未验证投递（不进群发）
- **电话**：—
- 来源等级：official（R41–R48 联系方式台账口径）
- **原始联系字段**：info@pamufficio.it（官网正文公开；未验证投递）；原入口：见 alliedtelesis.com 伙伴页
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。

## 关键人（KP）与触达通道

- 关键人未定位：首封信件以 info/通用邮箱开场并向其索要正确联系人。

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 工业级非管理小件（门店/办公供电层试单）

- **推什么**：STI-240GE（Saga） PoE 版（4G + 2×SFP，DIN，-40~75°C）
- **切入点**：门店摄像头/电话/打印点位的供电小件：4 口宽温小机试用价。
- **要问的问题**：门店点位的供电小交换要不要试一台？
- **随附证明**：一页报价 + 宽温要点（意）。

### 第 2 次跟进 · 24 口 CCTV/PoE（稍大项目接入层）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：稍大办公/店面项目：24 口 PoE++ 挂靠价。
- **要问的问题**：稍大项目接入层现在配什么？
- **随附证明**：规格要点 + 挂靠价。

### 第 3 次跟进 · 管理型 PoE（分段简件）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：大点项目的分段简件速查；无回响即归档。
- **要问的问题**：分段模板要不要留一份？
- **随附证明**：VLAN 速查卡（意）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第11批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：墨西拿 Tremestieri 办公用品+IT 综合小店：文具/家具/办公/信息四格，Allied Resell（CSV 记录）。
- **产品线与在售品牌**：办公信息设备+文具家具（综合店）。
- **目标行业与场景**：墨西拿商圈小微与店铺。
- **团队与规模**：小型综合店。
- **决策链与对接人**：info@pamufficio.it（CSV 9-27+官网明牌互证）。
- **技术与认证**：Allied Resell（CSV 记录）。
- **采购与供应链信号**：综合店走零售节奏：小 PoE 件试单+挂靠价。
- **近期动态与线索**：一页极简站（电话联系为主）。
- **与我方契合点**：门店/办公室小 PoE 件零售补位。
- **风险与注意**：量小微利：别投大篇幅；一页报价或先电话。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网四词主页：**INFORMATICA/OFFICE/CANCELLERIA（文具）/ARREDAMENTO（家具）**——墨西拿办公用品综合店。
  > INFORMATICA · OFFICE · CANCELLERIA · ARREDAMENTO（主页四格）
  > 来源：http://www.pamufficio.it/
- **【决策链与对接人】**官网明牌：电话+39 090 671001+info@pamufficio.it+地址 C.da Filangeri Pistunina（Tremestieri Messina）——CSV 9-27 同址互证。
  > Per qualsiasi informazione contattare il +39 090 671001 o inviare un'email a info@pamufficio.it · C.da Filangeri, Pistunina, 98125 - Zona Tremestieri Messina
  > 来源：http://www.pamufficio.it/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第19波50户.json`；价格均为 EXW 快照。

- **①背景再核**：PAM UFFICIO SRL(意大利 Messina,C.da Filangeri snc(Pistunina);**P.IVA 01261820839;REA ME-113569;1983-07-29 创 43 年;2-5 人;€626-714k(2024;utile €107k,-24% trend)**;办公设备+IT 铺;**MePA 60 项 abilitazioni 大谱(网络设备段已含)**;Amministratore Unico 位在册(atoka 打码条)→公开谱面未点名=**守档准由**)
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**守档准由;R66 第 19 波点名(谱面无实名)**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：MePA 60 项含网络段=PA 谱窗

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**P.IVA 01261820839;REA ME113569;C.da Filangeri snc, Messina;costituita 29/07/1983;2-5 dipendenti;fatturato €714.400(2024);utile €107.067;41+ 年谱(fatturatoitalia/atoka 件)
  > P.IVA 01261820839;REA ME113569;C.da Filangeri snc, Messina;costituita 29/07/1983;2-5 dipendenti;fatturato €714.400(2024);utile €107.067;41+ 年谱(fatturatoitalia/atoka 件)
  > 来源：https://www.fatturatoitalia.it/pam_ufficio_s_r_l-01261820839
- **【近期动态与线索】**MePA scheda: 60 abilitazioni(lotto Apparati di rete 含;amministrazionicomunali.it 件)=西西里 PA 谱大户
  > MePA scheda: 60 abilitazioni(lotto Apparati di rete 含;amministrazionicomunali.it 件)=西西里 PA 谱大户
  > 来源：https://www.amministrazionicomunali.it/sicilia/messina/pam-ufficio-srl
- **【决策链与对接人】**Amministratore Unico 在册(atoka 打码条)——公开谱面未见具名=守档准由;2026-10-08 留痕
  > Amministratore Unico 在册(atoka 打码条)——公开谱面未见具名=守档准由;2026-10-08 留痕
  > 来源：https://atoka.io/public/it/azienda/pam-ufficio-s-r-l/02e236615994

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：PAM UFFICIO SRL(意大利 Messina,C.da Filangeri snc(Pistunina);**P.IVA 01261820839;REA ME-113569;1983-07-29 创 43 年;2-5 人;€626-714k(2024;utile €107k,-24% trend)**;办公设备+IT 铺;**MePA 60 项 abilitazioni 大谱(网络设备段已含)**;Amministratore Unico 位在册(atoka 打码条)→公开谱面未点名=**守档准由**)
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：意大利墨西拿 43 年办公+IT 铺(MePA 60 项)
- **团队与规模**：2-5 人;1983 创
- **决策链与对接人**：**守档准由;R66 第 19 波点名(谱面无实名)**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 19 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：守档:AU 在册未具名(满锚;待专批点名)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | PAM 墨西拿办公用品 IT 支线：低信号窄位（$180 锚点一致） |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：MePA 60 项含网络段=PA 谱窗
- **W**：小实体谱
- **O**：无守档
- **T**：—

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ❓ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Gentile Direzione,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
