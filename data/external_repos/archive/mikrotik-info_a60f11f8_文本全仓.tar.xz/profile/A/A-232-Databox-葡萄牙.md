# Databox

> **评级 A**　|　葡萄牙 · Massamá　|　档案编号 `A-232`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-232
rating: A
country: 葡萄牙
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；信息待人工补齐（见备注）
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — DATABOX 葡大盘分销（16 年 Dell Top）：经销商货架窄口二轨（$180 锚点一致）；体量错位注；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Databox（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 葡萄牙 / Massamá | 事实 |
| 网站 | https://www.databox.pt | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Databox:Databox, Informática S.A.(葡萄牙 Massamá(里斯本);**1985 创 41 年;95-250 人;IT 渠道分销大户**;**Expo TI Databox 官网具名双 CEO: André Reis & João Pedro Reis(族谱双驾=O 金谱);Susana Pereira Networking Product & BD Manager(网络品线 KPI!)+Jorge Matos 产品&库存+José Neves Diretor Comercial+Delfim Gaspar BUM+Jose Aguincha Director+Vitor Gama**;Expo TI 16 届(2026-05-07 Estoril)谱
- 【推断】R66 第 20 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电
  - PoE 接入供电：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：databox@databox.pt
  - 状态：待核·未验证投递（不进群发）
- **电话**：+351 214308442
- 来源等级：official（R41–R48 联系方式台账口径）
- **原始联系字段**：databox@databox.pt（官网正文公开；未验证投递）；原入口：见 alliedtelesis.com 伙伴页；Vitor Gama（网络产品经理）：+351 214308442，未公开个人邮箱
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **André Reis**(CEO(Expo TI 官网自署双 CEO 谱))— expotidatabox.pt 官网(O) 〔已有(公司官方公开件/登记册自曝);源:https://expotidatabox.pt/〕
  - **João Pedro Reis**(CEO(双 CEO 谱次位))— expotidatabox.pt 官网(O) 〔已有(公司官方公开件/登记册自曝);源:https://expotidatabox.pt/〕
  - **Susana Pereira**(Networking Product & Business Development Manager(网络品线 KPI))— rocketreach 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://rocketreach.co/databox-informatica-sa-email-format_b47fa9e7fc4b95ae〕
  - **Jorge Matos**(Gestor de Produto and Stock(产品&库存=件链口))— rocketreach 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://rocketreach.co/jorge-matos-email_76250898〕
  - **José Neves**(Diretor Comercial / GM Marketing(商务总监))— rocketreach 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://rocketreach.co/databox-informatica-sa-email-format_b47fa9e7fc4b95ae〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| André Reis | CEO(Expo TI 官网自署双 CEO 谱) | expotidatabox.pt 官网(O) | official-self-published·谱/leads-only(直发需 opt-in) | https://expotidatabox.pt/ |
| João Pedro Reis | CEO(双 CEO 谱次位) | expotidatabox.pt 官网(O) | official-self-published·谱/leads-only(直发需 opt-in) | https://expotidatabox.pt/ |
| Susana Pereira | Networking Product & Business Development Manager(网络品线 KPI) | rocketreach 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://rocketreach.co/databox-informatica-sa-email-format_b47fa9e7fc4b95ae |
| Jorge Matos | Gestor de Produto and Stock(产品&库存=件链口) | rocketreach 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://rocketreach.co/jorge-matos-email_76250898 |
| José Neves | Diretor Comercial / GM Marketing(商务总监) | rocketreach 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://rocketreach.co/databox-informatica-sa-email-format_b47fa9e7fc4b95ae |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · AISENS 式新品牌上架流程+监控 PoE 组合

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行 L2+）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：借其 2026-07 接入 AISENS 的先例：询问新连接品类供应商的上架流程，先递 24 口 PoE 监控交换组合（WD Purple 渠道可搭售）。
- **要问的问题**：新连接/网络品类供应商的上架评估走哪个流程和负责人？
- **随附证明**：上架一页提案（葡/英）+ 监控方案搭配示例。

### 第 2 次跟进 · 户外监控/工业窄线

- **推什么**：STI-280GE（Saga）（工业非管理 8×电口 + 2×上联光，宽温）
- **切入点**：监控项目户外段的宽温小件与收发器窄线（不占大盘货位）。
- **要问的问题**：户外监控点的宽温件有货架位吗？
- **随附证明**：工业件窄线一页 + CE。

### 第 3 次跟进 · 中性发货/阶梯价条款

- **推什么**：—（条款）
- **切入点**：中性发货+阶梯价+区域保护的分销条款包，给采购口一套可执行模板。
- **要问的问题**：新品牌首单要什么条件（MOQ/账期/保护）？
- **随附证明**：分销条款一页（英）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第12批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：葡萄牙分销大厂：Dell 深绑 16 年奖（不动 Dell 关系）；连接品类扩编期（AISENS 先例）。
- **产品线与在售品牌**：Dell/华硕/LG/WD/Norton/Fsas/AISENS 等；消费企业通吃，监控渠道有盘位。
- **目标行业与场景**：葡萄牙 B2B 经销商网络（注册门户在线）。
- **团队与规模**：中型分销（市场部官宣勤快）。
- **决策链与对接人**：databox@databox.pt（官网 contactos，CSV 9-27 记 Massamá 地址）。
- **技术与认证**：—（CSV：Allied 伙伴页入选身份属集成/代理背景）
- **采购与供应链信号**：AISENS 式上架流程=直接对口路径；WD Purple 置顶=安防渠道存在，PoE 监控交换可搭车。
- **近期动态与线索**：2026-09 品牌官宣节奏=品类拓编窗口；Fsas 渠道通讯转述=华为/富士通类线路周边。
- **与我方契合点**：监控渠道配套 24 口 PoE 接入层；AISENS 类目错层的工业件窄线。
- **风险与注意**：Dell 深绑不动其主机/存量关系；只做连接品类空档，一页葡语/西语双语报价。

### R54 原文证据摘录（全部保留）

- **【业务定位】**葡萄牙 Massamá 老牌 IT 分销（B2B 经销商门户）：**Dell 六感 Top Distributor SNS 奖连续 16 年（2026 官宣）**——深度渠道型。
  > DATABOX foi distinguida, pelo 16.º ano consecutivo, com o prémio Top Distributor SNS da DELL Technologies. 16 anos consecutivos de reconhecimento.
  > 来源：https://www.databox.pt/
- **【近期动态与线索】**2026-07 新接入 **AISENS 连接配件品牌**（上架公告在站）——尝鲜新连接品牌的现成先例；轮播置顶 WD Purple 监控盘。
  > AISENS chega ao nosso portefólio. Nova parceria de distribuição AISENS, descubra soluções de conectividade... ‖ WD PURPLE（轮播置顶）
  > 来源：https://www.databox.pt/
- **【采购与供应链信号】**在线 B2B 经销商注册门户 revendedores/registo=分销伙伴体系成熟，新供应商按流程评估。
  > Obter Acesso — https://www.databox.pt/revendedores/registo/
  > 来源：https://www.databox.pt/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第20波50户.json`；价格均为 EXW 快照。

- **①背景再核**：Databox, Informática S.A.(葡萄牙 Massamá(里斯本);**1985 创 41 年;95-250 人;IT 渠道分销大户**;**Expo TI Databox 官网具名双 CEO: André Reis & João Pedro Reis(族谱双驾=O 金谱);Susana Pereira Networking Product & BD Manager(网络品线 KPI!)+Jorge Matos 产品&库存+José Neves Diretor Comercial+Delfim Gaspar BUM+Jose Aguincha Director+Vitor Gama**;Expo TI 16 届(2026-05-07 Estoril)谱
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**André Reis(CEO(Expo TI 官网自署双 CEO 谱),official-self-published·谱/leads-only(直发需 opt-in));João Pedro Reis(CEO(双 CEO 谱次位),official-self-published·谱/leads-only(直发需 opt-in));Susana Pereira(Networking Product & Business Development Manager(网络品线 KPI),leads-only·待 opt-in(LinkedIn/谱面带核));Jorge Matos(Gestor de Produto and Stock(产品&库存=件链口),leads-only·待 opt-in(LinkedIn/谱面带核));José Neves(Diretor Comercial / GM Marketing(商务总监),leads-only·待 opt-in(LinkedIn/谱面带核))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：双 CEO 族谱+网络品线 PM 具名

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Boas-vindas Databox: **André Reis & João Pedro Reis CEOs**(expotidatabox.pt 首屏自署);rocketreach 谱: Susana Pereira(Networking PM/BD)+Jorge Matos(Gestor Produto&Stock)+José Neves(Diretor Comercial)+Delfim Gaspar(BU Manager)+Vladimiro Bordalo(Retail SM)
  > Boas-vindas Databox: **André Reis & João Pedro Reis CEOs**(expotidatabox.pt 首屏自署);rocketreach 谱: Susana Pereira(Networking PM/BD)+Jorge Matos(Gestor Produto&Stock)+José Neves(Diretor Comercial)+Delfim Gaspar(BU Manager)+Vladimiro Bordalo(Retail SM)
  > 来源：https://expotidatabox.pt/
- **【联系方式与基础画像】**fundada 1985;95-250 employees;Massamá/Lisboa;+351 21 430 8400;databox@databox.pt;Expo TI Databox 16ª edição 07/05 Centro de Congressos do Estoril(crunchbase/expotidatabox 件)
  > fundada 1985;95-250 employees;Massamá/Lisboa;+351 21 430 8400;databox@databox.pt;Expo TI Databox 16ª edição 07/05 Centro de Congressos do Estoril(crunchbase/expotidatabox 件)
  > 来源：https://www.crunchbase.com/organization/databox-ec20

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Databox, Informática S.A.(葡萄牙 Massamá(里斯本);**1985 创 41 年;95-250 人;IT 渠道分销大户**;**Expo TI Databox 官网具名双 CEO: André Reis & João Pedro Reis(族谱双驾=O 金谱);Susana Pereira Networking Product & BD Manager(网络品线 KPI!)+Jorge Matos 产品&库存+José Neves Diretor Comercial+Delfim Gaspar BUM+Jose Aguincha Director+Vitor Gama**;Expo TI 16 届(2026-05-07 Estoril)谱
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：葡萄牙里斯本 41 年 IT 渠道分销大户
- **团队与规模**：95-250 人;1985 创
- **决策链与对接人**：**André Reis(CEO(Expo TI 官网自署双 CEO 谱),official-self-published·谱/leads-only(直发需 opt-in));João Pedro Reis(CEO(双 CEO 谱次位),official-self-published·谱/leads-only(直发需 opt-in));Susana Pereira(Networking Product & Business Development Manager(网络品线 KPI),leads-only·待 opt-in(LinkedIn/谱面带核));Jorge Matos(Gestor de Produto and Stock(产品&库存=件链口),leads-only·待 opt-in(LinkedIn/谱面带核));José Neves(Diretor Comercial / GM Marketing(商务总监),leads-only·待 opt-in(LinkedIn/谱面带核))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 20 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Reis 双 CEO 位+Pereira 网络 PM(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | DATABOX 葡大盘分销（16 年 Dell Top）：经销商货架窄口二轨（$180 锚点一致）；体量错位注 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：双 CEO 族谱+网络品线 PM 具名
- **W**：大分销谱
- **O**：Reis 双驾+Pereira 网络 PM 位
- **T**：一线链竞谱

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Exmos. Sres.,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
