# Dresdner ProSoft GmbH

> **评级 A**　|　德国 · Dresden　|　档案编号 `A-149`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-149
rating: A
country: 德国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；人工指定
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — ProSoft 德累斯顿：网络方案定制文化 value 二线（$180 锚点一致）；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Dresdner ProSoft GmbH（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 德国 / Dresden | 事实 |
| 网站 | https://www.dresdner-prosoft.com | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Dresdner ProSoft GmbH:Dresdner ProSoft GmbH(德国 Dresden,Zellescher Weg 3;**HR B 1104 AG Dresden;USt DE 140125400;1990 创 36 年**;11-50 人;谱型=Dresden 城区 IT 系统房(VERTIV 伙伴：USV/机柜/机房件;Datacenter+网络方案;同系 ProSoft Krippner GmbH(Krippner/Wohlfeld GF 独立屋）=姊妹谱)
- 【推断】R66 第 14 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电
  - PoE 接入供电：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@prosoft-dresden.com
  - 状态：既有/公开
- **电话**：—
- 来源等级：official（R41–R48 联系方式台账口径）
- **原始联系字段**：info@prosoft-dresden.com [Publicly listed; delivery not tested]; https://www.dresdner-prosoft.com
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Uwe Mees**(Geschäftsführer(双 GF;uwe.mees@))— 官网 Impressum+DS-GVO 页 双源 〔已有(公司官方公开件/登记册自曝);源:https://www.dresdner-prosoft.com/impressum/〕
  - **Frank Kwasny**(Geschäftsführer(双 GF;geschäftsführender Gesellschafter))— 官网 Impressum+XING+prosoft-krippner Standorte 〔已有(公司官方公开件/登记册自曝);源:https://www.dresdner-prosoft.com/impressum/〕
  - **Michael Hentschel**(Externer Datenschutzbeauftragter (TÜV) + IT-Consultant/Projektmanager)— XING+官网 DS 页 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://www.dresdner-prosoft.com/datenschutzerklaerung/〕
  - **Sarah Lange**(Marketing)— XING 员工谱 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://de.linkedin.com/company/dresdner-prosoft-gmbh〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Uwe Mees | Geschäftsführer(双 GF;uwe.mees@) | 官网 Impressum+DS-GVO 页 双源 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.dresdner-prosoft.com/impressum/ |
| Frank Kwasny | Geschäftsführer(双 GF;geschäftsführender Gesellschafter) | 官网 Impressum+XING+prosoft-krippner Standorte | official-self-published·谱/leads-only(直发需 opt-in) | https://www.dresdner-prosoft.com/impressum/ |
| Michael Hentschel | Externer Datenschutzbeauftragter (TÜV) + IT-Consultant/Projektmanager | XING+官网 DS 页 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://www.dresdner-prosoft.com/datenschutzerklaerung/ |
| Sarah Lange | Marketing | XING 员工谱 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://de.linkedin.com/company/dresdner-prosoft-gmbh |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（接入层第二选项）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：成本敏感客户层：24 口 PoE++ 同规格成本对照——定位第二选项而不是替位。
- **要问的问题**：预算紧的客户项目里接入层有没有第二选项？对照发你。
- **随附证明**：规格对照 + 单端口测算 + 报价（德文）。

### 第 2 次跟进 · 工业级非管理 PoE（车间/库房点位）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：制造类客户的车间/库房：宽温 DIN PoE。
- **要问的问题**：车间点位用什么交换？
- **随附证明**：宽温报告 + DIN 图 + 备件包价（德文）。

### 第 3 次跟进 · 管理型 PoE（合规分段参考件）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：贴他的 DSB/安全交付：管理型（VLAN/ERPS/ACL）分段参考件+配置基线样例。
- **要问的问题**：合规改造的分段参考件要不要进方案库？
- **随附证明**：VLAN/ERPS/ACL 模板 + 基线样例 + 样机（德文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第8批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：德累斯顿系统屋：服务器/定制机/网络全链+安全+外聘 DSB 服务，Allied Resell（CSV 记录；官网网络页挂 Cisco 图——主栈有 Cisco 倾向）。
- **产品线与在售品牌**：定制服务器/工作站、无线网络与 LAN/WAN 集成、F-Secure 安全栈、DSGVO 外聘 DSB。
- **目标行业与场景**：德累斯顿地区中小企业办公网/机房与安全合规改造。
- **团队与规模**：区域系统屋（挂靠 ProSoft Krippner 关联站，CSV 记录）。
- **决策链与对接人**：info@prosoft-dresden.com（CSV 9-27：关联企业站联系页明确指向+Xing 互证）。
- **技术与认证**：Allied Resell（CSV 记录）；F-Secure 伙伴（官网）。
- **采购与供应链信号**：办公网/机房改造单带接入层；DSB 生意=合规改造潮里他要给客户“分段+可审计”的方案件。
- **近期动态与线索**：站点 2023 版式稳态运营。
- **与我方契合点**：Cisco 旁位：接入层与管理型的成本对照件；合规语境下分段模板正好贴他的 DSB/安全话术。
- **风险与注意**：Cisco 主栈面前别替位：求「成本敏感客户层第二选项」模板话术；德文资料。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网板块：服务器（HPE 图）+定制机、网络方案（Cisco 图）——「无线局域网、LAN/WAN 集成、基础设施与组件、规划实施安装」全链。
  > Netzwerklösungen — großen Erfahrungsschatz und hohe Kompetenzen in den Bereichen drahtlose, lokale Netzwerke, LAN/WAN-Netzwerkintegration, Infrastruktur und Komponenten, Planung sowie Implementierung und Installation von Netzwerken
  > 来源：https://www.dresdner-prosoft.com/
- **【产品线与在售品牌】**安全线主打 F-Secure 代理；「硬软方案一体」的多厂伙伴口径。
  > IT-Security — Wir sind Partner verschiedener Hersteller, welche sowohl hard- als auch softwarebasierte Lösungen anbieten. Somit können wir Ihnen eine vollständige und kompromisslose Sicherheit schaffen（页图：F-Secure Freedome）
  > 来源：https://www.dresdner-prosoft.com/
- **【决策链与对接人】**官网专列外部数据保护官业务——具名 Michael Hentschel 出任客户的外聘 DSB（DSGVO 咨询是他的服务产品之一）。
  > Externer Datenschutz — Für unseren externen Datenschutzbeauftragten, Michael Hentschel, steht der Datenschutz in Ihrem Unternehmen an erster Stelle, deswegen berät er Sie allumfassend zu den Themen Datenschutz und DSGVO.
  > 来源：https://www.dresdner-prosoft.com/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第18波30户.json`；价格均为 EXW 快照。

- **①背景再核**：Dresdner ProSoft GmbH(德国 Dresden,Zellescher Weg 3;**HR B 1104 AG Dresden;USt DE 140125400;1990 创 36 年**;11-50 人;谱型=Dresden 城区 IT 系统房(VERTIV 伙伴：USV/机柜/机房件;Datacenter+网络方案;同系 ProSoft Krippner GmbH(Krippner/Wohlfeld GF 独立屋）=姊妹谱)
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Uwe Mees(Geschäftsführer(双 GF;uwe.mees@),official-self-published·谱/leads-only(直发需 opt-in));Frank Kwasny(Geschäftsführer(双 GF;geschäftsführender Gesellschafter),official-self-published·谱/leads-only(直发需 opt-in));Michael Hentschel(Externer Datenschutzbeauftragter (TÜV) + IT-Consultant/Projektmanager,leads-only·待 opt-in(LinkedIn/谱面带核));Sarah Lange(Marketing,leads-only·待 opt-in(LinkedIn/谱面带核))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：36 年谱+VERTIV 机件

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Geschäftsführer: Uwe Mees, Frank Kwasny;HR B 1104 Dresden;USt DE 140125400;Zellescher Weg 3, 01069 Dresden(官网 Impressum)
  > Geschäftsführer: Uwe Mees, Frank Kwasny;HR B 1104 Dresden;USt DE 140125400;Zellescher Weg 3, 01069 Dresden(官网 Impressum)
  > 来源：https://www.dresdner-prosoft.com/impressum/
- **【团队与规模】**Michael Hentschel: Externer DSB (TÜV)/IT-Consultant;Sarah Lange Marketing;gegründet 1990;VERTIV Partner;ProSoft Krippner 同系谱(Standorte 件)
  > Michael Hentschel: Externer DSB (TÜV)/IT-Consultant;Sarah Lange Marketing;gegründet 1990;VERTIV Partner;ProSoft Krippner 同系谱(Standorte 件)
  > 来源：https://www.dresdner-prosoft.com/datenschutzerklaerung/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Dresdner ProSoft GmbH(德国 Dresden,Zellescher Weg 3;**HR B 1104 AG Dresden;USt DE 140125400;1990 创 36 年**;11-50 人;谱型=Dresden 城区 IT 系统房(VERTIV 伙伴：USV/机柜/机房件;Datacenter+网络方案;同系 ProSoft Krippner GmbH(Krippner/Wohlfeld GF 独立屋）=姊妹谱)
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：德国 Dresden 36 年系统房(VERTIV 伙伴)
- **团队与规模**：11-50 人;1990 创
- **决策链与对接人**：**Uwe Mees(Geschäftsführer(双 GF;uwe.mees@),official-self-published·谱/leads-only(直发需 opt-in));Frank Kwasny(Geschäftsführer(双 GF;geschäftsführender Gesellschafter),official-self-published·谱/leads-only(直发需 opt-in));Michael Hentschel(Externer Datenschutzbeauftragter (TÜV) + IT-Consultant/Projektmanager,leads-only·待 opt-in(LinkedIn/谱面带核));Sarah Lange(Marketing,leads-only·待 opt-in(LinkedIn/谱面带核))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 14 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Mees/Kwasny 双 GF(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | ProSoft 德累斯顿：网络方案定制文化 value 二线（$180 锚点一致） |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：36 年谱+VERTIV 机件
- **W**：小实体谱
- **O**：双 GF 直达位
- **T**：一线链竞谱

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Guten Tag Herr Mees,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
