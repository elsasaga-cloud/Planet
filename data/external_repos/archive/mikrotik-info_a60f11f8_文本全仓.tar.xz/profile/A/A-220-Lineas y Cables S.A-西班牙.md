# Lineas y Cables S.A.

> **评级 A**　|　西班牙 · Madrid　|　档案编号 `A-220`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-220
rating: A
country: 西班牙
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；信息待人工补齐（见备注）
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — Lineas y Cables 西班牙集团：私营电信工程随单（$180 锚点一致）；铁路/能源/军工三重守界+Allied 实版；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Lineas y Cables S.A.（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 西班牙 / Madrid | 事实 |
| 网站 | https://www.grupolineasycables.com | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】波 R67 批2·A-220:西谱: **Líneas y Cables S.A. 深挖(LI 公章 771 粉+AOTEC 展会线+Defensa 带=军守界注)**:S.A. 1978 创(**48 年司史,LI 自报**),Pozuelo de Alarcón(Madrid)Calle Virgilio 19 Ciudad de la Imagen 28223;**51-200 员工 Publikt(私融)SA**;主营=「Telecomunicaciones, Seguridad y Defensa」+工程系统(R&D/distribution/installation:FTTH 光缆/radio/WiFi/光纤电缆/能源/暖通/安防/PCI/水务燃气/IOT/**Defensa 军带**);**KP 三谱:Reyes Estévez(Consejera Delegada=执行理事 P0)+Eduardo Briales(Director Calidad 质量总监)+Patricia Ruiz de León Frade(Técnico calidad/medio ambiente/PRL)**;**展会线=AOTEC XVII 2024 官方参展(LYC 集团名义)+Partner 谱:Commscope/Allied Telesis/Check Point/RNS/Motorola/LBE(贸易项列明——Defensa 场景军火类绝口)**;案例线=Topas Salamanca 监狱 interphonía IP(光纤+结构缆+IP系统);产品热词=Cable 768 FO/GPON→XGS-PON 迁移/UDS Enterprise。**合规守界:Defensa 标签在谱=任何商机仅用民用商用场景词,零军火/武器/监控压制语义**。
- 【推断】R67 推土机深挖 批2 具名 KP 金谱(LI+AOTEC 双源+Defensa 守界)
- 【假设】STC-424XGGPM-280W($165 USD EXW (2026-10-08, 15天有效))Estévez 执行理位/ Briales 质量门引路(民用商用限定)

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电
  - PoE 接入供电：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：lyc@lineasycables.com
  - 状态：待核·未验证投递（不进群发）
- **电话**：—
- 来源等级：official（R41–R48 联系方式台账口径）
- **原始联系字段**：lyc@lineasycables.com（官网正文公开；未验证投递）；原入口：见 alliedtelesis.com 伙伴页
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Reyes Estévez**(Consejera Delegada(执行理事 LI 自报);Defensa 带=邮件语义民用商用限;集团决策口 P0)— restevez@grupolineasycables.com(推断,送完核)/LI DM 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://es.linkedin.com/company/lineas-y-cables-s-a-〕
  - **Eduardo Briales**(Director Calidad(质量总监 LI 自报);QMS 带;项目门识)— ebriales@grupolineasycables.com(推断) 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://es.linkedin.com/company/lineas-y-cables-s-a-〕
  - **Patricia Ruiz de León Frade**(Técnico calidad/medio ambiente/PRL(质量环安职防 LI 自报))— pruiz@grupolineasycables.com(推断) 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://es.linkedin.com/company/lineas-y-cables-s-a-〕
  - **Alfonso Estévez Quintana**(Presidente(2022-07 起;二代接班谱))— BORME/datoscif/einforma 三源登记件 〔已有(公司官方公开件/登记册自曝);源:https://www.datoscif.es/empresa/lineas-y-cables-sa〕
  - **Reyes-Carlota Estévez Santiago**(Vicepresidenta + Consejero Delegado 双任(2026-06 BORME 谱))— datoscif/BORME 件 〔已有(公司官方公开件/登记册自曝);源:https://www.datoscif.es/empresa/lineas-y-cables-sa〕
  - **Norberto Abascal Carmona**(Consejero(理事))— BORME/einforma 件 〔已有(公司官方公开件/登记册自曝);源:https://www.einforma.com/informacion-empresa/lineas-cables〕
  - **Pedro Piñar de Jesús**(Secretario(秘书处))— BORME/datoscif 件 〔已有(公司官方公开件/登记册自曝);源:https://www.datoscif.es/empresa/lineas-y-cables-sa〕
  - **Julio Peñas Artero**(AESMIDE 会卡联络(协会谱))— aesmide.es 会卡 〔已有(公司官方公开件/登记册自曝);源:https://aesmide.es/asociado/lineas-y-cables-sa/〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Reyes Estévez | Consejera Delegada(执行理事 LI 自报);Defensa 带=邮件语义民用商用限;集团决策口 P0 | restevez@grupolineasycables.com(推断,送完核)/LI DM | LI 公章 O 级/邮箱推断 G 级 | https://es.linkedin.com/company/lineas-y-cables-s-a- |
| Eduardo Briales | Director Calidad(质量总监 LI 自报);QMS 带;项目门识 | ebriales@grupolineasycables.com(推断) | LI 公章 O 级/邮箱推断 G 级 | https://es.linkedin.com/company/lineas-y-cables-s-a- |
| Patricia Ruiz de León Frade | Técnico calidad/medio ambiente/PRL(质量环安职防 LI 自报) | pruiz@grupolineasycables.com(推断) | LI 公章 O 级/邮箱推断 G 级 | https://es.linkedin.com/company/lineas-y-cables-s-a- |
| Alfonso Estévez Quintana | Presidente(2022-07 起;二代接班谱) | BORME/datoscif/einforma 三源登记件 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.datoscif.es/empresa/lineas-y-cables-sa |
| Reyes-Carlota Estévez Santiago | Vicepresidenta + Consejero Delegado 双任(2026-06 BORME 谱) | datoscif/BORME 件 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.datoscif.es/empresa/lineas-y-cables-sa |
| Norberto Abascal Carmona | Consejero(理事) | BORME/einforma 件 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.einforma.com/informacion-empresa/lineas-cables |
| Pedro Piñar de Jesús | Secretario(秘书处) | BORME/datoscif 件 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.datoscif.es/empresa/lineas-y-cables-sa |
| Julio Peñas Artero | AESMIDE 会卡联络(协会谱) | aesmide.es 会卡 | official-self-published·谱/leads-only(直发需 opt-in) | https://aesmide.es/asociado/lineas-y-cables-sa/ |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 类目空缺提案（铁路/能源户外段工业宽温 PoE）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：Allied 货架无工业宽温真品：铁路沿线/能源站点/户外机柜的宽温 DIN PoE+SFP 长距——类目空档合作提案。
- **要问的问题**：户外/沿线点位的工业宽温件这个类目你们怎么解？（西语材料）
- **随附证明**：类目空档说明 + 宽温报告 + SFP 方案 + 分销价目（西）。

### 第 2 次跟进 · 管理型 PoE（ERPS 线性环：铁路/能源拓扑）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：铁路/能源线性拓扑的 ERPS 环收敛实测+L3——项目第二来源技术档。
- **要问的问题**：线性拓扑的 ERPS 环件要不要当第二来源测？
- **随附证明**：ERPS 收敛实测 + 拓扑方案（西）。

### 第 3 次跟进 · 24 口 CCTV/PoE（站点汇聚高段位补位）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：站点汇聚的 24 口 PoE++ 高段位补位；商业段第二来源价位。
- **要问的问题**：站点汇聚的高段位件有没有第二来源需求？
- **随附证明**：规格对照 + 第二来源价目（西）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第11批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：马德里波苏埃洛 40 年集团级集成商：电信/铁路/能源战略行业项目，Allied **Elite+Platinum 双深绑定**（CSV+官网 logo 互证）。⚠️防务伙伴语境（Mildef/Bertin）划线。
- **产品线与在售品牌**：电信/铁路/能源基件集成+Allied/Dell/Commscope/Prysmian 全线分销式集成。
- **目标行业与场景**：商业电信与铁路民营段、能源商业客户（谨慎）；⚠️防务关联段不碰。
- **团队与规模**：40 年中型集团。
- **决策链与对接人**：lyc@lineasycables.com（CSV 9-27：联系页公开）。
- **技术与认证**：Allied Integrate Elite+Platinum（CSV+官网）；第三厂集成多牌资质。
- **采购与供应链信号**：⚠️Elite/Platinum 深绑不可谈替位：现实空间=①Allied 无工业宽温真品线的类目空档（铁路沿线/户外/能源站点宽温 DIN PoE+ERPS 环）②项目第二来源 ③缆（Prysmian/NKT 关系）旁供电件套装。
- **近期动态与线索**：伙伴墙 2025-2026 持续扩（Racks&Networking/Virtual Cable 新牌）。
- **与我方契合点**：铁路/能源户外段的宽温工业 PoE+ERPS 线性环——他最痛的场景段恰是 Allied 无真品的空档。
- **风险与注意**：全信「类目空档/第二来源」不谈替位；防务关联（Mildef/Bertin）项目不涉；西语材料。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网：Grupo Líneas y Cables——40+ 年战略行业技术方案：电信/**铁路（ferroviario）**/能源等；第三方制造产品集成是其模式。
  > GRUPO LÍNEAS Y CABLES — Cuenta con más de 40 años de experiencia en la provisión de soluciones, productos y servicios tecnológicos en sectores estratégicos… telecomunicaciones, el sector ferroviario o la energía ‖ Trabajamos con partners referentes mundiales… e integramos soluciones fabricadas por terceros.
  > 来源：https://www.grupolineasycables.com/
- **【技术与认证】**伙伴墙亮牌：**Allied Platinum（Allied_Platinum logo 在列）**+Dell Platinum+Commscope/Prysmian/NKT/Clavister/SonicWall——核心堆头就是 Allied 旗舰位。
  > （伙伴墙）Dell Platinum（logo）· Allied Platinum（Allied_Platinum_250x150 logo）· Commscope · Prysmian · NKT · Check Point · SonicWall · Clavister · Elcon Megarad · Polomarconi · Grandstream · Fluke Networks
  > 来源：https://www.grupolineasycables.com/
- **【风险与注意】**伙伴墙同时列 **Mildef（军用计算机）与 Bertin Technologies（国防技术集团）**——⚠️防务供应语境浓厚，按防务关联段划线处理（CSV：Integrate Elite 级）。
  > （伙伴墙）Mildef · Bertin（Bertin Technologies）——防务技术供应商在册（官网）；（CSV 记录）伙伴等级：Integrate Elite, Resell
  > 来源：https://www.grupolineasycables.com/
- **【决策链与对接人】**CSV 9-27：官网联系页公开 lyc@lineasycables.com 与 +34 915 121 320、Calle Virgilio 19 Pozuelo de Alarcón——剔除地图噪声（CSV 原话）。
  > 官网联系页正文邮箱与+34 915121320、Calle Virgilio 19 Pozuelo de Alarcón Madrid 28223匹配；不用地图噪声当邮箱（CSV 2026-09-27 记录）
  > 来源：https://www.grupolineasycables.com/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R67_R56_推土机批2.json`；价格均为 EXW 快照。

- **①背景再核**：1978 S.A. 48 年;51-200;**Defensa 带守界(民用商用词必压)**
- **②芯片/型号**：GPON→XGS-PON 迁项;24 口 PoE(424XGGPM 280W)民用商用载线
- **③KP 深挖**：Estévez Consejera Delegada+Briales 质量+Ruiz QMS/PRL 三谱 O/G 级;AOTEC XVII 展会线
- **④Saga 对标**：民用商用光纤/GPON 迁项目 → 24 口 PoE 载线;Partner 谱 5 大
- **⑤在乎与偏好**：Defensa 带=民用商用句必压;AOTEC 展会送样;LI 771 粉

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Reyes Estevez: Consejera Delegada en Líneas y Cables S.A.;Eduardo Briales: Director Calidad;Patricia Ruiz de León Frade: Técnico QMS/medio ambiente/PRL
  > Reyes Estevez: Consejera Delegada en Líneas y Cables S.A.;Eduardo Briales: Director Calidad;Patricia Ruiz de León Frade: Técnico QMS/medio ambiente/PRL
  > 来源：https://es.linkedin.com/company/lineas-y-cables-s-a-
- **【公司谱】**Líneas y Cables S.A. | 771 seguidores;Fundación 1978;Pozuelo de Alarcón, Madrid;51-200 empleados;tipo privada;Especialidades: Networking, FTTH, Redes radio, WiFi, fiber cables, Defensa…
  > Líneas y Cables S.A. | 771 seguidores;Fundación 1978;Pozuelo de Alarcón, Madrid;51-200 empleados;tipo privada;Especialidades: Networking, FTTH, Redes radio, WiFi, fiber cables, Defensa…
  > 来源：https://es.linkedin.com/company/lineas-y-cables-s-a-
- **【展会线】**LYC va a realizar presencia en XVII Feria Tecnológica AOTEC…Expositor Oficial…Partners Commscope, Allied Telesis, Check Point, RNS, Motorola…
  > LYC va a realizar presencia en XVII Feria Tecnológica AOTEC…Expositor Oficial…Partners Commscope, Allied Telesis, Check Point, RNS, Motorola…
  > 来源：https://www.grupolineasycables.com/index.php/component/content/article/133-aotec-2?catid=57&Itemid=797
- **【项目案例】**Instalación de sistema de interfonía IP para centro penitenciario Topas (Salamanca) — Dpto Sistemas LyC, 03 Noviembre 2021
  > Instalación de sistema de interfonía IP para centro penitenciario Topas (Salamanca) — Dpto Sistemas LyC, 03 Noviembre 2021
  > 来源：https://www.grupolineasycables.com/index.php/component/content/article/123-instalacion-de-sistema-de-interfonia-ip-para-centro-penitenciario?catid=51&Itemid=797

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Líneas y Cables S.A.(1978,48 年,51-200):通讯工程集商+Defensa 带(军守界注)
- **产品线与在售品牌**：FTTH 光纤/radio/WiFi/GPON→XGS-PON/UDS;Partners Commscope/Allied Telesis/Check Point/RNS/Motorola
- **目标行业与场景**：光纤工程/网络载线/民用商用+「Defensa」标签(零军货语义=仅载线合规线)
- **团队与规模**：51-200;质量 LyC Dpto Sistemas 谱
- **决策链与对接人**：Reyes Estévez(Consejera Delegada)+Eduardo Briales(质量)+Patricia Ruiz de León Frade(QMS/PRL)
- **技术与认证**：AOTEC XVII 官方参展 2024;ISO 质量体;GPON→XGS-PON 迁专线
- **采购与供应链信号**：Partner 谱 Commscope/Allied Telesis/Check Point/RNS/Motorola 载销;工程项大一
- **近期动态与线索**：AOTEC 2024 展;Topas Salamanca 监狱 interfonía IP 项目;UDS Enterprise 新产品
- **与我方契合点**：Estévez 执行理位/ Briales 质量门 → 24口 PoE 民用商用普通项引路(GPON 迁项载线路线)
- **风险与注意**：**Defensa 标签在谱=绝口军火/武器/监控压制;民用商用场景词必压**;LI 771 粉;私融 S.A.

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Lineas y Cables 西班牙集团：私营电信工程随单（$180 锚点一致）；铁路/能源/军工三重守界+Allied 实版 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：48 年+Partner 谱 5 大
- **W**：Defensa 带规
- **O**：GPON→XGS 迁风
- **T**：守界压次

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] MikroTik 谱位在售线需官网核
  - [ ] Estévez 直邮推档
  - [ ] Defensa 场景词排检

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Reyes Estévez Team,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $165 USD EXW (2026-10-08, 15 days valid) — a value unit for civilian / commercial FTTH and GPON-to-XGS-PON migration deployments. Datasheet + CE pack on request.

Best regards
Saga / SmartByte ODM
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
