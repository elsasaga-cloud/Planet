# Celenet

> **评级 A**　|　西班牙 · Beniel (Murcia)　|　档案编号 `A-066`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-066
rating: A
country: 西班牙
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: true, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（交换认证 MTCSWE、组播/IPTV），且有具体人直联
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — Celenet 西班牙区域运营商+企业线：企业 WiFi/安防接入层随单，节点小盒二轨（$180 锚点一致）；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Celenet（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 西班牙 / Beniel (Murcia) | 事实 |
| 网站 | celenet.es | 事实 |
| 类型 | 集成商/顾问（MikroTik 认证） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | MikroTik 认证顾问 10 证全拿 / 9 证（含 MTCSWE） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Celenet:CeleNet(西班牙安达卢西亚;法务体锁定=**CELENETWORKS SL**(RIPE NCC 西班牙 LIR 会员名录件,2025-10 在列);全国电信运营商(operador de telecomunicaciones nacional):网络设计咨询/知识通信方案/企业协助/数字化转型促通;celenet.es;注:celenet.wordpress.com=VFMs 异名噪声已排
- 【推断】R66 第 12 波守档(身份锁定)
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：MikroTik 认证顾问 10 证全拿 / 9 证（含 MTCSWE））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、万兆上行/骨干、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - 万兆上行/骨干：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：ccardenas@celenet.es
  - 状态：既有/公开
- **电话**：+34 622 330 440、+34 649 395 961
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：Carlos Cardenas Cebrian +34 622 330 440 / ccardenas@celenet.es；Javier Prieto Vera +34 649 395 961 / jprietove@celenet.es
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。

## 关键人（KP）与触达通道

- 关键人未定位：首封信件以 info/通用邮箱开场并向其索要正确联系人。

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（企业项目接入层）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：他企业线做 VPN/安全/多站点：接入层 24 口 PoE++ + 4×10G 上行作为交付标配，企业客户一次到位。
- **要问的问题**：企业项目的接入交换机现在标准化在什么型号？
- **随附证明**：规格对照 + 交期/RMA 政策说明（英文）。

### 第 2 次跟进 · 工业级非管理 PoE（FTTH 节点/外线箱）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：FTTH 分光节点与室外箱体：宽温 DIN 免配置 + 2.5G SFP 上行，给建设期的外线段补件。
- **要问的问题**：外线节点箱里的供电与交换现在用什么？
- **随附证明**：宽温报告 + DIN 图 + 节点备件包价。

### 第 3 次跟进 · 管理型 PoE（接入层模板+IPTV 组播）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：他的组播/高可用专长：管理型 VLAN 分段 + IGMP 优化 + ERPS 环，做接入层统一模板，企业项目批量复制。
- **要问的问题**：企业接入层有没有做 ERPS 或组播优化的需求清单？
- **随附证明**：VLAN/IGMP/ERPS 模板 + 收敛实测（英文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第4批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：穆尔西亚本地电信运营商（原 MikroTik 顾问团队升级）：FTTH 居民宽带 + 企业专线/VPN/安全 + 面向其他运营商的连接服务。
- **产品线与在售品牌**：自有接入网（FTTH）与移动转售套餐 + 企业网解决方案；设备自用并随企业项目外配。
- **目标行业与场景**：穆尔西亚本地家庭/企业、园区多站点企业、运营商间批发链路；FTTH 分光节点与企业机房的接入层。
- **团队与规模**：组织化运营商班底（客服/工程），2 位 9–10 证顾问（Carlos Cárdenas + Javier）坐镇技术。
- **决策链与对接人**：工程侧 Carlos Cardenas Cebrian（+34 622 330 440 / ccardenas@celenet.es）；商务走 856 005 555 / info@celenet.es。
- **技术与认证**：双顾问 9–10 证含 MTCSWE/组播/BGP/MPLS（CSV 名录记录）——骨干与接入都懂。
- **采购与供应链信号**：运营商级持续采购：FTTH 节点、企业项目接入层、机房配套——量级比纯顾问高一个台阶。
- **近期动态与线索**：品牌化升级完成（新站 celenet-conecta 主题），正在扩张覆盖与企业线——网络建设期=设备评估期。
- **与我方契合点**：FTTH 节点与机房接入=24 口/10G；企业项目交付=管理型统一模板；组播专长=IPTV 方案的 IGMP 优化可以聊透。
- **风险与注意**：运营商谈供应商要稳定供货与 RMA 承诺：首轮就带交期/RMA 政策，不只报价格。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网抬头已明确「电信运营商」身份——公司从集成商扩展成了持牌运营商。
  > Operador de telecomunicaciones · Fibra, móvil y redes para llegar más lejos. · Conectividad para hogares, empresas y operadores.
  > 来源：https://celenet.es/
- **【产品线与在售品牌】**居民线卖 FTTH+移动套餐；企业线卖光纤、专线备份、VPN 与网络安全——另有「operadores」批发方向。
  > Fibra óptica FTTH · Tarifas móviles · Fibra y móvil en un mismo paquete · Fibra e internet para empresas · Enlaces dedicados y respaldo · VPN, redes y ciberseguridad.
  > 来源：https://celenet.es/
- **【团队与规模】**官网统一触点：856 005 555 / info@celenet.es，按区覆盖查询制销售，组织化程度比以往个体顾问时期高。
  > 856 005 555 · info@celenet.es · Cobertura real — Indícanos dónde necesitas el servicio y confirmaremos las opciones disponibles.
  > 来源：https://celenet.es/
- **【技术与认证】**公司内 2 位顾问均 9–10 证（含 MTCSWE）；Carlos 专长含组播 Multicast 与高可用/流量工程（来源性质：CSV 既有记录）。
  > 公司内 2 位顾问，均 9–10 证。Carlos：WISP、OSPF/BGP/MPLS、IPv6 规划、组播 Multicast、高可用…（CSV 备注）
  > 来源：https://mikrotik.com/consultants

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第12波.json`；价格均为 EXW 快照。

- **①背景再核**：CeleNet(西班牙安达卢西亚;法务体锁定=**CELENETWORKS SL**(RIPE NCC 西班牙 LIR 会员名录件,2025-10 在列);全国电信运营商(operador de telecomunicaciones nacional):网络设计咨询/知识通信方案/企业协助/数字化转型促通;celenet.es;注:celenet.wordpress.com=VFMs 异名噪声已排
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**守档准由;R66 波次二点名**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：国家级运营商+RIPE LIR 谱位

### R55 证据摘录（全部保留 · 含数量）

- **【业务定位】**CELENETWORKS SL — Local Internet Registries offering services in Spain(RIPE NCC 会员名录)
  > CELENETWORKS SL — Local Internet Registries offering services in Spain(RIPE NCC 会员名录)
  > 来源：https://www.ripe.net/membership/member-support/list-of-members/es/
- **【业务定位】**operador de telecomunicaciones andalucia;diseño y consultoría de redes;operador de telecomunicaciones nacional;transformación digital
  > operador de telecomunicaciones andalucia;diseño y consultoría de redes;operador de telecomunicaciones nacional;transformación digital
  > 来源：https://celenet.es/
- **【近期动态与线索】**2026-10-08 R66 12 波:身份=CELENETWORKS SL 锁定;人名谱(首页 Carlos Álvarez=客户证言非员工)未破→守档;波次二=西班牙 CNMC 运营商名录+Registro Mercantil 反查
  > 2026-10-08 R66 12 波:身份=CELENETWORKS SL 锁定;人名谱(首页 Carlos Álvarez=客户证言非员工)未破→守档;波次二=西班牙 CNMC 运营商名录+Registro Mercantil 反查
  > 来源：https://celenet.es/sobre-nosotros/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：CeleNet(西班牙安达卢西亚;法务体锁定=**CELENETWORKS SL**(RIPE NCC 西班牙 LIR 会员名录件,2025-10 在列);全国电信运营商(operador de telecomunicaciones nacional):网络设计咨询/知识通信方案/企业协助/数字化转型促通;celenet.es;注:celenet.wordpress.com=VFMs 异名噪声已排
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：西班牙安达卢西亚电信运营商(RIPE LIR)
- **团队与规模**：(CNMC/Mercantil 谱波次二补)
- **决策链与对接人**：**守档准由;R66 波次二点名**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 12 波守档
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：守档:身份锁定;R66 波次二点名(CNMC/Mercantil 反查)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Celenet 西班牙区域运营商+企业线：企业 WiFi/安防接入层随单，节点小盒二轨（$180 锚点一致） |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：国家级运营商+RIPE LIR 谱位
- **W**：人名谱零命中
- **O**：CNMC 运营名录反查可破
- **T**：运营商采购链层

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ❓ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text


We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
