# Watkins Security

> **评级 A**　|　美国 · Johnstown, PA　|　档案编号 `A-093`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-093
rating: A
country: 美国
biz_org: 个体顾问（无官网）
business_model: 顾问项目制
decision_speed: fast
price_sensitivity: high
volume_potential: 1  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：个体顾问（无官网）；顾问项目制
- **商业模式**：顾问项目制
- **为什么值得跟**：有明确交换/供电需求（交换专长、PoE/监控/门禁），三星重点
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — Watkins 60 年安防：场馆高密摄像柜 PoE（$180 锚点一致）；DHS 联邦红线不触；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Watkins Security（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 美国 / Johnstown, PA | 事实 |
| 网站 | —（无公开站点） | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 个体顾问（无官网） | 【推断】 |
| 商业模式 | 顾问项目制 | 【推断】 |
| 团队规模 | 一人/微型 | 【推断】 |
| 决策链 | 短（本人即决策） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Watkins Security:Watkins Security, LLC(美国 Johnstown, Pennsylvania,1203 Barnett Street, PA 15905;+1 814 288 9420;watkins-security.com;**2009 创(17 年)**;21-50 人(prospeo);~$2.4M;谱型=安防+数据网络设计安装服务商(IP 视频监控/门禁/网络基础设施/火灾检测/AI 视频分析/无线/光纤/生物识别/布线;ISO 质量体系传承;SIC 738/NAICS 56162);**排噪:Watkins Security Agency Inc(Baltimore MD,Goldie Watkins 护卫公司,thewatkinsgroup.com)=异体已排**
- 【推断】R66 第 12 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@watkins-security.com
  - 状态：既有/公开
- **电话**：—
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：info@watkins-security.com（官网 contact 页；Principal/CEO Christopher Watkins）
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Christopher L. Watkins**(Founder / President & Owner(前 Senior Systems Engineer+Vice President of Operations 高阶谱))— 公司 LinkedIn About 页自署+zoominfo/prospeo 双 Key Contact 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://www.linkedin.com/company/watkins-security-llc〕
  - **Richard Hamilton**(Director, Quality Assurance)— zoominfo 谱 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://www.zoominfo.com/c/watkins-security-llc/358637588〕
  - **Charles Kovalchik**(Security Technician)— zoominfo 谱 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://www.zoominfo.com/c/watkins-security-llc/358637588〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Christopher L. Watkins | Founder / President & Owner(前 Senior Systems Engineer+Vice President of Operations 高阶谱) | 公司 LinkedIn About 页自署+zoominfo/prospeo 双 Key Contact | leads-only·待 opt-in(LinkedIn/谱面带核) | https://www.linkedin.com/company/watkins-security-llc |
| Richard Hamilton | Director, Quality Assurance | zoominfo 谱 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://www.zoominfo.com/c/watkins-security-llc/358637588 |
| Charles Kovalchik | Security Technician | zoominfo 谱 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://www.zoominfo.com/c/watkins-security-llc/358637588 |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（商业项目接入层，限定商业）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：合规先行再报价：开场即说明「仅商业项目适用」+合规声明，再递度假村/园区类 24 口接入层成本测算。
- **要问的问题**：商业项目的接入层现在用什么型号？（附合规声明）
- **随附证明**：合规声明包 + 单路成本测算 + 规格对照（英文）。

### 第 2 次跟进 · 工业级非管理 PoE（室外/周界点位）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：积雪带（宾州西部）室外摄像头点位：宽温 -40 冷启动 DIN PoE，坏机率低的硬卖点。
- **要问的问题**：冬季室外点位坏机多吗？现在用什么型号？
- **随附证明**：宽温/-40 冷启动报告 + 备件包价。

### 第 3 次跟进 · 管理型 PoE（安防网段标准化）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：AI 监控流量大：VLAN 隔离+ERPS+10G 上行给视频骨干让路，模板化复制到多项目。
- **要问的问题**：视频骨干现在千兆还是万兆？有拥塞投诉吗？
- **随附证明**：VLAN/ERPS 模板 + 10G 实测 + 收敛数据。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第5批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：宾州西部家族安防公司（现 CEO Christopher Watkins）：安防/消防/网络一体集成，自建设计-安装-培训闭环。
- **产品线与在售品牌**：AI 视频监控+门禁+消防+网络全套；Allied Telesis Resell 伙伴（CSV 记录）。
- **目标行业与场景**：园区/市政/度假设施/活动安保；历史单含政府与大型赛事。
- **团队与规模**：中小公司、深资历团队（组合 60+ 年经验）；Service & Support 自养。
- **决策链与对接人**：info@watkins-security.com；Principal/CEO Christopher Watkins（CSV 记录）。
- **技术与认证**：Allied Telesis Resell（CSV 记录）；系统工程师班底。
- **采购与供应链信号**：项目制批量；政府/赛事单对供应链合规（TAA/NDAA）要求严格。
- **近期动态与线索**：AI 监控叙事升级中（新包装的服务页），产品线在往「AI 分析」靠。
- **与我方契合点**：商业设施（度假村/园区）视频监控接入层与室外工业件的价差替换。
- **风险与注意**：⚠️ 国土安全部/G20 客户史=产地红线：明确只供商业项目、首次沟通主动讲边界（中国产，不做政府/关键设施单）。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网服务全家福：安防+IP 视频监控+消防探测+门禁+网络+IT 一整套。
  > Providing a Complete Suite of Security, IP Video Surveillance, Fire Detection, Access Control, Networking, and IT Solutions
  > 来源：https://www.watkins-security.com/
- **【产品线与在售品牌】**主打 AI 驱动的监控方案：设计-实施-培训全流程，开放架构可集成视频/门禁/考勤/广播。
  > Securing Your World with AI-Powered Surveillance Solutions · We personally visit your location… conducting a thorough facility tour · The systems that we install are built on open architecture platforms.
  > 来源：https://www.watkins-security.com/
- **【团队与规模】**官网数字：60+ 年组合经验、1000 客户、2M+ 安装产品、3 国、5+ 行业荣誉。
  > 60+ Years of Experience · 1,000 Satisfied Clientele · 2M+ Products Installed · 3 Countries World Wide · 5+ Industry Recognitions
  > 来源：https://www.watkins-security.com/
- **【目标行业与场景】**历史客户墙含美国国土安全部、美网公开赛、G20 匹兹堡峰会、Vail 度假村——⚠️ 涉政府/重大赛事史。
  > Past Clients — Seal of the United States Department of Homeland Security · US Open · G20-Pittsburgh 2009 · Vail（客户 Logo 墙）
  > 来源：https://www.watkins-security.com/

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第12波.json`；价格均为 EXW 快照。

- **①背景再核**：Watkins Security, LLC(美国 Johnstown, Pennsylvania,1203 Barnett Street, PA 15905;+1 814 288 9420;watkins-security.com;**2009 创(17 年)**;21-50 人(prospeo);~$2.4M;谱型=安防+数据网络设计安装服务商(IP 视频监控/门禁/网络基础设施/火灾检测/AI 视频分析/无线/光纤/生物识别/布线;ISO 质量体系传承;SIC 738/NAICS 56162);**排噪:Watkins Security Agency Inc(Baltimore MD,Goldie Watkins 护卫公司,thewatkinsgroup.com)=异体已排**
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Christopher L. Watkins(Founder / President & Owner(前 Senior Systems Engineer+Vice President of Operations 高阶谱),leads-only·待 opt-in(LinkedIn/谱面带核));Richard Hamilton(Director, Quality Assurance,leads-only·待 opt-in(LinkedIn/谱面带核));Charles Kovalchik(Security Technician,leads-only·待 opt-in(LinkedIn/谱面带核))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：网络+安防双轨集成谱

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Mr. Christopher L. Watkins, founder of Watkins Security ... Senior Systems Engineer and Vice President of Operations(公司 LinkedIn About 页);ISO 质量体系传承
  > Mr. Christopher L. Watkins, founder of Watkins Security ... Senior Systems Engineer and Vice President of Operations(公司 LinkedIn About 页);ISO 质量体系传承
  > 来源：https://www.linkedin.com/company/watkins-security-llc
- **【团队与规模】**Christopher Watkins President & Owner;Richard Hamilton Director, Quality Assurance;Charles Kovalchik Security Technician;<$5M;21-50 Employees;$2,395,540 revenue
  > Christopher Watkins President & Owner;Richard Hamilton Director, Quality Assurance;Charles Kovalchik Security Technician;<$5M;21-50 Employees;$2,395,540 revenue
  > 来源：https://www.zoominfo.com/c/watkins-security-llc/358637588
- **【业务定位】**IP Video Surveillance, Access Control, Network Infrastructure, Artificial Intelligence;1203 Barnett Street, Johnstown, PA 15905;founded 2009
  > IP Video Surveillance, Access Control, Network Infrastructure, Artificial Intelligence;1203 Barnett Street, Johnstown, PA 15905;founded 2009
  > 来源：https://prospeo.io/c/watkins-security-revenue

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Watkins Security, LLC(美国 Johnstown, Pennsylvania,1203 Barnett Street, PA 15905;+1 814 288 9420;watkins-security.com;**2009 创(17 年)**;21-50 人(prospeo);~$2.4M;谱型=安防+数据网络设计安装服务商(IP 视频监控/门禁/网络基础设施/火灾检测/AI 视频分析/无线/光纤/生物识别/布线;ISO 质量体系传承;SIC 738/NAICS 56162);**排噪:Watkins Security Agency Inc(Baltimore MD,Goldie Watkins 护卫公司,thewatkinsgroup.com)=异体已排**
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：美国 PA 安防+数据网络设计安装商
- **团队与规模**：21-50 人;$2.4M;2009 创
- **决策链与对接人**：**Christopher L. Watkins(Founder / President & Owner(前 Senior Systems Engineer+Vice President of Operations 高阶谱),leads-only·待 opt-in(LinkedIn/谱面带核));Richard Hamilton(Director, Quality Assurance,leads-only·待 opt-in(LinkedIn/谱面带核));Charles Kovalchik(Security Technician,leads-only·待 opt-in(LinkedIn/谱面带核))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 12 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Owner 一人谱(opt-in 律);info@watkins-security.com CSV 已档

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Watkins 60 年安防：场馆高密摄像柜 PoE（$180 锚点一致）；DHS 联邦红线不触 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：网络+安防双轨集成谱
- **W**：小实体(决策=Owner 一人)
- **O**：Christopher Watkins 直达位
- **T**：大牌安防件链竞谱

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**本户特别红线/停止条件**

- 一人/个体=单点与节奏风险

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Hi Christopher,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
