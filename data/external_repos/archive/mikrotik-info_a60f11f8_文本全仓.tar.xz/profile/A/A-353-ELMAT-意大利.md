# ELMAT

> **评级 A**　|　意大利 · Padova / Roma　|　档案编号 `A-353`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-353
rating: A
country: 意大利
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: true, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（交换专长），且有具体人直联
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — ELMAT 意大 B2B 分销（Ruijie/Cambium/Teltonika/Axis/Milestone 牌墙+厂训体系）：企业网替补 SKU 缝（$180 锚点一致）；Ruijie 旁前句；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | ELMAT（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 意大利 / Padova / Roma | 事实 |
| 网站 | https://www.elmat.com | 事实 |
| 类型 | 分销（Netonix 授权） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Netonix 授权渠道（WISP 接入层交换机） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】ELMAT:ELMAT S.p.A.(意大利 Padova,Via Uruguay 15, 35127(+Roma 点);**1997 创 29 年;21-30 人;Cabling&Networking 分销(Video/Voice/Cabling/Networking/Energy/AV/Wireless;**Aruba WLAN Enterprise 专谱**;Netonix 谱档)**;**升谱: Michele Scapolo=Amministratore delegato(旧档 Responsabile Commerciale 升;RR 谱)+Andrea Rizzo=Co-CEO(旧档 marketing 升;RR 谱)**;**Pierpaolo Amadori Direttore commerciale(商总=件链 KPI)+Sara Viola Product Management+Maurizio Madeo Responsabile Area**;elmat@elmat.com;选品策展「explorers」+活动/培训谱
- 【推断】R66 第 22 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-08, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Netonix 授权渠道（WISP 接入层交换机））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、万兆上行/骨干、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - 万兆上行/骨干：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@elmat.com
  - 状态：既有/公开
- **电话**：049 7623011
- 来源等级：official-company（R41–R48 联系方式台账口径）
- **原始联系字段**：info@elmat.com（官网联系页；PEC elmat@pec.it）；049 7623011；Elmat spa，Via Uruguay 15, 35127 Padova
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Michele Scapolo**(Amministratore delegato(AD 升谱))— rocketreach 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://rocketreach.co/elmat-spa-profile_b4435394fa04d7bd〕
  - **Andrea Rizzo**(Co-CEO(联席 CEO 升谱))— rocketreach 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://rocketreach.co/elmat-spa-profile_b4435394fa04d7bd〕
  - **Pierpaolo Amadori**(Direttore commerciale(商务总监=件链 KPI))— rocketreach 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://rocketreach.co/elmat-spa-profile_b4435394fa04d7bd〕
  - **Sara Viola**(Product Management(产品经理))— rocketreach 谱面条 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://rocketreach.co/elmat-spa-profile_b4435394fa04d7bd〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Michele Scapolo | Amministratore delegato(AD 升谱) | rocketreach 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://rocketreach.co/elmat-spa-profile_b4435394fa04d7bd |
| Andrea Rizzo | Co-CEO(联席 CEO 升谱) | rocketreach 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://rocketreach.co/elmat-spa-profile_b4435394fa04d7bd |
| Pierpaolo Amadori | Direttore commerciale(商务总监=件链 KPI) | rocketreach 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://rocketreach.co/elmat-spa-profile_b4435394fa04d7bd |
| Sara Viola | Product Management(产品经理) | rocketreach 谱面条 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://rocketreach.co/elmat-spa-profile_b4435394fa04d7bd |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 具名 kp 引路口

- **推什么**：STC-424XGGPM-280W（统一口径=P1 系列，不外溢）
- **切入点**：具名 kp 引路 → 采购/技术硬件分载线
- **要问的问题**：贵司 24 口 PoE 交换机的硬件采购线由哪位同事主责？
- **随附/动作**：规格页

### 第 2 次跟进 · 一页目录卡

- **推什么**：一页目录卡（统一口径=P1 系列，不外溢）
- **切入点**：价值层 PoE 谱链卡
- **要问的问题**：可否入谱链名录？
- **随附/动作**：卡

### 第 3 次跟进 · 留档+LinkedIn 谱

- **推什么**：—（统一口径=P1 系列，不外溢）
- **切入点**：谱链明智途径
- **要问的问题**：—
- **随附/动作**：—


## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第22波50户.json`；价格均为 EXW 快照。

- **①背景再核**：ELMAT S.p.A.(意大利 Padova,Via Uruguay 15, 35127(+Roma 点);**1997 创 29 年;21-30 人;Cabling&Networking 分销(Video/Voice/Cabling/Networking/Energy/AV/Wireless;**Aruba WLAN Enterprise 专谱**;Netonix 谱档)**;**升谱: Michele Scapolo=Amministratore delegato(旧档 Responsabile Commerciale 升;RR 谱)+Andrea Rizzo=Co-CEO(旧档 marketing 升;RR 谱)**;**Pierpaolo Amadori Direttore commerciale(商总=件链 KPI)+Sara Viola Product Management+Maurizio Madeo Responsabile Area**;elmat@elmat.com;选品策展「explorers」+活动/培训谱
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Michele Scapolo(Amministratore delegato(AD 升谱),leads-only·待 opt-in(LinkedIn/谱面带核));Andrea Rizzo(Co-CEO(联席 CEO 升谱),leads-only·待 opt-in(LinkedIn/谱面带核));Pierpaolo Amadori(Direttore commerciale(商务总监=件链 KPI),leads-only·待 opt-in(LinkedIn/谱面带核));Sara Viola(Product Management(产品经理),leads-only·待 opt-in(LinkedIn/谱面带核))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-08, 15天有效))
- **⑤在乎与偏好**：AD+Co-CEO 双升谱+商总 KPI

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**RR 谱: Michele Scapolo Amministratore delegato+Andrea Rizzo Co-Ceo+Pierpaolo Amadori Direttore commerciale+Sara Viola Product Management(TradeManager 旧档: Scapolo=Responsabile Commerciale/Rizzo=marketing=升谱注)
  > RR 谱: Michele Scapolo Amministratore delegato+Andrea Rizzo Co-Ceo+Pierpaolo Amadori Direttore commerciale+Sara Viola Product Management(TradeManager 旧档: Scapolo=Responsabile Commerciale/Rizzo=marketing=升谱注)
  > 来源：https://rocketreach.co/elmat-spa-profile_b4435394fa04d7bd
- **【联系方式与基础画像】**Via Uruguay 15, 35127 Padova;049 7623011;elmat@elmat.com;sul mercato del Cabling&Networking dal 1997;**Aruba 专谱(WLAN Enterprise)**;21-30 dipendenti;wisp/system integrator/installatori 客群(smau/官网/X 件)
  > Via Uruguay 15, 35127 Padova;049 7623011;elmat@elmat.com;sul mercato del Cabling&Networking dal 1997;**Aruba 专谱(WLAN Enterprise)**;21-30 dipendenti;wisp/system integrator/installatori 客群(smau/官网/X 件)
  > 来源：https://www.smau.it/padova/2011/partners/elmat

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：ELMAT S.p.A.(意大利 Padova,Via Uruguay 15, 35127(+Roma 点);**1997 创 29 年;21-30 人;Cabling&Networking 分销(Video/Voice/Cabling/Networking/Energy/AV/Wireless;**Aruba WLAN Enterprise 专谱**;Netonix 谱档)**;**升谱: Michele Scapolo=Amministratore delegato(旧档 Responsabile Commerciale 升;RR 谱)+Andrea Rizzo=Co-CEO(旧档 marketing 升;RR 谱)**;**Pierpaolo Amadori Direttore commerciale(商总=件链 KPI)+Sara Viola Product Management+Maurizio Madeo Responsabile Area**;elmat@elmat.com;选品策展「explorers」+活动/培训谱
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：意帕多瓦 29 年布线网络分销(Aruba 专)
- **团队与规模**：21-30 人;1997 创
- **决策链与对接人**：**Michele Scapolo(Amministratore delegato(AD 升谱),leads-only·待 opt-in(LinkedIn/谱面带核));Andrea Rizzo(Co-CEO(联席 CEO 升谱),leads-only·待 opt-in(LinkedIn/谱面带核));Pierpaolo Amadori(Direttore commerciale(商务总监=件链 KPI),leads-only·待 opt-in(LinkedIn/谱面带核));Sara Viola(Product Management(产品经理),leads-only·待 opt-in(LinkedIn/谱面带核))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 22 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Scapolo AD+Amadori 商总位(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | ELMAT 意大 B2B 分销（Ruijie/Cambium/Teltonika/Axis/Milestone 牌墙+厂训体系）：企业网替补 SKU 缝（$180 锚点一致）；Ruijie 旁前句 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：AD+Co-CEO 双升谱+商总 KPI
- **W**：牌链专谱
- **O**：Scapolo/Rizzo/Amadori 直达位
- **T**：Aruba 链竞谱

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Gentile Sig. Scapolo,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
