# Balazs Meretei

> **评级 A**　|　匈牙利 · Kecskemét　|　档案编号 `A-012`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-012
rating: A
country: 匈牙利
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 4  # 1-5
needs: {poe: true, industrial: true, tenG: true, l2plus: true, voice: false, oem: false, hotel: false, training: false}
p1: STC-28DGGPM
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：有明确交换/供电需求（交换认证 MTCSWE、PoE/监控/门禁、组播/IPTV），且有具体人直联
- **P1（首触唯一主推）**：STC-28DGGPM（8口 PoE 接入盒） — Cisco↔MikroTik 迁移实验室置换机；$99 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：Do any of your nodes sit outdoors or in unheated cabinets, and how do you recover a frozen PoE device there today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；集团/分销内部决策层级未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Balazs Meretei（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 匈牙利 / Kecskemét | 事实 |
| 网站 | meretei.hu | 事实 |
| 类型 | 集成商/顾问（MikroTik 认证） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCSE+MTCSWE | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】波 26·A-012:匈牙利谱: **具名金谱·原批引真**:Balazs Meretei(匈牙利);CSV 信号:MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCSE+MTCSWE;切入:MikroTik 认证顾问：自己做方案/集成/运维并自行采购设备 → 用 ERPS/IGMP/VLAN/CLI/MIB 这类技术语言切入，不打价格战;R66 第 26 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R55_第2批.json,先报价不回、档案铺位、持续关注新一季,OK。
- 【推断】R66 第 26 波具名 KP 金谱(原批引真)
- 【假设】STC-28DGGPM($99 USD EXW (2026-10-08, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCSE+MTCSWE）

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电、工业/户外/宽温、万兆上行/骨干、L2+ 交换管理（VLAN/ERPS/QinQ）
  - PoE 接入供电：【推断】依据 CSV 信号/深挖
  - 工业/户外/宽温：【推断】依据 CSV 信号/深挖
  - 万兆上行/骨干：【推断】依据 CSV 信号/深挖
  - L2+ 交换管理（VLAN/ERPS/QinQ）：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：balazs@meretei.hu
  - 状态：既有/公开
- **电话**：+36 30 999 9900
- 来源等级：official-channel（R41–R48 联系方式台账口径）
- **原始联系字段**：+36 30 999 9900 / balazs@meretei.hu
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Balázs Meretei（NoXy）**(独立顾问/wireless-bolt.hu 客座 MTCNA 讲师)— balazs@meretei.hu；+36 30 999 9900 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://meretei.hu/ ・ https://www.wireless-bolt.hu/46618-oktatas/673516-mikrotik-mtcna-kepzes〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Balázs Meretei（NoXy） | 独立顾问/wireless-bolt.hu 客座 MTCNA 讲师 | balazs@meretei.hu；+36 30 999 9900 | 自有域邮箱既有；MX（flash-net.hu）已验 | https://meretei.hu/ ・ https://www.wireless-bolt.hu/46618-oktatas/673516-mikrotik-mtcna-kepzes |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-28DGGPM（8口 PoE 接入盒）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE 入门款

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：他在做视频监控与 IPTV：24 口 PoE++ 喂摄像头/AP，重点讲组播表现（IGMP snooping 行为、组播 VLAN）与功率预算。
- **要问的问题**：他现在监控/IPVT 项目里组播怎么做（snooping 开关、组播 VLAN、上行带宽）？
- **随附证明**：组播测试（不泛洪验证）+ 功率实测 + 30 天样机。

### 第 2 次跟进 · 工业级非管理 PoE（WISP/室外）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：WISP 塔站与室外箱体：宽温宽压、DIN、免配置；配 SFP 做长距离回传。
- **要问的问题**：他手上的 WISP 站点的供电与箱体条件如何？
- **随附证明**：宽温/宽压报告 + SFP 兼容清单 + 现场接线一页图。

### 第 3 次跟进 · 管理型 PoE（组播+冗余）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：管理型：IGMP snooping/querier、组播 VLAN、ERPS 环网 —— 直接对应他的 IPTV/监控规模。
- **要问的问题**：规模上去后他打算怎么解决组播泛洪与链路冗余？
- **随附证明**：组播配置模板 + ERPS 实测 + MIB 清单。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第1批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：匈牙利（Kecskemét）独立网络工程师，MikroTik 认证顾问；个人站点是技术备忘博客（RouterOS/IPsec/Cisco 现场笔记），说明是长期在项目上的实战派。
- **产品线与在售品牌**：以 MikroTik/RouterOS 生态为主，另有 Cisco/ASA 现场经验（博客内容）。
- **目标行业与场景**：ISP 网络（ADSL/DOCSIS/ETTH/FTTH/WISP）+ 大规模组播（IPTV、视频监控系统）+ RADIUS 认证计费系统（既有记录）。
- **团队与规模**：个人/小团队，决策链=本人。
- **决策链与对接人**：balazs@meretei.hu；+36 30 999 9900。
- **技术与认证**：MTCNA+MTCRE+MTCWE+MTCSE+**MTCSWE**（交换）；博客显示其关注 IPsec、证书、NTP/时区、Cisco 配置等细节。
- **采购与供应链信号**：按项目采购，个人决策；组播/IPTV 项目对 IGMP snooping、组播 VLAN、上行带宽要求高 —— 换设备试错成本高，需要样品测试。
- **近期动态与线索**：博客长期更新（最近含协议号速查、IPsec 证书生成、Cisco NTP 时区备忘等），无公司官网。
- **与我方契合点**：监控与 IPTV 组播是他明写的场景：24 口 PoE（摄像头/AP）+ 组播优化（IGMP snooping、组播 VLAN）+ 环网冗余，正好对上我们的管理型 PoE 与工业线。
- **风险与注意**：他是技术型个人客户：先聊组播/交换细节建立信任，价格话题放后面。

### R54 原文证据摘录（全部保留）

- **【业务定位】**个人站点为技术备忘博客（RouterOS/IPsec/Cisco 实战笔记）。
  > Gyakran kell, ha IPsec routereket bántunk …；Nagyon unom, hogy a switchek/routerek órája … Switch(config)#ntp server 148.6.0.1 / clock timezone CET 1
  > 来源：https://meretei.hu/
- **【目标行业与场景】**既有记录：ISP 网络 + 大规模组播（IPTV、视频监控）+ RADIUS/计费。
  > 专长 ISP 网络（ADSL/DOCSIS/ETTH/FTTH/WISP）+ 大规模组播网络（IPTV、视频监控系统）+ RADIUS 认证计费系统的设计实施
  > 来源：https://mikrotik.com/consultants
- **【技术与认证】**持 MTCSWE（交换）与多证，博客体现 Cisco 现场经验。
  > MTCNA+MTCRE+MTCWE+MTCSE+MTCSWE
  > 来源：https://mikrotik.com/consultants

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第26波50户.json`；价格均为 EXW 快照。

- **①背景再核**：波 26·A-012:匈牙利谱: **具名金谱·原批引真**:Balazs Meretei(匈牙利);CSV 信号:MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCSE+MTCSWE;切入:MikroTik 认证顾问：自己做方案/集成/运维并自行采购设备 → 用 ERPS/IGMP/VLAN/CLI/MIB 这类技术语言切入，不打价格战;R66 第 26 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R55_第2批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **②芯片/型号**：STC-28DGGPM·8-port PoE access box (802.3af/at, watchdog)
- **③KP 深挖**：**Balázs Meretei（NoXy）(独立顾问/wireless-bolt.hu 客座 MTCNA 讲师,自有域邮箱既有；MX（flash-net.hu）已验)**
- **④Saga 对标**：STC-28DGGPM vs PLANET/当批价差窗
- **⑤在乎与偏好**：匈牙利 谱;CE/UKCA;持续关注新一季

### R55 证据摘录（全部保留 · 含数量）

- **【联系方式与基础画像】**Balazs Meretei(匈牙利);CSV 信号:MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCSE+MTCSWE;切入:MikroTik 认证顾问：自己做方案/集成/运维并自行采购设备 → 用 ERPS/IGMP/VLAN/CLI/MIB 这类技术语言切入，不打价格战
  > Balazs Meretei(匈牙利);CSV 信号:MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCSE+MTCSWE;切入:MikroTik 认证顾问：自己做方案/集成/运维并自行采购设备 → 用 ERPS/IGMP/VLAN/CLI/MIB 这类技术语言切入，不打价格战
  > 来源：https://meretei.hu/
- **【联系方式与基础画像】**CSV 入口:+36 30 999 9900 / balazs@meretei.hu
  > CSV 入口:+36 30 999 9900 / balazs@meretei.hu
  > 来源：https://meretei.hu/

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：波 26·A-012:匈牙利谱: **具名金谱·原批引真**:Balazs Meretei(匈牙利);CSV 信号:MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCSE+MTCSWE;切入:MikroTik 认证顾问：自己做方案/集成/运维并自行采购设备 → 用 ERPS/IGMP/VLAN/CLI/MIB 这类技术语言切入，不打价格战;R66 第 26 波谱:我司 STC-28DGGPM($99 价锚)对口该谱;既有深挖批源:A类深挖_2026-09-28_R55_第2批.json,先报价不回、档案铺位、持续关注新一季,OK。
- **产品线与在售品牌**：MikroTik 认证顾问 MTCNA+MTCRE+MTCWE+MTCSE+MTCSWE
- **目标行业与场景**：匈牙利 谱;集成商/顾问（MikroTik 认证）
- **团队与规模**：匈牙利谱·具名决策档
- **决策链与对接人**：**Balázs Meretei（NoXy）(独立顾问/wireless-bolt.hu 客座 MTCNA 讲师,自有域邮箱既有；MX（flash-net.hu）已验)**
- **技术与认证**：STC-28DGGPM 对口谱;$99 USD EXW 锚
- **采购与供应链信号**：具名谱位引路
- **近期动态与线索**：2026-10-08 R66 26 波谱名牌(A 类补全批)
- **与我方契合点**：STC-28DGGPM(8-port PoE access box) 具名窗
- **风险与注意**：leads-only;直发需 opt-in

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-28DGGPM（8口 PoE 接入盒） | 主场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | Cisco↔MikroTik 迁移实验室置换机 |
| 备选2 | STC-424XGGPM-280W（24口 PoE + 4×10G） | 升级/延展场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：8口 GE(7)+SFP，PoE af/at 240W，DC 随附电源，L2+ 全特性（VLAN/ERPS<20ms/QinQ/Private VLAN/sFlow），PoE 看门狗自动冷重启
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：原批 O 级具名金谱+R56 谱基在册
- **W**：直发需 opt-in
- **O**：STC-28DGGPM $99 USD EXW 价差窗
- **T**：谱链节奏;先报价不回则档案铺位

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] KP 在职时效
  - [ ] 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Dear Balázs Meretei（NoXy） Team,

We build a 8-port PoE access box (802.3af/at, watchdog). Reference: $99 USD EXW (2026-10-08, 15 days valid) — a value unit that rides along with each deployment. Datasheet + CE pack on request.

Best regards
Saga / SmartByte ODM
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
