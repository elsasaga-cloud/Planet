# Gretsch-Unitas GmbH Baubeschläge

> **评级 A**　|　德国 · Ditzingen　|　档案编号 `A-152`　|　优先级 ★★★　|　状态：01-已跟进一轮（用户报告；具体日期/收件人未逐户记录）
>
> **触达状态（Stage）**：01-contacted　|　结构版本：结构化档案 v2（R56 规则，2026-09-28 用户审定）

```yaml structured_profile
code: A-152
rating: A
country: 德国
biz_org: 公司/工作室（有官网）
business_model: 工程/集成项目制
decision_speed: moderate
price_sensitivity: medium
volume_potential: 3  # 1-5
needs: {poe: true, industrial: false, tenG: false, l2plus: false, voice: false, oem: false, hotel: false, training: false}
p1: STC-424XGGPM-280W
stage: 01-contacted
struct_version: v2  # v2 骨架
updated: 2026-10-12
```

## SALES BRIEF（压缩模型）

- **是谁**：公司/工作室（有官网）；工程/集成项目制
- **商业模式**：工程/集成项目制
- **为什么值得跟**：【人工定级】A —— 自动规则已跳过；人工指定
- **P1（首触唯一主推）**：STC-424XGGPM-280W（24口 PoE + 4×10G） — A-152 与 A-153 同域同源 dup-suspect 标注（不删号）；随 A-153 判别；$180 USD EXW（2026-09-28 快照，15 天有效，报价前核价）
- **第一问（只问一个）**：How many PoE ports does a typical site of yours need today?
- **最大未知（影响成交的）**：现有交换机品牌与 PoE 预算未确认；采购量未确认
- **下一步**：R71（2026-10-12）：一轮跟进已完成（用户报告；本户具体发送日期/收件地址未逐户提供）。可继续按本档既有策略低频跟进；不对首轮无实质回应者无差别催促；不编排未提供的下次动作日期。

- **关联档警示**：A-153（同一实体重复建档）→ A-153 冻结不出信；一切触达只走 A-152 主档

## 基本事实（事实/推断/假设分层）

| 项 | 内容 | 层级 |
|---|---|---|
| 名称 | Gretsch-Unitas GmbH Baubeschläge（CSV 原样；登记名以调研为准） | 事实 |
| 国家/城市 | 德国 / Ditzingen | 事实 |
| 网站 | https://www.g-u.com | 事实 |
| 类型 | 集成商/代理（Allied Telesis） | 事实（CSV 名录口径） |
| 反向信号（资质/品牌） | Allied Telesis（Marvell Prestera 接入层） | 事实（名录/自报口径） |
| 组织性质 | 公司/工作室（有官网） | 【推断】 |
| 商业模式 | 工程/集成项目制 | 【推断】 |
| 团队规模 | 有官网组织，规模未量化 | 【推断】 |
| 决策链 | 中（联系人+业主/采购两层以内） | 【推断】 |


**深挖三层（R56 · 一句话版 · 全文见原始 JSON）**

- 【事实】Gretsch-Unitas GmbH Baubeschläge:Gretsch-Unitas GmbH Baubeschläge(Ditzingen;**HRB 202061 AG Stuttgart;资本 €8,000,000(2008 增资);GmbH 2006-03-08 创(GU 牌 1907 源)**;**GU 集团门类:窗门五金/门禁/自动开闭/楼宇管理+烟排 RWA;三代家族 of Resch 族谱(2023-11 老铺故 → 其弟继位)**;集团下 GU Automatic/BKS GmbH/Ferco S.A.S.
- 【推断】R66 第 14 波具名 KP 金谱
- 【假设】24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))具名谱位引路

## 技术与在用（芯片/型号/规格/出货·客户反馈尽量核实）

（待深挖批覆盖；当前仅有 CSV 名录口径：Allied Telesis（Marvell Prestera 接入层））

> 诚实边界：出货量/订单信息、客户反馈若无公开来源一律写「无公开」，不编造；在用品牌未获客户本人确认前一律视为【假设】。

## 需求与场景（推断标签）

- **推断需求面**：PoE 接入供电
  - PoE 接入供电：【推断】依据 CSV 信号/深挖

## HR 与规模信号（招聘/团队/绿旗）

- 暂无可核实的招聘/团队规模公开信号（LinkedIn 员工枚举登录墙外不可见，2026-09-28 纪律）。

## 联系方式（已有/猜测分标）

- **邮箱**：info@g-u.de
  - 状态：既有/公开
- **电话**：—
- 来源等级：official（R41–R48 联系方式台账口径）
- **原始联系字段**：info@g-u.de [Publicly listed; delivery not tested]; https://www.g-u.com
- **R71 跟进核对**：本户一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，不补造。已核实的地址级异常见本档 R71/退信记录；未将用户报告扩大成逐地址送达结论。
- **具名 KP 通道(R66/R64 捕件,已有/猜测分标)**:
  - **Dr.-Ing. Jörg Teunissen**(Geschäftsführer(**2025-04-01 新任**;Elektrotechnik 博士;Bielefeld))— glaswelt/baulinks 行业报+online-handelsregister 登记公告 〔已有(公司官方公开件/登记册自曝);源:https://www.glaswelt.de/fenster/neue-fuehrungsspitze-dr-teunissen-jetzt-gf-der-unit-baubeschlaege-bei-gretsch-unitas〕
  - **Michael Helmut Edler von Resch**(Geschäftsführer(2023-12-06 起;GU 集团三代业主+CEO))— online-handelsregister 登记公告+glaswelt 专文 〔已有(公司官方公开件/登记册自曝);源:https://www.online-handelsregister.de/handelsregisterauszug/bw/Stuttgart/HRB/202061/Gretsch-Unitas-GmbH-Baubeschlaege〕
  - **Manfred Künzel**(Geschäftsführer(companyhouse 谱位))— companyhouse 谱 〔猜测(leads-only·LinkedIn/谱面带核,直发需 opt-in);源:https://www.companyhouse.de/Gretsch-Unitas-GmbH-Baubeschlaege-Ditzingen〕
  - **Christian Choffat**(Gesamtprokurist(2025-04-10 总代理))— online-handelsregister 登记公告 〔已有(公司官方公开件/登记册自曝);源:https://www.online-handelsregister.de/handelsregisterauszug/bw/Stuttgart/HRB/202061/Gretsch-Unitas-GmbH-Baubeschlaege〕

## 关键人（KP）与触达通道

| 姓名 | 角色 | 联系方式 | 状态/核实度 | 来源 |
|---|---|---|---|---|
| Dr.-Ing. Jörg Teunissen | Geschäftsführer(**2025-04-01 新任**;Elektrotechnik 博士;Bielefeld) | glaswelt/baulinks 行业报+online-handelsregister 登记公告 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.glaswelt.de/fenster/neue-fuehrungsspitze-dr-teunissen-jetzt-gf-der-unit-baubeschlaege-bei-gretsch-unitas |
| Michael Helmut Edler von Resch | Geschäftsführer(2023-12-06 起;GU 集团三代业主+CEO) | online-handelsregister 登记公告+glaswelt 专文 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.online-handelsregister.de/handelsregisterauszug/bw/Stuttgart/HRB/202061/Gretsch-Unitas-GmbH-Baubeschlaege |
| Manfred Künzel | Geschäftsführer(companyhouse 谱位) | companyhouse 谱 | leads-only·待 opt-in(LinkedIn/谱面带核) | https://www.companyhouse.de/Gretsch-Unitas-GmbH-Baubeschlaege-Ditzingen |
| Christian Choffat | Gesamtprokurist(2025-04-10 总代理) | online-handelsregister 登记公告 | official-self-published·谱/leads-only(直发需 opt-in) | https://www.online-handelsregister.de/handelsregisterauszug/bw/Stuttgart/HRB/202061/Gretsch-Unitas-GmbH-Baubeschlaege |

## 跟进步骤（最多 3 次 · 成功/退出标准）

> 每次只推进一个台阶、只问一个问题；全程只推 P1（STC-424XGGPM-280W（24口 PoE + 4×10G）），备选型不进邮件。

### 第 1 次跟进 · 24 口 CCTV/PoE（电子门禁项目配套件）

- **推什么**：STC-424XGGPM-440W（Saga）（24×千兆 PoE++ + 4×万兆上行）（现行对照：STC-424XGGPM-280W——P 表唯一登记，440W 档已停编）
- **切入点**：顺其 IP 门禁/自动门项目：联网机电件背后的 24 口 PoE 接入层——门禁配套包一页（不碰其五金主业）。
- **要问的问题**：电子门禁项目的 PoE 接入层现在配什么？（德文，一页配套包）
- **随附证明**：配套包资料 + 规格对照 + CE 文档（德文）。

### 第 2 次跟进 · 工业级非管理 PoE（工厂/户外门机组点位）

- **推什么**：STI-280GE（Saga） PoE 版（8G + 2×2.5G SFP，DIN，-40~75°C）
- **切入点**：门机组/旋转门等户外与厂房点位：宽温 DIN PoE。
- **要问的问题**：户外门机组点位的供电交换怎么配？
- **随附证明**：宽温报告 + DIN 图 + 备件包价（德文）。

### 第 3 次跟进 · 管理型 PoE（楼宇分段标准件）

- **推什么**：STI-480XGGM（Saga）（8G + 4×SFP+ 10G，PoE 版）
- **切入点**：项目楼控/安防网的分段标准件：VLAN/ERPS 模板进其集团工程库。
- **要问的问题**：楼宇网分段标准要不要进工程参考库？
- **随附证明**：VLAN/ERPS 模板 + 收敛实测（德文）。


## R54 调研要点（加厚 · 全文见原始 JSON）

> 调研日期 **2026-09-28**；原始记录：`batch/A类加厚_2026-09-28_R54_第8批.json`。以下为要点压缩，证据原文全部保留。

- **业务定位**：斯图加特旁 Ditzingen 的建筑五金世界集团：电子门禁/自动门/楼控 IP 化项目商，Allied Resell（CSV 记录）。⚠️ 集团多行（A-152/153/154 同集团，CSV：协同避免重复联系）。
- **产品线与在售品牌**：建筑五金/锁具/电子门禁（BKS）/自动门（GU Automatic）/楼控与服务（GU BKS SERVICE）。
- **目标行业与场景**：全球地标的门窗+门禁项目；集团自用工厂与楼宇的网络。
- **团队与规模**：世界性集团（四品牌多地工厂），非小集成商。
- **决策链与对接人**：info@g-u.de（CSV 9-27：总部通用入口；与 A-153/154 同集团、保留编号不合并删除——CSV 原话）。
- **技术与认证**：Allied Resell（CSV 记录）。
- **采购与供应链信号**：集团级采购：门禁 IP 项目的 PoE 层是配套 BOM；大集团合规门槛高（供应商注册体系）——现实路径是从配件级小项进。
- **近期动态与线索**：全球参考项目持续（官网焕新版式）。
- **与我方契合点**：电子门禁/自动门联网项目的 PoE 件+集团自用工厂网络的工业件——以「门禁项目 PoE 配套包」形态的小切口进入。
- **风险与注意**：一行一策整体协调：A-152 为主入口、A-153（柏林行）不单独触达、A-154 服务实体走自己邮箱错峰；别三头发同内容（CSV 重点）。

### R54 原文证据摘录（全部保留）

- **【业务定位】**官网：GU 集团=门窗五金+自动门+电子门禁+楼控系统的世界性集团，品牌 GU Baubeschläge/BKS/GU Automatic/FERCO。
  > Wir sind die Unternehmensgruppe Gretsch-Unitas mit den Marken Gretsch-Unitas Baubeschläge, BKS, GU Automatic und FERCO. Mit jahrzehntelanger Erfahrung entwickeln wir intelligente Lösungen für Fenster- und Türtechnik, automatische Eingangssysteme und Zutrittskontrolle
  > 来源：https://www.g-u.com/de-de
- **【目标行业与场景】**参考项目世界级：纽约 520 West 28th（扎哈）、伦敦 Anna Freud Centre、哥本哈根 BLOX、斯图加特市立图书馆——大项目配套能力强。
  > Referenzen: 520 West 28th Street, New York City · Anna Freud Centre, London · BLOX - Dänisches Architekturzentrum · Stadtbibliothek Stuttgart
  > 来源：https://www.g-u.com/de-de
- **【产品线与在售品牌】**电子门禁与建筑管理系统 IP 化：BKS 的电子锁芯/门禁系统、GU Automatic 自动门驱动（Rietberg 产）——联网机电件背后是 PoE 网络段。
  > BKS GmbH — Schließzylinder, Schlösser und Zutrittssysteme – mechanisch und elektronisch ‖ GU Automatic GmbH — Innovative Antriebslösungen und automatische Türsysteme ‖ Zutrittskontrolle（集团口径）
  > 来源：https://www.g-u.com/de-de

## R55 再发掘要点（深挖 · 全文见原始 JSON）

> 调研日期 **—**；原始记录：`batch/A类深挖_2026-10-08_R66_R56_KP第18波30户.json`；价格均为 EXW 快照。

- **①背景再核**：Gretsch-Unitas GmbH Baubeschläge(Ditzingen;**HRB 202061 AG Stuttgart;资本 €8,000,000(2008 增资);GmbH 2006-03-08 创(GU 牌 1907 源)**;**GU 集团门类:窗门五金/门禁/自动开闭/楼宇管理+烟排 RWA;三代家族 of Resch 族谱(2023-11 老铺故 → 其弟继位)**;集团下 GU Automatic/BKS GmbH/Ferco S.A.S.
- **②芯片/型号**：(待谱面二补)
- **③KP 深挖**：**Dr.-Ing. Jörg Teunissen(Geschäftsführer(**2025-04-01 新任**;Elektrotechnik 博士;Bielefeld),official-self-published·谱/leads-only(直发需 opt-in));Michael Helmut Edler von Resch(Geschäftsführer(2023-12-06 起;GU 集团三代业主+CEO),official-self-published·谱/leads-only(直发需 opt-in));Manfred Künzel(Geschäftsführer(companyhouse 谱位),leads-only·待 opt-in(LinkedIn/谱面带核));Christian Choffat(Gesamtprokurist(2025-04-10 总代理),official-self-published·谱/leads-only(直发需 opt-in))**
- **④Saga 对标**：24 口 value PoE($180 USD EXW (2026-10-07, 15天有效))
- **⑤在乎与偏好**：三代家族+新 GF 谱

### R55 证据摘录（全部保留 · 含数量）

- **【决策链与对接人】**Zum 1. April 2025: Dr.-Ing. Jörg Teunissen neuer GF, gemeinsam mit Michael von Resch;Julius von Resch †23.11.2023 → Bruder Michael übernimmt;GU-Gruppe drifdritt Generation Familie von Resch(glaswelt 件)
  > Zum 1. April 2025: Dr.-Ing. Jörg Teunissen neuer GF, gemeinsam mit Michael von Resch;Julius von Resch †23.11.2023 → Bruder Michael übernimmt;GU-Gruppe drifdritt Generation Familie von Resch(glaswelt 件)
  > 来源：https://www.glaswelt.de/fenster/neue-fuehrungsspitze-dr-teunissen-jetzt-gf-der-unit-baubeschlaege-bei-gretsch-unitas
- **【联系方式与基础画像】**HRB 202061 Stuttgart;Stammkapital €8.000.000;Gründung 08.03.2006;Prokura: Choffat (Gesamtprokura 10.04.2025)/Faller(17.04.2025)(online-handelsregister 件)
  > HRB 202061 Stuttgart;Stammkapital €8.000.000;Gründung 08.03.2006;Prokura: Choffat (Gesamtprokura 10.04.2025)/Faller(17.04.2025)(online-handelsregister 件)
  > 来源：https://www.online-handelsregister.de/handelsregisterauszug/bw/Stuttgart/HRB/202061/Gretsch-Unitas-GmbH-Baubeschlaege

### R56 十维速览（深挖笔记 · 事实与推断混合，证据见上节）

- **业务定位**：Gretsch-Unitas GmbH Baubeschläge(Ditzingen;**HRB 202061 AG Stuttgart;资本 €8,000,000(2008 增资);GmbH 2006-03-08 创(GU 牌 1907 源)**;**GU 集团门类:窗门五金/门禁/自动开闭/楼宇管理+烟排 RWA;三代家族 of Resch 族谱(2023-11 老铺故 → 其弟继位)**;集团下 GU Automatic/BKS GmbH/Ferco S.A.S.
- **产品线与在售品牌**：(波次二补谱面)
- **目标行业与场景**：德国 GU 集团五金门牌商(三代家族)
- **团队与规模**：集团大谱;2006 创(牌 1907)
- **决策链与对接人**：**Dr.-Ing. Jörg Teunissen(Geschäftsführer(**2025-04-01 新任**;Elektrotechnik 博士;Bielefeld),official-self-published·谱/leads-only(直发需 opt-in));Michael Helmut Edler von Resch(Geschäftsführer(2023-12-06 起;GU 集团三代业主+CEO),official-self-published·谱/leads-only(直发需 opt-in));Manfred Künzel(Geschäftsführer(companyhouse 谱位),leads-only·待 opt-in(LinkedIn/谱面带核));Christian Choffat(Gesamtprokurist(2025-04-10 总代理),official-self-published·谱/leads-only(直发需 opt-in))**
- **技术与认证**：(波次二补)
- **采购与供应链信号**：(波次二补)
- **近期动态与线索**：2026-10-08 R66 14 波谱名牌
- **与我方契合点**：24 口 value PoE 谱链窗口
- **风险与注意**：Teunissen 履新贺卡+von Resch 集团位(opt-in 律)

## 产品决策（Saga · 单一决策口径）

| 优先级 | 型号 | 场景 | 价格（USD EXW 快照） | 选它的原因 |
|---|---|---|---|---|
| **P1（首触唯一）** | STC-424XGGPM-280W（24口 PoE + 4×10G） | 主场景 | $180 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | A-152 与 A-153 同域同源 dup-suspect 标注（不删号）；随 A-153 判别 |
| 备选2 | STC-28DGGPM（8口 PoE 接入盒） | 升级/延展场景 | $99 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |
| 备选3 | STI-288GP（工业非管理 8口 PoE） | 升级/延展场景 | $74.8 USD EXW（2026-09-28 快照，15 天有效，报价前核价） | P1 过后的台阶，不进首触邮件 |

- **P1 规格一句话**：24口 GE PoE af/at 280W + 4×10G SFP+，L2+ 全特性含 Voice VLAN，PoE 看门狗
- **口径纪律**：档案内如出现其他型号（历史段落），以本节 P1 为准；Saga 暂无对应规格的口子（商用 PoE bt 90W / 全万兆汇聚 / 8口商用 10G 上联）**不得**现编型号，按规则继续沿用旧对照并显式标注。

## SWOT

- **S**：三代家族+新 GF 谱
- **W**：集团层谱
- **O**：Teunissen 新 GF 庆贺位
- **T**：自家链栈=合作段

## 触达与风险红线

**通用红线（所有客户适用）**

1. 包装、外观、说明书**全部中性**，不出现「Made in China」，贴客户自己的型号。
2. **台厂不是客户**，只是信号源。
3. PoE 功率与工业温宽是最容易当场翻车的两项，口头承诺必须落到实测数据。
4. 大集团先问清采购层级（国别 vs 集团统一）。
5. 样机先送测，再谈价格。

**停止开发条件（命中任一即停）**：3 次定向触达无任何实质回复；确认现用平台完全满足需求；只愿比价不愿谈场景；决策者确认接触不到；对方书面拒绝。

## Qualification 清单

| 门槛 | 状态 |
|---|---|
| 需求面成立（PoE/接入层池） | ✅ |
| 决策人识别 | ✅ |
| 触达通道 | ✅ 邮箱域已验 MX |
| 现用交换品牌 | ❓ 未确认 |
| 采购量/预算 | ❓ 未确认 |
| 商业资格结论 | **技术上合格 / 商业上未合格（待首触信号）** |

## Unknowns（待问清单 · 首触后逐项消除）

- **深挖专属待问（R56）**：
  - [ ] 硬件采购线在职者(波次二)
  - [ ] MikroTik 谱面份额

- [ ] 现有交换机/PoE 品牌与型号（问法：见首触邮件第一问）
- [ ] 典型站点端口数与供电预算
- [ ] 上门/故障频次（订阅制客户的核心成本）
- [ ] 采购决策人与付款口径

## 首触邮件（英文样板 · 可直接发送）

**主题**：PoE switching for your projects

```text
Guten Tag Herr Dr. Teunissen,

We build a 24-port Gigabit PoE access switch (280W, 802.3af/at, watchdog). Reference: $180 USD EXW (2026-10-07, 15 days valid) — a value unit that rides along with each deployment. Could you point us to the colleague carrying the hardware purchasing line?

Best regards,
Saga Networks Export Desk
```

> 发送前检查：① 不出现「Made in China」或原产地信息；② 不承诺未实测的指标；③ 落款换成你自己的名字与公司；④ **一次只问一个问题**；⑤ 货币单位一律 USD 并带快照日期；⑥ 该客户为教师/公立身份时先读「本户特别红线」。

## 跟进记录

| 日期 | 渠道（邮件/电话/LinkedIn/展会） | 对象 | 我方动作 | 对方回应 | 下一步 | 下次动作日期 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

> 首次触达前留空；发出邮件后填入日期与渠道。有新进展时告诉我，我来更新本档案并重评 stage。

## 下次复核

- 固定节点：首触发出后 **14 天**无回复 → 复核是否降频/降级；有任何回复 → 当即重评 stage 与评级。
- 报价纪律：全部价格为 USD EXW 快照（2026-09-28，15 天有效）；过窗先核价再报价。

---

*建档日期：2026-09-22　|　结构 v2：2026-09-28（R56 规则）　|　数据来源：客户名单_反向信号_2026-09.csv + R54/R55 调研 JSON*

<!-- R71-FOLLOWUP-START -->
## R71 本轮跟进与邮件回执（2026-10-12）

- **跟进范围**：A/B 本轮一轮跟进已完成（用户报告）；逐户发送日期与实际收件地址未提供，本节不补造发送日志。
- **本户结论**：一轮跟进已完成；可继续按本档既有策略低频跟进，不把“已跟进”误写成“逐地址送达成功”。
- **地址级范围**：R71 退信台账未为本户列出新的精确地址异常；可继续跟进不等于对每个邮箱作了 SMTP 或逐地址送达验证。
- **后续节奏**：首轮之后不作无差别催促；按既有节奏等待或低频跟进，不填造日期。
<!-- R71-FOLLOWUP-END -->
