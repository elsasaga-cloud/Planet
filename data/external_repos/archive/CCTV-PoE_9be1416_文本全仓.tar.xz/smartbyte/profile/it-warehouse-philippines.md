# 客户档案：IT Warehouse — 菲律宾

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司全称 | IT Warehouse |
| 国家 | 菲律宾 (Quezon City) |
| 类型 | ISP设备分销商 |
| 网站 | itwarehouse.ph |
| 地址 | RedGold Building 1840 E. Rodriguez Sr. Ave, Cubao, Quezon City |
| 客户级别 | **A级（核心）** |
| 优先级 | ★★★★★ |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 邮箱 | business@itwarehouse.ph |
| 电话 | (02) 7905-6052 |
| 手机/Viber | 09228333572 (Viber-enabled) |
| Facebook | facebook.com/itwcomputersolution (96%推荐率, 65评论) |
| 营业时间 | 详见网站 |

## 公司深度分析

### 品牌组合
MikroTik, Ubiquiti, TP-Link, RF Elements, Alta Labs, Huawei Network, Ruijie/Reyee, Sopto, C-Data, VSOL, Corvia

### 客户群
ISP, WISP, 网络运营商, 系统集成商, 经销商, 个人/企业

### 产品品类
| 品类 | 在售品牌 |
|------|---------|
| 路由器 | MikroTik, Ubiquiti, TP-Link, Ruijie |
| 交换机 | **MikroTik CRS/CSS系列, Ubiquiti UniFi Switch, TP-Link Omada** |
| 无线AP | Ubiquiti UniFi, MikroTik, TP-Link, Ruijie |
| PtP/PtMP | RF Elements, Ubiquiti, MikroTik |
| 光纤设备 | Sopto, C-Data, VSOL, Corvia |
| 网络线缆 | TP-Link, Alta Labs |
| PoE设备 | 多品牌 |
| LTE | Huawei |

### 服务
- MikroTik配置服务
- 定制报价
- 免费网络研讨会/培训
- 成为经销商计划
- ISP运营商与安装服务

## 需求分析

### 菲律宾ISP市场
- 菲律宾有400+家ISP/WISP运营商
- 管理型交换机是ISP网络基础设施刚需
- MikroTik CRS系列是最常用的管理型交换机
- TP-Link Omada是新兴选择
- 市场价格敏感度高

### 痛点
1. MikroTik CRS系列价格较高（CRS326-24G-2S+ ~$200, CRS328-24P ~$500）
2. 无完整L3交换机选项（MikroTik L3功能有限）
3. TP-Link Omada用Realtek芯片，ISP客户偏好Marvell
4. 菲律宾ISP客户预算有限，需要高性价比方案

## 推荐产品方案

| SmartByte型号 | 配置 | FOB | 对标MikroTik | MikroTik价格 | 价差 |
|---------------|------|-----|-------------|-------------|------|
| STC-424XGGM | 24GE + 4×10G SFP+ | **$100** | CRS326-24G-2S+ | $200 | **低50%** |
| STC-424XGGPM-280W | 24GE PoE + 4×10G SFP+ | **$140** | CRS328-24P-4S+ | $500 | **低72%** |
| STC-424XGGM(L3) | 24GE + 4×10G SFP+ (**L3**) | **$210** | 无 | — | **独占** |
| STC-448XGGM | 48GE + 4×10G SFP+ | **$205** | CRS326无48口 | — | **独占** |
| STC-448XGGPM | 48GE PoE + 4×10G SFP+ | **$245** | CRS354-48P | $900 | **低73%** |

### 核心卖点
1. **"50-73%低于MikroTik"** — 直接对标MikroTik CRS系列，价格碾压
2. **"完整L3 BGP/OSPF"** — MikroTik CRS系列不支持完整BGP
3. **"Marvell芯片 vs Realtek"** — TP-Link Omada用Realtek，SmartByte用Marvell
4. **"菲律宾独家分销"** — 成为SmartByte菲律宾独家代理
5. **"400+ ISP客户的新选择"** — 管理型交换机是ISP刚需

### 跟进策略
1. 邮件发business@itwarehouse.ph，标题："Marvell L3 Managed Switch — 50% Below MikroTik, Exclusive PH Distribution"
2. Viber联系09228333572（菲律宾常用Viber）
3. 准备MikroTik CRS系列对标表
4. 提供菲律宾独家代理方案
5. 提供ISP部署案例

## 预期订单

| 阶段 | 预估金额 |
|------|---------|
| 首单 | $3,000-10,000 |
| 年供货 | $30,000-80,000 |
| 独家代理后 | $80,000-150,000 |
