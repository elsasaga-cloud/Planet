# 客户档案：WAV — 美国

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司全称 | WAV, LLC |
| 国家 | 美国 Aurora, IL (芝加哥郊区) |
| 类型 | WISP/ISP设备顶级分销商 |
| 网站 | wavonline.com |
| 仓储 | 美国7个战略仓库 |
| 2024年 | 收购了ISP Supplies (ispsupplies.com) |
| 客户级别 | **A级（核心）** |
| 优先级 | ★★★★★ |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 总机 | (800) 678-2419 / (630) 818-1000 |
| 总邮箱 | info@wavonline.com |
| 地址 | 2380A Prospect Drive, Aurora, IL 60502 |
| **营销EVP** | Zach Hubeck — zachh@wavonline.com / (847) 343-9216 |
| **销售代表** | Tre Owen — treo@wavonline.com / (360) 442-4415 |

## 公司深度分析

### 品牌组合
Cambium Networks, Ubiquiti, TP-Link, MikroTik, Mimosa (Cambium), Alta Labs, RF Elements, 光纤设备

### 产品品类
| 品类 | 说明 |
|------|------|
| 网络交换机 | **Network Switches, PoE Switches** — 核心品类 |
| 无线设备 | WiFi 7/6/5 AP, 2.4/5GHz, 60GHz |
| 固定无线 | PtP/PtMP radio |
| 光纤 | GPON/XGS-PON, SFP, DAC, 光缆 |
| 路由器 | 有线路由器, VoIP PBX |
| 基础设施 | 机柜, 天线, 塔架 |
| IoT | LoRaWAN, BLE |
| 培训 | Ubiquiti/MikroTik认证课程 |

### 客户群
WISP, ISP, MSP, 教育, 第一民族/部落, 酒店, 多住户单元(MDU), 石油天然气

### 增值服务
- 设备融资
- 培训认证
- 网络设计咨询
- 多供应商方案支持
- 7个仓库快速发货

## 需求分析

### 北美WISP市场
- 北美有2,000+家WISP运营商
- 管理型交换机是WISP网络核心设备
- Cambium和Ubiquiti是主力品牌
- 市场价格敏感度中等（更看重质量和支持）

### 痛点
1. 管理型交换机品牌有限（Cambium/Ubiquiti/MikroTik/TP-Link）
2. 无L3管理型交换机产品
3. Cambium交换机价格较高
4. 需要更多供应商以降低供应链风险

## 推荐产品方案

| SmartByte型号 | 配置 | FOB | 应用场景 |
|---------------|------|-----|---------|
| STC-424XGGM(L3) | 24GE + 4×10G (**L3**) | $210 | ISP汇聚层 |
| STC-448XGGM(L3) | 48GE + 4×10G (**L3**) | $365 | 大型ISP汇聚 |
| STC-448XGGPM | 48GE PoE + 4×10G | $245 | ISP接入层PoE |
| STC-424XGGPM-280W | 24GE PoE + 4×10G | $140 | 小型WISP |

### 核心卖点
1. **"填补L3空白"** — WAV品牌组合中无L3管理型交换机
2. **"比Cambium低60%+"** — WISP客户对价格敏感
3. **"FCC认证齐全"** — 可直接进入美国市场
4. **"Marvell芯片"** — 美国ISP客户认可Marvell
5. **"7仓库分销"** — WAV有能力快速铺货

### 跟进策略
1. 邮件发zachh@wavonline.com (营销EVP)
2. 电话(800) 678-2419
3. 提出成为WAV新供应商
4. 强调FCC+CE认证
5. 提供美国ISP部署案例
6. 参加ENTELC等行业展会（WAV是会员）

## 预期订单

| 阶段 | 预估金额 |
|------|---------|
| 首单 | $10,000-50,000 |
| 年供货 | $200,000-500,000+ |
