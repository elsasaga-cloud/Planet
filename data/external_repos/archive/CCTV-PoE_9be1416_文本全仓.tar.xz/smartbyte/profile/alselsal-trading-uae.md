# 客户档案：Alselsal Trading LLC — 阿联酋迪拜

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司全称 | Alselsal Trading LLC |
| 国家 | 阿联酋 Dubai |
| 类型 | MikroTik授权分销商 |
| 网站 | mikrotikuae.com |
| 成立 | 2002年 |
| 客户级别 | **A级（核心）** |
| 优先级 | ★★★★★ |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 电话 | +971 4 351 5118 |
| WhatsApp | +971 50 497 3673 |
| 邮箱 | info@alselsal.net |
| 地址 | Khalid bin Al Walid Street, Dubai, UAE |

## 公司深度分析

### 业务
- MikroTik授权分销商和经销商
- 覆盖Dubai、UAE、Africa、Gulf和MENA地区
- 提供MikroTik全线产品：路由器、交换机、无线、天线、PoE设备
- 服务对象：ISP、MSP、系统集成商、终端用户

### MikroTik交换机在售价格（参考）
| 型号 | AED价格 | USD |
|------|---------|-----|
| CRS326-24G-2S+RM | AED 1,995 | $542 |
| CRS328-4C-20S-4S+RM | AED 1,890 | $514 |
| CRS328-24P-4S+RM | 约AED 1,900 | $517 |
| CRS354-48P-4S+2Q+RM | AED 3,045 | $827 |
| CSS326-24G-2S+RM | AED 578 | $157 |

### 竞争环境
迪拜有多家MikroTik分销商竞争：
- Terrabyt (terrabyt.com)
- Neodata Technologies
- DSR Tech
- ICTech Distribution
- Digital World Technology
- Bizaar.ai

## 推荐产品方案

| SmartByte型号 | 配置 | FOB | 对标MikroTik | MikroTik在售 | 价差 |
|---------------|------|-----|-------------|-------------|------|
| STC-424XGGPM-280W | 24GE PoE + 4×10G | **$140** | CRS328-24P-4S+ | $517 | **低73%** |
| STC-424XGGM | 24GE + 4×10G | **$100** | CRS326-24G-2S+ | $542 | **低82%** |
| STC-424XGGM(L3) | 24GE + 4×10G (**L3**) | **$210** | 无直接对标 | — | **独占** |
| STC-448XGGPM | 48GE PoE + 4×10G | **$245** | CRS354-48P | $827 | **低70%** |

### 核心卖点
1. **"你的CRS328进货价$350-400，我的同级产品$140"** — 直接价格对比
2. **"你可以卖$350-400（vs MikroTik $517），更有竞争力+更高利润"**
3. **"L3 BGP/OSPF/ECMP，MikroTik CRS系列没有"** — 差异化
4. **"Marvell芯片，企业级"** — 不降级
5. **"Dubai多家MikroTik分销商竞争激烈，SmartByte帮你差异化"**

### 跟进策略
1. **WhatsApp直接联系 +971 50 497 3673** ← 最快方式
2. 邮件发info@alselsal.net，附MikroTik对标表
3. 提出样品试测（2台）
4. 讨论UAE+非洲代理条款
5. 提出GITEX Dubai展会面谈

## 预期订单

| 阶段 | 预估金额 |
|------|---------|
| 首单 | $3,000-10,000 |
| 年供货 | $30,000-80,000 |
