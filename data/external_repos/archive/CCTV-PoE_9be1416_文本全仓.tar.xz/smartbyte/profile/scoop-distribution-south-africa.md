# 客户档案：Scoop Distribution — 南非

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司全称 | Scoop Distribution (Pty) Ltd |
| 国家 | 南非 |
| 城市 | 开普敦(总部) / 约翰内斯堡 / 德班 |
| 类型 | 网络设备批发分销商 |
| 网站 | scoop.co.za |
| 成立 | 2001年（25年） |
| 地址 | 1A Harvest Cl, Richwood, Cape Town, 7441 |
| 客户级别 | **A级（核心）** |
| 优先级 | ★★★★★ |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 总邮箱 | sales@scoop.co.za |
| 开普敦 | cpt@scoop.co.za / +27(0)21 555 4740 |
| 约翰内斯堡 | jhb@scoop.co.za / +27(0)11 312 9414 |
| 德班 | dbn@scoop.co.za / +27(0)31 569 5103 |
| LinkedIn | linkedin.com/company/scoop-distribution-pty-ltd |
| Facebook | facebook.com/ScoopDistribution |
| Twitter | @tweetatscoop |

### 关键决策人
| 姓名 | 职位 | 接触策略 |
|------|------|---------|
| **Timothy Symonds** | CEO | 最终决策人，邮件抄送 |
| **Abby Carelse** | CPO (Chief Product Officer) | **首选联系人** — 负责产品选型，直接决定引进哪些新品牌 |
| Nadia Gonsalves | CFO | 涉及商务条款时联系 |
| Steven Joubert | 约堡Branch Manager | 约堡市场切入 |

## 公司深度分析

### 业务模式
- **批发分销**：面向经销商/集成商，不直接零售
- **三城覆盖**：开普敦+约堡+德班，南非三大城市全覆盖
- **SADC出口**：覆盖南部非洲发展共同体（博茨瓦纳、纳米比亚、津巴布韦、莫桑比克等）
- **品牌授权**：Ubiquiti/MikroTik/Reyee/Cudy/Linkbasic/Fanvil/Biwin 正式授权
- **自有品牌**："Scoop PoE Switches" — 已有自有品牌PoE交换机！
- **认证培训**：提供Ubiquiti/MikroTik认证培训课程

### 产品生态
| 品类 | 品牌 | 说明 |
|------|------|------|
| 无线WiFi | Ubiquiti UniFi / MikroTik / Reyee / Cudy | 全价位覆盖 |
| 网络交换机 | **MikroTik (管理型/PoE/非管理型)** + Ubiquiti UniFi + Reyee + **Scoop自有品牌PoE** | 核心品类 |
| VoIP | Fanvil | IP电话+PBX |
| 结构化布线 | Linkbasic | 机柜/线缆/光纤 |
| 存储 | Biwin | SSD/内存 |
| 监控 | IP Security | PoE摄像机 |
| UPS/电源 | Scoop PoE | 自有品牌 |

### 竞争现状（管理型交换机品类）
| 竞品 | 在Scoop的型号 | 零售价(ZAR) | 折合USD |
|------|-------------|-------------|---------|
| MikroTik CRS326-24G-2S+RM | 管理型24口 | ~R5,500 | ~$300 |
| MikroTik CRS328-24P-4S+RM | 管理型PoE 24口 | ~R9,500 | ~$520 |
| MikroTik CRS354-48P-4S+2Q+RM | 管理型PoE 48口 | ~R16,500 | ~$900 |
| Ubiquiti USW-24 (非管理型) | UniFi 24口 | ~R5,000 | ~$275 |
| Reyee RG-ES226GC-P | PoE管理型 | ~R4,500 | ~$250 |

## 需求分析

### 为什么是A级客户？
1. **已有自有品牌PoE交换机** — 说明对OEM合作有兴趣和经验
2. **管理型交换机品类空缺** — 目前只有MikroTik提供管理型，Ubiquiti UniFi全系非管理型
3. **无L3交换机** — 整个产品线没有L3管理型交换机
4. **南非WISP市场爆发** — 南非有200+家WISP，管理型交换机是刚需
5. **三城分销网络** — 一旦合作可快速覆盖南非+SADC区域

### 痛点
1. MikroTik管理型交换机价格高（CRS328-24P零售$520），经销商利润空间有限
2. Ubiquiti UniFi Switch全系非管理型，无法满足需要VLAN/QoS的客户
3. 自有品牌Scoop PoE只有非管理型，无法参与管理型项目投标
4. 没有L3交换机产品线，无法做企业/ISP汇聚层项目

## 推荐产品方案

### 方案一：OEM贴牌Scoop品牌管理型交换机（首选）
| SmartByte型号 | 配置 | FOB价 | 建议Scoop品牌零售价 | Scoop毛利率 |
|---------------|------|-------|-------------------|------------|
| STC-424DGGPM-280W | 24GE + 4×1G SFP (PoE 280W) | $65 | $200-250 (ZAR 3,600-4,500) | **67-74%** |
| STC-424XGGPM-280W | 24GE + 4×10G SFP+ (PoE 280W) | $140 | $350-400 (ZAR 6,300-7,200) | **60-65%** |
| STC-424XGGM(L3) | 24GE + 4×10G SFP+ (**L3**) | $210 | $450-550 (ZAR 8,100-9,900) | **53-62%** |

### 方案二：SmartByte品牌补充现有线
| SmartByte型号 | 对标MikroTik | FOB价 | vs MikroTik零售价 |
|---------------|-------------|-------|-----------------|
| STC-424XGGM | CRS326-24G-2S+ ($300) | $100 | **低67%** |
| STC-424XGGPM-280W | CRS328-24P-4S+ ($520) | $140 | **低73%** |
| STC-448XGGPM | CRS354-48P ($900) | $245 | **低73%** |

### 核心卖点（针对Scoop的具体话术）
1. **"升级你的Scoop品牌"** — "你们已有Scoop PoE交换机（非管理型），我们帮你升级到管理型+L3，贴Scoop品牌，你的经销商客户会立刻下单"
2. **"比MikroTik CRS328低73%"** — "你们的MikroTik CRS328-24P卖R9,500 ($520)，我们同级产品FOB只要$140，你可以卖R6,000 ($330)还保持高利润"
3. **"独家L3产品线"** — "南非市场上Ubiquiti/MikroTik/Reyee都没有完整L3（BGP/OSPF/ECMP），SmartByte让你独家拥有L3管理型交换机"
4. **"Marvell芯片，企业级"** — "不是Realtek或国产芯片，98% Marvell芯片，和Cisco/Aruba同级芯片方案"
5. **"SKD方案"** — "支持散件供应，可以在南非本地组装，降低进口关税（南非IT设备关税15%）"

## 竞争分析

### 当前供应商威胁
| 供应商 | 威胁级别 | 分析 |
|--------|---------|------|
| MikroTik | ★★★★☆ | 已是核心品牌，但利润空间有限，SmartByte可作为补充 |
| Ubiquiti | ★★★★☆ | 品牌力强，但UniFi Switch无管理型/L3 |
| Reyee (锐捷) | ★★★☆☆ | 中国品牌，价格中等，管理型产品线有限 |
| TP-Link | ★★☆☆☆ | 不在Scoop品牌组合中 |

### SmartByte切入角度
- **不替代现有品牌**，而是填补空白：L3管理型 + 自有品牌管理型
- 让Scoop在管理型交换机品类上有3个层级：SmartByte/Scoop品牌(性价比) + MikroTik(品牌) + 未来L3(独家)

## 跟进计划

| 阶段 | 行动 | 时间 | 细节 |
|------|------|------|------|
| 1 | 发送首封邮件给Abby Carelse (CPO) | 本周 | 主题："Upgrade Scoop PoE to Managed L3 — Marvell Chipset, 73% below MikroTik" |
| 2 | LinkedIn添加Abby Carelse和Timothy Symonds | 本周 | 附言：SmartByte L3 managed switches for Scoop brand |
| 3 | 准备"OEM Scoop品牌管理型交换机"方案书 | 2周内 | 含包装设计概念图、品牌印刷效果图 |
| 4 | 寄送2台样品 | 2周内 | STC-424XGGPM-280W + STC-424XGGM(L3) |
| 5 | 电话跟进 | 3周后 | 拨打+27(0)21 555 4740找CPO Abby |
| 6 | 讨论代理条款 | 1个月后 | 南非+SADC区域独家/非独家 |
| 7 | Securex South Africa展会面谈 | 2027年9月 | 提前3个月预约 |

### 首封邮件模板
```
Subject: Upgrade Scoop PoE to Managed L3 — Marvell Chipset, 73% Below MikroTik

Dear Abby,

I noticed Scoop Distribution already carries its own "Scoop PoE Switches" 
brand alongside MikroTik and Ubiquiti. That tells me you understand the 
value of differentiated product lines.

I'm reaching out from SmartByte Technology — we manufacture Marvell chipset 
managed switches (L3 with BGP/OSPF/ECMP and L2+ with 10G SFP+ uplinks) 
and offer full OEM/ODM services.

Here's what we could do for Scoop:

1. UPGRADE SCOOP BRAND TO MANAGED
   Your current Scoop PoE switches are unmanaged. We can produce Scoop-branded 
   L2+ managed switches (VLAN/QoS/LACP/IGMP + 4×10G SFP+) at $65-140 FOB.
   You could retail at R4,000-7,000 — higher margin than MikroTik CRS328.

2. EXCLUSIVE L3 PRODUCT LINE  
   No brand in your portfolio offers full L3 routing (BGP/OSPF/ECMP/VRRP).
   SmartByte can give Scoop exclusive access to L3 managed switches in 
   the South African market at $210-365 FOB.

3. 73% BELOW MIKROTIK
   Our 24-port PoE managed switch with 4×10G SFP+: $140 FOB
   vs. MikroTik CRS328-24P-4S+: $520 retail
   Your margin jumps from ~15% to 60%+.

We support OEM branding, SKD/CKD for local assembly, and provide CE/FCC 
certification. Our 8,000 sqm factory in Shenzhen uses 98% Marvell chipsets.

Would you like me to send 2 sample units for evaluation? I can also prepare 
a Scoop-branded packaging concept for your review.

Best regards,
[Name]
SmartByte Technology
peter@smartbyte.com.cn | +86-137-1429-3521
```

## 预期订单

| 阶段 | 预估金额 | 说明 |
|------|---------|------|
| 首单（试销） | $5,000-15,000 | 3-5款各10-20台 |
| 稳定供货 | $50,000-100,000/年 | 月度补货 |
| OEM合作后 | $100,000-200,000/年 | Scoop品牌管理型交换机 |
