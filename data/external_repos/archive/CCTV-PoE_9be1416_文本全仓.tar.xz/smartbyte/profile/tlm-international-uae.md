# 客户档案：TLM International FZE — 阿联酋迪拜

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司全称 | TLM International FZE |
| 前身 | Tiger General Trading LLC (1997) |
| 国家 | 阿联酋 Dubai (Jebel Ali Free Zone) |
| 类型 | ICT增值分销商 |
| 网站 | tlmintl.com |
| 成立 | 1997年（29年） |
| 仓储面积 | 350,000 sq ft（3个仓库） |
| SKU | 25,000+ |
| 经销商网络 | 1,500+ |
| 覆盖国家 | 45+ |
| 客户级别 | **A级（核心）** |
| 优先级 | ★★★★★ |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 网站Partner申请 | tlmintl.com → "Become a partner" |
| 地址 | Jebel Ali Free Zone (JAFZA), Dubai |
| LinkedIn | 搜索"TLM International FZE" |

### 关键决策人
| 姓名 | 职位 | 接触策略 |
|------|------|---------|
| **Rajesh Keshwani** | Founder & Managing Director | 创始人，最终决策人 |
| **Manish Keshwani** | Director of Distribution | **首选联系人** — 管分销和品牌引进 |
| **Haresh Israni** | Commercial Director | 商务条款谈判 |
| **Naresh Rangwani** | Director of Sales | 销售合作和渠道策略 |

## 公司深度分析

### 品牌组合
| 品类 | 品牌 |
|------|------|
| 网络设备 | **Ubiquiti, MikroTik, Ruijie, Cudy** |
| 消费IT | HP, Epson, Canon, Acer |
| 自有品牌 | **Lightwave** (IT & Electronics for Africa) |
| 物流 | TLM International Freight Services LLC |

### 战略方向
TLM明确声明要扩展到 **"Enterprise Networking, Memory, Gaming, Security, and PCs"** — SmartByte管理型交换机完美匹配其Enterprise Networking扩展需求！

### 发展里程碑
- 1997: Tiger General Trading在迪拜成立（100sqft办公室）
- 1999: 推出自有品牌"Lightwave"（专注非洲市场）
- 2005: 成立TLM International FZE，转入Jebel Ali Free Zone
- 2013: 正式进入分销领域，引进Ubiquiti和MikroTik
- 2021: 成为HP和Epson高级合作伙伴
- 未来方向: 扩展到西非、东非和沙特阿拉伯

## 需求分析

### 为什么是A级客户？
1. **1,500+经销商网络** — 一旦合作可快速上量
2. **45+国家覆盖** — 中东+非洲+CIS
3. **自有品牌Lightwave** — OEM合作的天然入口
4. **明确要扩展Enterprise Networking** — SmartByte正好填补
5. **25,000+ SKU** — 增加管理型交换机无门槛
6. **350,000 sq ft仓储** — 有能力大批量备货

## 推荐产品方案

### 方案一：OEM Lightwave品牌管理型交换机（首选）

| SmartByte可供型号 | 配置 | FOB价 | 建议Lightwave零售 | 毛利率 |
|-------------------|------|-------|------------------|--------|
| STC-424DGGPM-280W | 24GE PoE + 4×1G SFP | $65 | $180-220 | **64-70%** |
| STC-424XGGPM-280W | 24GE PoE + 4×10G SFP+ | $140 | $350-420 | **60-67%** |
| STC-424XGGM(L3) | 24GE + 4×10G SFP+ (**L3**) | $210 | $450-550 | **53-62%** |
| STC-448XGGPM | 48GE PoE + 4×10G SFP+ | $245 | $550-650 | **55-62%** |

### 核心卖点
1. **"Lightwave品牌管理型交换机"** — "你们已有Lightwave自有品牌，我们帮你做Lightwave管理型交换机"
2. **"填补Enterprise Networking空缺"** — "你们明确要扩展Enterprise Networking品类"
3. **"比Ruijie便宜50%"** — "SmartByte FOB $65起，经销商利润空间更大"
4. **"1500个经销商的新品类"** — "管理型交换机对MSP和ISP是刚需"
5. **"Marvell芯片=企业级"** — "你的HP企业客户认可Marvell芯片方案"

## 竞争分析

| 在TLM的品牌 | 管理型交换机能力 | SmartByte优势 |
|------------|----------------|-------------|
| Ubiquiti | UniFi Switch全系非管理型 | 完整L2+/L3管理型 |
| MikroTik | CRS系列管理型，L3有限 | BGP/OSPF/ECMP更完整 |
| Ruijie | 有管理型，但价格高 | FOB低50%+ |
| Cudy | 非管理型为主 | 填补管理型空缺 |

## 跟进计划

| 阶段 | 行动 | 时间 |
|------|------|------|
| 1 | LinkedIn添加Manish Keshwani和Naresh Rangwani | 本周 |
| 2 | 通过网站提交"Become a Partner"申请 | 本周 |
| 3 | 准备"Lightwave Managed Switch"品牌方案书 | 2周内 |
| 4 | 准备Lightwave包装设计概念图 | 2周内 |
| 5 | 邮件发送OEM合作方案 | 2周后 |
| 6 | 寄送3台样品（含贴牌效果图） | 1个月内 |
| 7 | GITEX Dubai展会面谈 | 2027年10月 |

## 预期订单

| 阶段 | 预估金额 |
|------|---------|
| 首单 | $10,000-30,000 |
| 年供货（SmartByte品牌） | $100,000-200,000 |
| OEM Lightwave品牌后 | $200,000-500,000/年 |
