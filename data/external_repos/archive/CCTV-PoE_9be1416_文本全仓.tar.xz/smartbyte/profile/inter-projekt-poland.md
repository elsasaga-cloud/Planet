# 客户档案：Inter Projekt S.A. — 波兰

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司全称 | Inter Projekt S.A. |
| 国家 | 波兰 Gliwice |
| 类型 | 网络设备进口分销商 |
| 网站 | interprojekt.pl / ip-sa.com.pl |
| 成立 | 20年+ |
| 客户级别 | **A级（核心）** |
| 优先级 | ★★★★★ |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 订单邮箱 | orders@interprojekt.pl |
| 技术支持 | pomoc@ip-sa.pl |
| 电话 | +48 32 3022 910 / +48 32 3022 920 |
| 技术支持 | +48 32 3022 925 |
| 手机 | +48 516 138 312 |
| 销售 | +48 32 3022 937 |
| 传真 | +48 32 335 1249 |
| 地址 | Wyczółkowskiego 10, 44-109 Gliwice, Poland |
| LinkedIn | linkedin.com/company/inter-projekt-s.a. |
| Facebook | facebook.com/interprojekt.sa |
| Instagram | @interprojektsa |
| Twitter | @InterProjekt |

## 公司深度分析

### 品牌组合
Ubiquiti, MikroTik, TP-Link, Mercusys, Tenda, RF Elements, Mantar, Optic, Lanberg

### 产品品类（管理型交换机相关）
| 品类 | 在售品牌 |
|------|---------|
| 管理型交换机 | **MikroTik (Managed)**, Ubiquiti UniFi |
| PoE交换机 | **MikroTik (PoE-Switches)**, Ubiquiti |
| 非管理型 | MikroTik, TP-Link, Mercusys, Tenda |
| SFP模块 | MikroTik, Ubiquiti |
| 无线AP | Ubiquiti UniFi全系, MikroTik |
| 路由器 | Ubiquiti EdgeMAX, MikroTik |

### 管理型交换机在售型号（MikroTik）
| 型号 | 端口 | 价格区间 |
|------|------|---------|
| CRS326-24G-2S+RM | 24GE + 2×10G SFP+ | ~€180 |
| CRS328-24P-4S+RM | 24GE PoE + 4×1G SFP+ | ~€450 |
| CRS320-8P-8B-4S+RM | 8GE PoE + 8×2.5G + 4×10G | ~€350 |
| CRS354-48P-4S+2Q+RM | 48GE PoE + 4×10G + 2×40G | ~€800 |
| CRS418-8P-8G-2S+RM | 8GE PoE + 8GE + 2×10G | ~€300 |

## 需求分析

### 波兰/东欧ISP市场
- 波兰是东欧最大的ISP市场之一
- MikroTik是波兰ISP首选交换机品牌
- 管理型交换机需求旺盛
- 价格敏感度中等偏高

### 痛点
1. MikroTik管理型交换机利润率有限（15-25%）
2. 无L3交换机（MikroTik L3有限）
3. Ubiquiti UniFi Switch全系非管理型
4. 需要差异化产品线

## 推荐产品方案

| SmartByte型号 | 配置 | FOB | 对标MikroTik | MikroTik€零售 | 价差 |
|---------------|------|-----|-------------|-------------|------|
| STC-424XGGM | 24GE + 4×10G | $100 | CRS326-24G-2S+ (€180) | €180 | **低50%** |
| STC-424DGGPM-280W | 24GE PoE + 4×1G SFP (AC5爆款) | $65 | CRS328-24P (€450) | €450 | **低87%** |
| STC-424XGGPM-280W | 24GE PoE + 4×10G | $140 | CRS328-24P-4S+ (€450) | €450 | **低73%** |
| STC-424XGGM(L3) | 24GE + 4×10G (**L3**) | $210 | 无 | — | **独占** |

### 核心卖点
1. **"比MikroTik CRS328低87%"** — STC-424DGGPM-280W FOB $65 vs CRS328 €450
2. **"填补L3空白"** — 波兰市场无L3管理型交换机在Inter Projekt产品线中
3. **"Marvell芯片"** — 企业级可靠性
4. **"波兰独家分销"** — 成为SmartByte波兰独家代理
5. **"20年分销经验"** — 成熟渠道，快速上量

### 跟进策略
1. 邮件发orders@interprojekt.pl + 销售电话+48 32 3022 937
2. LinkedIn联系公司页面
3. 准备MikroTik对标表（€价格）
4. 提供波兰独家代理方案
5. 提供CE/UKCA认证文件

## 预期订单

| 阶段 | 预估金额 |
|------|---------|
| 首单 | $5,000-20,000 |
| 年供货 | $50,000-150,000 |
