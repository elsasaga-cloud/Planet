# Batch 36 — 矩阵深挖：太阳能PoE + 医疗 + 零售POS + LED照明 + 数字标牌 + 高加索 + 中亚

**日期**: 2026-10-25  
**搜索轮次**: Round 124-128  
**新增客户/情报**: 42 家  
**方法论**: 行业 × 地区 × 应用 多维交叉搜索

---

## ☀️ 一、太阳能/离网 PoE (Solar/Off-Grid)

### 1. Linovision (中国+美国+欧盟)
- **类型**: A类 - 太阳能PoE专家
- **网站**: linovision.com / eu.linovision.com
- **产品**:
  - POE-SW505GD: 5口太阳能PoE (电压升压 9-57V, 远程DI重启, 行业首创)
  - POE-SW805G5U-Solar: 5口内置太阳能充电控制器
  - POE-SW806GM-Solar: L2管理太阳能PoE (内置MPPT, $369)
  - 4口MPPT太阳能PoE ($219)
- **特点**: NDAA合规, 远程电池监控, 工业级
- **应用**: 安防摄像头, IoT设备, 无线桥接
- **开发策略**: 中国+美国太阳能PoE专家 ★★★★★

### 2. LanaoTek (深圳)
- **类型**: A类 - 太阳能工业PoE OEM/ODM
- **网站**: lanaotek.com
- **产品**: 太阳能户外PoE交换机, 4/8/16/24口
- **特点**: DIN-Rail + IP67, OEM/ODM, 全球B2B
- **覆盖**: 美国, 欧盟, 中东
- **开发策略**: 深圳太阳能工业PoE OEM ★★★★★

### 3. Tycon Systems (美国)
- **类型**: B类 - 远程太阳能+监控
- **网站**: tyconsystems.com
- **产品**: 远程太阳能系统, 移动监控拖车, PoE方案
- **应用**: 安防, 无线, 公用事业, 工业, 远程基础设施
- **开发策略**: 美国远程太阳能PoE ★★★★★

### 4. FICOTEK (深圳)
- **类型**: A类 - 太阳能PoE远程监控
- **网站**: ficotek.cn
- **公司**: 深圳飞科特光电有限公司, 13+年经验
- **产品**: 太阳能PoE交换机 (工业温度, 防雷, 轻管理)
- **特点**: OEM/ODM, VLAN/QoS/RSTP/ERPS/SNMP, 1年换3年保终身技术支持
- **应用**: 安防, 能源, 风电, 铁路
- **开发策略**: 深圳太阳能PoE OEM ★★★★★

### 5. Planet Technology 太阳能系列 (台湾)
- **类型**: B类 - 太阳能PoE
- **产品**:
  - BSP-115HP-5A: 5口混合太阳能PoE + 1xSFP ($262.50)
  - BSP-115PV-15A: 5口802.3at PoE+ 太阳能 + LCD显示 ($345)
  - BSP-360: 太阳能+风能 (已停产)
- **开发策略**: 台湾太阳能PoE ★★★★☆

### 6. Ubiquiti SunMAX SolarSwitch
- **类型**: B类 - 太阳能PoE
- **产品**: SM-SW-40 (MPPT充电控制器 + 4口24V PoE, $234.35)
- **特点**: 远程管理, 24V PoE
- **开发策略**: Ubiquiti 太阳能PoE ★★★★☆

### 7. MokerLink (中国)
- **类型**: A类 - 太阳能工业PoE
- **产品**: IND-G041GSPW (5口千兆工业太阳能电池UPS PoE)
- **特点**: DIN-Rail, IP40
- **开发策略**: 中国太阳能工业PoE ★★★★☆

### 8. Netonix (美国)
- **类型**: B类 - DC输入PoE
- **产品**: WS-8-150-DC (DC输入PoE交换机, WISP推荐)
- **开发策略**: 美国DC输入PoE WISP ★★★★☆

### 9. Inscape Data / PoE Super Store (美国)
- **类型**: B类 - 户外PoE制造
- **网站**: poesuperstore.com
- **成立**: 2004年, 美国制造
- **产品**: 户外千兆PoE交换机, 无线, IP视频系统
- **开发策略**: 美国户外PoE制造 ★★★★★

### 10. Throncom (中国)
- **类型**: A类 - 工业光纤太阳能PoE
- **产品**: Mini 4口千兆工业光纤以太网太阳能PoE (升压9-58V到48V, 90W, SFP, LNK-IMC103GP-SFP)
- **开发策略**: 中国工业光纤太阳能PoE ★★★★☆

### 11. Wi-Tek (太阳能PoE)
- **类型**: B类 - 太阳能PoE
- **产品**: 太阳能输入, 电池, 可选DC输入 (WISP Reddit推荐)
- **开发策略**: Wi-Tek 太阳能PoE ★★★★☆

---

## 🏥 二、医疗 PoE

### 12. NVT Phybridge (加拿大)
- **类型**: B类 - 医疗PoE
- **网站**: nvtphybridge.com
- **产品**: PoE交换机 (热插拔电源, 功率冗余, 每口50W)
- **特点**: 利用现有Coax/UTP布线
- **开发策略**: 加拿大医疗PoE ★★★★★

### 13. PROCET PoE医疗方案 (中国)
- **类型**: A类 - 医疗PoE供电
- **网站**: procetpoe.com
- **产品**: 医疗PoE供电设备 + PoE to USB Type-C适配器 (60W)
- **特点**: 802.3bt 60W~100W, 支持医疗电机/医生办公设备
- **应用**: 智慧医院信息化
- **开发策略**: 中国医疗PoE供电 ★★★★★

### 14. Clarke County Hospital + Cisco UPOE+ (美国)
- **类型**: B类 - 医院PoE照明案例
- **方案**: Cisco Catalyst UPOE+ (90W) + GENISYS照明 + Panduit布线
- **特点**: 利用现有IT网络布线, 自管理部署
- **开发策略**: 美国医院PoE照明案例 ★★★★★

### 15. Thinlabs (美国)
- **类型**: B类 - PoE一体机
- **网站**: thinlabs.com
- **产品**: PoE供电一体机PC (PoE+或PoE++)
- **应用**: 医疗(护士站/患者登记/推车), 教育, 政府, 制造, 零售
- **开发策略**: 美国PoE一体机医疗 ★★★★★

---

## 🛒 三、零售/POS PoE

### 16. Versa Technology 零售方案
- **类型**: B类 - 零售PoE
- **产品**: D60-044 管理工业交换机
- **应用**: POS系统, 数字标牌, 自助结账, 客流分析
- **特点**: 极端条件, UPS供电持续
- **开发策略**: 美国零售PoE ★★★★★

### 17. Newbridge 零售连锁方案 (中国)
- **类型**: B类 - 零售连锁PoE
- **方案**: 主PoE交换机 → POS(VLAN10) + 监控(VLAN20) + AP(VLAN30)
- **要求**: POS延迟≤50ms, 监控2-4Mbps/路
- **开发策略**: 中国零售连锁PoE ★★★★★

### 18. Shade Innovations (美国)
- **类型**: B类 - 1kW PoE
- **产品**: 1K PoE交换机 (1000W, 8口90W或24口30W)
- **发布**: CEDIA 2025, 2025年9月
- **特点**: 4倍同类产品功率
- **开发策略**: 美国1kW PoE ★★★★☆

---

## 💡 四、PoE LED 照明

### 19. Versa Technology PoE LED
- **类型**: B类 - PoE照明
- **产品**: VX-GPU2626 (V2) L2+ 24口UPOE 2000W ($1995)
- **伙伴**: IGOR Nexos (IoT平台), Genisys (Innovative Lighting)
- **开发策略**: 美国PoE LED照明 ★★★★★

### 20. IGOR Nexos (美国)
- **类型**: B类 - PoE照明IoT
- **产品**: Nexos IoT平台 (围绕PoE架构, 照明+楼管)
- **认证**: Versatek认证伙伴
- **开发策略**: 美国PoE照明IoT ★★★★★

### 21. Genisys / Innovative Lighting (美国)
- **类型**: B类 - PoE照明
- **产品**: 集成软件自动化照明, 日光收集
- **开发策略**: 美国PoE照明 ★★★★★

### 22. PoE Texas LED照明
- **类型**: B类 - PoE照明套件
- **产品**:
  - AT-WS-W1: 动能无线墙开关 (无需电池)
  - AT-LED-24V: 24V PoE+ LED驱动
  - AT-LED-24V-DISC: PoE照明套件 (驱动+2x6000K吸顶灯+无线开关)
- **开发策略**: 美国PoE照明套件 ★★★★★

### 23. Signify (Philips Lighting, 荷兰)
- **类型**: 竞品 - PoE照明
- **产品**: PoE灯具系列 (集成传感器+边缘控制, 2024发布, 20+园区)
- **开发策略**: Philips PoE照明竞品 ★★★★☆

### 24. Microchip/Microsemi PoE照明
- **类型**: B类 - PoE照明交换
- **产品**: PDS-408G (8口 60W/口 480W total $980), PDS-208G (8口 240W fanless)
- **应用**: 数字天花板, 智能楼宇, LED照明
- **开发策略**: Microchip PoE照明 ★★★★★

### 25. Transition Networks/Lantronix PoE照明
- **类型**: B类 - PoE++照明
- **产品**: SM24TBT2DPA (24口管理千兆PoE++ 90W/口, 双热插拔电源 1560W)
- **应用**: 智能LED照明
- **开发策略**: Lantronix PoE++照明 ★★★★★

---

## 📺 五、PoE 数字标牌

### 26. Ubiquiti UniFi Connect
- **类型**: B类 - PoE数字标牌
- **产品**: Display Cast Pro (增强播放+USB-C), Display Cast Lite, Connect Display (PoE++触摸屏)
- **开发策略**: Ubiquiti PoE数字标牌 ★★★★★

### 27. Winmate (台湾)
- **类型**: B类 - PoE触摸显示器
- **产品**: PoE Touch Monitor (工业/数字标牌, 无需额外电源)
- **开发策略**: 台湾PoE触摸显示器 ★★★★★

### 28. GPO Display (美国加州)
- **类型**: B类 - PoE全景LCD
- **产品**:
  - PoE Panoramic LCDs (最大50")
  - POE57D: 57" 3840x430 全景显示
- **合规**: TAA (美国政府)
- **开发策略**: 美国PoE全景LCD ★★★★★

### 29. Bluefin Digital (美国)
- **类型**: B类 - PoE数字标牌
- **成立**: 2017年PoE数字标牌先驱
- **产品**: PoE+供电数字标牌 (最大15.6", 300ft Cat5e)
- **开发策略**: 美国PoE数字标牌 ★★★★★

### 30. SSA Electronic (深圳)
- **类型**: A类 - PoE数字标牌
- **网站**: ssa-digital.com
- **产品**: PoE数字标牌 (10.1"~21.5"+)
- **标准**: 802.3af (15.4W) / 802.3at (25.5W) / 802.3bt (71.3W)
- **开发策略**: 深圳PoE数字标牌 ★★★★★

### 31. Enable-IT (美国)
- **类型**: B类 - PoE延长器数字标牌
- **网站**: enableit.com
- **成立**: 2000年
- **产品**: 长距离以太网/PoE延长器 (数字亭, 商场, EV充电, 电梯, 家庭影院)
- **开发策略**: 美国PoE延长器数字标牌 ★★★★★

### 32. Visual Productions (荷兰)
- **类型**: B类 - 灯光控制PoE
- **产品**: PoeSwitch (4口DIN轨 60W $400, InfoComm 2024)
- **应用**: 灯光控制系统
- **开发策略**: 荷兰灯光PoE ★★★★☆

---

## 🚪 六、PoE 门禁

### 33. Borer Data Systems (英国)
- **类型**: B类 - PoE门禁
- **产品**: PoE门禁控制器 (1口/2口), PoE交换机, PoE Midspan Bridge V2
- **特点**: 300米CAT5/6, 防火墙隔离, 消防面板联动
- **开发策略**: 英国PoE门禁 ★★★★★

### 34. Paragon Security (英国)
- **类型**: B类 - PoE门禁
- **产品**: 2口PoE门禁控制器 (电锁/磁锁/门磁/闸机)
- **开发策略**: 英国PoE门禁 ★★★★☆

### 35. Altronix (美国)
- **类型**: B类 - PoE电源
- **产品**: Tango Series PoE驱动电源 (12VDC+24VDC via 802.3bt)
- **开发策略**: 美国PoE门禁电源 ★★★★★

---

## 🇬🇪 七、高加索地区 PoE (格鲁吉亚/亚美尼亚/阿塞拜疆)

### 36. Takopi Group (格鲁吉亚)
- **类型**: C类 - NETGEAR独家
- **网站**: takopi.ge
- **品牌**: NETGEAR (格鲁吉亚独家分销)
- **产品**: PoE++交换机, Wi-Fi 6/6E, AVoIP (M4250/M4350)
- **特点**: 终身保修, ProSUPPORT
- **开发策略**: 格鲁吉亚NETGEAR独家 ★★★★★

### 37. NETIS (格鲁吉亚)
- **类型**: C类 - 多品牌
- **网站**: netis.ge
- **地点**: Tbilisi, 4 Lekh Kachinski St
- **产品**: Dahua PFS3008-8GT-60 (198 GEL), S3226-24ET-240 (140 GEL), Ruijie RG-ES218GC-P (904 GEL)
- **开发策略**: 格鲁吉亚多品牌PoE ★★★★★

### 38. GLM (格鲁吉亚)
- **类型**: C类 - ONV
- **网站**: glm.ge
- **产品**: ONV GLMH1064PL (6口 4PoE + 2 uplink 60W 250米)
- **开发策略**: 格鲁吉亚ONV PoE ★★★★☆

---

## 🌍 八、中亚 PoE (哈萨克斯坦/乌兹别克斯坦)

### 39. Marvel Kazakhstan LLP
- **类型**: C类 - Cisco分销
- **产品**: Cisco Catalyst 3650 (24口/48口PoE), 2960L (24口PoE)
- **开发策略**: 哈萨克斯坦Cisco分销 ★★★★★

### 40. TOO Komptek (哈萨克斯坦)
- **类型**: C类 - Cisco
- **产品**: Cisco SF350-48P (48口10/100 PoE), SG350-52P (52口千兆PoE), 2960L (8口PoE)
- **开发策略**: 哈萨克斯坦Cisco PoE ★★★★★

### 41. Distribution Center Ying Ko (哈萨克斯坦)
- **类型**: C类 - Cisco
- **产品**: Cisco Catalyst 3650 (24口PoE 4x1G), 2960-X (24口PoE 370W)
- **开发策略**: 哈萨克斯坦Cisco PoE ★★★★☆

### 42. 乌兹别克斯坦PoE进口情报
- **类型**: 市场情报
- **数据**: 2025年271批8口PoE进口, 39活跃进口商, $1.55M
- **来源**: Export Genius
- **开发策略**: 乌兹别克斯坦PoE市场情报 ★★★★★

---

## 📊 Batch 36 统计

- **新增客户/情报**: 42 家
- **覆盖国家**: +5 (格鲁吉亚, 哈萨克斯坦, 乌兹别克斯坦, 加拿大, 荷兰)
- **新增行业**: 太阳能/离网PoE, 医疗PoE, LED照明PoE, 数字标牌PoE, 门禁PoE, 零售POS

---

## 🎯 关键发现

1. **太阳能PoE**: Linovision (中国+美国+欧盟), LanaoTek, Tycon, FICOTEK (深圳13年), Planet, Ubiquiti SunMAX, MokerLink, Netonix, Inscape Data, Throncom, Wi-Tek
2. **医疗PoE**: NVT Phybridge (加拿大), PROCET (中国), Clarke County+Cisco UPOE+, Thinlabs (PoE一体机)
3. **零售PoE**: Versa Technology, Newbridge, Shade Innovations 1kW
4. **LED照明PoE**: Versatek (2000W), IGOR Nexos, Genisys, PoE Texas, Signify/Philips, Microchip PDS-408G, Lantronix SM24TBT2DPA
5. **数字标牌PoE**: Ubiquiti Connect, Winmate, GPO Display (TAA), Bluefin, SSA Electronic (深圳), Enable-IT, Visual Productions
6. **门禁PoE**: Borer (英国), Paragon, Altronix Tango
7. **高加索**: Takopi Group (格鲁吉亚NETGEAR独家), NETIS (格鲁吉亚), GLM (格鲁吉亚ONV)
8. **中亚**: Marvel Kazakhstan, TOO Komptek, Distribution Center Ying Ko (哈萨克斯坦), 乌兹别克斯坦39进口商$1.55M

---

## 📈 累计统计

- **总客户/情报数**: 1,053 家 (1011 + 42)
- **覆盖国家**: 90+ 国家
- **Git 提交**: 37 次
- **超额完成**: 142% (目标 26 commits)
