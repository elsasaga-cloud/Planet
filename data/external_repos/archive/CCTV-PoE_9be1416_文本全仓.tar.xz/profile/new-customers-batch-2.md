# 第二批新客户档案 — 深度挖掘

> 挖掘日期：2026-09-22  
> 新增客户：约30家，覆盖东非/越南/泰国/Amazon D2C/东欧/俄罗斯/拉美

---

## 一、东非市场（肯尼亚/尼日利亚）— 7家新发现

### 1. I KEN Computers Limited (肯尼亚) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 肯尼亚（+津巴布韦） |
| 类型 | Hikvision国家分销商 |
| 产品 | CCTV、门禁、对讲、线缆、**交换机**、硬盘 |
| 电话 | +254 720 617 943 / +254 725 150 304 |
| 邮箱 | ikencomputerske@gmail.com |
| 网站 | ikencomputers.co.ke |
| 级别 | **A级** |

**推荐Saga产品**：STC-028GFP ($17.6) + STC-1216GFP ($44) + STC-1224GFP ($60.5)
**对标竞品**：Hikvision DS-3E1510P-SI (KSh 24,000 = ~$185) vs Saga STC-028GFP ($17.6) → **低90%**
**卖点**：①Hikvision国家分销商，PoE交换机配套刚需 ②覆盖肯尼亚+津巴布韦 ③比Hikvision PoE便宜90%

---

### 2. Sapphire Trading and Marketing Ltd (肯尼亚) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 肯尼亚 |
| 成立 | 1996年（30年历史！） |
| 类型 | Hikvision国家分销商、电子产品进口商 |
| 产品 | CCTV、门禁、对讲、报警、线缆、**交换机**、硬盘 |
| 电话 | +254 795 705 335 |
| 邮箱 | Info@sapphire.co.ke |
| 网站 | sapphire.co.ke |
| 级别 | **A级** |

**推荐Saga产品**：全系列非管理型PoE + PoE延长器
**卖点**：①30年历史的进口商/分销商 ②覆盖肯尼亚+东非市场 ③已有交换机品类

---

### 3. Secure Digital Limited (肯尼亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 肯尼亚 (Nairobi) |
| 类型 | Hikvision授权国家分销商 |
| 产品 | CCTV、门禁、对讲、报警、线缆、**交换机** |
| 网站 | securedigitallimited.com / hikvisionkenya.com |
| 特点 | 进口+供应+安装+维护全覆盖 |
| 级别 | **A级** |

**推荐Saga产品**：STC-028GFP + STC-1216GFP + STC-1224GFP + PoE延长器
**卖点**：①Hikvision授权国家分销商 ②进口+安装全产业链 ③PoE交换机配套需求大

---

### 4. CCTV Shop Kenya ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 肯尼亚 (Nairobi) |
| 类型 | Hikvision授权经销商 |
| 产品 | Hikvision全线（含PoE交换机在售！） |
| 电话/WhatsApp | +254 111 042 000 |
| 网站 | cctvshopkenya.co.ke |
| 在售PoE交换机 | DS-3E1510P-SI (KSh 24,000), DS-3E1526P-SI (KSh 61,000), DS-3E1552P-SI (KSh 91,000) |
| 级别 | **A级** |

**推荐Saga产品及对标**：
| Hikvision在售 | 售价(KSh) | 折合USD | Saga替代 | Saga FOB | 价差 |
|--------------|----------|---------|---------|---------|------|
| DS-3E1510P-SI 8口千兆PoE | 24,000 | $185 | STC-228GP (12口千兆PoE+SFP) | $30.8 | **低83%** |
| DS-3E1526P-SI 24口千兆PoE | 61,000 | $470 | STC-2024GP (24口千兆PoE) | $93.5 | **低80%** |
| DS-3E1552P-SI 48口千兆PoE | 91,000 | $700 | 无精确48口千兆PoE（最近似STC-448XGGPM $368.5） | $368.5 | **低47%** |

**卖点**：①**已在卖Hikvision PoE交换机** — 直接替代 ②价格碾压Hikvision 80-83% ③WhatsApp直联

---

### 5. Microview Nigeria ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 尼日利亚 |
| 成立 | 1995年（31年！） |
| 类型 | 增值分销商 |
| 产品 | 监控、网络设备、IT基础设施 |
| 品牌 | Hikvision, MikroTik, Ubiquiti, Cisco, D-Link, Cambium |
| 网站 | microviewng.com |
| 级别 | **A级** |

**推荐Saga产品**：全系列非管理PoE + 管理型 + PoE延长器
**卖点**：①31年历史的尼日利亚头部分销商 ②已有PoE交换机品类 ③覆盖全非洲 ④多品牌经营易切入

---

### 6. Stanificent Global Technologies (尼日利亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 尼日利亚 (Benin City/Lagos/Abuja) |
| 类型 | Hikvision PoE交换机经销商 |
| 网站 | stanificentglobal.com |
| 特点 | 全国配送，已在卖Hikvision 8口PoE交换机 |
| 级别 | **B级** |

**推荐Saga产品**：STC-028FP ($13.75) + STC-028GFP ($17.6)
**卖点**：①已在卖Hikvision PoE ②全国配送网络

---

### 7. BOW Dynamic System Ltd (尼日利亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 尼日利亚 (Lagos, Ajah) |
| 类型 | 安防+ICT集成商/分销商 |
| 品牌 | Pelco, Milestone, TYCO, Axis, BOSCH, Honeywell |
| 覆盖 | 尼日利亚+西非 |
| 级别 | **B级** |

**推荐Saga产品**：STC-228GP ($30.8) + STC-1216GFP ($44) + 管理型系列
**卖点**：①西非区域覆盖 ②高端品牌配套需求

---

## 二、越南市场 — 6家新发现

> **关键数据**：越南是全球PoE交换机进口第2大国（17,852批/年），仅次于印度！

### 8. LEHOANG Trading Technology Co., Ltd (越南) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 越南 (Ho Chi Minh City) |
| 成立 | 2002年（24年！） |
| 类型 | Hikvision国家分销商（越南CCTV行业领军进口商/分销商） |
| 电话 | +84-28 3981 2099 |
| 邮箱 | info@lehoangcctv.com |
| 网站 | lehoangcctv.com |
| 特点 | 越南最广泛的CCTV分销网络 |
| 级别 | **A级** |

**推荐Saga产品**：全系列非管理PoE + PoE延长器 + 光纤收发器
**卖点**：①越南最大CCTV分销商之一 ②24年行业经验 ③全国分销网络 ④PoE交换机是刚需配套

---

### 9. Phuong Viet Group (越南) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 越南 (Hanoi + HCM) |
| 成立 | 2008年 |
| 类型 | Hikvision国家授权分销商 |
| 产品 | 监控摄像头、DVR/NVR、门禁、报警、对讲 |
| 地址 | 总部: No. 88-90 Yen Lang, Dong Da, Hanoi / 分部: No. 319 Ly Thuong Kiet, HCM |
| 级别 | **A级** |

**推荐Saga产品**：全系列非管理PoE
**卖点**：①Hikvision越南授权国代 ②南北双总部覆盖 ③以服务质量为核心

---

### 10. Secure House JSC (越南) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 越南 (Hanoi + HCM) |
| 成立 | 2000年（26年！） |
| 类型 | 安防设备进口商/分销商 |
| 品牌 | Hikvision, RISCO GROUP, HYUNDAI TELECOME, AOLIN |
| 分销网络 | 63个省市数百个Master Dealer + SI + Small Dealer |
| 特点 | 越南最大安防设备进口商/分销商之一 |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE + 光纤收发器 + PoE延长器
**卖点**：①26年历史 ②63个省市分销网络 ③多品牌经营 ④大量进口经验

---

### 11. KBT Vietnam / Kabe Group ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 越南 (HCM + Hanoi) |
| 类型 | CCTV-IT-消防专业进口分销商 |
| 愿景 | 成为越南及区域CCTV/IT/消防领域领先专业进口分销商 |
| 总部 | Kabe Building, 104 Nguyen Xi, Binh Thanh, HCM |
| 北方分部 | Thinh Liet, Hoang Mai, Hanoi |
| 电话 | 0932 685 008 (HCM) / 0932 685 158 (Hanoi) |
| 网站 | kabegroup.vn |
| 策略 | 大量进口+仓储以获取最优价格 |
| 级别 | **A级** |

**推荐Saga产品**：全系列非管理PoE（大量进口走量）
**卖点**：①"大量进口+仓储"策略与HRUI低价策略完美匹配 ②南北双仓覆盖 ③CCTV+IT+消防全品类

---

### 12. SLA Vietnam Company Limited (越南) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 越南 |
| 类型 | IT网络设备分销商 |
| 品牌 | Cisco, HPE, Aruba, ShareTech, TP-Link, Ubiquiti, MikroTik, Zyxel, Extreme |
| 产品 | **L2/L3交换机、PoE交换机（管理型/非管理型）** |
| 网站 | sla.vn |
| PoE交换机在售 | ShareTech CCTV PoE Switch (4/8/16/24/48口) |
| 级别 | **A级**（管理型+非管理型双线） |

**推荐Saga产品**：非管理型PoE + Marvell管理型（STC-424XGGM等）
**卖点**：①越南IT交换机专业分销商 ②已有PoE交换机品类 ③管理型+非管理型双线需求

---

### 13. Cticom Technology & Communications (越南) ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 越南 (Hanoi) |
| 类型 | 安防系统设计/供应/安装 |
| 产品 | CCTV、报警、门禁、消防、视频会议、PA系统、智能家居 |
| 级别 | **B级** |

---

## 三、泰国/缅甸市场 — 3家新发现

### 14. CCTV (Thailand) Co., Ltd. ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 泰国 (Bangkok) |
| 类型 | CCTV系统集成商/分销商 |
| 品牌 | BOSCH（官方分销）、Panasonic、Tamron |
| 客户 | 政府机关（ICT部、教育部）+ 企业 |
| 级别 | **B级** |

---

### 15. JES CQTEC Co., Ltd. (泰国) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 泰国 (Bangkok) |
| 类型 | IDIS授权分销商，安防设备进口分销 |
| 地址 | 1083 Srinakarin Road, Suanluang, Bangkok 10250 |
| 电话 | +66 02-322-3801 |
| 网站 | jescqtec.com |
| 级别 | **B级** |

---

### 16. Winner Crystal Trading Co., Ltd. (缅甸) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 缅甸 |
| 成立 | 2008年 |
| 类型 | CCTV/安防/网络设备分销商 |
| 品牌 | **Dahua授权分销**(2016起), TP-Link, ZKTeco, Panasonic, Ruijie |
| 产品 | CCTV、报警、消防、PABX、门禁、网络配件 |
| 网站 | winnercrystal.org |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE + PoE延长器
**卖点**：①Dahua授权分销(PoE配套) ②Ruijie网络设备线 ③16年历史

---

## 四、Amazon D2C品牌（OEM机会）— 4家新发现

### 17. UGREEN Group Limited ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 中国深圳 / Amazon全球销售 |
| 类型 | 消费电子品牌（Amazon头部卖家） |
| Amazon卖家评分 | 4.9/5 (172,000+ 评价!) |
| 当前PoE交换机 | 10口(8PoE+2上联) $38-50, 6口(4PoE+2上联) |
| 制造商 | Ugreen Group Limited |
| 特点 | 金属壳、VLAN、Extend模式、PoE Auto Recovery |
| 级别 | **A级（OEM大客户）** |

**OEM合作机会**：
| UGREEN在售 | 零售价 | Saga可供型号 | Saga FOB | 毛利空间 |
|-----------|--------|-------------|---------|---------|
| 10口PoE (8PoE+2GE) | $38-50 | STC-028GFP (2GE+8PoE) | $17.6 | **55-65%** |
| 6口PoE (4PoE+2GE) | ~$30 | STC-024GP (2GE+4GE PoE) | $18.7 | **38-47%** |

**卖点**：①Amazon PoE交换机头部品牌 ②产品线可扩展（16口/24口PoE） ③Saga金属壳+VLAN+250米Extend模式与UGREEN产品特性高度吻合 ④巨大销量潜力

---

### 18. BV Security / BV-Tech (美国) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 美国 |
| 类型 | PoE交换机专业品牌 |
| 网站 | bvsecurity.com |
| Amazon产品线 | 6口/8口/16口PoE交换机 + 工业DIN导轨PoE + PoE注入器 |
| 特点 | PoE全线专业品牌，部分产品Made in Taiwan |
| 级别 | **A级（OEM/供货合作）** |

**推荐合作**：
| BV-Tech在售 | 零售价 | Saga可供型号 | Saga FOB |
|------------|--------|-------------|---------|
| 8口PoE+2GE 120W | ~$69 | STC-228GP (2SFP+2GE+8PoE 120W) | $30.8 |
| 16口PoE长距离 | ~$120 | STC-2016GP (2SFP+16PoE 300W) | $88 |
| 8口工业DIN PoE | ~$100 | HR工业级系列 | 询价 |

---

### 19. PoE Texas (美国) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 美国 (Texas) |
| 类型 | PoE设备专业品牌 |
| 产品 | PoE交换机、注入器、分离器 |
| 特点 | PoE细分市场专家 |
| 级别 | **B级** |

---

### 20. Security Camera King (美国) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 美国 |
| 类型 | 安防设备直销商 |
| 网站 | securitycameraking.com |
| 产品 | 自有品牌Elite系列PoE交换机（管理型ePoE/PoE/Hi-PoE） |
| 价格 | 24口管理型 $692 |
| 级别 | **B级（OEM机会）** |

---

## 五、东欧/俄罗斯/CIS — 5家新发现

> **关键数据**：哈萨克斯坦PoE交换机进口4,759批/年（全球第3！），俄罗斯1,636批/年

### 21. Fort Telecom / TFortis (俄罗斯) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 俄罗斯 (Perm) |
| 成立 | 2007年 |
| 类型 | IP视频监控网络设备开发商/供应商 |
| 品牌 | TFortis（自有品牌PoE交换机） |
| 覆盖 | 俄罗斯、CIS、欧洲、土耳其、海湾国家 |
| 电话 | +7 (342) 270-112-8 |
| 网站 | tfortis.com |
| 特点 | Made in Russia, -60°C~+50°C工作温度, IP66防爆 |
| 级别 | **A级（合作/OEM）** |

**合作模式**：①TFortis专注工业/户外极端环境，Saga可提供商用级产品互补 ②CIS区域渠道合作 ③OEM供货

---

### 22. AETEK (波兰/波罗的海) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 波兰 + 波罗的海国家 |
| 类型 | CCTV PoE网络设备分销商 |
| 网站 | cctvbaltic.pl |
| 产品 | PoE交换机（L2/L2+管理型）、天花板安装交换机、工业交换机 |
| 品牌 | AETEK（集成Milestone/Avigilon VMS） |
| 特点 | NDAA/TAA合规，天花板专利安装 |
| 级别 | **B级** |

---

### 23. Janex International (波兰) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 波兰 |
| 成立 | 1992年（34年！） |
| 类型 | 报警系统/CCTV进口商/分销商 |
| 覆盖 | 波兰+境外 |
| 级别 | **B级** |

---

### 24. AAT Holding sp. z o.o. (波兰) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 波兰 (Warsaw) |
| 类型 | CCTV分销商 |
| 级别 | **B级** |

---

### 25. Rovision / SC Cristal SRL (罗马尼亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 罗马尼亚 |
| 类型 | ICT公司 / CCTV设备进口商 |
| 品牌 | Dahua、Hikvision授权分销 |
| 网站 | rovision.ro |
| 特点 | 7年+进口经验 |
| 级别 | **B级** |

**推荐Saga产品**：全系列PoE（对标Dahua/Hikvision PoE）

---

## 六、拉美市场补充

> **市场数据**：拉美PoE交换机市场增长7.5%/年，巴西和墨西哥是主力

### 26. Eagle Eye Networks (拉美) ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 美国/拉美 |
| 类型 | 云监控VMS + 自有PoE交换机 |
| 拉美联系 | +52 55 8526 4926 |
| 邮箱 | latam@een.com |
| 特点 | 自有管理型PoE交换机（Gigabit + 100Mbps） |
| 级别 | **B级** |

---

## 七、英国市场

### 27. Netview CCTV (英国) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 英国 (Leicester) |
| 类型 | 安防贸易批发商 |
| 网站 | netviewcctv.co.uk |
| 产品 | **PoE交换机78+款在售!** Reyee/Ruijie + Vigitron + Veracity |
| 特点 | 仓库现货，当日发货 |
| 级别 | **A级** |

**推荐Saga产品**：全系列非管理PoE
**卖点**：①78+款PoE交换机在售说明需求极大 ②英国安防贸易批发商 ③比Reyee/Ruijie低50-60%

---

### 28. Euro CCTV (英国) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 英国 |
| 类型 | CCTV设备贸易供应 |
| 网站 | eurocctv.co.uk |
| PoE交换机在售 | Dahua PFS4218-16ET-240 (16口管理型PoE, 240W, 250m) |
| 级别 | **B级** |

**推荐Saga产品**：STC-1216GFP ($44) 对标Dahua 16口PoE
**卖点**：①250米传输与Dahua同级 ②价格低70%+

---

## 八、全球PoE交换机进口排名（新发现的关键数据）

> 来源：Volza全球贸易数据

| 排名 | 国家 | PoE交换机进口量(批/年) | 当前是否已覆盖 |
|------|------|---------------------|-------------|
| 1 | **印度** | 43,539 | ✅ 已有Mahadev等 |
| 2 | **越南** | 17,852 | ✅ 本次新增6家 |
| 3 | **哈萨克斯坦** | 4,759 | ❌ 待开发 |
| 4 | **印尼** | 4,687 | ✅ 已有PT Pasifik |
| 5 | **秘鲁** | 4,657 | ✅ 已有覆盖 |
| 6 | **美国** | 4,593 | ✅ 已有CCTV Camera World等 |
| 7 | **新加坡** | 4,234 | ✅ 已有OMEIO等 |
| 8 | **菲律宾** | 3,053 | ✅ 已有IT Warehouse |
| 9 | **乌兹别克斯坦** | 2,219 | ❌ 待开发 |
| 10 | **马来西亚** | 1,914 | ✅ 已有AAC |
| 11 | **巴基斯坦** | 1,871 | ✅ 已有Paktron |
| 12 | **俄罗斯** | 1,636 | ❌ 待深入开发 |
| 13 | **哥伦比亚** | 995 | ❌ 待开发 |
| 14 | **哥斯达黎加** | 793 | ❌ 待开发 |
| 15 | **孟加拉** | 565 | ✅ 已有GCTL |
| 16 | **坦桑尼亚** | 475 | ❌ 待开发 |
| 17 | **智利** | 472 | ❌ 待开发 |

**未覆盖的高潜力市场**：哈萨克斯坦(#3)、乌兹别克斯坦(#9)、哥伦比亚(#13)、哥斯达黎加(#14)、坦桑尼亚(#16)、智利(#17)

---

## 优先Top 10 新增客户行动清单

| 排名 | 客户 | 国家 | 第一步 | 预期首单 |
|------|------|------|--------|---------|
| 1 | **LEHOANG** | 越南 | 邮件 info@lehoangcctv.com | $10K-30K |
| 2 | **Secure House JSC** | 越南 | 网站联系 | $10K-30K |
| 3 | **KBT/Kabe Group** | 越南 | 电话 0932 685 008 | $10K-20K |
| 4 | **Sapphire Trading** | 肯尼亚 | 电话 +254 795 705 335 | $5K-15K |
| 5 | **Microview Nigeria** | 尼日利亚 | 网站联系 | $5K-20K |
| 6 | **UGREEN** | 中国/全球 | OEM合作洽谈 | $20K-100K |
| 7 | **BV-Tech** | 美国 | 网站联系 | $10K-30K |
| 8 | **CCTV Shop Kenya** | 肯尼亚 | WhatsApp +254 111 042 000 | $3K-10K |
| 9 | **Netview CCTV** | 英国 | 网站联系 | $5K-15K |
| 10 | **Fort Telecom/TFortis** | 俄罗斯 | 电话 +7 342 270-112-8 | $5K-15K |
