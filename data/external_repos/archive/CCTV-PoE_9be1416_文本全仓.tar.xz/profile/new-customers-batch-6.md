# Batch 6 新发现海外客户档案
> 深度挖掘 Round 5 (2026-10-25)
> 新增约30家客户，覆盖印尼/菲律宾/新加坡/摩洛哥/埃塞俄比亚/坦桑尼亚

---

## 一、印度尼西亚 (Indonesia)

### 1. PT. Visindo Global Teknologi
- **国家**: 印度尼西亚
- **网站**: visindo-global.com
- **电话**: 021 623 020 85, 021 293 82 221
- **邮箱**: vinsen_7783@
- **地址**: Mangga Dua Square Lt.2 Blok B No.010-012, Jl. Gunung Sahari Raya No.1, Jakarta Utara
- **业务**: Hikvision/Dahua Master Dealer，CCTV/Switch/Converter/PoE Extender
- **采购潜力**: $10K-30K/批
- **开发策略**: 雅加达IT中心核心位置

### 2. PT. Sejahtera Mandiri Perkasa
- **国家**: 印度尼西亚
- **电话**: +62-21-633-8191~95, +62 21 6905469
- **邮箱**: info@sejahteramandiri.com, info@gsb-security.com
- **网站**: sejateramandiri.com, gsb-security.com
- **地址**: Ketapang Business Center Blok B12, Jakarta Barat
- **业务**: 2011年成立，Hikvision授权分销2017年起
- **采购潜力**: $10K-30K/批
- **开发策略**: Hikvision官方合作伙伴

### 3. Hikvision Indonesia by GSI Group
- **国家**: 印度尼西亚
- **网站**: hikvision-indonesia.com
- **电话**: 021 3033 8611, 0811 2521 2359
- **地址**: Ruko Glodok Plaza D7, Jl. Pinangsia Raya, Jakarta 11120
- **业务**: Hikvision印尼官方分销
- **采购潜力**: $20K-50K/批
- **开发策略**: Hikvision印尼官方

### 4. PT. Synnex Metrodata Indonesia
- **国家**: 印度尼西亚
- **电话**: (+62) 21-29345800
- **邮箱**: ContactUs@metrodata.co.id
- **网站**: synnexmetrodata.com
- **地址**: APL Tower 42nd Floor, Jl. Letjen S. Parman Kav. 28, Jakarta Barat 11470
- **业务**: IT巨头分销
- **采购潜力**: $20K-50K/批
- **开发策略**: 印尼IT分销巨头

### 5. DISTCCTV (distributor-cctv.com)
- **国家**: 印度尼西亚
- **网站**: distributor-cctv.com
- **业务**: 印尼最大CCTV电商，2013年起，10,000+客户
- **产品线**: Hikvision/Dahua/HiLook/Ezviz/ZKTeco/Uniview/TP-Link/MikroTik
- **采购潜力**: $10K-30K/批
- **开发策略**: 印尼CCTV电商领导者

### 6. PT. Virtus Technology Indonesia
- **国家**: 印度尼西亚
- **网站**: virtusindonesia.com
- **地址**: Centennial Tower 39th Floor, Jl. Jend. Gatot Subroto Kav. 24-25, Jakarta 12930
- **业务**: Hikvision授权分销，教育/医疗/物流/矿业/交通
- **采购潜力**: $10K-20K/批
- **开发策略**: 行业解决方案专注

### 7. Media Bersama Sukses (MBS CCTV)
- **国家**: 印度尼西亚
- **网站**: mbscctv.com
- **地址**: Surabaya
- **业务**: Honeywell/Hikvision/Dahua/ZKTeco/Ruijie/TP-Link/Aruba授权
- **采购潜力**: $10K-20K/批
- **开发策略**: 泗水主力分销

### 8. PT. Zioncom Technology
- **国家**: 印度尼西亚
- **电话**: 021 75912227
- **邮箱**: hikvision@zioncom.co.id
- **网站**: zioncom.co.id
- **地址**: Komplek Golden Plaza, Jl. RS. Fatmawati 15 Blok E24, Jakarta Selatan
- **业务**: Hikvision分销
- **采购潜力**: $5K-15K/批
- **开发策略**: 雅加达南区

---

## 二、菲律宾 (Philippines)

### 9. Precious Island Corp / Expose
- **国家**: 菲律宾
- **网站**: pic-expose.ph, expose.ph
- **电话**: (632) 8732-6366, (632) 8741-1442, 0917-8415612 (Viber)
- **邮箱**: pic.salesdept@gmail.com
- **地址**: 1629 Laguna St., Santa Cruz, Manila
- **业务**: 菲律宾#1 Hikvision分销，Dahua/Ruijie/Ezviz
- **产品线**: CCTV/Camera/DVR/NVR/PoE/Access Control
- **采购潜力**: $20K-50K/批
- **开发策略**: 菲律宾Hikvision第一

### 10. Gigaworkz Technologies Inc.
- **国家**: 菲律宾
- **网站**: cctvphilippines.com
- **电话**: (02) 8281-8376, +63-975-913-0647
- **邮箱**: salesmanila@gigaworkz.com.ph
- **地址**: Manila (8 Ledesma St, San Juan City) + Cebu + Davao
- **业务**: Hikvision/Dahua/Bosch授权，13年+，150+安装项目，4区域办公室
- **采购潜力**: $10K-30K/批
- **开发策略**: 菲律宾全国覆盖

### 11. Verdantwaly Industrial Corp
- **国家**: 菲律宾
- **网站**: verdantwaly.com
- **业务**: Dahua/Ruijie/Hikvision/ZKTeco/Honeywell/Imou授权
- **采购潜力**: $10K-20K/批
- **开发策略**: 多品牌授权

### 12. HYE Enterprises Corp
- **国家**: 菲律宾
- **网站**: hye.com.ph
- **电话**: 0917-5399328, 700-14165
- **邮箱**: info@hye.com.ph
- **地址**: 8th Floor, Ora Electronics Center, 734 Gonzalo Puyat St, Quiapo, Manila
- **业务**: Dahua授权
- **采购潜力**: $5K-15K/批
- **开发策略**: 马尼拉Quiapo电子中心

### 13. Kital
- **国家**: 菲律宾
- **网站**: kital.com.ph
- **电话**: +632-8779-6111
- **地址**: 6/F Unit 607 The Taipan Place, 24 Emerald Ave, Ortigas Center, Pasig City
- **业务**: Dahua授权分销
- **采购潜力**: $5K-15K/批
- **开发策略**: Pasig CBD

---

## 三、新加坡 (Singapore)

### 14. Viskou System Pte Ltd
- **国家**: 新加坡
- **网站**: viskou.sg
- **电话**: +65 87119844
- **邮箱**: sales@viskou.com
- **业务**: 2014年起Hikvision分销
- **采购潜力**: $10K-20K/批
- **开发策略**: 新加坡Hikvision主力

### 15. Prowler International Pte Ltd
- **国家**: 新加坡
- **网站**: hikvision-singapore.com
- **电话**: 66354290, 82263347
- **邮箱**: enquiry@prowler.com.sg
- **业务**: Hikvision Diamond Partner 2007年起，PoE交换机全系列
- **采购潜力**: $10K-30K/批
- **开发策略**: 新加坡Hikvision最高级别

### 16. SGCCTV
- **国家**: 新加坡
- **网站**: sgcctv.com.sg
- **业务**: Hikvision Official Platinum Partner
- **产品线**: DS-3E0318P-E $325SGD, DS-3E1326P-EIM $420SGD, DS-3E1518P-SI $145SGD
- **采购潜力**: $10K-20K/批
- **开发策略**: 价格已明确

### 17. ADV CCTV
- **国家**: 新加坡
- **网站**: advcctv.com.sg
- **地址**: 33 Ubi Avenue 3, #02-41 Vertex, Singapore 408868
- **业务**: Hanwha/Hikvision/Ruijie/TRENDnet/Axis批发
- **采购潜力**: $10K-20K/批
- **开发策略**: 新加坡批发分销

### 18. HUASHU Technology Pte Ltd
- **国家**: 新加坡
- **网站**: huashusg.com
- **电话**: +65 86712490
- **邮箱**: sales@huashusg.com
- **地址**: 55 Ubi Ave 1 #04-16, Singapore 408935
- **业务**: Hikvision分销，大数据/云计算/IoT/AI
- **采购潜力**: $5K-15K/批
- **开发策略**: 技术驱动

---

## 四、摩洛哥 (Morocco)

### 19. Caméra Marrakech
- **国家**: 摩洛哥
- **网站**: camera-marrakech.com
- **电话**: +212 661-920098
- **邮箱**: contact@camera-marrakech.com
- **业务**: Hikvision专家，摩洛哥本地库存
- **产品线**: DS-3E0105P-E 890MAD (~$89), DS-3E0109P-E 1490MAD (~$149)
- **采购潜力**: $5K-15K/批
- **开发策略**: 价格已明确

### 20. Securite212
- **国家**: 摩洛哥
- **网站**: securite212.ma
- **电话**: 05.22.23.00.30
- **地址**: Casablanca
- **业务**: Hikvision分销
- **产品线**: DS-3E1510P-EI/M 780MAD (~$78)
- **采购潜力**: $5K-15K/批
- **开发策略**: 卡萨布兰卡

---

## 五、埃塞俄比亚/坦桑尼亚 (Ethiopia/Tanzania)

### 21. Electro IT Services
- **国家**: 埃塞俄比亚
- **网站**: electroitservices.net
- **电话**: +251 982 070809, +251 986 070809
- **邮箱**: info@electroitservices.net
- **地址**: Africa Avenue, Garad Mall, 2nd Floor #44, Addis Ababa
- **业务**: 埃塞俄比亚Hikvision领先分销
- **采购潜力**: $5K-15K/批
- **开发策略**: 埃塞俄比亚Hikvision主力

### 22. Securi Plex / Pentagon Solutions
- **国家**: 坦桑尼亚
- **网站**: pentagon-solutions.com
- **电话**: +255 744 222 333
- **邮箱**: info@pentagon-solutions.co.tz
- **地址**: Uhuru Street, Dar es Salaam
- **业务**: Hikvision全国分销（全品类：CCTV/门禁/交换机/线缆/HDD）
- **采购潜力**: $10K-20K/批
- **开发策略**: 坦桑尼亚Hikvision全国分销

### 23. Hubtech Kenya
- **国家**: 肯尼亚/东非
- **网站**: hubtech.co.ke
- **业务**: Hikvision交换机，全国+东非6国（乌干达/坦桑尼亚/卢旺达/南苏丹/索马里/刚果）
- **采购潜力**: $5K-15K/批
- **开发策略**: 东非6国覆盖

---

**Batch 6 总计: 23家新客户**
**覆盖国家/地区: 印尼、菲律宾、新加坡、摩洛哥、埃塞俄比亚、坦桑尼亚、肯尼亚 = 7个**

---

## 价格基准更新

| 国家 | 型号 | 价格 | 备注 |
|------|------|------|------|
| 印尼 | Hik DS-3E0310P-E/M 8端口 | Rp778K-1.1M (~$49-72) | 电商价 |
| 印尼 | Hik DS-3E1510P-EI 8端口千兆 | Rp965K-1.17M (~$61-74) | 电商价 |
| 印尼 | Hik DS-3E0326P-E 24端口 | Rp2.64M (~$167) | 电商价 |
| 印尼 | Hik DS-3E1518P-EI 16端口 | Rp3.8M (~$240) | 电商价 |
| 印尼 | Dahua DH-CS4010-8ET-60 | Rp1.03M (~$65) | 电商价 |
| 菲律宾 | Dahua DH-PFS3009-8ET-96 | ₱6,300 (~$110) | 分销价 |
| 菲律宾 | Hik DS-3E1318P-SI 16端口 | ₱16,250 (~$254) | 分销价 |
| 菲律宾 | Hik DS-3E0518P-E 16端口 | ₱13,900 (~$217) | 分销价 |
| 新加坡 | Hik DS-3E0318P-E 16端口 | $325SGD (~$242) | 分销价 |
| 新加坡 | Hik DS-3E1326P-EIM 24端口 | $420SGD (~$313) | 分销价 |
| 摩洛哥 | Hik DS-3E0105P-E 4端口 | 890MAD (~$89) | 零售价 |
| 摩洛哥 | Hik DS-3E0109P-E 8端口 | 1490MAD (~$149) | 零售价 |
| 摩洛哥 | Hik DS-3E1510P-EI 8端口千兆 | 780MAD (~$78) | 分销价 |
| 南非 | Hik DS-3E0105P-E 4端口 | ~R500 (~$27) | 零售价 |
| 南非 | Hik DS-3E0109P-E 8端口 | ~R1,000 (~$55) | 零售价 |
| 南非 | Hik DS-3E0318P-E 16端口 | ~R2,500 (~$137) | 零售价 |

---

> Batch 6 完成于 2026-10-25
