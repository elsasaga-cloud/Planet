# Batch 26 — ISC West展会 + 数字标牌PoE + Broadcom生态 + 加勒比
> 深度挖掘 Round 83-86 (2026-10-25)
> 方法论：ISC West 2025/2026参展商 / PoE数字标牌/视频墙 / Broadcom芯片生态 / 加勒比市场

---

## 一、ISC West 2025/2026 参展商情报 ★★★★★

> **情报**: ISC West是全球最大安防展，Las Vegas Venetian Expo，PoE交换机厂商必争之地

### 1. EnGenius（美国）
- **类型**: B类 — 安防网络品牌
- **网站**: engeniustech.com
- **展会**: ISC West 2026
- **产品**: VPN路由器/SMB/Enterprise交换机/无线/PtP/AI云摄像头/NVS
- **开发策略**: 美国安防网络品牌，PoE交换机全线
- **置信度**: ★★★★★

### 2. Lantronix @ ISC West 2026（Booth 34073）
- **类型**: 竞品 — 智能PoE+Edge AI
- **产品**: SmartSwitch.ai + SmartEdge AI网关 + PoE全线 + FLIR无人机AI + EdgeFabric.ai
- **合规**: NDAA, 国防/工业/商业安防
- **开发策略**: Lantronix Edge AI+PoE融合竞品
- **置信度**: ★★★★★

### 3. Antaira @ ISC West 2026（Booth 33055）
- **类型**: 竞品 — 工业PoE++
- **产品**: 高功率PoE++ 100W/口 (PTZ/多镜头摄像头), Wi-Fi 6长距离, L3管理
- **合规**: 55%+ BABA合规
- **开发策略**: Antaira ISC West PoE竞品
- **置信度**: ★★★★★

### 4. Intellinet @ ISC West 2026（Booth 2037）
- **类型**: 竞品 — PoE交换机全线
- **产品**: PoE交换机+配件 (PoE/PoE+/UPoE/PoE++)
- **地点**: Oldsmar, FL
- **开发策略**: 美国PoE品牌ISC West参展
- **置信度**: ★★★★★

### 5. VIVOTEK @ ISC West 2026（Booth 22043）
- **类型**: 竞品 — 安防+PoE全线
- **产品**: 商业/工业/户外交换机 + PoE扩展器/注入器/SFP/浪涌保护
- **事件**: 25周年
- **开发策略**: 台湾安防+PoE竞品
- **置信度**: ★★★★★

### 6. HRUI @ ISC West 2025（Booth 3071）
- **类型**: 竞品 — PoE全线
- **开发策略**: HRUI ISC West参展确认
- **置信度**: ★★★★★

### 7. Comnet @ ISC West 2025
- **类型**: 竞品 — PoE新品
- **产品**: 高性能PoE交换机 (多摄像头+存储)
- **开发策略**: Comnet安防PoE新品
- **置信度**: ★★★★☆

### 8. Transition Networks（美国）
- **类型**: B类 — PoE++管理交换机
- **产品**: SISPM1040-582-LRT (PoE++ 管理, IP安防/户外, Milestone VMS集成)
- **开发策略**: 美国工业PoE管理品牌
- **置信度**: ★★★★★

---

## 二、数字标牌PoE方案

> **市场洞察**: PoE数字标牌是新增长点。GPO Display 57" PoE全景屏需802.3bt Type 4。Thinlabs已部署8000+PoE标牌。

### 9. GPO Display（美国）
- **类型**: B类 — PoE显示器
- **网站**: gpodisplay.com
- **产品**: POE57D 57"全景PoE显示器 (3840x430, 802.3bt Type 4), TAA合规
- **配套**: TRENDnet PoE++注入器
- **应用**: 企业/教育/酒店, 政府/TAA采购
- **开发策略**: 美国PoE显示器品牌，需PoE++交换机
- **置信度**: ★★★★★

### 10. Thinlabs PoE Digital Signage（美国）
- **类型**: B类 — PoE数字标牌
- **网站**: thinlabs.com
- **规模**: 60,000+PoE设备, 8,000+数字标牌, 400+学校
- **生态**: NDI (Network Device Interface) 合作伙伴
- **开发策略**: PoE数字标牌领先品牌
- **置信度**: ★★★★★

### 11. Enable-IT（美国）
- **类型**: B类 — PoE扩展器数字标牌
- **网站**: enableit.com
- **成立**: 2000年 (PoE扩展器先驱)
- **产品**: 长距离以太网+PoE扩展器 (数字标牌方案)
- **开发策略**: 美国PoE扩展器先驱
- **置信度**: ★★★★★

---

## 三、Broadcom芯片生态（白盒交换机）

> **情报**: Broadcom芯片(Tomahawk/Trident/Jericho/Qumran)驱动大多数数据中心白盒交换机。Tomahawk 6为最新AI芯片。

### 12. Broadcom Tomahawk系列
- **类型**: 芯片竞品情报
- **芯片**: Tomahawk 2/3/4/5/6 (AI), BCM56960, Tomahawk+
- **应用**: 数据中心Spine/Leaf, AI后端
- **白盒交换机数**: 100+款(Hardware Nation)
- **置信度**: ★★★★★

### 13. Broadcom Trident系列
- **类型**: 芯片竞品情报
- **芯片**: Trident 2/3/4, Trident+, Trident3-X2/X5/X7, Trident4-X9
- **应用**: 企业/接入层
- **白盒交换机数**: 100+款
- **置信度**: ★★★★★

### 14. Cumulus Express CX-1048-P（NVIDIA）
- **类型**: B类 — Broadcom PoE白盒
- **产品**: 48口1G PoE+, 1-8口60W Ultra PoE, 4x10G SFP+ + 2x20G QSFP, Broadcom芯片, Cumulus Linux
- **开发策略**: NVIDIA/Broadcom PoE白盒交换机
- **置信度**: ★★★★★

### 15. Henan Chengjian（河南）
- **类型**: A类 — 400G交换机OEM
- **产品**: 400G以太网数据中心L3管理交换机
- **开发策略**: 河南400G OEM
- **置信度**: ★★★☆☆

---

## 四、加勒比/中美洲市场

### 16. Trinidad & Tobago PoE市场
- **类型**: C类区域市场
- **品牌**: STEAMEMO GPOE208 8口千兆PoE (TTD715), 10口全千兆PoE (TTD885)
- **渠道**: Facebook Marketplace
- **开发策略**: 加勒比PoE零售市场
- **置信度**: ★★★☆☆

### 17. Lantronix加勒比/Milestone集成
- **类型**: B类 — PoE+VMS方案
- **覆盖**: Bermuda/Costa Rica/Dominican Republic/Greenland/Mexico
- **集成**: Milestone XProtect + DMS设备管理
- **开发策略**: Lantronix加勒比+Milestone PoE方案
- **置信度**: ★★★★★

### 18. QSFPTEK（中国/全球）
- **类型**: B类 — PoE交换机全球电商
- **网站**: qsfptek.com
- **覆盖**: Jamaica/Dominican Republic/Costa Rica + 100+国家
- **开发策略**: 中国PoE交换机全球电商
- **置信度**: ★★★★☆

---

**Batch 26 总计: 18家新客户/情报**

> 关键发现：
> 1. **ISC West 8家** — EnGenius/Lantronix(SmartSwitch.ai)/Antaira(100W PoE++)/Intellinet/VIVOTEK 25周年/HRUI 2025/Comnet/Transition Networks
> 2. **数字标牌PoE 3家** — GPO Display 57" PoE全景/Thinlabs 8000+标牌/Enable-IT PoE扩展器先驱
> 3. **Broadcom生态4家** — Tomahawk 2-6 AI/Trident 2-4/Cumulus Express CX-1048-P Broadcom PoE/Henan Chengjian 400G OEM
> 4. **加勒比3家** — Trinidad & Tobago (STEAMEMO)/Lantronix加勒比Milestone/QSFPTEK全球电商
