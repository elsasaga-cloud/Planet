# 客户档案：PT. Pasifik Teknologi Indonesia — 印尼

## 联系信息
| 渠道 | 信息 |
|------|------|
| 国家 | 印尼 |
| 类型 | Hikvision授权分销商 |
| 主营 | Hikvision安防系统全线 |

## 推荐Saga产品
| 型号 | FOB($) | 推荐理由 |
|------|--------|---------|
| STC-028GFP | $13-15 | 配合Hikvision摄像头 |
| STC-1216GFP | $29-32 | 中型项目 |
| STC-1224GFP | $41-45 | 大型项目 |
| STC-228GP | $24-28 | 千兆+SFP |
| PoE延长器 | $4-7 | 印尼岛屿远距离 |
| 光纤收发器 | $7-11 | 跨区域联网 |

### 卖点：①Hikvision授权分销，Saga完美兼容 ②比Hikvision PoE便宜80%+ ③250米PoE适合印尼 ④金属壳耐高温高湿 ⑤OEM贴牌

## 预期：首单$3K-8K，年$20K-50K
