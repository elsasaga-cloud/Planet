# Batch 33 — MSP + 5G小基站CBRS + 印度市场 + PoE照明
> 深度挖掘 Round 111-114 (2026-10-25)
> 方法论：MSP服务商 / CBRS 5G小基站 / 印度分销商 / PoE照明品牌

---

## 一、MSP (Managed Service Provider)

### 1. Hummingbird Networks
- **类型**: B类 — IT服务商
- **网站**: hummingbirdnetworks.com
- **推荐**: Ubiquiti/Cisco Meraki/Aruba/Netgear小企业PoE
- **开发策略**: 美国MSP PoE推荐
- **置信度**: ★★★★☆

### 2. Suzhou Todahika（苏州）
- **类型**: A类 — PoE OEM
- **网站**: todahika.com
- **产品**: 4口PoE交换机, MSP云管理免授权
- **开发策略**: 苏州PoE OEM (MSP免授权)
- **置信度**: ★★★★☆

---

## 二、5G小基站 / CBRS ★★★★★

> **市场数据**: CBRS基站 400K+ (2024.7), $1.3B by 2027 CAGR 15%, 75%美国私有5G用CBRS, Small Cell 61M出货by 2030 $4.23B

### 3. Charter Communications CBRS
- **类型**: B类 — 5G CBRS
- **合作**: Nokia AirScale Kolibri (50-80W, 15磅, DOCSIS 3.1回传)
- **规模**: 210 PALs 106县, 23市场2025, 数千small cells
- **开发策略**: 美国5G CBRS运营商
- **置信度**: ★★★★★

### 4. Comcast + Samsung CBRS
- **类型**: B类 — 5G CBRS
- **产品**: Samsung 5G CBRS Strand Small Cell (第二代5G SoC)
- **开发策略**: 美国5G CBRS运营商
- **置信度**: ★★★★★

### 5. Nokia AirScale Kolibri
- **类型**: 竞品 — 5G小基站
- **产品**: 室外5G + CBRS室内 (2025), 15磅strand-mount
- **开发策略**: Nokia 5G小基站竞品
- **置信度**: ★★★★★

### 6. Lantronix SISPM1242-582-LRT
- **类型**: B类 — 10G强化PoE++
- **产品**: 10G强化PoE++多千兆 (2025.10), AI摄像头+WiFi 7边缘
- **开发策略**: 10G强化PoE++边缘方案
- **置信度**: ★★★★★

### 7. Qualcomm + Siemens私有5G
- **类型**: B类 — 工业私有5G
- **事件**: 2024.3 Amberg工厂小基站
- **开发策略**: 工业私有5G案例
- **置信度**: ★★★★☆

### 8. Meta企业内网
- **类型**: B类 — 企业内网
- **规模**: 1500 small cells
- **开发策略**: Meta企业内网small cell
- **置信度**: ★★★★☆

---

## 三、印度市场深挖 ★★★★★

> **Volza数据**: 印度全球最大PoE进口国 43539出货 (48%份额)

### 9. IPVoice Technologies（印度）
- **类型**: C类 — 16品牌授权
- **网站**: ipvoicetechnologies.in
- **品牌**: TP-Link/D-Link/Cisco/Aruba/Ubiquiti/MikroTik/Grandstream/Cambium/AirPro/Tenda/EnGenius/Extreme/Fortinet/Netgear/SonicWall/Sophos/Juniper/Lysora
- **覆盖**: 29000 PIN codes
- **开发策略**: 印度最大PoE多品牌分销
- **置信度**: ★★★★★

### 10. Montronics Electronics（孟买）
- **类型**: C类 — 15年出口
- **产品**: Smart PoE交换机
- **开发策略**: 孟买PoE出口商
- **置信度**: ★★★★☆

### 11. Digitage Infocom（新德里）
- **类型**: C类 — 9年分销
- **产品**: Grandstream GWN7803P 24口PoE管理
- **开发策略**: 新德里PoE分销
- **置信度**: ★★★★☆

### 12. Ten Delta ICT
- **类型**: C类 — Teltonika
- **产品**: TSW040 8口PoE+
- **开发策略**: 印度Teltonika分销
- **置信度**: ★★★★☆

### 13. Om Automation
- **类型**: C类 — 工业PoE
- **产品**: IPSMG 308 6S A 14口工业PoE管理 (₹40877)
- **开发策略**: 印度工业PoE
- **置信度**: ★★★★☆

### 14. Ruchi Telecom（新德里）
- **类型**: C类 — 17年分销
- **产品**: Juniper EX 4300 PoE
- **开发策略**: 新德里PoE老牌
- **置信度**: ★★★★☆

### 15. Mahadev Computers（孟买）
- **类型**: C类 — 7年
- **产品**: Netgear/D-Link 48口/Hikvision PoE
- **开发策略**: 孟买PoE分销
- **置信度**: ★★★★☆

### 16. Tricom India（新德里）
- **类型**: C类 — PoE+SFP
- **产品**: Tricom AI PoE 16(100)+2(1000)+1 SFP
- **开发策略**: 新德里PoE定制
- **置信度**: ★★★☆☆

### 17. MatchDigi（印度）
- **类型**: C类 — LB-Link独家
- **网站**: matchdigi.com
- **产品**: LB-Link PoE独家授权
- **开发策略**: 印度LB-Link PoE独家
- **置信度**: ★★★★☆

### 18. Scomp Enterprises (Noida)
- **类型**: C类 — SCOMP品牌
- **产品**: SEPOE4FE/SEPOEFE162G1/SEPOE8FE2G (4/8/16口)
- **开发策略**: Noida PoE品牌
- **置信度**: ★★★☆☆

---

## 四、PoE照明品牌 ★★★★★

> **情报**: PoE照明市场 $1.17B by 2024 / $922M by 2026, 2022.9 PoE Consortium成立

### 19. GENISYS / Innovative Lighting（美国Iowa）
- **类型**: B类 — PoE照明领先
- **网站**: genisyslighting.com
- **成立**: 2012年PoE (14年), 1993年LED
- **规模**: 100+员工, Iowa制造, $3M 2026
- **产品**: 下灯/墙开关/占用传感器/IntelliDrive
- **开发策略**: 美国PoE照明领先品牌
- **置信度**: ★★★★★

### 20. IGOR (West Des Moines, Iowa) [已关闭]
- **类型**: B类 — 历史竞品
- **成立**: 2013 Dwight Stewart, Nexos IoT平台
- **事件**: 2023.7关闭, DBS收购库存+客户服务
- **地位**: Cisco Digital Ceiling Partner
- **开发策略**: IGOR历史竞品 (DBS接盘)
- **置信度**: ★★★★★

### 21. Digital Building Solutions (DBS, 纽约)
- **类型**: B类 — 智能建筑集成
- **事件**: 2023收购IGOR库存+Day 2支持, MHT合作
- **开发策略**: IGOR接盘+MHT集成
- **置信度**: ★★★★★

### 22. PoE Consortium (2022.9成立)
- **类型**: 行业联盟
- **成员**: IGOR/GENISYS/Mecho/MHT/Platformatics/PoE Texas/Versa Technology
- **开发策略**: PoE照明行业联盟
- **置信度**: ★★★★★

### 23. Versa Technology PoE照明合作
- **类型**: B类 — 合作伙伴生态
- **合作**: Platformatics/IGOR/Genisys/NuLEDs/Cree
- **开发策略**: Versa PoE照明生态
- **置信度**: ★★★★☆

### 24. Inspired LED (Tempe, AZ)
- **类型**: B类 — Igor软件合作
- **事件**: 2016 Igor PoE软件合作
- **开发策略**: PoE照明灯具+Igor软件
- **置信度**: ★★★★☆

---

**Batch 33 总计: 24家新客户/情报**

> 关键发现：
> 1. **MSP 2家** — Hummingbird美国推荐/Todahika苏州MSP免授权
> 2. **5G CBRS 6家** — Charter Nokia Kolibri 50-80W/Comcast Samsung/Nokia 5G小基站/Lantronix 10G强化PoE++ 2025.10/Qualcomm Siemens私有5G/Meta 1500 small cells
> 3. **印度9家** — IPVoice 16品牌29K PIN/Montronics孟买15年/Digitage新德里/Ten Delta Teltonika/Om Automation工业₹40877/Ruchi 17年Juniper/Mahadev Netgear D-Link/Tricom AI PoE/MatchDigi LB-Link/Scomp Noida
> 4. **PoE照明7家** — GENISYS Iowa 2012 $3M/IGOR 2013关闭DBS收购/DBS纽约接盘/PoE Consortium 7成员/Versa 5合作/Inspired LED Igor合作/市场$922M 2026
