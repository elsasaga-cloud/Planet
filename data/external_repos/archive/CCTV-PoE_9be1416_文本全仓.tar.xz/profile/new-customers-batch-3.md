# 第三批新客户档案 — 深度挖掘（续）

> 挖掘日期：2026-09-22  
> 新增客户：约35家  
> 覆盖市场：哈萨克斯坦/哥伦比亚/墨西哥/坦桑尼亚/智利/东非扩展

---

## 一、哈萨克斯坦 — 5家新发现 ★★★

> **关键数据**：哈萨克斯坦是全球PoE交换机进口第3大国（4,759批/年）！Hikvision+Dahua设备统治市场。

### 1. Pulsar Systems (哈萨克斯坦) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哈萨克斯坦 (Astana + Almaty) |
| 成立 | 2010年 |
| 类型 | ZKTeco + Hikvision官方分销商 |
| 产品 | 安防设备、门禁、CCTV、网络设备 |
| Astana办公室 | пр. Бауыржана Момышулы, д. 2В |
| Almaty办公室 | ул. Тулебаева, д. 38, БЦ "Жетису", 401 |
| 电话 | +7 (702) 000-61-17 (Almaty), +7 (708) 486-29-08 (Astana) |
| 邮箱 | info@pulsar.kz |
| 网站 | pulsar.kz |
| 级别 | **A级** |

**推荐Saga产品**：全系列非管理PoE + PoE延长器
**卖点**：①哈萨克斯坦PoE进口全球第3（4,759批/年） ②Hikvision官方分销(PoE配套刚需) ③Astana+Almaty双仓覆盖 ④比Hikvision PoE便宜70-85%

---

### 2. Barlau Global Distribution (哈萨克斯坦) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哈萨克斯坦 (Almaty) |
| 类型 | Hikvision/HiWatch/HiLook官方授权分销商 |
| 地址 | Almaly district, Gogol street 150, Almaty |
| 特点 | 官方授权+技术支持+售后保修+项目支持 |
| 级别 | **A级** |

---

### 3. Safety Expert (哈萨克斯坦) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哈萨克斯坦 (Almaty) |
| 类型 | 安防设备分销商 |
| 品牌 | Uniview, Ajax, Uniarch, Hikvision |
| 产品 | 包含PoE交换机在售 |
| 网站 | safetyexpert.kz |
| 在售Hikvision PoE | DS-3E0524-E (49,764₸), DS-3E0510P-E (42,660₸), DS-3E1526P-SI, DS-3T0510HP-E/HS (85,859₸), DS-3E0109P-E(C) (31,500₸) |
| 级别 | **A级** |

**对标价差**：
| Hikvision在售 | 零售₸ | 折合USD | Saga替代 | Saga FOB |
|--------------|-------|---------|---------|---------|
| DS-3E0510P-E (8口PoE) | 42,660 | ~$85 | STC-028GFP | $17.6 |
| DS-3E0524-E (24口) | 49,764 | ~$100 | STC-1224GFP | $41.3 |
| DS-3T0510HP-E/HS (Hi-PoE) | 85,859 | ~$172 | STC-228GP | $30.8 |

---

### 4. Otvertka.kz (哈萨克斯坦) ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哈萨克斯坦 (Almaty) |
| 类型 | Hikvision PoE交换机零售商 |
| 地址 | мкр. Таугуль-3, ул. О. Жандосова 2Б |
| 电话 | +7 727 339 51 51 |
| 邮箱 | info@otvertka.kz |
| 网站 | otvertka.kz |
| 在售PoE | DS-3E1310P-EI/M (34,696₸), DS-3T0506HP-E/HS (49,357₸) |
| 级别 | **B级** |

---

### 5. Videosystem SP (哈萨克斯坦) ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哈萨克斯坦 |
| 类型 | IP摄像头/AHD/PoE交换机批发 |
| 产品 | IP cameras, AHD cameras, NVR, PoE switches |
| 级别 | **B级** |

---

## 二、哥伦比亚 — 10家新发现 ★★

> 哥伦比亚PoE进口997批/年，但市场增长快，且是拉美分销枢纽

### 6. Redatel S.A.S. (哥伦比亚) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哥伦比亚 (Bogotá + Medellín) |
| 类型 | 安防电子进口商/批发商 |
| 产品 | CCTV(IP/AHD/PTZ/DVR/NVR)、报警、门禁、网络、消防 |
| 品牌 | Hikvision, Dahua, EZVIZ, Axis, Cisco, DTX Security |
| Bogotá | Calle 65 # 11-38, +57 313 890 4740 |
| Medellín | Circular 4 # 69-11 |
| 授权 | Supervigilancia Res. 6605 |
| 网站 | redatel.net |
| 级别 | **A级** |

**推荐Saga产品**：全系列非管理PoE + PoE延长器
**卖点**：①Bogotá+Medellín双仓 ②进口+批发全产业链 ③多品牌经营(非独家，易切入) ④比Hikvision/Dahua PoE便宜70-85%

---

### 7. GSP - Global Security Protection (哥伦比亚) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哥伦比亚 (8个城市有办事处!) |
| 成立 | 15年+历史 |
| 类型 | Hikvision授权官方分销商 |
| 覆盖 | Bogotá(3个办公点), Medellín, Cali, Barranquilla, Bucaramanga, Santa Marta等 |
| 特点 | 8城市有办事处+仓库,当日发货, Secpronet+GSP Academy认证培训 |
| 网站 | gsp.com.co |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE + 管理型
**卖点**：①哥伦比亚最广分销网络(8城) ②15年经验 ③PoE交换机是NVR/摄像头配套刚需

---

### 8. GVS Colombia (哥伦比亚) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哥伦比亚 (Medellín) |
| 类型 | 安防电子分销商(Dahua官方分销) |
| 品牌 | Ajax, ZKTeco, Dahua, Hanwha, Imou, GVS Security, Onvision, Tenda |
| 历史 | 2011-2018是Hikvision分销,2018年转Dahua |
| 特点 | 5个服务中心,全国覆盖 |
| 网站 | gvscolombia.com |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE（对标Dahua PoE交换机配套）

---

### 9. JFM Technology (哥伦比亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哥伦比亚 (Ibagué总部 + Bogotá/Medellín/Barranquilla仓库) |
| 类型 | 技术设备分销商(Hikvision授权) |
| 品牌 | LG, Microsoft, WatchGuard, HPE, Hikvision, Kenwood, Ruijie |
| 在售PoE | Switch Hikvision DS-3E1318P-EI/M (COP$732,519≈$175), Dahua DH-CS4010 (COP$326,817) |
| 网站 | jfmtechnology.com |
| 级别 | **A级** |

**对标价差**：Hikvision DS-3E1318P 零售COP$732,519(~$175) vs Saga STC-1216GFP FOB $28.8 → **低84%**

---

### 10. DASA Technology (哥伦比亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哥伦比亚 (Bogotá) |
| 类型 | 安防电子批发分销商 |
| 产品 | 486个SKU, 20个品牌 |
| 特点 | 授权分销+全国配送 |
| 网站 | dasacctv.com |
| 级别 | **B级** |

---

### 11. Security Depot (哥伦比亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哥伦比亚 (Bogotá + Medellín) |
| 品牌 | Hikvision, Dahua, HiLook, EZVIZ, ZKTeco, DSC, Paradox |
| 网站 | securitydepot.com.co |
| 电话 | +57 310 551 8121 |
| 级别 | **B级** |

---

### 12. Operkom (哥伦比亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哥伦比亚/拉美 |
| 类型 | 安防电子批发分销商 |
| 品牌 | Dahua, Hikvision, ZKTeco, Imou, DSC, Ajax, Intelbras |
| 网站 | operkom.com |
| 级别 | **B级** |

---

### 13. Grupo Control de Colombia (哥伦比亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哥伦比亚 (Medellín + Cali) |
| 成立 | 2012年 |
| 类型 | Hikvision授权分销商 |
| 电话 | +57 300 735 7229 |
| 邮箱 | argenisomana@grupocontrol.co |
| Medellín | Cl. 48C #66-27 |
| Cali | Calle 24 Norte #5AN-21 |
| 网站 | grupocontrol.co |
| 级别 | **B级** |

---

### 14. Sumitelco (哥伦比亚) ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哥伦比亚 (Medellín) |
| 类型 | 安防电子进口商/分销商 |
| 品牌 | DTX, EZVIZ, IMOU, Uniview, Hikvision, Tuya Smart |
| 电话 | +57 312 750 0421 |
| 邮箱 | contacto@sumitelco.com |
| 网站 | sumitelco.com |
| 级别 | **B级** |

---

### 15. Elenst (哥伦比亚/委内瑞拉/巴西) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 哥伦比亚+委内瑞拉+巴西+拉美+中美+美国 |
| 类型 | 拉美最大安防电子批发商之一 |
| 产品 | Hikvision全线(项目级) |
| 覆盖 | Bogotá, Medellín, Cali, Barranquilla, Bucaramanga, Santa Marta + 全国配送 |
| 网站 | elenst.com |
| 级别 | **A级** |

**卖点**：①覆盖哥伦比亚+委内瑞拉+巴西 ②拉美最大批发商之一 ③项目级Hikvision配套

---

## 三、墨西哥 — 8家新发现 ★★

> **市场数据**：墨西哥安防摄像头市场2025年$8.2亿，2030年达$12.8亿，CAGR 9.3%！

### 16. SYSCOM (墨西哥) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 墨西哥 (Chihuahua总部 + 全国20分支!) |
| 类型 | **墨西哥最大安防分销商**（Hikvision已收购其股份） |
| 员工 | 501-1,000人 |
| 分支 | 17个墨西哥分支 + 2个美国分支 + 1个哥伦比亚分支 |
| 品牌 | Hikvision独家授权 + Ruijie + 数百品牌 |
| 网站 | syscom.mx |
| 级别 | **A级（战略级）** |

**分析**：SYSCOM是Hikvision在墨西哥唯一授权分销商，Hikvision已入股。但PoE交换机品类中Ruijie产品价格高，Saga可作为低价PoE替代方案进入非独家品类。

---

### 17. TVC - TVCenLínea (墨西哥) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 墨西哥 (全国20个分支!) |
| 类型 | 安防电子批发分销商 |
| 品牌 | Dahua, DSC, Ubiquiti, Vivotek, ZKTeco |
| 产品 | CCTV、门禁、报警、网络、**PoE交换机在售** |
| 网站 | tvc.mx |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE（Dahua PoE配套）
**卖点**：①20个分支覆盖全国 ②Dahua PoE替代品 ③比Dahua PoE便宜70%+

---

### 18. SILYMX (墨西哥) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 墨西哥 (Naucalpan总部 + CDMX + Guadalajara + Morelos) |
| 类型 | B2B批发分销商 |
| SKU | **32,000+** |
| 品牌 | Hikvision, Dahua, Ubiquiti, Belden, Panduit, Epcom, Grandstream, Syscom, TP-Link, MikroTik, Ruijie |
| 电话 | (55) 9046 8290, (55) 9331 4234, (33) 2736 4412 (Guadalajara) |
| 网站 | sily.mx |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE + PoE延长器 + 光纤收发器
**卖点**：①32,000+ SKU说明品类极广 ②多品牌经营(易切入) ③已有PoE交换机品类

---

### 19. VIGILANTEC (墨西哥) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 墨西哥 (Guadalajara) |
| 类型 | Dahua DPP Diamante分销商（最高级别！） |
| 特点 | Dahua认证技术支持+最佳价格 |
| 网站 | vigilantec.mx |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE（Dahua PoE配套）

---

### 20. Seguridad Hikvision Monterrey (墨西哥) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 墨西哥 (Monterrey) |
| 成立 | 15年+ |
| 类型 | Hikvision批发商 |
| 电话 | (81) 2087-1300, (81) 2146-6437 |
| 地址 | Alfonso Reyes 3408, MTY, NL |
| 网站 | seguridadhikvision.com |
| 级别 | **B级** |

---

### 21. CCTV México (墨西哥) ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 墨西哥 |
| 类型 | Hikvision PoE交换机零售商 |
| 在售PoE | Hikvision 8口千兆PoE+管理型 (含SFP, 300m延长, 110W) |
| 网站 | cctvmexico.mx |
| 级别 | **B级** |

---

### 22. Tecnosinergia (墨西哥) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 墨西哥 |
| 类型 | 大型安防设备分销商 |
| 规模 | 10,000分销渠道, 50+品牌, 3000+产品, 7个分支 |
| 城市 | CDMX, Guadalajara, Monterrey等 |
| 特点 | 计划开20家门店(CDMX大都市区), 已开4家 |
| 级别 | **A级** |

---

### 23. Grupo Mayorista Gictronics (墨西哥) ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 墨西哥 (Querétaro + Monterrey + San Luis Potosí) |
| 类型 | CCTV批发商 |
| 品牌 | Pelco, Axis, Dahua, Hikvision |
| 电话 | (442) 819-7500 |
| 邮箱 | ventas@gictronics.com |
| 网站 | gictronics.com |
| 级别 | **B级** |

---

## 四、坦桑尼亚 — 4家新发现 ★★

### 24. Pentagon Solutions (坦桑尼亚) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 坦桑尼亚 (Dar es Salaam) |
| 类型 | Hikvision国家分销商 |
| 产品 | CCTV、报警、门禁、考勤、电围栏、消防、自动门 |
| 地址 | Uhuru Street (Near Lumumba St), Dar es Salaam |
| 电话 | +255 744 222 333 |
| 邮箱 | info@pentagon-solutions.co.tz |
| 网站 | pentagon-solutions.com |
| 级别 | **A级** |

---

### 25. Nordic Distribution TZ Limited (坦桑尼亚) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 坦桑尼亚 (Dar es Salaam) |
| 成立 | 2009年 |
| 类型 | ICT/网络/电力/安防产品领先分销商 |
| 品牌 | Siemon (400G/800G网络设备) |
| 地址 | Plot no. 161, Regent Estate, Dar es Salaam |
| 邮箱 | sales@nordic-computers.com |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE + PoE延长器
**卖点**：①东非ICT领先分销商 ②已有网络设备线 ③PoE交换机配套需求

---

### 26. Securi Plex Ltd (坦桑尼亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 坦桑尼亚 |
| 类型 | Hikvision国家分销商 |
| 产品 | CCTV、门禁、对讲、报警、线缆、**交换机**、金属探测器、行李扫描 |
| 级别 | **A级** |

---

### 27. Rotech (坦桑尼亚/桑给巴尔/肯尼亚) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 坦桑尼亚 + 桑给巴尔 + 肯尼亚 + 东非 |
| 类型 | CCTV/安防系统集成商+供应商 |
| 产品 | IP摄像头(PoE, IP67, triple stream), CCTV系统 |
| 网站 | rotech.co.tz |
| 级别 | **B级** |

---

## 五、智利 — 5家新发现 ★★

### 28. Comdiel Ltda (智利) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 智利 (Santiago) |
| 类型 | 网络设备/PoE交换机分销商 |
| 地址 | Manuel Montt 1854, Providencia, Santiago |
| 电话 | +56 2 2225 6775 |
| 邮箱 | info@comdiel.cl |
| 网站 | comdiel.cl |
| 级别 | **B级** |

---

### 29. SSTT SpA (智利) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 智利 (Santiago, Ñuñoa) |
| 类型 | Dahua区域分销商 |
| 地址 | General José Artigas 3028, Ñuñoa, Santiago |
| 特点 | 12年市场经验, Dahua官方区域分销 |
| 网站 | sstt.cl |
| 级别 | **B级** |

**推荐Saga产品**：全系列PoE（Dahua PoE配套）

---

### 30. Wei Chile (智利) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 智利 (Santiago, Providencia) |
| 类型 | 网络设备分销商 |
| 产品 | Switches, PoE注入器 |
| 地址 | Marchant Pereira 150, Providencia, Santiago |
| 电话 | +56 2 2379 0000 / +56 2 2820 4600 |
| 邮箱 | ventas@wei.cl |
| 网站 | wei.cl |
| 级别 | **B级** |

---

### 31. Ikseg Store (智利) ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 智利 (Santiago, Macul) |
| 类型 | PoE交换机零售商 |
| 地址 | Los Evangelistas 3595, Macul, Santiago |
| 电话 | +56 23 245 0880 / +56 22 791 4525 |
| 网站 | ikseg.cl |
| 级别 | **B级** |

---

### 32. Automatec Importaciones SpA (智利) ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 智利 (Santiago + 6个分支城市) |
| 类型 | 工业PoE交换机进口商 |
| 产品 | Wi-Tek工业8GE PoE 240W + 2SFP (在售) |
| 地址 | Av. Marathon 2879, Macul, Santiago |
| 电话 | +562 2941 6700 |
| 邮箱 | canalweb@automatec.cl |
| 分支 | Puerto Montt, Talca, Galvarino, Concepción, Viña del Mar, Temuco |
| 网站 | automatec.cl |
| 级别 | **B级** |

---

## 六、东非扩展 — 5家新发现

### 33. Nordic Computers (坦桑尼亚) ★★★★

| 维度 | 详情 |
|------|------|
| 邮箱 | sales@nordic-computers.com |
| 地址 | Plot 161, Regent Estate, Dar es Salaam |
| 级别 | **B级** |

### 34. Quasar Company Limited (毛里求斯) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 毛里求斯 (Willowvale) |
| 成立 | 2004年 |
| 类型 | 电子/网络/安防产品分销商 |
| 电话 | +230 5257 2499 |
| 邮箱 | shravan@quasar.mu |
| 网站 | quasar.mu |
| 级别 | **B级** |

### 35. HISEC (非洲/法语区) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 非洲法语区 |
| 类型 | 安防电子分销+集成 |
| 产品 | 门禁、CCTV、入侵报警、消防 |
| 级别 | **B级** |

---

## 优先行动清单（第三批精选）

| 排名 | 客户 | 国家 | 联系方式 | 第一步 | 预期首单 |
|------|------|------|---------|--------|---------|
| 1 | **Pulsar Systems** | 哈萨克斯坦 | info@pulsar.kz, +7 702 000-61-17 | 邮件 | $5K-15K |
| 2 | **Redatel S.A.S.** | 哥伦比亚 | +57 313 890 4740 | 邮件+电话 | $5K-15K |
| 3 | **GSP** | 哥伦比亚 | gsp.com.co | 网站联系 | $10K-30K |
| 4 | **GVS Colombia** | 哥伦比亚 | gvscolombia.com | 网站联系 | $5K-15K |
| 5 | **SILYMX** | 墨西哥 | (55) 9046 8290 | 电话+邮件 | $10K-30K |
| 6 | **TVC** | 墨西哥 | tvc.mx | 网站联系 | $10K-20K |
| 7 | **Pentagon Solutions** | 坦桑尼亚 | +255 744 222 333, info@pentagon-solutions.co.tz | 邮件+电话 | $3K-8K |
| 8 | **Nordic Distribution TZ** | 坦桑尼亚 | sales@nordic-computers.com | 邮件 | $3K-8K |
| 9 | **Safety Expert** | 哈萨克斯坦 | safetyexpert.kz | 网站联系 | $5K-15K |
| 10 | **Elenst** | 哥伦比亚/拉美 | elenst.com | 网站联系 | $5K-20K |

---

**累计新客户：28(第二批) + 35(第三批) = 63家新增**
**总客户数：45(原有) + 63(新增) = 108家海外目标客户**
