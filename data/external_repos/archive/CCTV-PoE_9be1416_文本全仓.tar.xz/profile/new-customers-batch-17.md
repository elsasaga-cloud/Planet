# Batch 17 — 深圳OEM竞品 + 零售/仓储垂直 + 其他
> 深度挖掘 Round 43-46 (2026-10-25)
> 方法论：Alibaba/Made-in-China深圳OEM竞品 + 零售PoE + 仓储PoE

---

## 一、深圳OEM/ODM PoE交换机竞品（直接竞品）

### 1. ONV (Optical Network Video Technologies)（深圳）— 已收录Batch 16
- **补充**: Alibaba验证制造商15年, Top 20% Network Switches美国市场, 6条生产线
- **评分**: 4.9/5 (10评价), 87.8%复购率
- **开发策略**: 核心竞品

### 2. Ewind Technology（深圳）— 已收录Batch 14
- **补充**: Alibaba验证7年, ~120员工, AI Smart PoE/Watchdog/VLAN
- **认证**: CE/ROHS/FCC
- **客户**: 智慧城市/工业自动化
- **评分**: 4.6/5 (16评价)
- **开发策略**: 核心竞品

### 3. SDAPO（东莞）— 已收录Batch 16
- **补充**: Alibaba验证5年, 1400m², 4.9/5 (34评价), 100%复购率

### 4. E-Linkchina Technology（深圳）
- **类型**: 竞品 — 工业PoE交换机
- **网站**: Made-in-China
- **产品**: Solar 12-48V 4 PoE at+1上行迷你工业交换机 ($29.90), 5口千兆PoE+ DIN Rail ($20.50)
- **开发策略**: 深圳工业PoE竞品
- **置信度**: ★★★★★

### 5. Utop Technology (Utoptek)（深圳）
- **类型**: 竞品 — OEM/ODM PoE交换机
- **网站**: Made-in-China
- **产品**: 4/8/16/24/48口工业PoE ($29-89), 8口反向PoE ($6.90), 千兆8口 ($10-14)
- **认证**: ISO 9001
- **开发策略**: 深圳OEM PoE竞品，低价
- **置信度**: ★★★★★

### 6. Jeetronics Communications（深圳）
- **类型**: 竞品 — PoE/工业交换机
- **产品**: 8x千兆PoE工业交换机 ($65-69), SFP光模块
- **开发策略**: 深圳PoE竞品
- **置信度**: ★★★★☆

### 7. Sunsoont Technology（深圳）
- **类型**: 竞品 — PoE交换机
- **网站**: Alibaba验证6年
- **产品**: PoE交换机/PoE延长器
- **评分**: 4.8/5 (96评价), 99%准时交货
- **开发策略**: 深圳PoE竞品
- **置信度**: ★★★★★

### 8. Dasheng Digital（深圳）
- **类型**: 竞品 — 管理型PoE交换机
- **网站**: Alibaba验证4年
- **产品**: 管理型PoE交换机 (FCC认证)
- **评分**: 4.8/5 (83评价), 支持FBA
- **开发策略**: 深圳管理型PoE竞品
- **置信度**: ★★★★★

### 9. Yuguang Anpa Electronic（深圳）
- **类型**: 竞品 — PoE交换机
- **网站**: Alibaba验证3年
- **规模**: 50+员工, 8000m²
- **评分**: 4.9/5 (47评价), 100%准时
- **开发策略**: 深圳PoE竞品，响应快
- **置信度**: ★★★★★

### 10. Hisource Technology（深圳）
- **类型**: 竞品 — PoE交换机/注入器/分配器
- **网站**: Alibaba
- **产品**: PoE交换机 ($15-20), PoE延长器, 户外PoE ($20.07)
- **开发策略**: 深圳PoE全线竞品
- **置信度**: ★★★★★

### 11. BTON Technology（深圳）
- **类型**: 竞品 — PoE+交换机
- **成立**: 2011年
- **产品**: 16口PoE+交换机 (250W, 2千兆+1 SFP, 802.3at/af)
- **开发策略**: 深圳老牌PoE竞品
- **置信度**: ★★★★★

### 12. Huoyi Technology（深圳）
- **类型**: 竞品 — 云管理PoE交换机
- **网站**: Alibaba验证6年
- **产品**: 云管理4/6/8/16/24口PoE交换机 (L2, 48V, IEEE 802.3af/at)
- **开发策略**: 深圳云管理PoE竞品
- **置信度**: ★★★★★

### 13. COMFAST / Four Seas Global Link（深圳）
- **类型**: 竞品 — PoE交换机
- **成立**: 14年
- **产品**: CF-SG181P 8口千兆PoE交换机 (内置电源)
- **开发策略**: 深圳老牌PoE竞品
- **置信度**: ★★★★★

### 14. Hs Fiber Communication（深圳）
- **类型**: 竞品 — PoE交换机OEM
- **产品**: HSGQ-SG2024P 24口千兆 ($75-83.8), SG2008P 8口 ($21.9-28)
- **认证**: ISO 9001, ISO 14001
- **开发策略**: 深圳PoE交换机OEM
- **置信度**: ★★★★☆

### 15. Hongking Communication（深圳）
- **类型**: 竞品 — PoE交换机OEM/ODM
- **产品**: 100M 8+2+1SFP PoE交换机 ($24.10)
- **开发策略**: 深圳PoE OEM
- **置信度**: ★★★★☆

### 16. MVTEAM Technology（深圳）
- **类型**: 竞品 — CCTV PoE交换机
- **产品**: 802.3at 8口10/100Mbps PoE交换机
- **开发策略**: 深圳CCTV PoE竞品
- **置信度**: ★★★★☆

### 17. Yunlink Technology（深圳）
- **类型**: 竞品 — PoE交换机+无线
- **规模**: 209员工, 2000m²
- **认证**: ISO9001:2015
- **产品**: PoE交换机/无线路由器/室外AP
- **开发策略**: 深圳PoE+无线竞品
- **置信度**: ★★★★★

### 18. Lianzhengda Technology（深圳）
- **类型**: 竞品 — PoE交换机
- **成立**: 12年
- **产品**: LZD 8口PoE ($5.50-6.50)
- **评分**: 4.0/5 (4评价)
- **开发策略**: 深圳超低价PoE竞品
- **置信度**: ★★★★☆

### 19. PUSR (USR-ISG)
- **类型**: 竞品 — 工业PoE交换机
- **产品**: 5/8口千兆工业PoE (-40~85°C, 无风扇DIN Rail)
- **开发策略**: 工业PoE竞品
- **置信度**: ★★★★☆

### 20. Wanglink（深圳）
- **类型**: 竞品 — PoE交换机
- **产品**: 8口千兆PoE (TP-Link兼容)
- **开发策略**: 深圳PoE OEM
- **置信度**: ★★★★☆

---

## 二、零售/仓储垂直

### 21. IP Security Depot（美国）
- **类型**: C类 — 仓储网络方案
- **网站**: ipsecuritydepot.com
- **开发策略**: 美国仓储安防
- **置信度**: ★★★★☆

### 22. Gear Net Technologies（美国）
- **类型**: C类 — PoE交换机选型
- **网站**: gntme.com
- **开发策略**: 美国网络集成
- **置信度**: ★★★★☆

### 23. ShowMeCables（美国）
- **类型**: C类 — 零售/办公PoE
- **网站**: showmecables.com
- **开发策略**: 美国线缆+PoE
- **置信度**: ★★★★☆

### 24. Alavsta Tech（中国）
- **类型**: B类 — 商业PoE方案
- **网站**: alvasta-tech.com
- **品牌**: ISON工业PoE交换机, Moxa, InHand
- **开发策略**: 商业PoE方案商
- **置信度**: ★★★★☆

### 25. Inscape Data / PoE Superstore（美国）
- **类型**: B类 — 户外PoE交换机
- **网站**: poesuperstore.com
- **成立**: 2004年
- **产品**: LinkPower户外PoE交换机 (专利, 2/4/8口千兆)
- **开发策略**: 美国户外PoE专业品牌
- **置信度**: ★★★★★

### 26. EnableIT（美国）
- **类型**: B类 — PoE延长器+数字标牌
- **网站**: enableit.com
- **成立**: 2000年
- **产品**: PoE延长器 (数字标牌/充电桩/电梯)
- **开发策略**: 美国PoE延长器老牌
- **置信度**: ★★★★★

### 27. Delta-Opti（波兰）
- **类型**: C类 — Reyee仓储方案
- **部署**: 2025年11月部署Reyee仓储+PoE方案
- **开发策略**: 波兰仓储PoE客户
- **置信度**: ★★★★☆

---

## 三、关键竞品情报总结

### 深圳PoE交换机OEM竞品价格带
- **8口10/100M PoE**: $5.50-10
- **8口千兆PoE**: $10-28
- **16口千兆PoE+**: $40-65
- **24口千兆PoE+**: $55-90
- **48口PoE**: $100+
- **工业PoE (DIN Rail)**: $20-70

### 深圳OEM PoE交换机厂商密度
- Alibaba上442家PoE交换机供应商
- 278家OEM, 241家ODM, 58家有自有专利
- 主要集中在深圳
- 头部厂商: ONV(15年)/Ewind(7年)/SDAPO(5年)/COMFAST(14年)/Lianzhengda(12年)/BTON(2011年)

---

**Batch 17 总计: 27家新客户/竞品**

> 关键发现：
> 1. **深圳OEM竞品20家** — 完整价格带$5.50-90, Alibaba 442家供应商, 278家OEM
> 2. **零售/仓储7家** — IP Security Depot/Gear Net/ShowMeCables/Alavsta/Inscape/EnableIT/Delta-Opti波兰
> 3. **核心竞品对标**: ONV/Ewind/SDAPO/COMFAST/BTON/Huoyi(云管理)/Yunlink(无线)
> 4. **价格情报**: 8口PoE $5.50-10, 24口PoE+ $55-90, 深圳价格极具竞争力
