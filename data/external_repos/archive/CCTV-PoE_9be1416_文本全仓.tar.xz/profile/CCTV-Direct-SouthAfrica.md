# 客户档案：CCTV Direct — 南非

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司名称 | CCTV Direct |
| 国家 | 南非 Randburg, Johannesburg |
| 类型 | 安防设备电商/直销 |
| 网站 | cctv-direct.co.za (Shopify) |
| 客户级别 | **A级（核心）** |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 邮箱 | info@cctv-direct.co.za |
| 电话 | 066 240 8183 (8am-1pm weekdays) |
| WhatsApp | Kishka Bichener 071 493 5476（仅WhatsApp） |
| 仓库 | JHB (Randburg)，支持客户自提 |

**关键联系人：Kishka Bichener — WhatsApp 071 493 5476**

## 公司深度分析

### 当前PoE交换机在售（从网站提取）
- **已在销售Hikvision PoE交换机** — 直接对口！
- **已在销售Dahua PoE交换机** — 直接对口！
- ZAR定价，南非本地货币

### 产品组合
Hikvision全线 / Dahua / HiLook / IP摄像头 / NVR / 报警 / 太阳能安防

### 业务模式
- Shopify电商平台
- 南非全国免费快递
- 仓库自提（EFT/现金付款有折扣）
- Payfast/Payflex支付

## 推荐Saga产品

| Saga型号 | 规格 | FOB($) | 建议ZAR零售 | 对标 |
|----------|------|--------|-----------|------|
| STC-028GFP | 10口百千兆PoE | $13-15 | R800-1,200 | Hikvision 8口PoE (R2,500+) |
| STC-1216GFP | 18口百千兆PoE | $29-32 | R1,500-2,000 | Dahua 16口PoE (R4,500+) |
| STC-228GP | 12口千兆PoE+SFP | $24-28 | R1,200-1,800 | — |
| PoE延长器 | 250m | $4-7 | R300-500 | 配套热卖 |

### 核心卖点
1. **"比Hikvision/Dahua PoE便宜70-80%"** — 电商价格竞争利器
2. **"250米PoE"** — 差异化卖点，南非竞品没有
3. **"金属外壳"** — 电商详情页卖点
4. **"免运费+仓库自提"** — 与CCTV Direct商业模式匹配
5. **"OEM品牌"** — 可以贴CCTV Direct品牌

## 跟进计划

| 阶段 | 行动 | 时间 |
|------|------|------|
| 1 | **WhatsApp联系Kishka: 071 493 5476** | 本周 |
| 2 | 邮件info@cctv-direct.co.za | 本周 |
| 3 | 准备Saga vs Hikvision/Dahua PoE价格对比 | 1周内 |
| 4 | 寄样到JHB仓库 | 2周内 |

## 预期订单

| 阶段 | 预估金额 |
|------|---------|
| 首单 | $3,000-8,000 |
| 年供货 | $30,000-60,000 |
