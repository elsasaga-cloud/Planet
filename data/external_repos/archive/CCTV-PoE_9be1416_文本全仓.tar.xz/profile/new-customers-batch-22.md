# Batch 22 — MikroTik/WISP分销 + 教育PoE + VoIP PoE市场
> 深度挖掘 Round 67-70 (2026-10-25)
> 方法论：MikroTik PoE分销 / WISP ISP PoE / 教育PoE / VoIP PoE IP电话

---

## 一、MikroTik PoE分销商（全球）

### 1. LinITX（英国）
- **类型**: C类 — MikroTik+Ubiquiti Master Distributor
- **网站**: linitx.com
- **开发策略**: 英国MikroTik官方分销
- **置信度**: ★★★★★

### 2. Flytec Computers（美国）
- **类型**: C类 — MikroTik官方分销
- **网站**: flyteccomputers.com
- **开发策略**: 美国MikroTik PoE分销
- **置信度**: ★★★★☆

### 3. Baltic Networks（美国）
- **类型**: C类 — MikroTik ISP设备
- **网站**: balticnetworks.com
- **开发策略**: 美国MikroTik ISP分销
- **置信度**: ★★★★☆

### 4. Getic（欧洲）
- **类型**: C类 — MikroTik VAD
- **网站**: getic.com
- **认证**: MikroTik Value Added Distributor + Ubiquiti Elite
- **开发策略**: 欧洲MikroTik增值分销
- **置信度**: ★★★★★

### 5. Multilink Solutions（美国）
- **类型**: C类 — Master Distributor
- **网站**: multilink.us
- **品牌**: MikroTik+Ubiquiti+Revo FTTH
- **开发策略**: 美国Master Distributor
- **置信度**: ★★★★★

### 6. WISP.PL（波兰）
- **类型**: C类 — MikroTik VAD
- **网站**: wisp.pl
- **品牌**: MikroTik+Ubiquiti+TP-Link+Tenda+Teltonika+Cudy
- **开发策略**: 波兰MikroTik VAD，覆盖东欧
- **置信度**: ★★★★★

### 7. Vesuvius Streamline
- **类型**: C类 — MikroTik+Ubiquiti分销
- **网站**: vesuviustreamline.com
- **规模**: 166 MikroTik + 130 Ubiquiti产品
- **开发策略**: MikroTik+Ubiquiti网络设备分销
- **置信度**: ★★★★☆

### 8. Wireless Professional Solutions / WISP（澳大利亚）
- **类型**: C类 — MikroTik+Ubiquiti官方
- **网站**: wisp.net.au
- **品牌**: MikroTik+Ubiquiti+IgniteNet+PLANET+ASRock Rack
- **开发策略**: 澳大利亚+新西兰MikroTik官方分销
- **置信度**: ★★★★★

### 9. Alselsal Trading（UAE/Dubai）
- **类型**: C类 — MikroTik Dubai/Africa/MENA
- **网站**: mikrotikuae.com
- **地点**: Khalid bin Al Walid Street, Dubai
- **开发策略**: UAE→非洲→MENA MikroTik分销
- **置信度**: ★★★★★

### 10. MikroTik Russia
- **类型**: C类 — 俄罗斯官方
- **网站**: mikrotik.ru
- **开发策略**: 俄罗斯MikroTik官方分销
- **置信度**: ★★★★★

### 11. NetXL（英国）
- **类型**: C类 — MikroTik分销
- **网站**: netxl.com
- **开发策略**: 英国MikroTik分销
- **置信度**: ★★★★☆

### 12. i4WiFi（捷克/欧洲）
- **类型**: C类 — Ubiquiti/MikroTik
- **网站**: i4wifi.eu
- **开发策略**: 捷克Ubiquiti/MikroTik分销
- **置信度**: ★★★★☆

### 13. MakroWisp
- **类型**: C类 — Ubiquiti分销
- **网站**: makrowisp.com
- **开发策略**: Ubiquiti PoE分销
- **置信度**: ★★★☆☆

### 14. Airpath Wirelessnet（印度）
- **类型**: C类 — Ubiquiti+MikroTik
- **网站**: airpathnetworks.in
- **地点**: Chennai
- **开发策略**: 印度Ubiquiti+MikroTik PoE分销
- **置信度**: ★★★★☆

### 15. Elettra Teknologi（印尼）
- **类型**: C类 — MikroTik官方
- **网站**: elettra.co.id
- **开发策略**: 印尼MikroTik官方分销
- **置信度**: ★★★★☆

### 16. Linktechs（美国）
- **类型**: C类 — MikroTik PoE ISP
- **网站**: shop.linktechs.net
- **产品**: CRS328-24P-4S+RM / CRS112-8P-4S-IN / netPower 16P
- **开发策略**: 美国MikroTik PoE ISP方案
- **置信度**: ★★★★☆

---

## 二、教育PoE市场

> **市场数据**: 教育占全球PoE交换机收入14.2% (2025), CAGR 9.1%

### 17. NVT Phybridge（加拿大/全球）
- **类型**: B类 — PoE教育方案
- **网站**: nvtphybridge.com
- **案例**: Michigan State University 4000+IP电话, Catholic School 160校区$2M节省
- **开发策略**: PoE教育/长距离方案专家
- **置信度**: ★★★★★

### 18. PoE Partner Education（德国）
- **类型**: B类 — PoE教育方案
- **网站**: poe-partner.com/en/application-schools-universities
- **产品**: PoE Texas Switch + GAT-USBC-PD-V3 (PoE→USB-C 25W iPad充电)
- **开发策略**: 欧洲PoE教育方案
- **置信度**: ★★★★★

---

## 三、VoIP PoE IP电话市场 ($2.1B→$4.9B 2032)

> **市场数据**: PoE IP电话市场2024年$2.1B, 预计2032年$4.9B, CAGR 11.2%

### 19. Fanvil Technology（深圳）
- **类型**: B类 — PoE IP电话品牌
- **网站**: fanvil.com
- **产品**: PoE IP电话全线
- **开发策略**: 深圳PoE IP电话品牌，需PoE交换机配套
- **置信度**: ★★★★★

### 20. Htek / Hanlong Tech（深圳）
- **类型**: B类 — PoE IP电话OEM
- **网站**: htekphone.com
- **产品**: PoE IP电话OEM/ODM
- **开发策略**: 深圳PoE IP电话OEM
- **置信度**: ★★★★☆

### 21. Escene Communication（深圳）
- **类型**: B类 — PoE IP电话
- **网站**: escene.com
- **开发策略**: 深圳VoIP PoE品牌
- **置信度**: ★★★★☆

### 22. Snom Technology（德国）
- **类型**: B类 — PoE IP电话
- **网站**: snom.com
- **开发策略**: 德国PoE IP电话品牌
- **置信度**: ★★★★★

### 23. Yeastar（中国）
- **类型**: B类 — VoIP PBX+PoE
- **网站**: yeastar.com
- **产品**: VoIP PBX + IP电话
- **开发策略**: VoIP PBX品牌，需PoE交换机配套
- **置信度**: ★★★★★

### 24. Dinstar（深圳）
- **类型**: B类 — VoIP网关+PoE
- **网站**: dinstar.com
- **开发策略**: 深圳VoIP网关品牌
- **置信度**: ★★★★☆

### 25. Grandstream（深圳/美国）
- **类型**: B类 — VoIP+PoE全线
- **网站**: grandstream.com
- **产品**: PoE IP电话+交换机+PBX+AP+摄像头
- **开发策略**: 深圳+美国VoIP全线品牌
- **置信度**: ★★★★★

### 26. ADI Technologies（印度）
- **类型**: C类 — VoIP PoE授权分销
- **网站**: adi4.com
- **品牌**: Grandstream/Yealink/Cisco/Fanvil/Dinstar
- **开发策略**: 印度VoIP PoE授权分销
- **置信度**: ★★★★☆

### 27. NeedToKnow Comms（澳大利亚）
- **类型**: C类 — Yealink/Grandstream
- **网站**: needtoknowcomms.com.au
- **开发策略**: 澳大利亚VoIP PoE分销
- **置信度**: ★★★☆☆

---

## 四、WISP/ISP PoE交换机

### 28. Ubiquiti UISP-S
- **类型**: 竞品 — WISP MicroPoP
- **产品**: 8口GbE PoE 110W SFP $115
- **开发策略**: WISP专用PoE竞品
- **置信度**: ★★★★★

### 29. MikroTik CRS328-24P-4S+RM
- **类型**: 竞品 — ISP PoE
- **产品**: 24口GbE PoE+ 450W 4x10G SFP+
- **开发策略**: ISP PoE竞品标杆
- **置信度**: ★★★★★

---

**Batch 22 总计: 29家新客户/情报**

> 关键发现：
> 1. **MikroTik分销16家** — LinITX英国/Flytec美国/Getic欧洲VAD/Multilink美国Master/WISP.PL波兰VAD/WISP澳洲官方/Alselsal Dubai非洲MENA/Russia官方/i4WiFi捷克/Airpath印度/Elettra印尼/Linktechs美国
> 2. **教育PoE 2家** — NVT Phybridge(MSU 4000+电话)/PoE Partner Education(USB-C iPad充电)
> 3. **VoIP PoE市场8家** — Fanvil/Htek/Escene深圳/Snom德国/Yeastar/Dinstar/Grandstream/ADI印度
> 4. **WISP竞品2家** — Ubiquiti UISP-S $115/MikroTik CRS328 450W
> 5. **其他1家** — NeedToKnow澳洲VoIP
