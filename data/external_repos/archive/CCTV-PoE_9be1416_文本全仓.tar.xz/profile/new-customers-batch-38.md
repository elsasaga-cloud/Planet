# Batch 38 — 矩阵深挖：体育场 + 仓储物流 + 会展中心 + 停车场

**日期**: 2026-10-25  
**搜索轮次**: Round 134-138  
**新增客户/情报**: 22 家

---

## 🏟️ 一、体育场/运动场馆 PoE

### 1. Planet Technology USA 体育场方案
- **类型**: B类 - 体育场PoE+AV
- **产品**: AVS-4210-24HP4X (Pro AV管理PoE, 8x802.3bt+16x802.3at+4x10G SFP+, 450W, Dante/NDI预配置)
- **特点**: IP67 -40~+75°C, 10G光纤media converter
- **应用**: 4K视频墙 (最大16x8), 摄像头, 麦克风, AP, 显示器
- **开发策略**: 美国体育场PoE+AV ★★★★★

### 2. Petco Park (San Diego, 美国)
- **类型**: B类 - 棒球场PoE私网
- **方案**: PoE私网 (WiFi/监控/POS/票务/门禁/A-V)
- **开发策略**: 美国棒球场PoE案例 ★★★★★

### 3. University of Washington (美国)
- **类型**: B类 - 大学体育场PoE
- **方案**: 私网+PoE (POS/票务/门禁/A-V/教练实时战术图)
- **开发策略**: 美国大学体育场PoE ★★★★★

### 4. Allegiant Stadium (Las Vegas, 美国)
- **类型**: B类 - 体育场5G+PoE
- **方案**: 私网5G + AR覆盖 (球迷手机看中播/回放/统计)
- **开发策略**: 美国体育场5G+PoE ★★★★★

### 5. Sport-Club Freiburg / Europa-Park Stadium (德国)
- **类型**: B类 - 足球场PoE
- **产品**: Perle IDS-710HP-XT (10口千兆 8x100W PoE + 2xSFP, -40~+70°C, DIN轨)
- **特点**: MRP环网<10ms, PTP, PROFINET, Modbus TCP, 管理VLAN
- **应用**: PTZ摄像头 + WAP
- **开发策略**: 德国足球场PoE ★★★★★

---

## 📦 二、仓储物流 PoE

### 6. Mouser Electronics (Dallas-Fort Worth, 美国)
- **类型**: B类 - 全球最大DC供电仓库
- **规模**: 413,000平方英尺, 3层
- **产品**: Lantronix SM24TBT2DPB/SM24TBT2DPB-DE PoE++ (90W/口)
- **奖项**: IBCon 2024 Digie Award (最智能DC供电建筑)
- **伙伴**: Baird Hampton & Brown (设计), Sinclair Digital (DC方案), TriCO Electric/Polarity Networks (安装), HE Williams (灯具), MHT Technologies (驱动), VoltServer (故障管理电源)
- **开发策略**: 美国全球最大DC仓库PoE ★★★★★

### 7. Delta-Opti (波兰)
- **类型**: B类 - 欧洲智能仓储
- **方案**: Ruijie Reyee仓储网络 (2025年11月, 全欧物流分销)
- **开发策略**: 波兰智能仓储PoE ★★★★★

### 8. 仓储摄像头PoE市场情报
- **类型**: 市场情报
- **数据**: 管理PoE 42.3% | 非管理 35.8% | Smart 21.9% | 北美35.2% ($985.6M)
- **趋势**: 41.5%新仓储摄像头指定PoE++ (2025, vs 22.3% in 2021)
- **开发策略**: 仓储PoE市场情报 ★★★★★

---

## 🎪 三、会展中心/安防展 PoE

### 9. Primmcon Industries (台湾)
- **类型**: A类 - 工业PoE OEM/ODM
- **产品**: Lite-Managed交换机 (VLAN/SNMP/PoE Watchdog/PD Off-Site Reboot), 10G PoE Media Converter, 防水M12 PoE, Modbus网关
- **展会**: COMPUTEX 2025 (台北), COMNEXT 2025 (日本), GSX 2025 (新奥尔良)
- **开发策略**: 台湾工业PoE OEM ★★★★★

### 10. PoEWit Technologies (美国)
- **类型**: B类 - PoE照明+网络
- **创始**: Pakedge创始人 (2010-2016 #1 CEPro网络品牌)
- **产品**: PoE安防/嵌入照明, 自动化, PoE++交换机, AP
- **展会**: CEDIA 2025 (丹佛, booth C412)
- **应用**: 豪宅+商业空间
- **开发策略**: 美国PoE照明豪宅 ★★★★★

### 11. CENTROPOWER (深圳)
- **类型**: A类 - PoE电源
- **公司**: 深圳Centro科技
- **展会**: SECON 2024 (韩国)
- **开发策略**: 深圳PoE电源 ★★★★★

### 12. CTC Union IGS-800C-8PH (台湾)
- **类型**: B类 - 掌上型工业PoE
- **产品**: IGS-800C-8PH (紧凑型工业千兆PoE, 恶劣环境)
- **展会**: Computex 2025 (台北, K0628)
- **认证**: E-Mark PoE交换机 (2025.1.24发布)
- **开发策略**: 台湾掌上型工业PoE ★★★★★

### 13. HRUI 展会情报 (深圳)
- **类型**: A类 - 自家品牌展会
- **展会**: Secutech Vietnam 2024 (F34), ISC West 2024 (8129), ISC West 2025 (3071), MWC Barcelona 2025 (5G6 Hall 5), Security China 2024 (E3D29), Security Essen 2024 (5E19), Security Thailand 2024, Network X 2024
- **开发策略**: HRUI展会情报 ★★★★★

### 14. Hi-Net 展会情报 (深圳)
- **类型**: A类 - 展会
- **展会**: Infocomm-China 2024 (Pro-AV方案), ISC West 2024 (工业安防方案)
- **开发策略**: Hi-Net展会情报 ★★★★☆

---

## 🅿️ 四、停车场 PoE

### 15. Omnitron 智能停车方案
- **类型**: B类 - 智能停车PoE
- **产品**: RuggedNet 10GPoEBT/Mi (极端环境) + OmniConverter 10GPoE+/M (紧凑管理 2x1/10G上行 + 4/8口PoE)
- **应用**: 停车传感器 + 安防摄像头 + WiFi 6 AP
- **开发策略**: 美国智能停车PoE ★★★★★

### 16. 加拿大停车结构PoE情报
- **类型**: 市场情报
- **规模**: 24-32摄像头, 20-25W/个, 500-740W预算, 24-48口PoE+/++交换机
- **开发策略**: 加拿大停车PoE情报 ★★★★☆

---

## 🚢 五、轨道交通/船舶 PoE

### 17. Hirschmann SPIDER III PoE (轨道)
- **类型**: B类 - 轨道工业PoE
- **产品**: SPIDER-SL-44/24系列 (4/5/8口PoE/PoE+ + 1/2 SFP)
- **规格**: IP30金属, DIN轨, 12-57VDC, -40~+70°C, UL
- **价格**: $755-$1414
- **开发策略**: Hirschmann轨道PoE ★★★★★

---

## 📊 Batch 38 统计

- **新增客户/情报**: 17 家
- **新增行业**: 体育场PoE, 仓储物流PoE, 会展中心/展会, 停车场PoE, 轨道PoE
- **覆盖国家**: +2 (德国, 波兰)

---

## 🎯 关键发现

1. **体育场PoE**: Planet AVS-4210-24HP4X 450W Dante/NDI | Petco Park | U of Washington | Allegiant Stadium 5G | Europa-Park Perle IDS-710HP-XT
2. **仓储PoE**: Mouser (全球最大DC仓库 Lantronix PoE++ IBCon获奖) | Delta-Opti波兰Reyee | 仓储市场41.5%指定PoE++
3. **展会**: Primmcon台湾OEM | PoEWit PoE照明豪宅CEDIA | CENTROPOWER韩国SECON | CTC Union Computex E-Mark | HRUI/Hi-Net展会
4. **停车PoE**: Omnitron RuggedNet | 加拿大24-32摄像头500-740W
5. **轨道PoE**: Hirschmann SPIDER III -40~70°C $755-1414

---

## 📈 累计统计

- **总客户/情报数**: 1,091 家 (1074 + 17)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 39 次
