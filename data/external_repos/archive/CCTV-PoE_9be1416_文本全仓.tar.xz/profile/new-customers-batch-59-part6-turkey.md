# Batch 59 Part 6: 土耳其机场+大学+建筑+白电+燃气
## 5渠道: IST 9000 CCTV+208大学Ruijie+48 ENR Top 250+Arçelik/Vestel I4.0+İGDAŞ 24646km
_2026-10-27 | 15 entries | Turkey Deep Mining Part 6_

---

### 渠道AD: 航空 (3家 = 20,000+ PoE)
- **101.41 İGA Istanbul Airport** 🇹🇷 A类 | **9,000 CCTV**, 1.44M m², 84.4M旅客, 15K+ PoE
- **101.42 Turkish Cargo SmartIST** 🇹🇷 A类 | 205K m², 2.2→4.5M吨, 全球#3货运
- **101.43 Turkish Airlines** 🇹🇷 A类 | **₺100B投资8设施**, 492→800架飞机, 数据中心

### 渠道AE: 大学 (2条 = 200,000+ PoE)
- **101.44 Koç University** 🇹🇷 A类 | **已用Ruijie**, 32栋宿舍, 2.1Gbps, 验证中国方案
- **101.45 208大学情报** 🇹🇷 A类 | **6.3M学生**, YÖK管辖, İTÜ/METU/Boğaziçi/Koç/Sabancı

### 渠道AF: 建筑巨头 (6条 = 137国出口)
- **101.46 Rönesans** 🇹🇷 A类 | **ENR#50**, 11年Top 50, $50B, 28国, 1000+项目
- **101.47 Limak** 🇹🇷 A类 | **ENR#51**, $4.1B, IST机场+Kuwait T2+Çanakkale大桥
- **101.48 ENKA** 🇹🇷 B类 | ENR#46, $3.4B
- **101.49 Cengiz** 🇹🇷 B类 | IST机场合作方, $15B在建
- **101.50 Yapı Merkezi** 🇹🇷 B类 | ENR#113, $2.7B, 铁路+桥梁
- **101.51 48家情报** 🇹🇷 A类 | **12,297项目**, $515.8B累计, 137国, PoE随出口

### 渠道AG: 白电制造 (2家 = 18,000+ PoE)
- **101.52 Arçelik/Beko** 🇹🇷 A类 | **46厂×14国**, 欧洲最大, WEF灯塔×2, 3500传感器, 5G网络
- **101.53 Vestel** 🇹🇷 A类 | **1.3M m²** Vestel City, 3000万台/年, NatGeo Mega Factories

### 渠道AH: 燃气 (2家 = 3,000+ PoE)
- **101.54 İGDAŞ** 🇹🇷 A类 | **24,646km管网**(世界最大), 7M用户, 749调压器, SCADA+地震
- **101.55 行业情报** 🇹🇷 B类 | 全国18.5M用户, 多城市分配公司

---

## 关键发现

### 超级PoE项目 (单项目>5,000端口)
1. **İGA Istanbul Airport**: 15,000+ PoE (9,000 CCTV + 周界 + 行李 + WiFi)
2. **Arçelik 46工厂**: 10,000+ PoE (产线+AGV+传感器)
3. **Vestel City**: 8,000+ PoE (1.3M m²全厂区)
4. **Turkish Airlines 8设施**: 5,000+ PoE

### 战略洞察
- **Ruijie已在Koç大学落地** = 中国网络方案在土耳其高校已被接受
- **48家ENR建筑商** = PoE可随土耳其项目出口137国(Russia/Turkmenistan/Iraq/Libya/Africa)
- **İGDAŞ SCADA招标**(2026) = 防火墙+网络设备采购窗口
- **Arçelik用Nokia 5G+Cisco WAN** = 已有高端网络基础设施, 可切入PoE层
