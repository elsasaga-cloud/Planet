# Batch 60 Part 5: UK养老院+监狱+港口+私立医院+公交
## 5渠道: Welltower 600+养老院£6.4B/117监狱13K bodycam/ABP 21港口5G/Spire £1B收购/Big Five 34K公交250K端口
_2026-10-27 | 16 entries | UK Deep Mining Part 5_

---

### 渠道U: 养老院 (6条)
- **102.101 Welltower** 🇬🇧 A类 | **600+ UK养老院**, £10B portfolio, £5.2B Barchester+£1.2B HC-One
- **Barchester** 🇬🇧 A类 | 270家, 14,500床, **£967M**, £127M capex
- **HC-One** 🇬🇧 A类 | 275家, 15,400床, £434M
- **Care UK** 🇬🇧 A类 | 242家, 15,411床, £581M, +Aria+Danforth 12K床
- **Bupa** 🇬🇧 B类 | 154家, £12.9B全球
- **Avery+Anchor+MHA** 🇬🇧 B类 | 103+121+charity

### 渠道V: 监狱 (4条)
- **102.102 HM Prison** 🇬🇧 A类 | **117监狱**, 13K Motorola bodycam, £100M安全, £4B新建
- **Smart Prison** 🇬🇧 A类 | £400M Full Sutton(Kier) + Glen Parva + 3新
- **模拟→数字** 🇬🇧 A类 | CCTV坏了1年! "analogue no-one produces" = 必须换全系统
- **AI+生物识别** 🇬🇧 B类 | 异常行为+身份验证+自动锁定+手机屏蔽

### 渠道W: 港口 (5条)
- **102.103 ABP** 🇬🇧 A类 | **21港口**, 25% UK海运, Avigilon全集团
- **Felixstowe** 🇬🇧 A类 | UK #1集装箱48%, **Private 5G**, £200M, £3.4M 5G+CCTV+IoT
- **DP World** 🇬🇧 A类 | London Gateway £1B, 3,700冷藏, Zodiac TOS
- **Tilbury** 🇬🇧 B类 | 16M吨, **500+ CCTV**+ANPR, 港口警察
- **Peel Ports** 🇬🇧 B类 | Liverpool+Manchester

### 渠道X: 私立医院 (6条)
- **102.104 Circle** 🇬🇧 A类 | **54医院**, PureHealth UAE, 最大网络
- **Spire** 🇬🇧 A类 | 38医院, **£1B Toscafund**, 1.36M患者, £99M capex
- **Nuffield** 🇬🇧 A类 | 37医院+113健身, **£200M AI诊断**, 非营利
- **HCA UK** 🇬🇧 B类 | 7医院London高端
- **Ramsay** 🇬🇧 B类 | 35医院, 区域
- **Bupa Hospitals** 🇬🇧 A类 | Cromwell+New Victoria+King Edward VII's(2025回归)

### 渠道Y: 公交运营商 (5条)
- **102.105 Stagecoach** 🇬🇧 A类 | **8,347车**, £500M+电动, Synectics £1.5M CCTV, Chargd B2B充电
- **FirstGroup** 🇬🇧 A类 | 6,000车, 1,400零排放, £89M Heliox 5场站
- **Go-Ahead** 🇬🇧 A类 | 6,000车, **1,000伦敦ZE**(UK最大), Oxford £82.5M
- **Arriva** 🇬🇧 A类 | €2.5B I Squared收购, **£340M投资**(809新车+8场站电气化)
- **National Express** 🇬🇧 B类 | 长途, Stagecoach合并

---

## 关键发现
- **Welltower £6.4B** = 世界最大养老院交易, 600+ UK养老院
- **监狱模拟→数字** = "no-one produces analogue anymore" = 必须换全系统!
- **Felixstowe Private 5G** = UK最大私有5G, CCTV远程控制起重机
- **Spire £1B收购** = UK私立医院整合潮
- **公交250K端口** = 34,610车×6摄像头+200场站×200端口
