# 客户档案：GCTL (Germany Computer & Telecom Ltd) — 孟加拉

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司全称 | Germany Computer and Telecom Limited |
| 品牌名 | GCTL Security |
| 国家 | 孟加拉 Dhaka |
| 类型 | 安防设备进口商/分销商 |
| 网站 | gctlsecurity.com |
| 客户级别 | **A级** |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 邮箱 | sales@gctlbd.com / info@gctlbd.com |
| 电话 | +880 1847213868 / +880 2 48952407 |
| 电话2 | +880 1979228870 |
| Facebook | facebook.com/gctlsecur |
| LinkedIn | linkedin.com/in/gctlbd |
| Twitter | @gctlbd |
| YouTube | youtube.com/channel/UCm5gVepC_OX2kfJPf97AMxA |
| Instagram | @gctl_security |

## 公司深度分析

### 产品线
CCTV摄像头 / 门禁系统 / 入侵报警 / 排队管理 / X光行李扫描仪 / LED显示屏

### 品牌代理
- **AVTECH** — 进口商（台湾品牌）
- **Hikvision** — 分销商
- **Dahua** — 分销商
- **CP Plus** — 分销商

### 项目案例
- X光安检设备安装（DBL集团等大型企业）
- LED显示屏安装（政府部门）
- 安防系统集成

## 推荐Saga产品

| Saga型号 | 规格 | FOB($) | 推荐理由 |
|----------|------|--------|---------|
| STC-028GFP | 10口百千兆PoE | $13-15 | 配合Hikvision/Dahua/AVTECH摄像头 |
| STC-1216GFP | 18口百千兆PoE | $29-32 | 中型项目 |
| STC-1224GFP | 26口百千兆PoE | $41-45 | 大型项目 |
| STC-228GP | 12口千兆PoE+SFP | $24-28 | 高端+光纤联网 |
| PoE延长器 | 250m | $4-7 | 孟加拉布线距离远 |

### 核心卖点
1. **"配合你已有的Hikvision/Dahua/AVTECH摄像头"** — 完美兼容
2. **"孟加拉市场最低价"** — FOB $13-15起
3. **"250米PoE"** — 孟加拉安装距离远
4. **"金属外壳+PoE看门狗"** — 减少售后维护
5. **"OEM贴牌"** — 可以贴GCTL品牌

## 跟进计划

| 阶段 | 行动 | 时间 |
|------|------|------|
| 1 | 邮件sales@gctlbd.com | 本周 |
| 2 | 电话+880 1847213868 | 1周内 |
| 3 | LinkedIn加gctlbd | 1周内 |
| 4 | 寄送样品 | 2周内 |

## 预期订单

| 阶段 | 预估金额 |
|------|---------|
| 首单 | $3,000-8,000 |
| 年供货 | $20,000-50,000 |
