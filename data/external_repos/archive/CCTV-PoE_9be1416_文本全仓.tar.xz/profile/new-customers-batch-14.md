# Batch 14 — 智慧城市 + VoIP生态 + 日韩市场 + 市场规模情报
> 深度挖掘 Round 31-34 (2026-10-25)
> 方法论：智慧城市PoE / VoIP电话生态 / 日韩成熟市场 / 市场规模情报

---

## 一、B类：VoIP电话品牌 → PoE交换机生态

### 1. Grandstream Networks（美国波士顿）— 已在Batch 8
- **补充**: 自有PoE交换机线（GWN7803P/GWN7801P/GWN7721P/GWN7711P/GWN7700P）
- **VoIP电话线**: GRP2612P/GXP2140/GXP2135/GXP1625/GXV3470视频电话
- **开发策略**: 电话+交换机捆绑销售，A类高价值目标
- **置信度**: ★★★★★

### 2. Yealink（中国厦门）
- **类型**: A类竞品 — VoIP电话#1品牌，自有PoE交换机
- **网站**: yealink.com
- **产品**: RCH80 (8口PoE+ AV-over-IP交换机 $389)
- **电话线**: T54W/T46U/T33G/T31P/T31G/T34W全系列PoE
- **开发策略**: VoIP市场#1，自有交换机线，竞品情报
- **置信度**: ★★★★★

### 3. Fanvil（中国北京）
- **类型**: B类 — VoIP电话品牌
- **产品**: 全系列PoE IP电话
- **Reddit评价**: "界面差，PoE交换机重启时不兼容"
- **开发策略**: VoIP品牌，可能需要更兼容的PoE交换机
- **置信度**: ★★★★☆

### 4. Eagaton（中国）
- **类型**: B类 — 新兴VoIP品牌
- **产品**: T53P (PoE IP电话, 3 SIP, 2.4寸彩屏)
- **开发策略**: 新兴VoIP品牌，需要PoE交换机配套
- **置信度**: ★★★☆☆

### 5. IP Phone Warehouse（美国）
- **类型**: C类 — VoIP设备分销
- **网站**: ipphone-warehouse.com
- **品牌**: Grandstream GWN交换机/Yealink RCH80/Polycom
- **开发策略**: 美国VoIP设备专业分销
- **置信度**: ★★★★★

### 6. VoIP Supply（美国）
- **类型**: C类 — PoE交换机+VoIP
- **网站**: voipsupply.com
- **品牌**: Grandstream GWN系列全线PoE交换机
- **开发策略**: 美国VoIP供应链
- **置信度**: ★★★★★

---

## 二、智慧城市 PoE 情报

### 7. Teltonika Networks（立陶宛）
- **类型**: B类 — 工业PoE交换机用于智慧照明
- **网站**: teltonika-networks.com
- **产品**: TSW040 (8口PoE+ 工业交换机, 240W, -40~75°C)
- **应用**: 智慧城市照明系统
- **开发策略**: 立陶宛工业品牌，智慧城市PoE方案
- **置信度**: ★★★★★

### 8. Microchip Technology（美国）
- **类型**: B类 — 户外PoE交换机芯片+方案
- **产品**: PDS-204GCO (户外802.3bt PoE交换机, 网络安全)
- **应用**: 智慧城市(交通/监控/IoT)
- **开发策略**: 芯片级PoE方案商
- **置信度**: ★★★★★

### 9. Konten Networks（中国）
- **类型**: 竞品 — 工业PoE交换机+智慧城市
- **网站**: konten-networks.com
- **产品**: MP-1604XB (16+4口工业管理型PoE+ 10G上行)
- **特点**: UL/CE/FCC认证, ERPS环网, -40~75°C
- **开发策略**: 智慧城市/校园PoE方案竞品
- **置信度**: ★★★★☆

### 10. Inscape Data（美国）
- **类型**: B类 — 户外PoE一体机方案
- **网站**: inscapedata.com
- **产品**: All-in-One-Box PoE方案（智慧城市）
- **开发策略**: 智慧城市PoE基础设施
- **置信度**: ★★★★☆

### 11. Planet Technology USA
- **类型**: B类 — 智慧城市PoE方案
- **网站**: planetechusa.com
- **应用**: PoE LED照明/智慧公园/智慧建筑
- **开发策略**: 台湾品牌美国分支，智慧城市PoE
- **置信度**: ★★★★★

### 12. Shoroq IT Dubai（迪拜）
- **类型**: C类 — WiFi/PoE方案集成商
- **网站**: shoroqitdubai.com
- **品牌**: Cisco/Aruba/Ruckus/Ubiquiti
- **开发策略**: 迪拜办公室WiFi/PoE集成
- **置信度**: ★★★★☆

---

## 三、日韩市场情报

### 13. Soltech Co Ltd（韩国）
- **类型**: A类 — 韩国PoE交换机出口#1
- **出货**: 占韩国PoE交换机出口26%（12批/年）
- **开发策略**: 韩国最大PoE交换机出口商
- **置信度**: ★★★★★

### 14. Hyundai Rotem Company（韩国）
- **类型**: B类 — 韩国PoE交换机出口#3
- **出货**: 占韩国PoE交换机出口15%（7批/年）
- **开发策略**: 韩国铁路/工业PoE
- **置信度**: ★★★★★

### 15. Panasonic Electric Works Networks（日本）
- **类型**: B类 — 日本PoE交换机出口
- **产品**: PoE compliant switch HUB
- **美国地址**: 38 Tesla, Irvine, California
- **开发策略**: 松下PoE方案
- **置信度**: ★★★★★

### 16. ALAXALA Networks（日本）
- **类型**: 竞品 — 日本网络交换机品牌
- **开发策略**: 日本核心网络品牌
- **置信度**: ★★★★★

---

## 四、市场规模情报

### 全球PoE交换机市场
- **2025年市场规模**: $3.8B (USD)
- **2034年预测**: $7.9B
- **CAGR**: 8.5%
- **亚太占比**: 36.4% ($1.38B)
- **北美占比**: 28.6%
- **欧洲占比**: 22.3%
- **管理型占比**: 61.2%

### 日本市场
- **2024年非管理型PoE**: $0.9B → 2033年 $1.5B (CAGR 5.8%)

### 韩国市场
- **2024年非管理型PoE**: $0.6B → 2033年 $1.0B (CAGR 6.0%)

### PoE安防交换机市场
- **亚太CAGR**: 14.3% (最快增长)
- **亚太2024**: $736M (占全球23%)

### PoE照明市场
- **2025年亚太**: $35.25M (CAGR 13.0%)
- **硬件占比**: 60%（含PoE交换机）

---

**Batch 14 总计: 16家新客户/情报**

> 关键发现：
> 1. **VoIP生态6家** — Grandstream(补充)/Yealink(自有交换机)/Fanvil/Eagaton/IP Phone Warehouse/VoIP Supply
> 2. **智慧城市6家** — Teltonika/Microchip/Konten/Inscape Data/Planet USA/Shoroq Dubai
> 3. **日韩4家** — Soltech韩国#1/Hyundai Rotem/Panasonic/ALAXALA
> 4. **市场情报**: 全球$3.8B, 亚太$1.38B, CAGR 8.5%, 安防PoE CAGR 14.3%
