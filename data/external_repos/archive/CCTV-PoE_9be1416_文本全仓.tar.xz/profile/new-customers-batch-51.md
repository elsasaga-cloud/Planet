# Batch 51 — 垂直场景PoE：医疗 + 教育校园 + 酒店 + 体育场 + 广播演播室

**日期**: 2026-10-25  
**搜索轮次**: Round 199-203  
**新增客户/情报**: 28 家  
**聚焦**: 医疗医院, 教育校园, 酒店住宿, 体育场馆, 广播演播室

---

## 🏥 一、医疗医院 PoE

### 1. Yamaha SWX2322P-16MT (日本)
- **类型**: B类 - 医疗PoE++ SDVoE
- **案例**: 帝京大学沟口病院 (Teikyo University Hospital, Mizonokuchi), 2023年X线透视系统升级, 多设备信息单显示
- **产品**: SWX2322P-16MT, 10G/multi-gigabit智能L2 PoE++ 16口, SDVoE标准兼容, Mediaedge传输设备测试
- **特点**: SDVoE Optimal Settings一键激活, 医疗信息大容量高速传输, 安全措施完整 (未来扩展帝京大学+地方医疗机构), Dante IP音频集成计划
- **结果**: 530+检查治疗 (呼吸+消化等), 大幅减少眼部移动, 集中检查治疗, 考虑手术室+血管造影室扩展
- **开发策略**: 日本医疗PoE++ SDVoE ★★★★★

### 2. NVT Phybridge 医疗 (美国)
- **类型**: B类 - 医疗PoE长距离
- **产品**: PoE交换机热插拔电源+冗余+电源管理+50W/口, 同轴/UTP现有基础设施IP+IoT设备
- **特点**: 数字化转型+云+AI医疗, 传统PoE交换机距离+电缆限制→高基础设施成本+风险+复杂性+电子废物, 利用现有同轴/UTP
- **开发策略**: 美国医疗PoE长距离 (同轴/UTP) ★★★★★

### 3. Omnitron 医院IoT PoE (美国)
- **类型**: B类 - 医疗IoT PoE
- **优势**: 连续电力+数据单电缆 (简化布线+减少故障点→患者监护+远程医疗车), 简化基础设施 (无独立电气→降成本+快速部署), 未来设备可扩展 (无需重工程)
- **部署建议**: 冗余设计 (故障切换+备份PoE交换机), 网络分段 (医疗IoT vs 访客WiFi vs 管理→降安全风险), 工业级PoE (24/7+医疗标准合规), 优先扩展 (未来 vs 当前)
- **开发策略**: 美国医院IoT PoE ★★★★★

### 4. Cisco Catalyst 9300 UPOE+ 照明 (美国)
- **类型**: B类 - 医疗PoE照明
- **案例**: Clarke County Hospital, Cisco UPOE+ PoE照明, 现有IT网络电缆+Cisco UPOE+交换+自管理部署多新建+翻新区域
- **产品**: Catalyst 9300系列90W UPOE+, Panduit以太网电缆+PanZone天花板外壳+GENISYS创新照明
- **特点**: 编程照明控制 (运动传感器+日程+控制箱), 仪表板监控 (如网络设备), IT团队灵活放置 (难达区域), 90W UPOE+扩展OT设备 (桌面终端+安防摄像头+环境控制+门禁等)
- **开发策略**: 美国医疗PoE照明 (90W UPOE+) ★★★★★

### 5. PROCET 医疗PoE (中国)
- **类型**: A类 - 医疗PoE供电
- **产品**: PoE over Ethernet IEEE802.3bt 60-100W, 医疗电机+医生办公设备 (iPad+电脑+监控), PoE to USB Type-C适配器60W 100/1000Mbps高通用性, 减少转换线+适配器
- **应用**: 远程医疗+现场诊断+智能健康监测穿戴+数字病历管理
- **开发策略**: 中国医疗PoE供电 ★★★★★

### 6. 医疗PoE市场情报
- **类型**: 市场情报
- **规模**: Healthcare PoE细分17.8%份额 (2025#2), CAGR 8.7%, 临床系统依赖可靠始终在线网络 (护士呼叫+患者监护+药物管理+电子病历工作站)
- **特点**: 管理PoE交换机稳定买家 (网络安全分段+保证正常运行+远程监控重启医疗级设备), 极端快速采用PoE系统 (护士呼叫站+患者监护+电子门锁+自动配药器)
- **开发策略**: 医疗PoE市场潜力极高 (17.8%#2 CAGR 8.7%) ★★★★★

---

## 🎓 二、教育校园 PoE

### 7. Aoyama Gakuin University (日本)
- **类型**: C类 - 校园PoE大项目
- **计划**: 2029年前部署3,000 PoE接入点, 电源预算与端口数并列采购优先
- **开发策略**: 日本校园PoE大项目 (3,000 AP) ★★★★★

### 8. Arista 710HXP 校园户外 (美国)
- **类型**: B类 - 校园PoE++加固
- **产品**: 710HXP系列加固PoE++户外, 体育场照明+停车场监控
- **开发策略**: 美国校园PoE++加固 (体育场+停车) ★★★★★

### 9. Ubiquiti ECS Enterprise Campus PoE (美国)
- **类型**: B类 - 校园PoE+++
- **产品**:
  - ECS-24-PoE: 24口90W PoE+++ (16×10GbE+8×2.5GbE), 2×25G SFP28, 1050W, L3, $2,499
  - ECS-48-PoE: 48口90W PoE+++ (16×2.5GbE+32×10GbE), 4×25G SFP28, 2150W, L3, $3,999
  - ECS-24S-PoE: 24口 (16×10GbE+8×2.5GbE), 4×25G SFP28+2×100G QSFP28堆叠, 热插拔风扇+电源, 1050W, $2,999 (9月18日)
  - ECS-48S-PoE: 48口, 2150W, $3,999
- **PoE注意**: 1050W需双600W电源共享模式, 冗余模式降至450W
- **开发策略**: 美国校园PoE+++ 90W (10G+25G+100G) ★★★★★

### 10. Huawei S5731/S6730 校园 (中国)
- **类型**: B类 - 校园PoE
- **产品**: S5731-H24P4XC (PoE+/UPOE 720W 中型企业+教育), S6730-H48X6C (PoE++ 960W 校园+医疗)
- **案例**: 大学校园宿舍+教室WiFi (S5735-L24P4X+AirEngine AP, 统一电源控制+延迟-40%)
- **开发策略**: 中国校园PoE (宿舍+教室WiFi) ★★★★★

### 11. Cisco UPOE+ Academy (美国)
- **类型**: B类 - 教育PoE 90W
- **案例**: Academy for International Education (AIE), 学区首个Cisco Catalyst UPOE+交换机, 每教室90W PoE+USB-C dongle, 单连接插电+联网
- **开发策略**: 美国教育PoE 90W USB-C ★★★★★

### 12. PoE Partner 学校大学 (德国)
- **类型**: B类 - 教育PoE
- **产品**: PoE Texas Switch集中供电多设备, 90W/口管理IEEE 802.3bt, GAT-USBC-PD-V3 PoE to USB-C 25W (美国唯一专利, iPad+平板教室充电+连接单电缆)
- **开发策略**: 德国教育PoE 90W USB-C ★★★★★

### 13. Lantronix Campus PoE++ (美国)
- **类型**: B类 - 校园PoE++
- **产品**: SM8TBT2SA 8口, SM24TBT4SA 24口, SM24TBT4XPA 24口, PoE++/PoE+同交换机, Percepxion云管理软件预配置, 智能LED照明+智能建筑传感器+接入点+IP摄像头
- **开发策略**: 美国校园PoE++ Percepxion云 ★★★★★

### 14. 教育PoE市场情报
- **类型**: 市场情报
- **规模**: Education PoE细分14.2%份额 (2025), CAGR 9.1% (2025-2034), 技术丰富教室环境加速 (PoE交互平板+IP对讲+校园WiFi 6+集成BMS)
- **驱动**: 美国E-Rate+EU数字教育行动计划+澳大利亚/加拿大/印度/巴西政府资助K-12+高教网络基础设施升级 (系统包含管理PoE交换机更换)
- **案例**: 高等教育早期采用 (讲堂密集用户), 48口分发交换机2,880W电源 (翻倍上代容量→未来采购基线), Juniper Mist AP 60W全吞吐+Arista 90W/口校园交换机 (2025)
- **开发策略**: 教育PoE市场潜力极高 (14.2% CAGR 9.1%) ★★★★★

---

## 🏨 三、酒店住宿 PoE

### 15. Ruijie Reyee 酒店CCTV (中国)
- **类型**: A类 - 酒店PoE#1
- **产品**: Smart CCTV Switch系列, SMB酒店简化管理+高可靠硬件
- **特点**: 工业级耐用 (4kV防雷保护旧电气系统+无风扇静音→客房区无噪音), Ruijie Cloud管理 (99.99%可用+AI诊断→非技术员工远程部署维护)
- **案例**: Delta-Opti波兰 (2025年11月) 仓储网络+CCTV监控+配送多设施
- **开发策略**: 中国酒店PoE#1 (CCTV+Cloud AI) ★★★★★

### 16. Kuailu Hotel 五星PoE升级 (中国)
- **类型**: C类 - 酒店PoE案例
- **案例**: Kuailu Hotel 500间五星, 网络不稳+布线混乱+维护成本高→客人互联网满意度低+安防风险
- **方案**: 三层架构 (核心三层PoE+汇聚+接入二层PoE), 客房双频无线AP+PoE交换机, 24口客房+48口公共/安防 802.3bt
- **安全**: 端口安全+VLAN+防火墙
- **结果**: 网络性能显著提升 (客房+公共高速稳定WiFi→满意度大增), 安防更全面 (全方位无缝), PoE简化布线→降施工成本+维护难度+运营成本
- **开发策略**: 中国五星酒店PoE升级案例 ★★★★★

### 17. Conrad New York Downtown PoE照明 (美国)
- **类型**: C类 - 酒店PoE照明
- **案例**: PoE酒店照明改造, 报告60-75%节能, 实际影响公用账单
- **开发策略**: 美国酒店PoE照明 (60-75%节能) ★★★★★

### 18. Sinclair Hotel Fort Worth PoE (美国)
- **类型**: C类 - 酒店PoE智能
- **案例**: PoE照明+窗帘+智能房间组件 (vs传统电气), 40%电耗降低
- **开发策略**: 美国酒店PoE智能 (40%节能) ★★★★★

### 19. Hotel Marcel New Haven PoE (美国)
- **类型**: C类 - 酒店PoE零碳
- **案例**: 完全独立化石燃料, DC低压照明+PoE自动窗帘 (综合可持续方法)
- **开发策略**: 美国酒店PoE零碳 (DC低压+PoE窗帘) ★★★★★

### 20. NVT Phybridge 酒店PoE (美国)
- **类型**: B类 - 酒店PoE长距离
- **产品**: PoE交换机热插拔+冗余+电源管理+50W/口, 同轴/UTP现有基础设施IP+IoT
- **特点**: 数字化转型+云+AI酒店→提升客人体验+优化运营+合规, 传统PoE距离+电缆限制→高成本+风险+复杂性+电子废物
- **开发策略**: 美国酒店PoE长距离 (同轴/UTP) ★★★★★

### 21. TP-Link Omada 酒店 (中国)
- **类型**: B类 - 酒店PoE SDN
- **产品**: Omada SDN平台, WiFi 7 AP+PoE交换机 (4/5/8/12/16/24/48口)+MGIG+管理+光纤, Wi-Fi网关+网络交换机, PoE+/PoE++/PoE供电/PoE穿透, 工业+L3+核心, 无缝客人体验+易迁移+集中控制+可扩展安全+角色访问+VLAN分段+自动更新
- **开发策略**: 中国酒店PoE SDN (WiFi 7+全PoE) ★★★★★

### 22. Ubiquiti U7 In-Wall WiFi 7 (美国)
- **类型**: B类 - 酒店PoE入墙
- **产品**: Access Point U7 In-Wall, 入墙4-stream 2.4/5GHz WiFi 7, 房间级覆盖+无缝安装, 集成2.5GbE PoE交换机, PoE+输入单口PoE输出, 酒店环境
- **开发策略**: 美国酒店PoE入墙 (WiFi 7+2.5G PoE+) ★★★★★

---

## 🏟️ 四、体育场馆 PoE

### 23. Planet Technology USA 体育场 (美国)
- **类型**: B类 - 体育场PoE+AV-over-IP
- **产品**: AVS-4210-24HP4X Pro AV Managed PoE Switch, 8×802.3bt PoE+++16×802.3at PoE++4×10G SFP+上行, 450W总PoE预算, 摄像头+扬声器+显示+AP
- **特点**: IP67 -40~75°C屋顶+周边, 10G光纤媒体转换器骨干速度跨场馆, PoE交换机自动检测非PoE设备 (混合网络), Dante+NDI预配置AV-over-IP
- **应用**: 安防摄像头+门禁, 记分牌+走廊标牌+视频墙 (IHD-420PT/PR视频墙扩展器)
- **开发策略**: 美国体育场PoE+AV-over-IP ★★★★★

### 24. Sport-Club Freiburg Europa-Park Stadium Perle (德国)
- **类型**: B类 - 体育场PoE工业
- **案例**: Europa-Park Stadium, 足球场周边8杆50m间隔每杆3 PTZ摄像头+不锈钢外壳网络, 场边+新闻发布室+办公室WAP员工WLAN
- **产品**: Perle IDS-710HP-XT工业PoE管理交换机, 10口千兆8×100W PoE+2SFP (1G/2.5G/10/100/1000铜), IEEE802.3bt PoE, DIN轨小外壳
- **特点**: 体育场环境高要求 (边缘设备常暴露工业条件), 全球供应链挑战Perle唯一按时交付符合严格规格PoE交换机
- **开发策略**: 德国体育场PoE工业 (Perle唯一按时) ★★★★★

---

## 📺 五、广播演播室 PoE

### 25. Visual Productions PoeSwitch (荷兰)
- **类型**: B类 - 广播PoE灯光控制
- **产品**: PoeSwitch, 非管理DIN轨网络交换机, 4口100M RJ45 PoE Class 3+1口1000M上行, IPv4/IPv6 QoS, CE/RoHS/UKCA/FCC, 802.3af, 60W预算 (15.4W/口), 功耗60W最大/1.02W待机, 4.09×4.16×2.36英寸, HDR-100-48可选电源, $400
- **应用**: 中小型灯光控制系统Visual Productions控制器连接+供电, InfoComm 2024发布
- **开发策略**: 荷兰广播PoE灯光控制 ($400) ★★★★★

### 26. Ikan Lyra PoE 广播灯光 (美国)
- **类型**: B类 - 广播PoE++ DMX-over-IP
- **产品**:
  - LBX8-POE: 50W PoE++ 802.3bt单Cat6, 双色3200K-5600K, Art-Net+sACN+DMX-over-IP, Q-SYS认证插件, 钨等效500W, 97CRI
  - LBX10-POE: 85W PoE++同样控制栈, 钨等效750W, 5-pin XLR传统DMX512
  - LBX20-POE: 170W双PoE++连接, 钨等效1000W, 大工作室
- **特点**: PoE演播室灯光改变部署模型 (电力+控制单Cat6→无电工+无管道+无许可大多数辖区), 灯具成IP设备网络 (AV团队已管理平台控制), DMX-over-IP (Art-Net+sACN标准广播控制语言→与视频流+控制信号同网络→无需独立DMX控制台), Q-SYS认证插件控制256灯/宇宙 (无需独立灯光控制台)
- **案例**: Gwinnett County Public Schools Georgia 40+广播工作室PoE灯光 (无任何位置拉电气许可)
- **交换机**: PoE++ 802.3bt管理足够每口瓦数+总预算, Ikan预匹配Netgear Ultra90 PoE++ 802.3bt (380W非管理小部署/720W管理大部署+VLAN分段)
- **开发策略**: 美国广播PoE++ DMX-over-IP (Q-SYS+Art-Net+sACN) ★★★★★

### 27. PTZCam 16口PoE+ 直播 (美国)
- **类型**: B类 - 直播PoE+
- **产品**: 16口千兆PoE+直播网络交换机, L2管理, 16×1Gbps PoE+ RJ-45 (25.5W/口) + 2SFP 1Gbps上行 (光纤/铜SFP模块不含), 300W总PoE, 56Gbps总交换带宽, IEEE802.3af/at
- **应用**: PTZ摄像头+控制器+编码器直播流
- **开发策略**: 美国直播PoE+ (PTZ+控制器+编码器) ★★★★★

### 28. Studio Technologies Model 214 PoE广播 (美国)
- **类型**: B类 - 广播PoE音频
- **产品**: Model 214播音员控制台, 单PoE以太网连接易部署+快速运行, 体育广播教育Mt. San Antonio College学生制作体育赛事+课堂教学
- **特点**: 单网络连接实现复杂连接到制作环境→减轻学生制作压力, 光纤附加PoE交换机同战术光纤支持播音员视频监视器→播音员站快速运行, 学生无问题部署使用
- **开发策略**: 美国广播PoE音频 (播音员控制台) ★★★★★

---

## 📊 Batch 51 统计

- **新增客户/情报**: 28 家
- **聚焦行业**: 医疗医院, 教育校园, 酒店住宿, 体育场馆, 广播演播室
- **覆盖国家**: +2 (日本, 荷兰已有)

---

## 🎯 关键技术发现

1. **医疗医院**: Yamaha SWX2322P-16MT 10G PoE++ SDVoE帝京大学沟口病院530+检查 (日本), NVT Phybridge医疗50W/口同轴/UTP (美国), Omnitron医院IoT PoE冗余+分段+工业级 (美国), Cisco Catalyst 9300 UPOE+ 90W PoE照明Clarke County Hospital (美国), PROCET医疗802.3bt 60-100W USB-C (中国), Healthcare 17.8%#2 CAGR 8.7%
2. **教育校园**: Aoyama Gakuin 3,000 AP 2029 (日本), Arista 710HXP加固PoE++户外体育场+停车 (美国), Ubiquiti ECS-24/48-PoE 90W PoE+++ 10G+25G+100G 1050/2150W $2,499/$3,999 (美国), Huawei S5731/S6730校园 (中国), Cisco UPOE+ 90W USB-C AIE (美国), PoE Partner学校90W USB-C (德国), Lantronix Campus PoE++ Percepxion云 (美国), Education 14.2% CAGR 9.1%
3. **酒店住宿**: Ruijie Reyee Smart CCTV#1 4kV防雷+Cloud AI 99.99% (中国), Kuailu五星500间PoE升级三层802.3bt (中国), Conrad NY 60-75%节能 (美国), Sinclair Fort Worth 40%节能 (美国), Hotel Marcel零化石DC低压+PoE窗帘 (美国), NVT Phybridge 50W/口同轴/UTP (美国), TP-Link Omada SDN WiFi 7+全PoE (中国), Ubiquiti U7 In-Wall WiFi 7 2.5G PoE+ (美国)
4. **体育场馆**: Planet AVS-4210-24HP4X Pro AV 8×802.3bt+16×802.3at+4×10G 450W Dante+NDI IP67 -40~75°C (美国), Sport-Club Freiburg Europa-Park Perle IDS-710HP-XT 10口100W 8+2SFP唯一按时 (德国)
5. **广播演播室**: Visual Productions PoeSwitch 4口60W $400灯光控制InfoComm 2024 (荷兰), Ikan Lyra PoE LBX8/10/20 50-170W PoE++ DMX-over-IP Art-Net/sACN Q-SYS Gwinnett 40+工作室 (美国), PTZCam 16口PoE+ 300W直播PTZ (美国), Studio Technologies Model 214 PoE播音员 (美国)

---

## 📈 累计统计

- **总客户/情报数**: 1,349 家 (1321 + 28)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 53 次
- **超额完成**: 193% (目标 700客户)
