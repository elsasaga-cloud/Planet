# 波兰深度挖掘 Part 2 + Part 3 (渠道 114-123)

**日期**: 2026-10-27  
**国家**: 波兰 (Poland)  
**渠道数**: 10 (Part 2: 5, Part 3: 5)  
**PoE端口**: 688,000+ 端口

---

## Part 2 (114-118): 413,000+ 端口

### 114. 购物中心 (250个, 6,003K sqm GLA) → 75,000+
- Westfield Arkadia: 287K sqm, 230店铺, 中欧最大 (Unibail-Rodamco-Westfield)
- Silesia City Center: 86K sqm, 310店铺 (Katowice)
- Westfield Mokotów: 68K sqm, 260店铺

### 115. 物流仓储 → 50,000+
- **Amazon**: 12个履约中心, PLN 23B投资, 25K+员工
  - Sosnowiec/Gliwice(210K sqm)/Wrocław/Łódź/Warsaw
  - Dobromierz: 200K sqm, 5K+机器人 (2026.10)
- **DHL**: €180M Robakowo (Poznań), 1M包裹/日
- **Zalando**: 3个履约中心 (DHL Supply Chain运营)
- **Panattoni**: 100+物流园区, 10M+ sqm
- **Prologis**: 25+园区, 2.2M+ sqm
- **SEGRO**: 20+园区, Stryków 302K sqm

### 116. 港口海运 → 8,000+
- **Gdańsk**: 71M吨 (全国57%), Baltic Hub 4.5M TEU (波罗的海最大), Smart Gate
- **Gdynia**: 23M吨, BCT 1M TEU (ICTSI), GCT (Hutchison Ports, NATO NCAGE)
- **Szczecin-Świnoujście**: 35.3M吨, €2.3B新深水码头 (2M TEU, 2030)
- ISPS合规, AEO认证, PCS/TOS/e-NOT智能系统

### 117. 体育场 → 30,000+
- **PGE Narodowy**: 58,274座, PLN 1.91B, Cisco Connected Stadium, 5G DAS
- **Silesian Stadium**: 54,378座 (Chorzów)
- **Enea Stadium**: 42,837座 (Poznań, Euro 2012)
- **Tarczyński Arena**: 42,771座 (Wrocław, Euro 2012)
- **Polsat Plus Arena**: 41,620座 (Gdańsk, Euro 2012)
- Ekstraklasa 18队 + I/II Liga 30+场馆

### 118. 政府公共行政 → 250,000+
- 21部委 + 16省长办公室 + 380县 + 2,477市镇
- 警察: 93,637人, 17区域指挥部, 5特种部队
- 边境警卫/消防/SOK/ABW/AW
- CANARD自动交通监控 (全国测速)

---

## Part 3 (119-123): 275,000+ 端口

### 119. 数据中心 (80设施, 16.19% CAGR) → 20,000+
- **Atman**: WAW-1 (57MW), WAW-2 (16MW), WAW-3 (43MW, €720M, 液冷, 2025)
- **Equinix**: WA1/WA2/WA3/WA4x (xScale, 100%可再生)
- **EdgeConneX**: WAW01-03 + Digital Ursus (波兰最大, Top 5科技)
- **Data4**: Jawczyce €500M, 60MW (2030)
- **Beyond.pl**: Poznań 150MW AI-Ready
- **Vantage**: Warsaw 12英亩
- Warsaw占80%, 500MW目标 (2030), 1,200MW (2034)

### 120. 矿业 → 10,000+
- **PGG**: 37K员工, 7煤矿, EU最大硬煤 (ABB MineOptimize)
- **JSW**: 21K员工, 5煤矿, EU最大焦煤 (Industry 4.0, 全自动长壁面)
- **KGHM**: 34K员工, 3铜矿, 710K吨铜 + 1,347吨银 (ABB 800xA)
- 安全系统: SMP-NT/A甲烷监控, 地震声学, 人员定位, 巷道收敛

### 121. 农业食品加工 (1,270+企业) → 90,000+
- **Animex** (WH Group): $3.4B, 11K员工, 11加工厂, 1.5亿禽/年
- **Mlekovita**: $2.5B, 5K员工, 25工厂, 800万升/日, 167国出口
- **Cedrob**: $1.9B, 最大家禽 (Duda品牌)
- **Mlekpol**: $1.8B, 乳制品合作社
- **Maspex**: PLN 16B, Tymbark/Łaciate/Kubuś
- HACCP/ISO 9001/IFS/BRC认证

### 122. 媒体广播 → 15,000+
- **TVP**: 13全国 + 16地区频道, 250个DVB-T发射塔
- **Polsat**: 30频道, Polsat Box 3.47M用户
- **TVN** (WBD): TVN/TVN24/Player.pl
- **Canal+ Polska**: 20+频道, UEFA Champions League

### 123. 商业办公楼 → 140,000+
- **Varso Tower**: 310m, 53层, EU最高 (Foster+Partners, BREEAM Outstanding)
- **Warsaw Spire**: 220m, 49层, 129K sqm (Ghelamco)
- **Warsaw Unit**: 200.7m, **Skyliner**: 195m, **WTT**: 186m
- Warsaw CBD 6.5M+ sqm, 10+摩天大楼
- 其他城市: Wrocław Sky Tower 212m, Gdańsk Olivia Star 180m

---

## 波兰全部总结

| Part | 渠道 | PoE端口 |
|------|------|---------|
| Part 1 (104-113) | 分销/国防/能源/铁路/零售/机场/制造/酒店/医疗/大学 | 1,385,000+ |
| Part 2 (114-118) | 购物中心/物流/港口/体育场/政府 | 413,000+ |
| Part 3 (119-123) | 数据中心/矿业/食品/媒体/办公楼 | 275,000+ |
| **总计** | **20渠道** | **2,073,000+ 端口** |
