# Batch 57: 跨域矩阵深挖 (10维交叉组合)
## 弱电工程+网络顾问+MSP云管+AV-over-IP+5G小基站+PoE照明+BMS楼控+游艇海事+边缘计算+光纤ISP
_2026-10-25 | 28 entries | 10 cross-domain dimensions_

---

### 92.1 KIT Communications | 美国Pennsylvania | B类
- **网站**: kit-communications.com
- **业务**: 1999年成立, BICSI RCDD认证, 3400+商业项目, 结构化布线+IP摄像头+门禁+WiFi+PoE
- **PoE需求**: PoE交换机为摄像头/AP/门禁供电, Cat6A PoE++
- **产品线**: 管理型PoE交换机+工业级+光纤收发器
- **策略**: B类(中国供应商经验), 推荐Saga Marvell管理型+HRUI非管理型组合

### 92.2 Fuse Systems | 国际(海事+企业) | A类
- **网站**: fuse.systems
- **业务**: 网络交换机选型指南(PoE预算/multi-gig/stacking), 海事IT游艇网络(35m+三层拓扑)
- **PoE需求**: 指定PoE交换机规格, 海事L3冗余核心+PoE+接入层
- **产品线**: L2/L3管理型PoE交换机+10G SFP+冗余
- **策略**: A类(顾问指定品牌), 推荐Saga Marvell L3管理型

### 92.3 Telecomate | 国际 | B类
- **网站**: telecomate.com
- **业务**: PoE功率预算架构指南(PSE内部总线150-1600W), 动态功率分配, 企业选型
- **PoE需求**: 深度PoE技术内容, 802.3af/at/bt标准解读
- **产品线**: 全系列PoE交换机+技术文档
- **策略**: B类(技术内容合作), OEM产品+技术白皮书

### 92.4 Datto Networking (Kaseya) | 美国+国际 | A类
- **网站**: datto.com/products/switches
- **业务**: 云管理PoE+交换机, 多租户MSP平台, PoE+全端口30W
- **PoE需求**: 云管理PoE交换机OEM/白标, Zero-Touch Provisioning
- **产品线**: L2管理型PoE交换机+云管理+ZTP
- **策略**: A类(MSP平台OEM), 量大标准化, Benchu Group白标合作

### 92.5 Grandstream Networks | 美国(Boston) | A类
- **网站**: grandstream.com/products/networking-switches
- **业务**: 管理型+非管理型PoE交换机, 3年质保, VoIP+AP+摄像头生态
- **PoE需求**: PoE交换机OEM/ODM全系列, 3年质保
- **产品线**: 全系列PoE交换机(8/16/24/48口)
- **策略**: A类(OEM品牌商), 3年质保匹配Saga品质

### 92.6 AVPro Edge | 美国(South Dakota) | A类
- **网站**: avproglobal.com
- **业务**: AC-MXNET-10G-SW24C 24口10G PoE(8×PoE+++16×PoE+), Dante/AES67/SDVoE QoS优化
- **PoE需求**: 10G PoE++交换机OEM, 预配置Dante/AES67 QoS
- **产品线**: 10G管理型PoE++交换机+AV专用配置
- **策略**: A类(AV专业品牌OEM), 高溢价, RTL9303 10G PoE+Marvell方案

### 92.7 NETGEAR AV Line | 美国 | B类(参考)
- **网站**: netgear.com/hub/business/av/switches-streaming-av-over-ip
- **业务**: M4250 AV Line(NDI/Dante/AES67 profiles), M4350 16×2.5G PoE+++4×SFP28 25G
- **PoE需求**: AV-over-IP PoE交换机参考
- **策略**: B类(参考竞品), 开发类似AV Line产品

### 92.8 SoundTube Entertainment (MSE Audio) | 美国(Kansas) | A类
- **网站**: soundtube.com
- **业务**: STNet Switch II 16口PoE 700W Dante专用, 每口40W PoE供IPD扬声器
- **PoE需求**: 16口PoE交换机OEM, 700W PSU, Dante QoS
- **产品线**: 管理型PoE交换机+Dante QoS+16口1RU
- **策略**: A类(音响品牌OEM), 定制16口700W PoE

### 92.9 GENISYS Lighting | 美国 | A类
- **网站**: genisyslighting.com
- **业务**: 美国PoE照明制造商, Innovative Lighting分部, 7.4%市场份额, Made in USA
- **PoE需求**: PoE++交换机(60-90W)供LED, 802.3bt Type 3/4
- **产品线**: PoE++管理型交换机(60-90W/口)
- **策略**: A类(PoE照明品牌), $1.43B新兴市场(2025), PoE++高功率

### 92.10 Igor Inc | 美国 | A类
- **网站**: igor-tech.com
- **业务**: PoE照明系统集成, 企业园区+机构建筑, 2024扩展部署协议
- **PoE需求**: PoE交换机(802.3at/bt), 管理型VLAN+QoS
- **产品线**: PoE++管理型交换机
- **策略**: A类(照明系统集成), 24/48口管理型PoE++

### 92.11 Platformatics | 美国 | A类
- **网站**: platformatics.com
- **业务**: 自动化PoE照明平台(节点+控制器+交换机+传感器+灯具+云)
- **PoE需求**: 自产PoE交换机OEM, 智能照明集成, 云平台
- **产品线**: 管理型PoE交换机+照明固件+云API
- **策略**: A类(平台型OEM), 完整PoE照明生态

### 92.12 Wipro Lighting | 印度(Bangalore) | A类
- **网站**: wiprolighting.com
- **业务**: Wipro集团照明分部, 2024年9月扩展拉美分销
- **PoE需求**: PoE交换机供照明系统, 拉美市场
- **产品线**: PoE管理型交换机+照明集成
- **策略**: A类(印度大品牌), 拉美扩展需新供应商

### 92.13 CoolAutomation | 以色列 | A类
- **网站**: coolautomation.com
- **业务**: HVAC-BMS网关(BACnet IP/MS-TP BTL认证+Modbus TCP/RTU), 实时调试
- **PoE需求**: PoE交换机供BMS控制器+传感器, VLAN隔离BMS/IT
- **产品线**: 管理型PoE交换机+BACnet兼容
- **策略**: A类(BMS网关品牌), 技术深度高

### 92.14 Sentrado | 国际 | B类
- **网站**: sentrado.com
- **业务**: Siemens Desigo BMS集成, DDC控制器(BACnet/IP+Modbus+LonWorks), 2000 I/O点
- **PoE需求**: PoE交换机供DDC+传感器+执行器, BACnet/IP
- **产品线**: 管理型PoE交换机+BACnet QoS
- **策略**: B类(Siemens集成商)

### 92.15 ONEXP | 荷兰 | B类
- **网站**: onexp.com
- **业务**: 超级游艇AV/IT/网络安全集成, VSAT+5G+Starlink+OneWeb混合网络
- **PoE需求**: 海事PoE交换机(AP+摄像头+AV), 冗余电源, 宽温
- **产品线**: 工业管理型PoE交换机+冗余+宽温
- **策略**: B类(游艇集成商), 高溢价niche

### 92.16 GMTS | 国际 | B类
- **网站**: gmts.io
- **业务**: Peplink WAN+UniFi船载LAN, VLAN(WiFi/CCTV/IoT/AV), PoE预算+标签化机柜
- **PoE需求**: 船载PoE交换机, VLAN分段, 冗余
- **产品线**: 工业管理型PoE交换机+VLAN+冗余
- **策略**: B类(海事IT集成), 推替代/补充方案

### 92.17 Yacht Router Pro | 国际 | A类
- **网站**: yachtrouter.com
- **业务**: Yacht Router Pro s6(4 SAT+5G+WiFi), Network Expander Pro 24口GbE PoE
- **PoE需求**: 24口GbE PoE交换机OEM, 海事级, SFP+ 10G
- **产品线**: 管理型24口PoE交换机+SFP+海事级
- **策略**: A类(游艇设备OEM), 代工24口PoE

### 92.18 Teltonika Networks | 立陶宛 | B类
- **网站**: teltonika-networks.com
- **业务**: OTD140/OTD500 5G户外路由(IP55 PoE in/out), TSW100 PoE交换机
- **PoE需求**: 配套PoE交换机(户外CCTV+AP), 工业级
- **产品线**: 工业PoE交换机+户外级+宽温
- **策略**: B类(已有PoE产品线), 推配套工业PoE

### 92.19 InHand Networks (映翰通) | 中国+国际 | B类
- **网站**: inhand.com
- **业务**: ODU12 5G户外路由(Wi-Fi 7 IP65 PoE+ 18W), 2.5G以太网, 双SIM
- **PoE需求**: 配套PoE交换机(NVR/AP), PoE级联
- **产品线**: 工业PoE交换机+2.5G
- **策略**: B类(中国同行), 合作配套PoE

### 92.20 Aircom Global | 印度+中东+东非 | B类
- **网站**: aircomglobal.com
- **业务**: 光纤基础设施(印度/乌干达/坦桑尼亚/肯尼亚/迪拜), ISP/电信/企业, 15年
- **PoE需求**: PoE交换机供ISP接入层+FTTx+监控
- **产品线**: 管理型+非管理型PoE+光纤收发器
- **策略**: B类(东非+中东ISP), 多国量大

### 92.21 NAFICON | 迪拜UAE+芬兰 | B类
- **网站**: naficon.ae
- **业务**: 芬兰母公司(北欧电信/数据中心), 迪拜制造中心, ISO9001, 30年
- **PoE需求**: PoE交换机配套光纤(数据中心+电信)
- **产品线**: 管理型PoE+SFP光纤模块
- **策略**: B类(中东光纤制造商), 管理型PoE+SFP

### 92.22 FIBER Technologies Uganda | 乌干达+东非 | D类
- **网站**: fiber-technologies.com
- **业务**: 光纤/网络/电信, FIBERDK丹麦合作, FOA认证(东非+中非)
- **PoE需求**: PoE交换机供ISP+企业项目
- **产品线**: PoE交换机+光纤收发器
- **策略**: D类(东非项目), FOA认证专业度

### 92.23 Stellar System | 沙特Riyadh | D类
- **网站**: stellarsystem.sa
- **业务**: 2024年成立, 中东电信网络基础设施
- **PoE需求**: PoE交换机供电信+数据中心+企业
- **产品线**: PoE管理型+非管理型
- **策略**: D类(沙特新公司), Vision 2030

### 92.24 Comatec (Al Awael) | 沙特 | D类
- **网站**: comatec.sa
- **业务**: Al Awael子公司, 501-1000员工, 数据网络通信
- **PoE需求**: PoE交换机供沙特基础设施
- **产品线**: PoE全系列
- **策略**: D类(沙特大型承包商), Vision 2030

### 92.25 Antaira Technologies | 美国(California) | B类(参考)
- **网站**: antaira.com
- **业务**: 工业PoE交换机(-40~75°C, PoE++ 95W/口), 网络冗余, 边缘计算
- **策略**: B类(参考竞品), 学习边缘计算PoE方案

### 92.26 Lantronix | 美国(California) | B类(参考)
- **网站**: lantronix.com
- **业务**: 管理型L2加固PoE++交换机+云管理(2024), 小尺寸+宽温, IoT智能建筑
- **策略**: B类(参考竞品), 学习云管+工业PoE结合

### 92.27 Robustel | 中国(南京)+国际 | B类
- **网站**: robustel.com
- **业务**: IoT网关(Modbus/OPC UA/BACnet/DNP3/MQTT), RobustOS Pro(Debian 11), Docker
- **PoE需求**: 配套PoE交换机供IoT设备
- **产品线**: 工业PoE交换机+网关配套
- **策略**: B类(中国同行), 合作配套PoE

### 92.28 NVT Phybridge | 加拿大 | A类
- **网站**: nvtphybridge.com
- **业务**: PoLRE24/PoLRE48管理型(单对UTP PoE 365m 4倍标准), 全球邮轮, PowerWise智能功率共享
- **PoE需求**: 长距离PoE交换机OEM, 单对线UTP 365m
- **产品线**: 管理型PoE交换机+长距离+功率共享
- **策略**: A类(长距离PoE OEM), 邮轮niche高溢价

---

## 关键技术趋势

### PoE照明市场 ($1.43B→$5.28B, 2025-2035, CAGR 13.9%)
- Signify(26.4%份额)+Cisco+Eaton+Hubbell+GENISYS(7.4%)
- 802.3bt Type 3(60W)+Type 4(90W)成为主流
- 智能建筑集成+能源管理驱动

### AV-over-IP协议生态
- Dante(Audinate): 90%+专业AV市场份额
- AES67: 开放标准, 跨厂商互操作(Dante/Ravenna/Livewire)
- SMPTE ST 2110-30: 广播级音频
- 需求: 管理型交换机+QoS+IGMP Snooping+PTP

### 5G小基站市场
- 2027年预计1300万户外5G小基站部署
- PoE供电: 802.3at(30W)→802.3bt(60-90W)
- 户外要求: IP65+, -40~+85°C, 6kV浪涌

### BMS/BAS协议栈
- BACnet/IP: 60%+商业建筑HVAC控制器
- Modbus TCP/RTU: 传统冷水机/锅炉
- MQTT: IoT传感器边缘
- PoE供电: 分布式传感器+控制器

### 边缘计算市场 ($14.7B→$71.9B, 2025-2035, CAGR 17.5%)
- 74%全球数据将在传统数据中心外处理(2030s)
- 工业PoE交换机为边缘设备供电
- IIoT占最大收入份额(22.7%)
