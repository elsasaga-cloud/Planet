# Batch 60 Part 1: 英国PoE分销+安防集成+智能建筑+NHS+数据中心
## 5渠道: 14家PoE分销+15家大型安防集成+8家智能建筑+NHS £151B+135数据中心
_2026-10-27 | 51 entries | UK Deep Mining Part 1_

---

### 渠道A: PoE/网络分销 (14家)
- **102.1 Netview CCTV** 🇬🇧 A类 | Leicester, Hikvision+Ruijie授权, 78+款PoE
- **102.2 ISET UK** 🇬🇧 B类 | Nottingham, Trade-only, HikVision PoE
- **102.3 Mast Digital** 🇬🇧 B类 | Doncaster, Dahua Tier 1
- **102.4 CCTV Kits** 🇬🇧 A类 | Warwickshire, Reyee主营, 88款PoE
- **102.5-14** 其他10家分销商 (CCTV Line/Satsecure/Euro CCTV/CCTV Global/Videcon/CCTVdirect等)

### 渠道B: 安防集成 (15家大型企业)
- **102.15 DSSL** 🇬🇧 A类 | Genetec Elite, 3000+摄像头
- **102.16 Videcom** 🇬🇧 A类 | 2000+摄像头, ANPR+AI
- **102.17 Link CCTV** 🇬🇧 A类 | 450+站, 伦敦最大合同
- **102.18 Abel Alarm** 🇬🇧 A类 | UK最大私营, 1965年
- **102.19-29** 其他11家 (CCTV Surveillance/Vision CCTV/Synergitech/Barry Bros/G4S等)

### 渠道C: 智能建筑/IoT (8家)
- **102.30 Ideal** 🇬🇧 A类 | UK首个商业PoE工作空间, Cisco, 40+智能建筑
- **102.31 ACCL** 🇬🇧 A类 | 25年, PoE优先, NHS
- **102.32-37** 其他6家 (Electracom/Infogrid/Smart Spaces/Connexin等)

### 渠道D: NHS (2条情报)
- **102.38 NHS England** 🇬🇧 A类 | **£151B**, £10B数字转型, 100K+ PoE端口
- **102.39 采购框架** 🇬🇧 A类 | G-Cloud 14 + NHS SBS £2.5B + NOE CPC £1.5B

### 渠道E: 数据中心 (12家)
- **102.40 VIRTUS** 🇬🇧 A类 | UK #1, London5 90MW
- **102.41 Equinix** 🇬🇧 A类 | 10伦敦DC, £3.9B Hertfordshire
- **102.42 Telehouse** 🇬🇧 A类 | LINX总部, 73MW, 132kV变电站
- **102.43-50** 其他8家 (Global Switch/Ark/Digital Realty/Kao/Datum等)
- **102.51 行业情报** 🇬🇧 A类 | 1.6GW, 135 DC, £44B AI投资

---

## 关键发现
- **英国安防集成商**: 1,398+家(SecurityInformed.com目录)
- **PoE已在UK验证**: Ideal部署UK首个商业PoE工作空间(Cisco)
- **NHS**: £10B数字转型 + £2.5B框架 = 巨大PoE替换机会(Cisco 2960/3850老化)
- **数据中心**: £44B私人投资(12个月), 3.5GW在建, 关键国家基础设施
