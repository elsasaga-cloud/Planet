# Batch 35 — 矩阵式深挖：洁净室 + 机场 + NDAA/TAA + 中美洲 + 太平洋岛国 + 南亚 + WISP + 危险环境

**日期**: 2026-10-25  
**搜索轮次**: Round 119-123 (矩阵组合)  
**新增客户/情报**: 45+ 家  
**方法论**: 行业 × 地区 × 标准 × 应用 多维交叉搜索

---

## 🏭 一、洁净室/制药 PoE

### 1. ARISTA (英国)
- **类型**: B类 - 洁净室 PoE 计算
- **产品**: PoE-enabled panel PCs, thin clients, displays, workstations
- **应用**: 制药洁净室 (墙装/ pedestal / VESA / 吊臂 / 嵌入式)
- **特点**: 集中 UPS 在服务器房, 通过 PoE 交换机供电到洁净室
- **优势**: 无需进入洁净室即可远程重启端口, Persistent PoE on Reboot
- **标准**: IEEE 802.3bt Type 3/4 (100W)
- **开发策略**: 英国制药 PoE 计算专家
- **置信度**: ★★★★★

### 2. 英国制药制造商趋势
- **情报**: 越来越多采用高功率 PoE (802.3bt 100W) 简化洁净室计算设备供电
- **应用**: Panel PCs, 平板显示器, 触摸屏, 瘦客户端, 工作站
- **优势**: 集中 UPS, 网络管理电源, 单端口控制
- **开发策略**: 英国制药 PoE 趋势情报
- **置信度**: ★★★★☆

---

## ✈️ 二、机场/航空 PoE

### 3. Omnitron 机场案例 (美国)
- **类型**: B类 - 机场 WiFi + 监控
- **产品**: iConverter + OmniConverter PoE media converters
- **方案**: 光纤从核心 PoP 到 IDF, PoE 交换机 + WiFi AP + IP 摄像头
- **拓扑**: Hub and spoke (每个 concourse 4 个 IDF)
- **挑战**: 停车场户外摄像头需硬化设备, 长距离需光纤
- **开发策略**: 美国机场 PoE 光纤方案
- **置信度**: ★★★★★

### 4. Planet Technology 机场方案 (美国)
- **类型**: B类 - 机场网络
- **产品**: IGS-4215-16P2T2S 工业交换机
- **规格**: 16x GbE PoE + 2x GbE copper + 2x SFP fiber
- **功能**: DHCP Snooping, IP Source Guard, ARP Inspection, 802.1x, RADIUS/TACACS+, SNMPv3
- **PoE 管理**: Schedule function (定时开关), 节能 + 安全
- **开发策略**: 美国机场 PoE 工业方案
- **置信度**: ★★★★★

---

## 🇺🇸 三、NDAA/TAA 合规品牌 (美国政府/国防)

### 5. Comnet (美国)
- **类型**: B类 - NDAA/TAA 硬化交换机
- **产品**:
  - CNG7F2T5P: 5口非管理 PoE+ 120W, -40°C~+75°C
  - CWX4F20T4M: 28口管理核心 (4x 10G SFP+ + 24x SFP)
  - CNX16F4T12MPB: 12口管理 PoE++ 360W (8x 90W 802.3bt)
- **应用**: 安全/工业/政府网络
- **合规**: TAA + NDAA
- **开发策略**: 美国 NDAA/TAA 硬化 PoE
- **置信度**: ★★★★★

### 6. TRENDnet NDAA/TAA 产品线
- **类型**: B类 - NDAA/TAA 全线
- **产品**: TPE-TG240g (24口 370W), TPE-3182WSB (18口 2.5G 450W), TPE-7124SBF (12口 10G), TPE-30284 (28口), TPE-5240WS (52口)
- **特点**: Lifetime warranty (美加), 2.5G PoE++
- **开发策略**: 美国 NDAA/TAA PoE 全线
- **置信度**: ★★★★★

### 7. D-Link NDAA 合规系列
- **类型**: B类 - NDAA 合规
- **产品**: DGS-1210-10P (10口 65W), DGS-1100-24PV2 (24口 100W), DGS-1100-05PDV2 (5口 PoE extender)
- **特点**: Lifetime warranty (北美), Smart Managed
- **开发策略**: D-Link NDAA 合规 PoE
- **置信度**: ★★★★★

### 8. BV-Tech (台湾)
- **类型**: B类 - NDAA 合规
- **产品**: 28口管理 (24 PoE+ + 4 uplink 250W), 5口 (4 PoE+ 55W)
- **制造**: Made in Taiwan
- **合规**: NDAA
- **开发策略**: 台湾 NDAA PoE 品牌
- **置信度**: ★★★★★

### 9. Tripp Lite (美国)
- **类型**: B类 - TAA 工业
- **产品**: NGI-U05POE4 (5口工业 30W 120W total, -10~60°C)
- **合规**: TAA (GSA Schedule)
- **开发策略**: 美国 TAA 工业 PoE
- **置信度**: ★★★★☆

### 10. Speco (美国)
- **类型**: B类 - NDAA IP65
- **产品**: P4S5O (5口 IP65 4口 PoE)
- **合规**: NDAA
- **开发策略**: 美国 NDAA 户外 PoE
- **置信度**: ★★★★☆

### 11. ipcampower (美国)
- **类型**: B类 - UL/NDAA/TAA
- **产品**: IPCP-24P2G-AF2 (24口 PoE+ 360W + 2 GbE uplink)
- **合规**: UL Listed + NDAA + TAA
- **质保**: 3年
- **开发策略**: 美国 UL/NDAA/TAA PoE
- **置信度**: ★★★★☆

### 12. AETEK (台湾) - Saudi Arabia
- **类型**: B类 - TAA/NDAA 沙特
- **应用**: 沙特政府设施/关键基础设施/Vision 2030
- **合规**: TAA + NDAA Section 889
- **开发策略**: 台湾 TAA/NDAA PoE 沙特
- **置信度**: ★★★★★

---

## 🌎 四、中美洲 PoE

### 13. Ticomer (哥斯达黎加)
- **类型**: C类 - 多品牌分销
- **网站**: cqnetcr.com
- **品牌**: TP-Link, Ubiquiti, MikroTik, Ruijie, Hikvision, Dahua, Wi-Tek, Huawei
- **产品**: USW-Flex, USW-24, USW-48-PoE, CSS610-8P-2S+, DS-3E0505D-O, Aruba JL683B
- **开发策略**: 哥斯达黎加多品牌 PoE 分销
- **置信度**: ★★★★★

### 14. Grupo Orotec (危地马拉)
- **类型**: C类 - ZKTeco 授权
- **网站**: tiendaoficialorotec.com
- **品牌**: ZKTeco (独家授权)
- **地点**: 7 Avenida 4-25 zona 4, Guatemala City
- **开发策略**: 危地马拉 ZKTeco PoE 独家
- **置信度**: ★★★★★

### 15. Grupo Teltec (危地马拉)
- **类型**: C类 - Hikvision 授权
- **网站**: grupoteltec.com
- **品牌**: Hikvision (工业交换机 DS-3T1506HP-SI)
- **地点**: Zona 11, Guatemala City
- **开发策略**: 危地马拉 Hikvision PoE 分销
- **置信度**: ★★★★★

### 16. camarasdeseguridad.com.gt (危地马拉)
- **类型**: C类 - 安防 PoE
- **品牌**: WI-TEK (WI-PS306GF-O 户外 IP65), Hikvision
- **开发策略**: 危地马拉安防 PoE
- **置信度**: ★★★★☆

### 17. Panacompu (巴拿马)
- **类型**: C类 - Ubiquiti
- **网站**: panacompu.com
- **产品**: USW-Lite-16-POE ($269.90), USW-PRO-48-POE ($1339.50), UDM-SE ($623.10)
- **开发策略**: 巴拿马 Ubiquiti PoE 分销
- **置信度**: ★★★★★

### 18. Steren (墨西哥/中美洲)
- **类型**: C类 - 电子零售
- **覆盖**: 墨西哥 400+ 店 + 哥斯达黎加/萨尔瓦多/厄瓜多尔/危地马拉/哥伦比亚/巴拿马/洪都拉斯/多米尼加/秘鲁
- **产品**: 8口/4口 PoE 交换机
- **开发策略**: 墨西哥电子零售 PoE 中美洲覆盖
- **置信度**: ★★★★★

### 19. 哥斯达黎加政府采购
- **类型**: G类 - 政府招标
- **项目**: 24口 PoE 接入交换机 (Caja Costarricense De Seguro Social)
- **规格**: 24口 10/100/1000 PoE
- **开发策略**: 哥斯达黎加政府 PoE 采购情报
- **置信度**: ★★★★☆

---

## 🏝️ 五、太平洋岛国 PoE

### 20. UNDP Samoa RFQ
- **类型**: G类 - 联合国采购
- **项目**: Cloud Managed PoE Switch (3台)
- **规格**: 24口 GbE PoE+ + 4x 10G uplink, ≥370W, L2/3, 3年 license/support
- **开发策略**: 联合国 Samoa PoE 采购
- **置信度**: ★★★★★

### 21. Prospettiva Cyber Systems (PCS, 南非)
- **类型**: B类 - 太平洋岛国供应
- **产品**: 工业以太网交换机, PoE 交换机, 光纤路由器, SD-WAN, 数据中心机架
- **覆盖**: Papua New Guinea
- **特点**: EU engineering + 南非制造
- **开发策略**: 南非 PCS 太平洋岛国 PoE
- **置信度**: ★★★★☆

### 22. JIAXUN (中国)
- **类型**: A类 - 斐济工业 PoE
- **产品**: JXRD024FP-AC (100M 24口工业 PoE)
- **应用**: 斐济工业环境
- **开发策略**: 中国 JIAXUN 斐济工业 PoE
- **置信度**: ★★★★☆

---

## 🌏 六、南亚 PoE (缅甸/尼泊尔/孟加拉/斯里兰卡)

### 23. ICT Myanmar (缅甸)
- **类型**: C类 - PoE 零售
- **网站**: ict.com.mm
- **地点**: 369 Laydaungkan Road, Yangon
- **产品**: PoE 交换机
- **开发策略**: 缅甸 PoE 零售
- **置信度**: ★★★★☆

### 24. Reyee Myanmar Pricebook
- **类型**: B类 - 缅甸价格表
- **文档**: Customer - Myanmar Reyee Pricebook 5th May 2025 (Scribd)
- **产品**: Unmanaged/Managed/PoE switches (3-5年 warranty)
- **开发策略**: Reyee 缅甸 PoE 市场情报
- **置信度**: ★★★★☆

### 25. First Aid Nepal (尼泊尔)
- **类型**: C类 - 多品牌分销
- **网站**: firstaidnepal.com
- **品牌**: Dahua, Hikvision, Netis, Ruijie
- **产品**: PFS3117-16ET-135 (16口 NPR 25243), DH-PFS3006-4ET-36 (6口 NPR 3242)
- **开发策略**: 尼泊尔多品牌 PoE 分销
- **置信度**: ★★★★★

### 26. All Nepal Sales (尼泊尔)
- **类型**: C类 - Hikvision
- **网站**: allnepalsales.com
- **产品**: Hikvision 4口 (NPR 4000), 8口 (NPR 7000), 24口 PoE
- **开发策略**: 尼泊尔 Hikvision PoE
- **置信度**: ★★★★☆

### 27. Quality Computer Nepal (尼泊尔)
- **类型**: C类 - 多品牌
- **网站**: qualitycomputer.com.np
- **品牌**: Hikvision, Ruijie Reyee
- **产品**: DS-3E0106P-E/M (NPR 4199), RG-ES106F-P (NPR 5550), RG-ES228GS-P (NPR 58700)
- **开发策略**: 尼泊尔多品牌 PoE
- **置信度**: ★★★★☆

### 28. Trimatrik Multimedia (孟加拉)
- **类型**: C类 - 安防 PoE
- **网站**: trimatrikbd.com
- **地点**: Uttara, Dhaka
- **产品**: PoE 交换机 (CCTV/IP camera/access control)
- **开发策略**: 孟加拉安防 PoE
- **置信度**: ★★★★★

### 29. BDStall (孟加拉)
- **类型**: C类 - 网络 PoE
- **网站**: bdstall.com
- **产品**: ONV-H1108PLS (10口 BDT 3000), E-LINK EL-408GP (8口 BDT 8000), ONV H1064PSD (4口 BDT 2600)
- **价格范围**: BDT 2500 - 120000
- **开发策略**: 孟加拉网络 PoE 价格情报
- **置信度**: ★★★★★

### 30. Techland BD (孟加拉)
- **类型**: C类 - 网络 PoE
- **网站**: techlandbd.com
- **产品**: TP-Link TL-SG2210P (BDT 14950), Hikvision DS-3E0110MP-E/M (BDT 3600), TP-LINK TL-SL2428P V4 (BDT 26950)
- **开发策略**: 孟加拉网络 PoE
- **置信度**: ★★★★☆

### 31. Hikvision Colombo (斯里兰卡)
- **类型**: C类 - Hikvision 授权
- **网站**: hikvisioncolombo.com
- **产品**: 5口/8口/24口/32口 PoE 交换机
- **联系**: +94778377990, info@energycctv.lk
- **开发策略**: 斯里兰卡 Hikvision PoE 授权
- **置信度**: ★★★★★

### 32. TechGates (斯里兰卡)
- **类型**: C类 - Hasivo
- **网站**: techgates.lk
- **品牌**: Hasivo (独家)
- **产品**: 8口 GbE PoE + 2 GbE uplink (LKR 34900)
- **开发策略**: 斯里兰卡 Hasivo PoE 独家
- **置信度**: ★★★★★

### 33. Zoomtech (斯里兰卡)
- **类型**: C类 - GV-TECH
- **网站**: zoomtech.lk
- **产品**: GV-TECH 8口 PoE (LKR 6490)
- **开发策略**: 斯里兰卡 GV-TECH PoE
- **置信度**: ★★★★☆

### 34. ICTD Sri Lanka (斯里兰卡)
- **类型**: C类 - Dahua
- **网站**: ictdistribution.net/sri
- **品牌**: Dahua (PoE 2.0: Watchdog, BT 90W, Intelligent PoE, Long Distance)
- **开发策略**: 斯里兰卡 Dahua PoE 2.0
- **置信度**: ★★★★★

---

## 📡 七、WISP (Wireless ISP) PoE

### 35. Ubiquiti UISP-S (WISP 专用)
- **类型**: B类 - WISP MicroPoP
- **产品**: UISP-S (8口 GbE PoE 27V passive + 1x 1G SFP, 110W)
- **特点**: Fanless, Bluetooth setup, UISP app, Layer 2
- **应用**: WISP 塔站, MicroPoP
- **开发策略**: Ubiquiti WISP PoE 专用
- **置信度**: ★★★★★

### 36. Ubiquiti UISP Switch Pro
- **类型**: B类 - WISP Pro
- **产品**: UISP-S-Plus (2.5 GbE PoE for ISP)
- **开发策略**: Ubiquiti WISP Pro PoE
- **置信度**: ★★★★★

### 37. MikroTik WISP PoE 系列
- **类型**: B类 - WISP PoE
- **产品**:
  - CRS328-24P-4S+RM (24口 GbE PoE + 4x 10G SFP+)
  - CRS112-8P-4S-IN (8口 GbE PoE + 4x 1G SFP)
  - netPower 16P (16口 GbE PoE + 2x 10G SFP+, 户外)
- **开发策略**: MikroTik WISP PoE 系列
- **置信度**: ★★★★★

### 38. Microchip PDS-204GCO (WISP 户外)
- **类型**: B类 - WISP 户外 PoE
- **产品**: PDS-204GCO (第二代户外 PoE 交换机)
- **特点**: 极端天气, 温度变化, 高可用性
- **开发策略**: Microchip WISP 户外 PoE
- **置信度**: ★★★★★

### 39. Moss-Link WISP BOM
- **类型**: B类 - WISP 设备清单
- **产品**: S802E PoE 交换机 (塔站供电 sector radios)
- **BOM**: WB5acH6-29 backhaul + WB5acH6-20 sector + YA795 CPE + S802E PoE + YC801 4G fallback
- **开发策略**: WISP 设备清单情报
- **置信度**: ★★★★☆

---

## ⚠️ 八、危险环境 PoE (IEC 61850 / ATEX / IECEx)

### 40. Cisco Catalyst IE9300 Rugged (变电站/危险区)
- **类型**: 竞品 - 变电站 PoE
- **产品**: IE9300 系列 (IE-9310-16P8S4X)
- **规格**: 4GB/8GB DRAM, -40°C~+75°C, 双 Hazloc 电源
- **认证**: IEC 61850-3, IEEE 1613:2009, ATEX/IECEx (Class I Zone 2), UL 121201/CSA 213 (C1D2)
- **开发策略**: Cisco 变电站 PoE 竞品
- **置信度**: ★★★★★

### 41. Moxa EDS-4012 系列 (变电站/危险区)
- **类型**: B类 - 工业 PoE
- **产品**: EDS-4012-4GC-HV/LV/LV-T
- **规格**: 8x 10/100 + 4x FE/GE SFP, 88-300VDC/85-264VAC, -40°C~+75°C
- **认证**: EN 50121-4, IEC 61850-3, IEEE 1613, C1D2, ATEX, IECEx
- **价格**: $1372-$1741
- **开发策略**: Moxa 变电站 PoE
- **置信度**: ★★★★★

### 42. Axis Ex Connection Rail 4-port PoE (防爆)
- **类型**: B类 - 防爆 PoE
- **产品**: Ex Connection Rail 4-port PoE PS24
- **规格**: 4x 30W PoE, 单模/多模光纤
- **认证**: ATEX + IECEx Ex d IIC/IIIC
- **特点**: 扩展摄像头温度范围, 耐腐蚀
- **开发策略**: Axis 防爆 PoE
- **置信度**: ★★★★★

### 43. Advantech UNO-410 (防爆网关)
- **类型**: B类 - 防爆网关
- **产品**: UNO-410 (DIN-Rail 网关)
- **认证**: UL C1D2, ATEX Zone 2, IECEx Zone 2
- **应用**: 易燃气体/液体/蒸汽环境
- **开发策略**: Advantech 防爆网关
- **置信度**: ★★★★☆

### 44. Hirschmann MTS2724-6X-MP-E (工业管理 PoE)
- **类型**: B类 - 工业管理 PoE
- **产品**: Mammuthus Layer3 Gigabit 以太网交换机 PoE/PoE+
- **开发策略**: Hirschmann 工业管理 PoE
- **置信度**: ★★★★☆

### 45. Rockwell/Allen-Bradley Stratix (IEC 61850)
- **类型**: 竞品 - 变电站 PoE
- **认证**: IEC 61850-3 (冗余电源配置)
- **开发策略**: Rockwell Stratix 变电站 PoE 竞品
- **置信度**: ★★★★☆

---

## 🏛️ 九、政府/监狱/博物馆 PoE

### 46. Newbridge 政府项目案例 (中国)
- **类型**: B类 - 政府 PoE
- **案例**:
  1. 省级监管平台: 16口 GbE PoE, ERPS 环网 20ms 自愈
  2. 青藏高原"数字邮政": 车载 PoE 交换机 IP54, -40°C 冷启动 18秒, 太阳能兼容
  3. 县级政务中心: PoE 解决方案
- **优势**: 节省 60% 布线成本, 运维频率从月→年
- **开发策略**: 中国政府 PoE 项目案例
- **置信度**: ★★★★★

### 47. SilverNet (英国)
- **类型**: B类 - 世界最小 PoE
- **产品**: 73208MP-12V (35mm x 120mm x 90mm, 350g)
- **规格**: 可变电压工业交换机 9-56VDC PoE
- **特点**: 世界最小 PoE 交换机
- **开发策略**: 英国世界最小 PoE
- **置信度**: ★★★★★

---

## 📊 Batch 35 统计

- **新增客户/情报**: 47 家
- **覆盖国家**: +8 (哥斯达黎加, 危地马拉, 巴拿马, 墨西哥, 萨摩亚, 斐济, 缅甸, 尼泊尔, 孟加拉, 斯里兰卡)
- **新增行业**: 洁净室/制药, 机场/航空, WISP, 危险环境 (变电站/防爆), 政府/监狱
- **新增标准**: NDAA, TAA, IEC 61850, IEEE 1613, ATEX, IECEx, UL, IP65

---

## 🎯 关键发现

1. **洁净室 PoE**: ARISTA (英国) 制药洁净室 PoE 计算专家, 802.3bt 100W
2. **机场 PoE**: Omnitron + Planet Technology 机场 WiFi + 监控方案
3. **NDAA/TAA 合规**: Comnet, TRENDnet, D-Link, BV-Tech, Tripp Lite, Speco, ipcampower, AETEK (沙特)
4. **中美洲**: Ticomer (哥斯达黎加), Grupo Orotec/Teltec (危地马拉), Panacompu (巴拿马), Steren (墨西哥+9国)
5. **太平洋岛国**: UNDP Samoa RFQ (24口 370W+), PCS (PNG), JIAXUN (斐济)
6. **南亚**: ICT Myanmar, Reyee Myanmar, First Aid Nepal, All Nepal Sales, Trimatrik (孟加拉), Hikvision Colombo (斯里兰卡)
7. **WISP**: Ubiquiti UISP-S/Pro, MikroTik CRS/netPower, Microchip PDS-204GCO, Moss-Link S802E
8. **危险环境**: Cisco IE9300, Moxa EDS-4012, Axis Ex Connection Rail, Advantech UNO-410, Hirschmann, Rockwell Stratix
9. **政府/监狱**: Newbridge 中国项目 (ERPS 20ms), SilverNet 世界最小 PoE

---

## 📈 累计统计

- **总客户/情报数**: 1,011 家 (964 + 47)
- **覆盖国家**: 85+ 国家
- **Git 提交**: 36 次
- **超额完成**: 138% (目标 26 commits)

**Batch 35 圆满完成！** 🎉
