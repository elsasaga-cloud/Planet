# Batch 49 — 生态伙伴PoE：CCTV安装商 + 智慧城市照明 + IP摄像头 + 门禁 + WiFi AP

**日期**: 2026-10-25  
**搜索轮次**: Round 189-193  
**新增客户/情报**: 28 家  
**聚焦**: CCTV安防安装商, 智慧城市街道照明, IP摄像头制造商, 门禁系统, WiFi无线接入点

---

## 📹 一、CCTV安防安装商 PoE

### 1. JBN Security Systems (荷兰)
- **类型**: C类 - B2B批发分销
- **产品**: Hikvision, Dahua, TP-Link VIGI, Ajax Systems, Omada, Reyee, Teltonika, Milesight
- **客户**: 安防安装商, 系统集成商, 商业客户
- **开发策略**: 荷兰B2B CCTV批发分销 ★★★★★

### 2. CCTV Camera World (美国)
- **类型**: C类 - 安防公司品牌
- **位置**: 亚历山大, 弗吉尼亚
- **产品**: 完整安防系统, 独立摄像头, PoE摄像头, DVR, NVR, 网络设备, 存储
- **客户**: 房主, 小企业, 大企业, 专业安装商 (美国+国际)
- **开发策略**: 美国CCTV公司品牌 ★★★★☆

### 3. MossLink PoE (中国深圳)
- **类型**: A类 - PoE制造商
- **产品**: PoE交换机工厂直供深圳, OEM定制集成商+安防品牌
- **特点**: 每摄像头安装成本降低40-60%, Watchdog端口重启减少冻屏摄像头维护, IP67户外全季节
- **开发策略**: 中国深圳PoE制造商 (CCTV安装商渠道) ★★★★★

### 4. ITMan.ae CCTV (阿联酋)
- **类型**: C类 - CCTV网络安装指南
- **推荐**: Cisco WS-C2960X-24PS-L/WS-C3850-48U-L (强PoE输出+风暴控制+VLAN+PoE监控), Ubiquiti USW-24-PoE/USW-48-PoE (高PoE预算+远程管理+UniFi Controller), MikroTik CRS328-24P-4S+RM (PoE-out+SFP++WinBox+VLAN+路由+防火墙)
- **开发策略**: 阿联酋CCTV网络安装指南 ★★★★☆

### 5. 7sectors AETEK (沙特)
- **类型**: C类 - 授权合作伙伴
- **位置**: 吉达, 沙特
- **服务**: 安防/音频/数据基础设施品牌授权, 销售/集成支持/项目供应 (系统集成商+承包商)
- **开发策略**: 沙特授权合作伙伴 (政府NDAA/TAA项目) ★★★★☆

### 6. Hikvision PoE交换机 (中国)
- **类型**: B类 - PoE交换机产品线
- **产品**:
  - DS-3E0310HP-E: 非管理8 FE 110W (家庭/小商店/300m)
  - DS-3E0520HP-E: 非管理16 GbE 225W (千兆摄像头/光纤上行)
  - DS-3E0528HP-E: 非管理24 GbE 370W (大型即插即用)
  - DS-3E1318P-EI: 智能管理16 FE 130W (VLAN+远程PoE重置)
  - DS-3E1518P-SI: L2管理16 GbE 225W (管理千兆/光纤)
  - DS-3E1526P-SI: L2管理24 GbE 370W (中大型管理网络)
- **技术**: 802.3af/PoE+/Hi-PoE (802.3bt 90W), 长距离PoE 300m (标准100m的3倍)
- **开发策略**: 中国PoE交换机产品线 ★★★★★

---

## 💡 二、智慧城市街道照明 PoE

### 7. Microchip PDS-204GCO (美国)
- **类型**: B类 - 户外PoE智慧城市
- **产品**: PDS-204GCO, 下一代IEEE 802.3bt户外PoE交换机智慧城市
- **特点**: 增强网络保护+网络可用性, 端点认证+流量策略管理+DoS攻击防护, WiFi AP+安防摄像头+IoT, 标准以太网电缆不改变网络基础设施, VSC7514 10口工业以太网交换机+VCS6817 IStaX软件
- **开发策略**: 美国户外PoE智慧城市 ★★★★★

### 8. Teltonika TSW040 (立陶宛)
- **类型**: B类 - 智能照明PoE
- **产品**: TSW040 8口PoE+, 非管理, 8xPoE-out RJ45, 集中智能照明系统 (供电+连接同电缆)
- **开发策略**: 立陶宛智能照明PoE ★★★★★

### 9. EKS Fiber Optic PE-LIGHT-S (德国)
- **类型**: B类 - 智慧城市光纤+PoE
- **产品**: PE-LIGHT-S, 光纤接续盒+4口千兆管理以太网PoE, 2光纤口冗余环 (RSTP), 多模62.5/125µ或50/125µ, 120W最大 (60W/口), 230VAC 140W, -30~65°C (30°C起PoE降额3.5W/K)
- **开发策略**: 德国智慧城市光纤+PoE ★★★★★

### 10. Signify PoE照明 (荷兰)
- **类型**: C类 - PoE照明领导者
- **2024亮点**: 发布新PoE灯具系列 (集成传感器+本地边缘控制), 20+商业园区部署
- **开发策略**: 荷兰PoE照明领导者 ★★★★☆

### 11. Transition Networks SM24TBT2DPA (美国)
- **类型**: B类 - LED照明PoE++
- **产品**: SM24TBT2DPA, 24口管理千兆PoE++, 60W全24口或90W 16口同时, 双热插拔100-250VAC电源, 1560W PoE输出 (可选第二电源)
- **开发策略**: 美国LED照明PoE++ ★★★★★

### 12. Shade Innovations 1K PoE (美国)
- **类型**: B类 - 高功率PoE性价比
- **产品**: 1K PoE交换机, 1000W, 8口90W或24口30W, 25%同类成本, CEDIA Expo 2025丹佛#2533, 2025年9月中授权经销商
- **开发策略**: 美国高功率PoE性价比 (25%成本) ★★★★★

### 13. Microchip PDS-408G (美国)
- **类型**: B类 - 智能照明PoE
- **产品**: PDS-408G, 8口PoE, IEEE 802.3bt, 480W总 (90W单口或60W 8口同时), $980
- **开发策略**: 美国智能照明PoE $980 ★★★★★

---

## 🎥 三、IP摄像头制造商 PoE

### 14. Hikvision 海康威视 (中国)
- **类型**: B类 - 全球#1 IP摄像头
- **FY2025**: RMB 92.51B (USD 12.95B), 创新业务RMB 25.45B (27.51%), Q1 2026营收+11.78%
- **产品**: ColorVu+AcuSense PoE IP摄像头, PoE NVR+交换机, 8MP 4K, 0.002 lux, IR 40-130ft, ONVIF Profile T+HikCentral
- **PoE**: PoE+主流, PoE++高端4K+多传感器, 长距离PoE 300m
- **开发策略**: 中国全球#1 IP摄像头 (PoE交换机+摄像头协同) ★★★★★

### 15. Dahua 大华 (中国)
- **类型**: B类 - 全球#2 IP摄像头
- **FY2025**: RMB 32.744B (+1.75%), 净利润+32.77%
- **产品**: WizSense+WizMind PoE摄像头, NVR, Imou消费线, 8MP 0.005 lux Starlight, IR 100-165ft, ONVIF+强AI
- **PoE**: PoE+广泛, PoE++ PTZ+多传感器, 原生ePoE 800m (ePoE交换机/同轴)
- **开发策略**: 中国全球#2 IP摄像头 ★★★★☆

### 16. Axis Communications (瑞典)
- **类型**: B类 - 企业级专业PoE
- **2025**: 净销售SEK 20.763B (Canon子公司)
- **产品**: P/Q/M系列专业PoE网络摄像头, 8MP 4K, 0.07 lux Lightfinder 2.0, IR 131ft, AXIS Camera Station+Profile T/S/M, 网络安全+合规领先
- **PoE**: PoE+主流, PoE++ PTZ+多传感器, 中跨/PoE延长器
- **开发策略**: 瑞典企业级专业PoE (网络安全+合规) ★★★★★

### 17. Hanwha Vision 韩华 (韩国)
- **类型**: B类 - NDAA合规PoE++
- **Q4 2025**: 安防营收KRW 324B, Q3利润率10.0% (关税+订单延迟)
- **产品**: PNM-C19183RVTP多传感器PTZ半球, Jetson AI 100 TOPS边缘, WAVE VMS摄像头内置, PoE++ Type 3 42W最大32W典型, -40~55°C IP66/IK10/NEMA 4X
- **PoE**: PoE++多传感器创新, 5MP多传感器+PTZ+AI人物/面部/车辆/车牌
- **开发策略**: 韩国NDAA合规PoE++ (Jetson AI+WAVE VMS) ★★★★★

### 18. Motorola Solutions 视频安防 (美国)
- **类型**: B类 - 视频安防+门禁
- **2025**: 视频安防+门禁USD 2.1B
- **品牌**: Avigilon+Pelco
- **开发策略**: 美国视频安防+门禁 ★★★★☆

### 19. FCC 2025禁令 (美国)
- **类型**: 市场情报
- **事件**: FCC 2025年10月命令+2026年6月26日通知, 关闭Hikvision/Dahua遗留进口路线, 集成商转向Axis/Hanwha/Motorola/Verkada/Ubiquiti/i-PRO
- **影响**: 美国市场Hikvision/Dahua新销售有效关闭, 已安装可继续运行
- **开发策略**: FCC禁令推动NDAA合规品牌 (Axis/Hanwha/Motorola) ★★★★☆

---

## 🚪 四、门禁系统 PoE

### 20. Paxton Net2 Plus PoE+ (英国)
- **类型**: B类 - PoE门禁控制器
- **产品**: 682-721 Net2 Plus 1门控制器+内置TCP-IP转换器, PoE+金属箱, RJ45直插LAN, 兼容802.3af/at第三方PoE交换机, 5年保修
- **开发策略**: 英国PoE门禁控制器 ★★★★★

### 21. Borer PoE门禁 (英国)
- **类型**: B类 - PoE门禁控制器
- **产品**: 04-154单门/04-155双门PoE TCP-IP控制器, PoE供电门锁+生物识别+出门设备, 监控门状态 (开门+锁状态+出门按钮), 小体积安全侧安装
- **开发策略**: 英国PoE门禁控制器 ★★★★★

### 22. Avigilon ES-PS-S4 (美国)
- **类型**: B类 - 户外PoE管理交换机
- **产品**: ES-PS-S4, 管理5口, 户外IP66
- **开发策略**: 美国户外PoE管理交换机IP66 ★★★★★

### 23. Axis PoE门禁 (瑞典)
- **类型**: B类 - PoE门禁群组
- **产品**: PoE门禁控制器群组 (swarm), 内置管理接口
- **开发策略**: 瑞典PoE门禁群组 ★★★★★

### 24. ASSA ABLOY IN220 PoE锁 (瑞典)
- **类型**: B类 - PoE门锁
- **产品**: IN220 PoE锁, PoE供电配置 (需连接PoE交换机或注入器)
- **开发策略**: 瑞典PoE门锁 ★★★★☆

---

## 📶 五、WiFi无线接入点 PoE

### 25. Ruckus R770 Wi-Fi 7 (美国)
- **类型**: B类 - Wi-Fi 7 PoE++
- **产品**: R770, Wi-Fi 7 802.11be, 三频2.4/5/6GHz, 9.34 Gbps, 768客户端, 5GbE PoE+1G, 10G PoE端口, Ruckus One控制器
- **开发策略**: 美国Wi-Fi 7 PoE++ ★★★★★

### 26. Ruckus ICX 8200-C08ZP (美国)
- **类型**: B类 - PoE++交换机WiFi AP
- **产品**: ICX 8200-C08ZP, 4x1/2.5G + 4xMulti-gig/10G + 2x25G SFP28, 4x10G PoE++, 优化Wi-Fi 6/6E/7 AP多千兆, IPv4/IPv6 L3 (静态/RIP/OSPF/VRRP/VRF/GRE/PIM/PBR), Ruckus One管理
- **开发策略**: 美国PoE++交换机WiFi AP ★★★★★

### 27. Aruba Instant On 1930 (美国)
- **类型**: B类 - 中小企业PoE云管理
- **产品**: 1930 24口Gb 24xGE PoE 195W/370W + 4x1G/10G SFP+, L2+智能, 云管理, 1/3 Cisco成本, 企业级功能
- **开发策略**: 美国中小企业PoE云管理 (1/3 Cisco成本) ★★★★★

### 28. TP-Link TL-SX3206HPP (中国)
- **类型**: B类 - 预算PoE++ WiFi 7
- **产品**: TL-SX3206HPP, 4x10G PoE++ + 2x10G SFP+, 200W PoE预算, ~$500, Ruckus R770 40W PoE适配
- **开发策略**: 中国预算PoE++ WiFi 7 (~$500) ★★★★★

---

## 📊 Batch 49 统计

- **新增客户/情报**: 28 家
- **聚焦行业**: CCTV安装商, 智慧城市照明, IP摄像头, 门禁, WiFi AP
- **覆盖国家**: +3 (立陶宛, 韩国, 英国已有)

---

## 🎯 关键技术发现

1. **CCTV安装商**: JBN Security荷兰B2B批发 (Hikvision/Dahua/VIGI/Ajax/Reyee), CCTV Camera World美国, MossLink深圳40-60%成本降低, ITMan.ae阿联酋Cisco/Ubiquiti/MikroTik, 7sectors沙特AETEK授权
2. **智慧城市照明**: Microchip PDS-204GCO户外802.3bt+网络保护 (美国), Teltonika TSW040 8口智能照明 (立陶宛), EKS Fiber PE-LIGHT-S 4口120W RSTP (德国), Signify 20+园区 (荷兰), Transition 24口90W 1560W (美国), Shade 1K 25%成本 (美国), Microchip PDS-408G 8口480W $980 (美国)
3. **IP摄像头**: Hikvision RMB 92.51B (中国#1), Dahua RMB 32.744B (中国#2), Axis SEK 20.763B (瑞典企业级), Hanwha KRW 324B (韩国NDAA Jetson AI), Motorola $2.1B (美国Avigilon+Pelco), FCC 2025禁令Hikvision/Dahua美国
4. **门禁**: Paxton Net2 Plus PoE+ (英国), Borer 04-154/155 PoE TCP-IP (英国), Avigilon ES-PS-S4 IP66户外 (美国), Axis PoE群组 (瑞典), ASSA ABLOY IN220 PoE锁 (瑞典)
5. **WiFi AP**: Ruckus R770 Wi-Fi 7 10G PoE (美国), Ruckus ICX 8200 4x10G PoE++ 25G SFP28 L3 (美国), Aruba Instant On 1930 24口195W/370W云1/3 Cisco (美国), TP-Link TL-SX3206HPP 4x10G PoE++ 200W $500 (中国)

---

## 📈 累计统计

- **总客户/情报数**: 1,291 家 (1263 + 28)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 51 次
- **超额完成**: 184% (目标 700客户)
