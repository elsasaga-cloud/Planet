# 第四批新客户档案 — 深度挖掘（续）

> 挖掘日期：2026-09-22  
> 新增客户：约28家  
> 覆盖市场：乌兹别克斯坦/斯里兰卡/土耳其/荷兰-比利时/保加利亚/爱沙尼亚  
> 新增类型：VMS软件厂商PoE交换机兼容合作

---

## 一、乌兹别克斯坦 — 7家新发现 ★★★

> **关键数据**：全球PoE交换机进口第9大国（2,219批/年）！仅8口PoE就有39家进口商、271批出货（$155万/年）

### 1. Hikvision Uzbekistan / LOGI GROUP 2009 LTD ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 乌兹别克斯坦 (Tashkent) |
| 类型 | Hikvision官方分销商 |
| 地址 | Chilanzar district, 2nd Quarter, 76 Arnasoy Street, Neus Business Centre |
| 电话 | +998 99 213 48 63 |
| 邮箱 | info@uzhikvision.uz |
| 网站 | uzhikvision.uz |
| 在售PoE | 管理型+非管理型全系列Hikvision PoE交换机 |
| 级别 | **A级** |

**在售对标**：
| Hikvision在售 | 零售UZS | 折合USD | Saga替代 | Saga FOB |
|--------------|---------|---------|---------|---------|
| DS-3E0105P-E/M(B) 5口PoE | 286,000 | ~$23 | STC-028FP | $13.75 |
| DS-3E0510P-E 8口千兆PoE | 754,000 | ~$60 | STC-208GP | $16.9 |
| DS-3E1526P-SI 24口千兆PoE | 3,993,000 | ~$318 | STC-2024GP | $93.5 |

**卖点**：①Hikvision官方(PoE配套刚需) ②比Hikvision PoE便宜70-85% ③250米PoE

---

### 2. Dahua Uzbekistan / uzdahua.uz ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 乌兹别克斯坦 (Tashkent) |
| 类型 | Dahua官方分销商 |
| 电话 | +998 77 375 65 62 |
| 网站 | uzdahua.uz |
| 在售PoE | 管理型+非管理型全系列Dahua PoE交换机 |
| 级别 | **A级** |

---

### 3. SAT Solutions ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 乌兹别克斯坦 (Tashkent) |
| 类型 | Dahua战略系统集成商 + Hikvision授权 |
| 产品 | CCTV、门禁、消防、IT基础设施（**PoE交换机、结构化布线、UPS、机柜**） |
| 地址 | 5 Katta Darkhon St, Tashkent |
| 网站 | satsolutions.uz |
| 产品目录 | 3,200+个品项！ |
| 客户案例 | Damira Beverages工厂(112门禁+Dahua CCTV), Uzum电商平台(100+取货点) |
| 覆盖 | 乌兹别克斯坦 + 塔吉克斯坦 + 土库曼斯坦出口 |
| 级别 | **A级** |

**推荐Saga产品**：全系列非管理PoE + Marvell管理型 + PoE延长器
**卖点**：①3,200+品项说明采购量大 ②Dahua战略集成商(PoE配套) ③IT基础设施全覆盖 ④中亚3国出口

---

### 4. Kamol System Service ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 乌兹别克斯坦 (Tashkent) |
| 类型 | Hikvision官方分销商 |
| 地址 | Chilanzar district, Arnasay Street, Chilanzar-1 block, 29/16-1 |
| 特点 | 安防+消防设备库存 |
| 级别 | **B级** |

---

### 5. Smart Technology Systems ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 乌兹别克斯坦 (Tashkent) |
| 类型 | Hikvision分销商/出口商 |
| 地址 | Yunusabad district, Yunusabad-4 block, 80 |
| 特点 | 有出口资质 |
| 级别 | **B级** |

---

### 6. Bizkim.uz ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 乌兹别克斯坦 (Tashkent) |
| 类型 | PoE交换机批发供应商 |
| 产品 | Ubiquiti/Hikvision PoE交换机 |
| 网站 | bizkim.uz |
| 级别 | **B级** |

---

### 7. Hikvision Support (批发) ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 乌兹别克斯坦 |
| 类型 | PoE交换机批发供应商 |
| 产品 | Ubiquiti PoE交换机, 最低5件起 |
| 级别 | **B级** |

---

## 二、斯里兰卡 — 3家新发现 ★★

### 8. Colombo CCTV / Advanced Digital Technology ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 斯里兰卡 (Colombo) |
| 类型 | **Hikvision授权分销商**（斯里兰卡最大） |
| 总部 | No. 408, Galle Road, Wellawatta, Colombo-06 |
| 分店1 | No. 144-1/2, Spencer House, 1st Cross Street, Colombo-11 |
| 分店2 | No. 109, Galle Road, Bambalapitiya, Colombo-04 |
| 服务中心 | No. 28, 42nd Lane, Wellawatta, Colombo-06 |
| 电话 | 0112-364264, 0112-590500, 0774-999555 |
| 邮箱 | info@camera.lk, info@colombocctv.com |
| 网站 | camera.lk / colombocctv.com / colombocctv.lk |
| 在售PoE | **全系列Hikvision PoE交换机**（非管理+管理+工业级） |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE（替代Hikvision PoE）

---

### 9. Energy CCTV Security Camera Solution ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 斯里兰卡 (Ragama + Kelaniya) |
| 类型 | Hikvision + EZVIZ授权经销商 |
| 总部 | No. 530A, Negombo Road, Mahabage, Ragama |
| 分店 | No. 01, Wewalduwa Road, Dalugama, Kelaniya |
| 电话 | +94 778 377 990 / +94 72 437 7990 / +94 112 917 770 |
| 邮箱 | info@energycctv.lk |
| 网站 | hikvisioncolombo.com / energycctv.com |
| 在售PoE | 全系列Hikvision PoE + EZVIZ产品 |
| 覆盖 | Colombo, Gampaha, Kalutara安装 + 全岛配送 |
| 级别 | **A级** |

---

### 10. Hikvision Lanka ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 斯里兰卡 (Maharagama) |
| 类型 | Hikvision授权经销商 |
| 地址 | No.191A Old Road, Maharagama |
| 网站 | hikvisionlankalk.com |
| 在售PoE | DS-3E0106P(Rs.23,004), DS-3E0310P(Rs.41,040), DS-3E0318P(Rs.96,120) |
| 级别 | **B级** |

---

## 三、土耳其 — 8家新发现 ★★

### 11. TESAN ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 土耳其 |
| 类型 | **Hikvision土耳其官方分销商（2016年起）** |
| 产品 | CCTV、报警、对讲、**交换机** |
| 网站 | tesan.com.tr |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE（对标Hikvision交换机配套）
**卖点**：①土耳其Hikvision官方分销(PoE刚需) ②8年合作关系

---

### 12. CCTVburada ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 土耳其 (Istanbul) |
| 类型 | Hikvision授权经销商 |
| 办公室 | Orta Mah. Kanuni Sk. No:1, Kartal, Istanbul |
| 仓库 | Çamçeşme Mah. Erva St. No:20, Pendik, Istanbul |
| 电话 | 0216 212 59 39 |
| 邮箱 | info@cctvburada.com |
| 网站 | cctvburada.com |
| 产品 | Hikvision全线（含PoE交换机）+ 安装+网络基础设施服务 |
| 级别 | **A级** |

---

### 13. ONCU Security Systems ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 土耳其 (Istanbul, Beykoz) |
| 类型 | Hikvision分销商 |
| 地址 | Fatih Sultan Mehmet Cd. Yayabeyi Sk. No:8, Beykoz-Istanbul |
| 电话 | +90 216 537 0123 |
| 邮箱 | info@oncuguvenlik.com.tr |
| 网站 | oncuguvenlik.com.tr |
| 级别 | **B级** |

---

### 14. AVENIR (Aselsan) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 土耳其 (Istanbul) |
| 类型 | CCTV/安防/智能家居厂商+分销 |
| 规模 | **1500+代理商和经销商!覆盖土耳其+周边国家** |
| 特点 | Aselsan旗下品牌,低价策略+售后 |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE（匹配其低价策略）
**卖点**：①1500+代理渠道=巨大销量 ②低价策略与Saga完美匹配 ③覆盖土耳其+周边

---

### 15. Okisan Güvenlik ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 土耳其 |
| 类型 | **Dahua + Tiandy 土耳其授权分销商** |
| 产品 | IP/HDCVI/激光/热成像/智能家居/消防 |
| 网站 | okisan.com |
| 级别 | **B级** |

---

### 16. Uranyum CCTV ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 土耳其 |
| 类型 | PoE交换机零售商 |
| 产品 | Dahua/Hikvision PoE交换机在售 |
| 网站 | uranyumcctv.com |
| 级别 | **B级** |

---

### 17. Koyuncu Elektronik A.S. ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 土耳其 (Istanbul) |
| 类型 | 全国性技术分销商 |
| 产品 | IT、安防电子、消费电子 |
| 渠道 | IT销售渠道、安防合作伙伴、零售连锁、电商 |
| 级别 | **B级** |

---

### 18. Sensormatic Güvenlik Group ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 土耳其 (Istanbul) |
| 成立 | 1994年（32年！） |
| 类型 | **土耳其最大安防系统集成商**（Securitas集团旗下） |
| 产品 | 视频监控、门禁、周界安防、EAS、消防、入侵报警、远程视频 |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE + 管理型
**卖点**：①土耳其最大安防集成商 ②Securitas集团(全球背书) ③大型项目PoE需求

---

## 四、荷兰/比利时/保加利亚 — 6家新发现 ★★

### 19. JBN Security Systems B.V. ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 荷兰 (Almere, Flevoland) |
| 类型 | **B2B安防批发商/进口商** |
| 品牌 | Hikvision, Dahua, TP-Link VIGI, Ajax, Omada, Reyee, Teltonika, Milesight |
| 产品 | CCTV、报警、网络（**PoE交换机**）、门禁、对讲、Wi-Fi、4G/5G |
| 电话 | +31 85 016 3355 |
| 邮箱 | info@jbnsecurity.com |
| 网站 | jbnsecurity.com |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE（替代Reyee/Dahua PoE）
**卖点**：①荷兰B2B批发商 ②已有PoE交换机品类 ③多品牌经营(易切入) ④比Reyee/Dahua低50-70%

---

### 20. SmartSD BV ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 荷兰 (Breda) |
| 类型 | 安防设备分销商 |
| 品牌 | Hikvision, Dahua, Ajax, Akuvox, 2N, Paxton, Acre, Rosslare, Notifier |
| 产品 | 视频、门禁、对讲、入侵报警、消防、**IT网络** |
| 地址 | Minervum 7118, 4817 ZN Breda |
| 网站 | smartsd.com |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE + 管理型
**卖点**：①荷兰/比利时分销 ②有Hikvision HCSA认证培训 ③IT网络品类=PoE切入

---

### 21. Dero Security Products ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 荷兰 (Veldhoven) |
| 类型 | **Dahua官方分销商** + Honeywell/DWL/Netgear |
| 特点 | 紧凑灵活的批发组织，专注安防零售分销 |
| 级别 | **B级** |

---

### 22. ADI-GARDINER Netherlands B.V. ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 荷兰/比利时/卢森堡 (BNL地区) |
| 类型 | **Hikvision BNL授权分销商** |
| 产品 | CCTV + 非CCTV产品（**显示器、交换机、线缆、对讲、报警**） |
| 特点 | 年增长极快 |
| 级别 | **A级** |

**推荐Saga产品**：全系列PoE（作为非CCTV品类中的交换机替代/补充）

---

### 23. MEGATEH.eu ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 爱沙尼亚（覆盖全欧洲+全球） |
| 成立 | 2008年（18年） |
| 类型 | 安防设备在线分销商 |
| 品牌 | Dahua, Hikvision/HiLook, Ajax, Commax, EZVIZ, Imou, Aqara, Paradox |
| 在售PoE | Dahua CS4220-16GT-240 (€226.99) 等 |
| 网站 | megateh.eu |
| 级别 | **B级** |

---

### 24. MB Vision Ltd / cctvspot.co.uk ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 保加利亚（覆盖全欧洲+全球） |
| 成立 | 2012年 |
| 类型 | **Hikvision + Dahua 授权经销商** |
| 特点 | 在线销售为主,欧洲+巴尔干+全球配送 |
| 产品缺陷率 | <0.05%（3年内） |
| 网站 | cctvspot.co.uk |
| 级别 | **B级** |

---

## 五、VMS软件厂商PoE兼容合作机会 — 3家 ★★★★★

> **关键发现**：Allied Telesis已开发Milestone XProtect VMS的PoE交换机管理插件！这意味着Saga也可以开发类似插件，进入VMS推荐设备列表。

### 25. Milestone Systems (Canon集团) ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 丹麦 (Copenhagen) |
| 类型 | 全球VMS市场份额#1（27.4%） |
| 产品 | XProtect VMS |
| 兼容设备 | 14,000+摄像头/编码器, 180+厂商 |
| 已有PoE合作 | **Allied Telesis已开发Milestone PoE交换机管理插件** |
| 插件市场 | Milestone Marketplace |
| 级别 | **战略级** |

**Saga合作方案**：
1. 开发Saga PoE交换机Milestone XProtect插件（参考Allied Telesis）
2. 上架Milestone Marketplace
3. 让Saga成为Milestone推荐PoE交换机品牌
4. 影响全球14,000+安装项目选择Saga PoE

---

### 26. Genetec ★★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 加拿大 (Montreal) |
| 类型 | 全球VMS市场份额#2（22.46%）, Omdia 2025年#1 |
| 产品 | Security Center (Omnicast) |
| 特点 | 开放平台,多品牌摄像头兼容 |
| 级别 | **战略级** |

---

### 27. Avigilon (Motorola Solutions) ★★★★

| 维度 | 详情 |
|------|------|
| 国家 | 加拿大/美国 |
| 类型 | 全球VMS市场份额#3（18.6%） |
| 产品 | Avigilon Unity / Alta |
| 特点 | ONVIF兼容,支持第三方设备 |
| 级别 | **战略级** |

---

### 28. Beoview Benelux B.V. ★★★

| 维度 | 详情 |
|------|------|
| 国家 | 荷兰 (Purmerend) |
| 成立 | 2025年 |
| 类型 | PoE交换机制造商/分销商 |
| 产品 | SW-POE-24 24口千兆PoE+交换机, beoCatBUS® P电源交换机 |
| 网站 | beoview.com |
| 级别 | **B级（OEM合作机会）** |

---

## 优先行动清单（第四批精选）

| 排名 | 客户 | 国家 | 联系方式 | 预期首单 |
|------|------|------|---------|---------|
| 1 | **Hikvision Uzbekistan** | 乌兹别克 | +998 99 213 48 63, info@uzhikvision.uz | $5K-15K |
| 2 | **SAT Solutions** | 乌兹别克 | satsolutions.uz | $5K-20K |
| 3 | **TESAN** | 土耳其 | tesan.com.tr | $10K-30K |
| 4 | **AVENIR** | 土耳其 | 1500+代理 | $10K-30K |
| 5 | **JBN Security** | 荷兰 | +31 85 016 3355, info@jbnsecurity.com | $5K-15K |
| 6 | **Colombo CCTV** | 斯里兰卡 | 0112-590500, info@colombocctv.com | $3K-10K |
| 7 | **Energy CCTV** | 斯里兰卡 | +94 778 377 990, info@energycctv.lk | $3K-10K |
| 8 | **SmartSD** | 荷兰 | smartsd.com, Breda | $5K-10K |
| 9 | **Sensormatic** | 土耳其 | Istanbul, Securitas集团 | $10K-30K |
| 10 | **Milestone插件** | 丹麦 | Marketplace上架 | 战略级 |

---

**累计客户：28(第二批) + 35(第三批) + 28(第四批) = 91家新增**
**总客户数：45(原有) + 91(新增) = 136家海外目标客户，覆盖26个国家/地区**
