# Batch 28 — 智能建筑PoE + IP门禁对讲 + 南美市场 + ISE 2026 Barcelona
> 深度挖掘 Round 91-94 (2026-10-25)
> 方法论：智能建筑BMS/IoT / IP门禁对讲品牌 / 南美5国 / ISE 2026 (92170访客, 1751参展商)

---

## 一、智能建筑 / BMS / IoT PoE

> **市场数据**: PoE电源方案市场 $2.6B (2024) → $12.4B (2034)

### 1. PoE Partner（德国）
- **类型**: B类 — PoE智能建筑方案
- **网站**: poe-partner.com
- **产品**: PoE Texas Switch, 90W/port, 802.3bt
- **开发策略**: 德国PoE智能建筑方案商
- **置信度**: ★★★★★

### 2. Belden Building Automation Switch（美国）
- **类型**: B类 — 建筑自动化交换机
- **产品**: 8口100M PoE/PoE+嵌入配电板, 230V/24V, 无需额外电源
- **开发策略**: 美国建筑自动化品牌
- **置信度**: ★★★★★

### 3. Atlantik Elektronik（德国）
- **类型**: C类 — Lantronix智能建筑分销
- **产品**: SM24TBT4XPA/SM24TBT2DPB PoE++智能建筑
- **开发策略**: 德国Lantronix分销
- **置信度**: ★★★★☆

### 4. OmniConverter / Omnitron Systems（美国）
- **类型**: B类 — PoE建筑自动化
- **网站**: omnitron-systems.com
- **成立**: 1992年
- **产品**: PoE光纤交换机+媒体转换器 (建筑自动化)
- **开发策略**: 美国PoE建筑自动化品牌
- **置信度**: ★★★★★

### 5. MHT Technologies（美国）
- **类型**: B类 — PoE控制器+AI
- **网站**: mht-technologies.com
- **产品**: Inspextor PoE控制器, 802.3bt, MQTT, 802.1x, AI基础设施
- **开发策略**: PoE智能建筑+AI控制器品牌
- **置信度**: ★★★★★

### 6. Digital Building Solutions (DBS)
- **类型**: B类 — 智能建筑集成商
- **合作**: MHT Technologies Inspextor
- **开发策略**: MHT PoE集成合作伙伴
- **置信度**: ★★★★☆

### 7. Versa Technology C62-084-91-770
- **类型**: B类 — L2管理PoE++
- **产品**: 8口PoE + 2口GbE + 2 SFP, 720W, ONVIF摄像头控制
- **开发策略**: PoE++建筑管理交换机
- **置信度**: ★★★★★

### 8. Switch Automation
- **类型**: B类 — BMS/IoT平台
- **网站**: switchautomation.com
- **产品**: BMS/HVAC/照明/能源/IoT集成
- **开发策略**: 智能建筑BMS平台
- **置信度**: ★★★★☆

---

## 二、IP门禁/对讲 PoE品牌

> **情报**: IP门禁对讲全线PoE供电，需PoE交换机配套

### 9. GBF Electronics（美国）
- **类型**: B类 — IP门禁品牌
- **网站**: gbfelectronics.com
- **产品**: PL963PMPOE/PL964PMBL-POE/SentryLink ($279-$1699), PoE+WiFi, iOS/Android
- **开发策略**: 美国IP门禁品牌
- **置信度**: ★★★★★

### 10. Algo 8028G2（加拿大）
- **类型**: B类 — SIP门禁
- **产品**: PoE+ SIP门禁 (NEMA 3R, UL/CSA/FCC/CE, RESTful API)
- **开发策略**: 加拿大SIP门禁品牌
- **置信度**: ★★★★★

### 11. Hanwha TID-600R（韩国）
- **类型**: B类 — Wisenet生态门禁
- **产品**: PoE IP视频门禁 (IP65, Wisenet VMS集成)
- **开发策略**: 韩国Wisenet生态门禁
- **置信度**: ★★★★★

### 12. Aiphone IX-EA（日本）
- **类型**: B类 — IP门禁
- **产品**: PoE视频门禁 (IP54, 嵌入式, 多户呼叫路由)
- **开发策略**: 日本IP门禁品牌
- **置信度**: ★★★★★

### 13. DoorBird D2101V（德国）
- **类型**: B类 — IP门禁
- **产品**: IP视频门禁 (V2A不锈钢, 嵌入式)
- **开发策略**: 德国IP门禁品牌
- **置信度**: ★★★★☆

### 14. Alpha Communications G+（美国）
- **类型**: B类 — 多户门禁
- **产品**: TCP/IP PoE门禁 (CAT5/6, 最多799监视器, 19门口机)
- **开发策略**: 美国多户门禁品牌
- **置信度**: ★★★★☆

### 15. Dahua PFS3005-5ET-60套装
- **类型**: 竞品 — PoE交换机+门禁套装
- **产品**: PoE交换机+VTO门禁+VTH监视器
- **开发策略**: 大华门禁PoE套装竞品
- **置信度**: ★★★★★

---

## 三、南美5国市场

### 16. Metacom（智利）
- **类型**: C类 — 智利PoE分销
- **网站**: metacom.cl
- **品牌**: Ubiquiti/D-Link/Dahua/Planet/Allied Telesis
- **地点**: Santiago, +56 2 2862 8000
- **开发策略**: 智利PoE分销商
- **置信度**: ★★★★★

### 17. Aletecno（阿根廷）
- **类型**: C类 — 阿根廷PoE
- **网站**: aletecno.com.ar
- **产品**: PoE 4/8/16/24口 (工业级)
- **覆盖**: 阿根廷+LATAM
- **开发策略**: 阿根廷PoE分销
- **置信度**: ★★★★★

### 18. Security One（阿根廷）
- **类型**: C类 — Axis授权分销
- **事件**: Axis Communications阿根廷新增授权分销
- **开发策略**: 阿根廷安防分销
- **置信度**: ★★★★☆

### 19. Volza南美进口数据
- **类型**: 市场情报
- **排名**: Colombia 144/Chile 123/Costa Rica 116/Ecuador 106/Peru 5752(大)/Argentina 58
- **开发策略**: 南美PoE进口数据
- **置信度**: ★★★★★

### 20. Guayaquil Ecuador市场
- **类型**: C类区域市场
- **品牌**: Hikvision/TP-Link/HP/Aruba 6200F/D-Link/Ubiquiti PoE
- **渠道**: Facebook Marketplace
- **开发策略**: 厄瓜多尔PoE零售市场
- **置信度**: ★★★☆☆

---

## 四、ISE 2026 Barcelona (Feb 3-6) ★★★★★

> **展会数据**: 92,170访客, 1,751参展商, Fira Barcelona Gran Via, AV over IP+IPMX首发

### 21. NETGEAR @ ISE 2026（Booth 2U240）
- **类型**: 竞品 — AV PoE交换机
- **产品**: M4350-16M4V (16x2.5G PoE++ 1130W Neutrik etherCON/opticalCON/powerCON) + M4350-16C (16x100G聚合核心)
- **开发策略**: NETGEAR ISE 2026 AV PoE新品
- **置信度**: ★★★★★

### 22. Aurora Multimedia @ ISE 2026（Booth 5E700）
- **类型**: B类 — AVoIP PoE++
- **产品**: VPX-TC1-UCP 4K 1G AVoIP PoE++ (2xUSB-C + RJ45 PSE)
- **开发策略**: AVoIP PoE++方案
- **置信度**: ★★★★★

### 23. Jazz Hipster @ ISE 2026
- **类型**: B类 — PoE音频
- **产品**: PoE音频方案+建筑吸顶音箱
- **开发策略**: PoE网络音频品牌
- **置信度**: ★★★★☆

### 24. Adamson MS8.2（加拿大）
- **类型**: B类 — AVB网络交换机
- **产品**: MS8.2 AVB-ready Network Switch (Milan, 48扬声器, USB Milan Bridge)
- **开发策略**: AVB Milan网络交换机
- **置信度**: ★★★★★

### 25. d&b audiotechnik U-Series（德国）
- **类型**: B类 — PoE++音箱
- **产品**: U-Series PoE++ + Milan + R1网络
- **开发策略**: 德国专业音箱PoE++
- **置信度**: ★★★★★

### 26. Niveo Professional（荷兰）
- **类型**: B类 — AV交换机
- **产品**: SDVoE/AVoIP/AVB/Dante交换机
- **开发策略**: 荷兰AV网络交换机品牌
- **置信度**: ★★★★★

### 27. Kiloview @ ISE 2026（Booth 4M800）
- **类型**: B类 — AVoIP生态
- **产品**: 连接/控制/管理/传输全套AVoIP
- **开发策略**: AVoIP生态品牌
- **置信度**: ★★★★★

### 28. AIMS IPMX认证
- **类型**: 行业标准
- **事件**: ISE 2026首发48个IPMX认证产品
- **开发策略**: IPMX标准兼容交换机机会
- **置信度**: ★★★★★

---

**Batch 28 总计: 28家新客户/情报**

> 关键发现：
> 1. **智能建筑8家** — PoE Partner德国/Belden建筑自动化/Atlantik德国Lantronix/OmniConverter 1992/MHT Inspextor+AI/DBS集成/Versa 720W/Switch Automation BMS
> 2. **IP门禁7家** — GBF美国/Algo加拿大SIP/Hanwha韩国Wisenet/Aiphone日本/DoorBird德国/Alpha美国多户799/Dahua套装
> 3. **南美5家** — Metacom智利/Aletecno阿根廷LATAM/Security One阿根廷/Volza进口数据(Peru 5752大)/Guayaquil Ecuador
> 4. **ISE 2026 8家** — NETGEAR M4350-16M4V 16x2.5G PoE++ 1130W Neutrik/Aurora 4K AVoIP PoE++/Jazz Hipster PoE音频/Adamson MS8.2 Milan/d&b PoE++/Niveo AV交换机/Kiloview AVoIP/AIMS IPMX 48认证
