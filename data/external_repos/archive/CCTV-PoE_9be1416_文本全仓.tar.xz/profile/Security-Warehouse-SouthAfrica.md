# 客户档案：Security Warehouse — 南非

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司全称 | Security Warehouse |
| 国家 | 南非 |
| 类型 | 安防设备分销商 |
| 网站 | securitywarehouse.co.za |
| 成立 | 多年运营 |
| Google评分 | 4.4/5（295条评价） |
| 客户级别 | **A级（核心）** |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 总部 (Centurion) | +27 12 653 1005 / info@securitywarehouse.co.za |
| 东Rand (JHB) | +27 11 608 2309 / er@securitywarehouse.co.za |
| Strijdom Park | +27 11 791 5563 / sp@securitywarehouse.co.za |
| West Rand | +27 10 745 4300 / wr@securitywarehouse.co.za |
| Boksburg | +27 11 823 2054 / bb@securitywarehouse.co.za |
| LinkedIn | 搜索"Security Warehouse Centurion" |
| 总部地址 | 118 Theuns Street, Hennopspark, Centurion, 0046 |

**关键发现：5个分支机构！覆盖南非Gauteng全省，分销能力极强**

## 公司深度分析

### 分支机构（5个！）
| 分支 | 城市 | 电话 | 邮箱 |
|------|------|------|------|
| Head Office | Centurion (比勒陀利亚) | +27 12 653 1005 | info@ |
| East Rand | Johannesburg | +27 11 608 2309 | er@ |
| Strijdom Park | Randburg (JHB) | +27 11 791 5563 | sp@ |
| West Rand | Roodepoort (JHB) | +27 10 745 4300 | wr@ |
| Boksburg | Boksburg | +27 11 823 2054 | bb@ |

### 当前PoE交换机在售品牌（从网站提取）
| 品牌 | 型号示例 | ZAR售价 | USD |
|------|---------|---------|-----|
| Dahua | 8口PoE 96W | R3,999-4,399 | ~$220 |
| Dahua | 16口PoE 190W | R5,000-6,000 | ~$300 |
| Dahua | 24口PoE 240W | R6,000-7,000 | ~$370 |
| Duxbury | 8口PoE | ~R2,500 | ~$140 |
| Netgear | 8口PoE + SFP | ~R3,000 | ~$165 |
| Provision | 4口PoE | ~R1,500 | ~$83 |

### 产品线
Dahua CCTV全线 / Dahua PoE交换机 / Dahua NVR / 门禁 / 报警 / ICT / 太阳能安防 / 电围栏 / 大门自动化

## 推荐Saga产品及对标

### 主推产品（替代Dahua PoE交换机）
| Saga型号 | 规格 | 进货价(¥) | FOB($ USD) | 对标Dahua | Dahua ZAR | 价差 |
|----------|------|----------|-----------|----------|----------|------|
| **STC-028GFP** | 10口百千兆PoE | ¥94.5 | $13-15 | Dahua 8口PoE | R3,999 ($220) | **低93%** |
| **STC-1216GFP** | 18口百千兆PoE | ¥207 | $29-32 | Dahua 16口PoE | R5,000 ($277) | **低89%** |
| **STC-1224GFP** | 26口百千兆PoE | ¥297 | $41-45 | Dahua 24口PoE | R6,500 ($360) | **低88%** |
| **STC-228GP** | 12口千兆PoE+SFP | ¥171 | $24-28 | Netgear 8口PoE+SFP | R3,000 ($165) | **低84%** |

### 配套产品
| Saga型号 | 规格 | 进货价 | 推荐理由 |
|----------|------|--------|---------|
| PoE延长器 | 100m→250m | ~¥30-50 | 非洲远距离部署刚需 |
| 光纤收发器 | 单模/多模 | ~¥50-80 | 配合多分支联网 |
| STC-08GE | 8口千兆以太网 | ¥55.8 | ICT网络配套 |

### 核心卖点话术（针对Security Warehouse）
1. **"你的Dahua 8口PoE卖R3,999，我的同级产品FOB $15，你可以卖R1,500-2,000还保持高利润"** — 价格碾压Dahua
2. **"250米超长PoE传输"** — "Dahua标准100米，Saga支持250米，你的非洲客户远距离布线不用再买延长器"
3. **"金属外壳+VLAN隔离"** — "不是塑料壳白牌，专业安防级品质"
4. **"PoE看门狗自动重启"** — "减少你的售后维护成本，端口故障自动恢复"
5. **"CE/FCC/RoHS认证"** — "南非进口海关无阻碍"
6. **"OEM贴牌"** — "可以贴Security Warehouse品牌，建立你的自有品牌PoE交换机线"

## 竞争分析

| 竞品品牌 | 在SW的售价 | Saga FOB | Saga优势 |
|---------|----------|---------|---------|
| Dahua 8口PoE | R3,999 ($220) | $13-15 | **低93%** |
| Netgear 8口PoE+SFP | R3,000 ($165) | $24-28 | **低84%** |
| Duxbury 8口PoE | R2,500 ($140) | $13-15 | **低90%** |
| Provision 4口PoE | R1,500 ($83) | $7.5 (STC-028FP(Saga最近似型号，原ZX902-AF-42N)) | **低91%** |

### 切入角度
Security Warehouse当前**过度依赖Dahua品牌PoE交换机**。Saga可以作为：
1. **低价替代品牌** — 填补价格敏感客户需求
2. **自有品牌OEM** — "Security Warehouse"品牌PoE交换机

## 跟进计划

| 阶段 | 行动 | 时间 | 细节 |
|------|------|------|------|
| 1 | 邮件发info@securitywarehouse.co.za | 本周 | 主题："PoE Switches — 90% Below Dahua Pricing, OEM Available" |
| 2 | 电话+27 12 653 1005找采购部 | 1周内 | 提及邮件，请求采购负责人联系 |
| 3 | 准备Saga vs Dahua PoE对标表 | 1周内 | 含型号/端口/PoE功率/价格对比 |
| 4 | 寄送样品（STC-028GFP + STC-1216GFP各2台） | 2周内 | DHL到Centurion总部 |
| 5 | 提出OEM "Security Warehouse"品牌方案 | 1个月后 | 含包装设计概念图 |
| 6 | 讨论5个分支统一供货方案 | 2个月后 | 批量价格 |

### 首封邮件模板
```
Subject: PoE Switches — 90% Below Dahua, Metal Case, 250m Range

Dear Purchasing Team,

I see Security Warehouse distributes Dahua PoE switches at R3,999-6,500. 
We manufacture equivalent PoE switches at $13-45 FOB — that's 90% below 
Dahua pricing.

Quick comparison:
• Your Dahua 8-port PoE 96W: R3,999 ($220)
• Our 10-port PoE with 2× Gigabit uplink: $13-15 FOB
• You can sell at R1,500-2,000 and still earn higher margins

Key features your installers will appreciate:
✓ 250-meter PoE transmission (vs standard 100m) — fewer extenders needed
✓ Metal housing — not plastic, built for African conditions
✓ VLAN port isolation — prevents broadcast storms on CCTV networks
✓ PoE Watchdog — auto-restarts frozen cameras, reduces truck rolls
✓ CE/FCC/RoHS certified — smooth customs clearance

We also offer OEM branding — we can produce "Security Warehouse" branded 
PoE switches with your logo, packaging, and label.

Would you like 2 sample units shipped to your Centurion head office?

Best regards,
[Name]
Saga / Saga Telecom
Saga销售邮箱 | +86-18820293198
```

## 预期订单

| 阶段 | 预估金额 | 说明 |
|------|---------|------|
| 首单 | $5,000-10,000 | 3-5款各50-100台 |
| 稳定供货 | $50,000-100,000/年 | 5个分支统一补货 |
| OEM后 | $100,000-200,000/年 | Security Warehouse品牌 |
