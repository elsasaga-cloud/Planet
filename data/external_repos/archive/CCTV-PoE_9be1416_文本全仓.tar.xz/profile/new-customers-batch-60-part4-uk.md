# Batch 60 Part 4: UK LinkedIn+Amazon+海关+展会+政府采购
## 5渠道: 740 IT Director职位/TP-Link统治UK PoE/中国51%份额/Security Expo 350展商/G-Cloud £16.8B
_2026-10-27 | 20 entries | UK Deep Mining Part 4_

---

### 渠道P: LinkedIn决策者 (1条)
- **102.96 LinkedIn UK** 🇬🇧 A类 | **740+ IT Director**, 2000+ Infra Manager, Tesco/Network Rail/Liberty Global/Clear Channel/Stella McCartney/Sotheby's/British Museum/NHS/Saab/WeWork都在招

### 渠道Q: Amazon UK卖家 (3条)
- **102.97 TP-Link** 🇬🇧 A类 | UK PoE #1, LS105GP **60K评价** 500+/月, £27.99, **Amazon's Choice**
- **NETGEAR** 🇬🇧 B类 | UK PoE #2, GS305 13.5K评价
- **TRENDnet** 🇬🇧 B类 | UK PoE #3, NDAA+TAA合规, TPE-204US 20口UPoE 370W

### 渠道R: 海关数据 (3条)
- **102.98 HS 851762** 🇬🇧 A类 | 409货运, **中国51%**(210), 台湾17%, 印度7%
- **TP-Link Systems** 🇬🇧 A类 | 最大进口商, 越南→美国, 142吨/单次
- **UK Cisco** 🇬🇧 B类 | CBS350-8FP 6货运

### 渠道S: 安防展会 (4条)
- **102.99 IFSEC** 🇬🇧 A类 | 600展商20K观众, Hikvision/Uniview/Norbain/CCTV Direct, ⚠️"retired"
- **Security Expo** 🇬🇧 A类 | **350展商10K观众**, Smiths Detection/Abloy/Gallagher/Rapiscan/QNAP UK, Government Zone(Home Office/BTP/Met Police)
- **Infosecurity Europe** 🇬🇧 B类 | 380展商13.8K观众, 网络安全
- **Security Event** 🇬🇧 B类 | AMG Systems(工业PoE/光纤/无线)

### 渠道T: 政府采购框架 (5条)
- **102.100 G-Cloud 14** 🇬🇧 A类 | 46K服务4K供应商, Direct Award, NHS/大学/警察可用
- **G-Cloud 15** 🇬🇧 A类 | **£16.8B框架**, 4年, 2025.10启动
- **Network Services 3** 🇬🇧 A类 | RM6116, IoT+智慧城市, Cinos/Exponential-e/Birmingham Telecom
- **Exponential-e** 🇬🇧 B类 | 100GbE全英, 5×ISO
- **Birmingham Telecom** 🇬🇧 B类 | 暗光纤+亮光纤, 4年CCS批准

---

## 关键发现
- **TP-Link UK PoE统治**: 60K评价, £27.99, 可直接价格战
- **中国51%海关份额**: 中国PoE已验证UK市场, TP-Link从越南转口
- **G-Cloud £16.8B**: Direct Award, 所有UK公共部门可买, NHS+大学+警察
- **Security Expo 2026**: 最活跃UK安防展, Government Zone直接见Home Office/BTP
- **740+ IT Director职位**: 直接InMail决策者, 提供PoE+CCTV方案
