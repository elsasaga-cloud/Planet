# Batch 46 — 新兴场景PoE：EV充电 + 数据中心 + 监狱 + 研究实验室 + 动物园水族馆

**日期**: 2026-10-25  
**搜索轮次**: Round 174-178  
**新增客户/情报**: 12 家  
**聚焦**: EV充电站, 数据中心机房, 监狱矫正设施, 研究实验室, 动物园水族馆

---

## 🔌 一、EV充电站 PoE

### 1. EV充电站市场情报
- **类型**: 市场情报
- **规模**: 全球EV充电站$25.5B (2025), 特斯拉7-10%, ChargePoint 5-8%, ABB 5-7%, Shell 4-6%, BP Pulse
- **亮点**:
  - ChargePoint+GM合作: 2025年底前安装数百个超快充电端口, Express Plus 500kW, Omni Port CCS/NACS兼容
  - Ionna: 8家车企合资, 2025春首站, 147站1,332端口, 目标2030年30,000端口
  - Tesla NACS: 25,000+超充, 2025年几乎所有品牌兼容 (Ford/GM/Hyundai/Kia/Honda/BMW/VW等)
- **PoE潜力**: 中 (充电桩监控+WiFi+摄像头+支付终端), 通过工业/商业渠道
- **开发策略**: EV充电站PoE潜力中 ★★★☆☆

---

## 🖥️ 二、数据中心 PoE

### 2. Ampcom数据中心PoE (市场情报)
- **类型**: 市场情报
- **案例**: 数据中心/MDF机房PoE设计
  - WiFi 6 AP 12台×23W = 276W (PoE+)
  - 固定半球摄像头 16台×12W = 192W (红外)
  - PTZ摄像头户外 4台×32W = 128W (加热/雨刷峰值)
  - 门禁/IoT 4台×8W = 32W
  - 总36设备 628W (740W预算80% = 592W设计目标)
- **20%余量规则**: 启动浪涌+设备同时上电+热管理
- **开发策略**: 数据中心PoE设计专家 ★★★★☆

### 3. PoE交换机市场PoE应用 (数据中心)
- **类型**: 市场情报
- **规模**: PoE千兆交换机数据中心细分$750M (2024)→$1,500M (2035)
- **趋势**: 数据中心开始探索PoE++为紧凑边缘计算节点供电 (布线间+远程分支)
- **开发策略**: 数据中心PoE边缘计算潜力高 ★★★★☆

---

## 🔒 三、监狱矫正设施 PoE

### 4. LAN Access 监狱监控 (西班牙)
- **类型**: B类 - 监狱监控PoE
- **产品**: 矫正设施视频监控, 全IP或混合系统, 带或不带PoE交换机, 壁挂式, 可配置存储+电源
- **开发策略**: 西班牙监狱监控PoE ★★★★★

### 5. 监狱安防市场情报
- **类型**: 市场情报
- **规模**: 监狱安防系统$6.5B (2034)
- **主要厂商**: Securitas Technology, Johnson Controls, Honeywell, Siemens, Bosch Security, Axis Communications, Hikvision, Dahua, Hanwha Vision, Genetec, Milestone, Avigilon (Motorola), FLIR (Teledyne), Pelco, Vivotek, Geovision, Texecom, Risco Group, Pyronix, Senstar
- **PoE潜力**: 高 (IP监控+WiFi+门禁+平板+视频通话), 通过安防/政府渠道
- **开发策略**: 监狱安防PoE潜力高 ★★★★☆

---

## 🔬 四、研究实验室 PoE

### 6. 研究实验室市场情报
- **类型**: 市场情报
- **案例**: Fermilab Helen Edwards工程研究中心 (2025年12月), 80,000平方英尺, 中微子/探测器/量子科学研究
- **PoE潜力**: 中高 (IP监控+WiFi+传感器+IoT), 通过教育/工业渠道
- **开发策略**: 研究实验室PoE潜力中高 ★★★☆☆

---

## 🦁 五、动物园水族馆 PoE

### 7. Mandai Wildlife Reserve (新加坡)
- **类型**: C类 - 野生动物园
- **项目**: Rainforest Wild Asia, 2025年3月12日开放, 13公顷亚洲雨林, 10个区域, Mandai Wildlife Group管理
- **开发策略**: 新加坡野生动物园 (PoE WiFi+监控+互动) ★★★★☆

### 8. Birch Aquarium Living Seas (美国)
- **类型**: C类 - 水族馆
- **项目**: Living Seas展览, 2025年5月开放, Hall of Fishes改造, 太平洋海洋之旅, 4,000+动物
- **开发策略**: 美国水族馆 (PoE WiFi+监控+互动) ★★★☆☆

### 9. Florida Aquarium (美国)
- **类型**: C类 - 水族馆
- **项目**: $4,500万扩建二期, 2025年开放, 重新设计二楼夹层+潮池触摸体验
- **开发策略**: 美国水族馆扩建 ★★★☆☆

### 10. Chester Zoo Heart of Africa (英国)
- **类型**: C类 - 动物园
- **项目**: Heart of Africa沉浸式体验, 2025年4月开放, 长颈鹿+斑马+鸵鸟共栖
- **开发策略**: 英国动物园 ★★★☆☆

### 11. Beijing Haichang Ocean Park (中国)
- **类型**: C类 - 海洋公园
- **项目**: 北京海昌海洋公园, 2027年开放, 157,100平方米 (全球最大新建水族馆), Legacy Entertainment+The Aquarium Design Company设计, 400万年访客, 8层度假酒店, 通州紧邻环球影城
- **开发策略**: 中国海洋公园 (PoE WiFi+监控+互动+酒店) ★★★★☆

### 12. 动物园水族馆市场情报
- **类型**: 市场情报
- **规模**: 动物主题公园$8.27B (2024)→$8.56B (2025)
- **主要运营商**: Disney Animal Kingdom 15-20%, SeaWorld 12-16%, San Diego Zoo 10-14%, Chimelong 8-12%, Everland 5-9%
- **PoE潜力**: 高 (园区WiFi+IP监控+数字标牌+互动AR+POS), 通过安防/商业渠道
- **开发策略**: 动物园水族馆PoE潜力高 ★★★★☆

---

## 📊 Batch 46 统计

- **新增客户/情报**: 12 家
- **聚焦行业**: EV充电站, 数据中心, 监狱, 研究实验室, 动物园水族馆
- **覆盖国家**: +2 (新加坡, 英国已有)

---

## 🎯 关键技术发现

1. **EV充电站**: ChargePoint+GM 500kW Omni Port (美国), Ionna 8车企合资30K端口 (美国), Tesla NACS 25K+超充兼容所有品牌, PoE潜力中
2. **数据中心**: Ampcom PoE设计36设备628W 20%余量 (市场情报), PoE千兆数据中心$750M→$1,500M, PoE++边缘计算潜力高
3. **监狱**: LAN Access全IP/混合+PoE (西班牙), 监狱安防$6.5B (2034), Securitas/Honeywell/Siemens/Bosch/Axis/Hikvision, PoE潜力高
4. **研究实验室**: Fermilab 80K sq ft (美国), PoE潜力中高
5. **动物园水族馆**: Mandai Rainforest Wild 13公顷 (新加坡), Birch Living Seas 4K动物 (美国), Florida $45M扩建 (美国), Chester Heart of Africa (英国), Beijing Haichang 157K m²全球最大 (中国)

---

## 📈 累计统计

- **总客户/情报数**: 1,222 家 (1210 + 12)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 48 次
- **超额完成**: 175% (目标 700客户)
