# Batch 27 — 东欧市场 + 仓储物流PoE + Veracity UK + Amazon白牌数据
> 深度挖掘 Round 87-90 (2026-10-25)
> 方法论：东欧分销 / 仓储PoE市场($2.8B) / Veracity PoE配件 / Amazon/Alibaba白牌销量数据

---

## 一、东欧市场（波兰/捷克/罗马尼亚/保加利亚/匈牙利/乌克兰）

### 1. Quantix Intelligent Computing（中国）
- **类型**: A类 — 波兰市场交换机供应商
- **网站**: quantixgpu.com
- **特色**: AI-ready silicon, 46人QC团队, 5级检测(48-72h烤机), CE/ErP认证
- **市场**: 波兰Industry 4.0/物流枢纽(Poznań/Łódź)/FinTech(Warsaw)
- **开发策略**: 波兰市场AI交换机供应商
- **置信度**: ★★★★★

### 2. Winstars Technology（深圳）
- **类型**: A类 — PoE OEM大厂
- **成立**: 2005年 (17年)
- **规模**: 1000员工, GlobalSources Premier Supplier
- **出口**: 亚洲/大洋洲/中南美/东欧/中东非洲/北美/西欧
- **开发策略**: 深圳PoE OEM大厂，东欧出口经验
- **置信度**: ★★★★★

### 3. SHENZHEN EQUALS INDUSTRY（深圳）
- **类型**: A类 — PoE OEM/ODM
- **规模**: 300员工, OEM/ODM 3年保修
- **出口**: 西欧/北美/东欧/大洋洲/中南美
- **开发策略**: 深圳PoE OEM，东欧出口
- **置信度**: ★★★★☆

### 4. Allegro.pl（波兰）
- **类型**: C类 — 波兰最大电商
- **网站**: allegro.pl
- **品牌**: Hikvision PoE交换机热销
- **开发策略**: 波兰PoE电商平台
- **置信度**: ★★★★★

### 5. Intellinet Europe（德国）
- **类型**: C类 — 欧洲PoE分销
- **网站**: intellinetnetwork.eu
- **法律实体**: IC Intracom Vertriebs GmbH
- **产品**: 交换机/PoE/光纤/SFP/配线架/机柜全线
- **开发策略**: 德国PoE欧洲分销
- **置信度**: ★★★★★

### 6. Delta-Opti（波兰）
- **类型**: B类 — Ruijie仓储案例
- **事件**: 2025年11月Ruijie部署智能仓储网络
- **开发策略**: 波兰智能仓储Ruijie案例
- **置信度**: ★★★★★

---

## 二、仓储物流PoE市场 ★★★★★

> **市场数据**: PoE仓储摄像头交换机 $2.8B (2025) → $5.9B (2034), CAGR 8.6%
> **Amazon 60+新配送中心** (2024), 每个需300-600 IP摄像头 + 20-50台高口数PoE交换机

### 7. Lantronix + Mouser Electronics仓库
- **类型**: B类 — PoE++仓储案例
- **规模**: 413,000 sqft三层全球配送中心 (全球最大Class 4 DC供电建筑)
- **产品**: SM24TBT2DPB/SM24TBT2DPB-DE PoE++交换机 (90W/口)
- **应用**: PoE照明+占用传感器+摄像头+WiFi AP
- **获奖**: IBCon 2024 Digie Award最智能DC供电建筑
- **开发策略**: PoE++仓储照明标杆案例
- **置信度**: ★★★★★

### 8. Teltonika TSW202仓储方案
- **类型**: B类 — 管理PoE+仓储
- **产品**: TSW202 (8口GbE PoE+ 30W/口, 管理型)
- **应用**: 智能物流仓储
- **开发策略**: Teltonika仓储PoE方案
- **置信度**: ★★★★★

### 9. 2.5GbE/5GbE PoE仓储机会
- **类型**: 市场情报
- **需求**: 4K/8K摄像头流需要2.5GbE/5GbE PoE (避免10GbE成本)
- **趋势**: 2025年首波2.5GbE PoE仓储部署
- **PoE++采用率**: 41.5%新仓储安装指定PoE++ (2021年仅22.3%)
- **开发策略**: 2.5GbE PoE仓储新兴机会
- **置信度**: ★★★★★

---

## 三、Veracity (UK) PoE配件专家

> **情报**: Veracity (UK) 是IP传输产品制造商，50+国家分销，PoE扩展器/同轴电缆方案/摄像头工具

### 10. Veracity (UK)
- **类型**: B类 — PoE传输专家
- **网站**: veracityglobal.com
- **分布**: UK/USA/Middle East/India/SEA, 50+国家
- **产品线**: OUTREACH/LONGSPAN/CAMSWITCH/NTP/存储/视频墙
- **开发策略**: UK PoE传输品牌，需PoE交换机配套
- **置信度**: ★★★★★

### 11. Veracity OUTREACH系列
- **类型**: B类 — PoE扩展器
- **产品**: VOR-ORM(100m PoE直通), VOR-ORM-G(千兆), VOR-ORM-XT(IP66户外), VOR-ORM-GXT(千兆户外IP66/67)
- **规格**: 每单元+100m, 最多800m, 90W PoE, 802.3af/at/bt
- **开发策略**: PoE扩展器领先品牌
- **置信度**: ★★★★★

### 12. Veracity CAMSWITCH
- **类型**: B类 — PoE交换机
- **产品**: VCS-4P1 4+1口802.3at PoE交换机 (£387.79)
- **开发策略**: Veracity自有PoE交换机
- **置信度**: ★★★★☆

### 13. Veracity LONGSPAN
- **类型**: B类 — 长距PoE
- **产品**: VLS-1P-B, PoE 25W扩展600-800m (Cat5e/Cat6)
- **开发策略**: 长距PoE方案
- **置信度**: ★★★★☆

---

## 四、Amazon/Alibaba白牌销量数据

> **情报**: Amazon/Alibaba白牌PoE交换机精确销量数据，揭示价格/销量/品牌竞争格局

### 14. Amazon B2C热销排名
- TP-Link TL-SG2428P: 626台/月, $291.75 (24口PoE+ 250W Omada)
- 5口PoE+交换机: 523台/月, $26.26 (云管理)
- 8口千兆PoE: 288台/月, $44.12 (120W, 金属, 无风扇)
- **YuanLey 5口PoE**: 114台/月, $25.48 (Hasivo OEM)
- **YuanLey PoE扩展器**: 256台/月, $37.53 (Hasivo OEM)
- **Real HD 10口PoE**: 115台/月, $24.29
- **YuanLey 4口户外IP67**: 80台/月, $48.55 (防水)

### 15. Alibaba B2B价格
- OEM PoE 4+2口 100Mbps: $4.50-6.00 (MOQ 1), 月销700+
- Passive PoE千兆: $5.80-7.20, 月销1000+
- KuWFi PoE 48V: $12.99-14.99, 月销524+
- OEM PoE 8口千兆: $14.50-15.00, 月销297+

### 16. Shenzhen Utop Technology（深圳）
- **类型**: A类 — PoE OEM
- **产品**: 4-24口PoE OEM/ODM, $12-16/台
- **开发策略**: 深圳PoE OEM低价供应商
- **置信度**: ★★★★☆

### 17. Hongking Communication（深圳）
- **类型**: A类 — 工业PoE OEM
- **产品**: 8FE+2FE DIN Rail DC48-58V工业PoE $18/台
- **开发策略**: 深圳工业PoE OEM
- **置信度**: ★★★☆☆

---

**Batch 27 总计: 17家新客户/情报**

> 关键发现：
> 1. **东欧6家** — Quantix波兰AI/Winstars 1000人OEM/EQUALS 300人/Allegro.pl波兰电商/Intellinet欧洲/Delta-Opti波兰Ruijie案例
> 2. **仓储物流3家** — Lantronix+Mouser 413K sqft DC PoE++(IBCon获奖)/Teltonika TSW202/2.5GbE PoE仓储新兴(41.5%采用PoE++)
> 3. **Veracity UK 4家** — Veracity 50+国/OUTREACH扩展器(100-800m)/CAMSWITCH/LONGSPAN
> 4. **白牌数据4家** — Amazon精确销量(TP-Link 626/月, YuanLey 256/月)/Alibaba $4.5-15/Utop $12-16/Hongking $18
