# Batch 32 — 交通管理 + 东南亚深挖 + 酒店PoE + Tycon配件
> 深度挖掘 Round 107-110 (2026-10-25)
> 方法论：交通ANPR/红绿灯 / 越南+泰国+菲律宾+印尼+马来西亚 / 酒店WiFi+IPTV / Tycon PoE配件

---

## 一、交通管理 / ANPR PoE ★★★★★

> **情报**: 智能交通(ITS)需全千兆+PoE++, 100摄像头需400-800MB交换容量

### 1. Milesight TrafficX系列
- **类型**: B类 — AI交通PoE
- **网站**: milesight.com
- **产品**: TrafficX/TrafficC/Parking/Entrance + 4/8/16/24口PoE交换机
- **特色**: NDAA合规, 4G太阳能ANPR, AI Road Traffic 5G Pro Bullet Plus
- **开发策略**: AI交通+PoE交换机品牌
- **置信度**: ★★★★★

### 2. OmniConverter交通灯网络
- **类型**: B类 — 红绿灯PoE
- **产品**: OmniConverter 10G/M + RuggedNet GHPoEBT/Mi (4口GbE 100W PoE)
- **应用**: RSU路侧单元+预抢占+PTZ+红绿灯
- **开发策略**: 美国交通灯PoE方案
- **置信度**: ★★★★★

### 3. AVCOMM 6000-PoE + 8000系列
- **类型**: B类 — ITS交换机
- **网站**: avcomm.us
- **产品**: 96Gbps全千兆, PoE工业 (100摄像头400-800MB, QoS)
- **开发策略**: 美国智能交通交换机
- **置信度**: ★★★★★

### 4. Geovision GV-PoE
- **类型**: B类 — CCTV PoE
- **产品**: 4-24口PoE (70W/130W/250W/400W), NVR集成远程PoE控制
- **开发策略**: CCTV PoE+NVR集成
- **置信度**: ★★★★★

### 5. EuroCCTV UK
- **类型**: C类 — 英国CCTV分销
- **网站**: eurocctv.co.uk
- **产品**: 2026最佳PoE (Hi-PoE 60W+ ANPR, Dahua 16口240W)
- **开发策略**: 英国CCTV PoE分销
- **置信度**: ★★★★☆

---

## 二、东南亚5国深挖（越南/泰国/菲律宾/印尼/马来西亚）★★★★★

> **Volza数据**: Vietnam 17852进口(全球第2 20%)/Indonesia 4687(第4)/Philippines 3053(第8)/Malaysia 1914(第10)

### 6. SLA Company Limited（越南）
- **类型**: C类 — ShareTech PoE分销
- **网站**: sla.vn
- **产品**: 4/8/16/24/48口PoE (GE+SFP uplink)
- **开发策略**: 越南PoE分销
- **置信度**: ★★★★★

### 7. PT Tiga Tiga Nusantara（印尼）
- **类型**: C类 — 印尼最大PoE出口
- **数据**: 52出货 (印尼最大)
- **开发策略**: 印尼PoE贸易龙头
- **置信度**: ★★★★☆

### 8. LIANYUE VIETNAM CO LTD
- **类型**: C类 — 越南最大100 PoE出口
- **数据**: 297出货, 12015吨
- **开发策略**: 越南PoE出口龙头
- **置信度**: ★★★★☆

### 9. Ruijie Reyee SEA子公司
- **类型**: B类 — 东南亚本地化
- **覆盖**: Malaysia/Indonesia/Vietnam/Philippines/Thailand (全资)
- **案例**: 2025.11 Thaishin International School Thailand Wi-Fi 7
- **开发策略**: Ruijie SEA本地化参考
- **置信度**: ★★★★★

### 10. Volza SEA贸易流
- **类型**: 市场情报
- **出口**: Vietnam 21040 (第2) / Malaysia 4294 (第5) / Thailand 1467 (第9) / Philippines 536
- **进口**: China 52766→东南亚 (50%份额)
- **开发策略**: SEA PoE贸易流情报
- **置信度**: ★★★★★

---

## 三、酒店/度假村 PoE ★★★★★

> **情报**: 酒店WiFi 7需802.3bt PoE++ 60-90W/口, IPTV需IGMP snooping+jumbo frames

### 11. Omada酒店方案
- **类型**: B类 — 酒店PoE全线
- **产品**: SG3452XMPP (48口, 40xPoE+ + 8xPoE++ + 4x10G SFP+)
- **案例**: Manchester Hall 100+房 / Lotte City Hotel Jeju
- **开发策略**: TP-Link酒店PoE方案
- **置信度**: ★★★★★

### 12. Newbridge酒店PoE
- **类型**: B类 — 酒店PoE案例
- **案例**: Kuailu酒店 (三层架构, 24口客房+48口公共+安防, 802.3bt)
- **开发策略**: 酒店PoE升级方案
- **置信度**: ★★★★☆

### 13. Lantronix Hotel Marcel
- **类型**: B类 — net-zero酒店标杆
- **产品**: SM24TBT2DPB PoE++ (UL认证, 24x90W, DC微电网)
- **集成**: Sinclair Digital Services
- **地位**: 美国首个net-zero能源酒店
- **开发策略**: PoE++绿色建筑标杆
- **置信度**: ★★★★★

### 14. PoE酒店照明
- **类型**: 应用情报
- **案例**: Alila Marea Beach Resort California (PoE节省50%材料+人工)
- **开发策略**: PoE照明酒店应用
- **置信度**: ★★★★☆

### 15. Californiatelecom酒店WiFi
- **类型**: B类 — 酒店WiFi集成
- **网站**: californiatelecom.com
- **方案**: WiFi 7 AP 20W+ PoE++ 802.3bt必须, 4 VLAN (Guest/Staff/POS/IoT)
- **开发策略**: 美国酒店WiFi PoE集成
- **置信度**: ★★★★☆

### 16. Fuse Systems酒店WiFi
- **类型**: B类 — 酒店WiFi设计
- **网站**: fuse.systems
- **方案**: 802.3bt PoE++ 60-90W, Cat6A, IGMP+jumbo (Samsung/LG/Otrum IPTV)
- **开发策略**: 酒店WiFi PoE设计
- **置信度**: ★★★★☆

---

## 四、Tycon PoE配件深挖

> **情报**: Tycon Systems (美国) 是PoE注入器/分路器/扩展器领先品牌，-40~85°C工业级

### 17. Tycon Systems / Tycon Power（美国）
- **类型**: B类 — PoE配件全线
- **网站**: tyconsystems.com
- **产品**: 注入器/分路器/扩展器, -40~85°C, 屏蔽RJ45
- **开发策略**: 美国PoE配件领先品牌
- **置信度**: ★★★★★

### 18. Tycon POE-INJ-1000-WT系列
- **类型**: B类 — 130W千兆PoE
- **型号**: WT (1245+ 3678-) $12.95 / WTs (1236+ 4578-) $11.95 / WTx (3645+ 1278-) $14.95
- **规格**: 130W, 5-58VDC, 100m, -40~85°C
- **开发策略**: 高功率PoE注入器
- **置信度**: ★★★★★

### 19. Tycon POE-INJ/SPLT-G
- **类型**: B类 — 150W千兆
- **规格**: 2.5A 12-65VDC 150W, $49.95
- **开发策略**: 超高功率PoE
- **置信度**: ★★★★☆

### 20. Tycon POE-EXT-GD-HP
- **类型**: B类 — 户外PoE扩展
- **规格**: 千兆802.3at, IP66, 100m (多单元300m)
- **开发策略**: 户外PoE扩展
- **置信度**: ★★★★☆

### 21. iComTech Tycon分销
- **类型**: C类 — 美国Tycon分销
- **网站**: icomtechinc.com
- **开发策略**: Tycon美国分销
- **置信度**: ★★★★☆

### 22. Streakwave Tycon分销
- **类型**: C类 — 美国Tycon分销
- **网站**: streakwave.com
- **开发策略**: Tycon美国分销
- **置信度**: ★★★★☆

---

**Batch 32 总计: 22家新客户/情报**

> 关键发现：
> 1. **交通5家** — Milesight TrafficX NDAA/OmniConverter红绿灯RuggedNet 100W/AVCOMM 6000 96Gbps/Geovision NVR集成/EuroCCTV UK Hi-PoE
> 2. **东南亚5家** — SLA越南ShareTech/PT Tiga Tiga印尼最大/LIANYUE越南最大100 PoE 297出货/Ruijie Reyee SEA全资/Volza SEA贸易流(Vietnam 17852进口全球第2)
> 3. **酒店6家** — Omada SG3452XMPP 48口Manchester Hall/Newbridge Kuailu/Lantronix Hotel Marcel net-zero 24x90W/Alila Marea PoE照明/Californiatelecom WiFi 7/Fuse IGMP
> 4. **Tycon 6家** — Tycon Systems全线/POE-INJ-1000-WT/WTs/WTx 130W/POE-INJ/SPLT-G 150W/POE-EXT-GD-HP IP66/iComTech/Streakwave
