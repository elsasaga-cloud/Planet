# Batch 11 — 南亚分销 + 政府招标 + 全球品牌/竞品 + 台湾ODM
> 深度挖掘 Round 19-22 (2026-10-25)
> 方法论：南亚区域搜索 / 政府招标分析 / 全球品牌搜索 / 台湾ODM情报

---

## 一、C类：孟加拉国网络设备分销（7家）

### 1. Trimatrik Multimedia（孟加拉达卡）
- **类型**: C类 — 孟加拉领先PoE交换机供应商
- **网站**: trimatrikbd.com
- **品牌**: Dahua, 298, Verbex, Huawei
- **开发策略**: 孟加拉PoE交换机专业供应商
- **置信度**: ★★★★★

### 2. Star Tech（孟加拉）
- **类型**: C类 — 大型IT零售商
- **网站**: startech.com.bd
- **品牌**: Zyxel, Genata, Cisco, MikroTik, TP-Link, Tenda, Cudy, Ruijie, BDCOM, NETGEAR, D-Link, HikVision, Grandstream, Huawei
- **开发策略**: 孟加拉最大IT零售之一
- **置信度**: ★★★★★

### 3. Global Brand PLC（孟加拉）
- **类型**: C类 — ICT分销
- **网站**: globalbrand.com.bd
- **品牌**: Cudy (GS5024PS4 L3管理型PoE)
- **开发策略**: 孟加拉ICT分销商
- **置信度**: ★★★★★

### 4. Computer Village（孟加拉）
- **类型**: C类 — 25年+网络设备
- **网站**: computervillage.com.bd
- **品牌**: Tenda, TP-Link, Cudy, Mikrotik, NETGEAR
- **开发策略**: 孟加拉老牌网络设备商
- **置信度**: ★★★★★

### 5. CSL Systems（孟加拉）
- **类型**: C类 — 多品牌网络分销
- **网站**: cslsystems.com.bd
- **品牌**: Cisco, Mikrotik, TP-Link, D-Link, Hikvision, Dahua, Ruijie
- **开发策略**: 孟加拉全品类网络分销
- **置信度**: ★★★★★

### 6. Touch IT（孟加拉）
- **类型**: C类 — Tiandy/Dahua PoE
- **网站**: touchit.com.bd
- **品牌**: Tiandy (TC-P3S系列PoE), Dahua
- **开发策略**: 孟加拉Tiandy渠道
- **置信度**: ★★★★☆

### 7. Ryans（孟加拉）
- **类型**: C类 — IT零售
- **网站**: ryans.com
- **品牌**: TP-Link, Tenda, Cudy, Ruijie, Netgear, Dahua, Micronet, MikroTik, Grandstream
- **开发策略**: 孟加拉IT零售连锁
- **置信度**: ★★★★★

---

## 二、C类：尼泊尔网络设备分销（5家）

### 8. First Aid Nepal（尼泊尔）
- **类型**: C类 — Ruijie授权分销+PoE交换机
- **网站**: firstaidnepal.com
- **品牌**: Ruijie/Reyee, Dahua, Hikvision, Cisco, CP Plus
- **开发策略**: 尼泊尔网络设备进口/分销商
- **置信度**: ★★★★★

### 9. All Nepal Sales（尼泊尔）
- **类型**: C类 — Hikvision PoE交换机
- **网站**: allnepalsales.com
- **品牌**: Hikvision (DS-3E系列)
- **开发策略**: 尼泊尔安防设备分销
- **置信度**: ★★★★☆

### 10. Gigabyte Exim（尼泊尔）
- **类型**: C类 — 网络设备进口
- **网站**: gigabyte.com.np
- **成立**: 2018年
- **产品**: OLT, ONU, AP, 交换机, VoIP
- **开发策略**: 尼泊尔网络设备解决方案商
- **置信度**: ★★★★☆

### 11. Nicofire（尼泊尔）
- **类型**: C类 — PoE交换机零售
- **网站**: nicofire.com
- **品牌**: CP Plus, JVS
- **开发策略**: 尼泊尔PoE交换机在线零售
- **置信度**: ★★★☆☆

### 12. Gadget House Nepal（尼泊尔）
- **类型**: C类 — Cisco交换机
- **网站**: gadgethousenepal.com
- **品牌**: Cisco (WS-C2960L系列)
- **开发策略**: 尼泊尔IT零售
- **置信度**: ★★★☆☆

---

## 三、C类：斯里兰卡 + 巴基斯坦（5家）

### 13. ICT Distribution（斯里兰卡/柬埔寨/老挝/缅甸）
- **类型**: C类 — Aruba增值分销
- **网站**: ictdistribution.net
- **地址**: 3rd floor, 30 Sir Lester James Peries Mawatha, Colombo 05
- **电话**: +94 112 590 186
- **邮箱**: info@ictdistribution.net
- **区域**: 斯里兰卡+柬埔寨+老挝+缅甸
- **开发策略**: 多国分销，覆盖南亚+东南亚
- **置信度**: ★★★★★

### 14. MM Sri Lanka（斯里兰卡）
- **类型**: C类 — EnGenius/HPE PoE交换机
- **网站**: mmsrilanka.com
- **品牌**: EnGenius (Cloud Managed PoE+), HPE Instant On 1930
- **开发策略**: HPE Instant On斯里兰卡授权电商合作伙伴
- **置信度**: ★★★★★

### 15. DCL Engineering（斯里兰卡科伦坡）
- **类型**: C类 — 企业网络交换机
- **产品**: 1GE-100GE光纤/铜缆交换机
- **开发策略**: 斯里兰卡网络工程
- **置信度**: ★★★★☆

### 16. MB Communication（巴基斯坦卡拉奇）
- **类型**: C类 — Hikvision PoE交换机
- **网站**: mbcommunication.com.pk
- **品牌**: Hikvision (DS-3E系列全线), BlackCopper, Tenda
- **开发策略**: 巴基斯坦网络设备零售
- **置信度**: ★★★★☆

### 17. Ultra Tech（巴基斯坦）
- **类型**: C类 — 网络设备分销
- **网站**: ultratech.pk
- **成立**: 2018年
- **产品**: 网络交换机/路由器/光纤设备
- **开发策略**: 巴基斯坦网络设备在线分销
- **置信度**: ★★★★☆

---

## 四、B类：全球品牌（A/B类新客户 + 竞品情报）

### 18. ZKTeco（中国/全球）
- **类型**: A类竞品 — 安防品牌扩展到PoE交换机
- **网站**: zkteco.com/en/POESwitch
- **全球分支**: 阿根廷/巴西/哥伦比亚/埃及/欧洲/香港/印度/印尼/爱尔兰/日本/肯尼亚/韩国/拉美/马来/墨西哥/中东/尼日利亚/菲律宾/秘鲁/沙特/南非/泰国/土耳其/美国/越南/西非/巴基斯坦
- **开发策略**: 安防巨头扩展到网络交换机，其全球渠道可争取
- **置信度**: ★★★★★

### 19. Linovision USA / Hinovision Solutions LLC（美国德州Plano）
- **类型**: A类 — 美国PoE交换机品牌
- **网站**: linovision.com
- **产品**: 商用(11款)/工业(18款)/管理型(10款)/太阳能DC12V(11款)/机器人(2款)/户外(1款)/超远距离(3款)
- **特点**: NDAA合规, 工业DIN-Rail
- **开发策略**: 美国PoE专业品牌，可能需要中国OEM
- **置信度**: ★★★★★

### 20. Omnitron Systems（美国加州）
- **类型**: B类 — PoE交换机制造商
- **网站**: omnitron-systems.com
- **成立**: 1992年
- **开发策略**: 美国PoE交换机品牌
- **置信度**: ★★★★★

### 21. Petenet（加拿大）
- **类型**: A类 — 加拿大UL认证PoE交换机
- **网站**: petenetcorp.com
- **成立**: 2008年
- **特点**: UL认证, 北美市场
- **开发策略**: 加拿大自有品牌PoE交换机
- **置信度**: ★★★★★

### 22. GZCOM（深圳）
- **类型**: 竞品 — PoE交换机/以太网/AP
- **网站**: gzcomm.com
- **地址**: 401, Annex Building, Jinhedan Commercial Center, 329 Longhuan 3rd Road, Longhua, Shenzhen
- **电话**: 86-15876566237
- **邮箱**: luffy@gzcomm.com
- **出口**: 西欧/北美/东南亚/CIS/非洲/中东/南美
- **开发策略**: 深圳竞品，了解其客户
- **置信度**: ★★★★★

### 23. Winstars Technology（深圳）
- **类型**: 竞品 — 大型PoE交换机OEM
- **成立**: 2005年
- **员工**: 1000人
- **出口**: 亚洲/澳洲/中南美/东欧/中东非洲/北美/西欧
- **开发策略**: 深圳大型OEM竞品
- **置信度**: ★★★★★

### 24. Benchu Group（深圳）
- **类型**: 竞品 — PoE交换机/注入器/光纤
- **网站**: benchu-group.com
- **产品**: PoE交换机, PoE注入器, 光纤网络产品
- **开发策略**: 深圳OEM/ODM竞品
- **置信度**: ★★★★☆

### 25. Rubytech（台湾）
- **类型**: 竞品情报 — 台湾ODM PoE交换机
- **网站**: rubytech.com.tw / rubytech-corp.com
- **产品**: 230+ SKU, 1G/2.5G/10G PoE交换机
- **产能**: 140万台/年, ISO9001/14001/TL9000
- **开发策略**: 台湾ODM竞品，100%台湾制造
- **置信度**: ★★★★★

### 26. CTC Union（台湾）
- **类型**: 竞品情报 — 工业PoE交换机
- **网站**: ctcu.com
- **成立**: 1993年
- **产品**: L2以太网交换机, 工业交换机, 媒体转换器
- **开发策略**: 台湾工业交换机竞品
- **置信度**: ★★★★★

### 27. Proscend（台湾/全球）
- **类型**: B类 — 工业路由器+PoE，扩展非洲
- **网站**: proscend.com
- **开发策略**: 正在扩展非洲市场
- **置信度**: ★★★★☆

### 28. NVT Phybridge（全球）
- **类型**: B类 — PoE交换机+扩展器
- **成立**: 2008年
- **员工**: 51-100人
- **开发策略**: PoE长距离扩展专业品牌
- **置信度**: ★★★★☆

---

## 五、政府招标情报

### 29. 哈萨克斯坦政府PoE交换机采购（活跃）
- **类型**: 市场情报 — 大量PoE交换机招标
- **金额**: KZT 25,000 - 41,552,000（约$50 - $80,000）
- **产品**: 8口/16口管理型PoE交换机, 安全接入交换机
- **开发策略**: 通过当地分销商参与招标
- **置信度**: ★★★★★

### 30. 印度各邦政府PoE交换机采购（极活跃）
- **类型**: 市场情报 — 印度全国PoE交换机招标
- **覆盖**: 卡纳塔克/特伦甘纳/中央邦/马哈拉施特拉/旁遮普/北方邦/比哈尔/西孟加拉/德里/哈里亚纳
- **品牌**: CP Plus, Dahua, Hikvision, D-Link, Cisco, Juniper
- **开发策略**: 印度政府采购极活跃，通过CP Plus等渠道
- **置信度**: ★★★★★

### 31. 巴基斯坦联邦PoE+交换机采购
- **类型**: 市场情报 — L3 PoE+交换机招标
- **地点**: 伊斯兰堡 Evacuee Trust Complex
- **标准**: IEEE 802.3af/at/bt, 金属机箱, 机架式
- **开发策略**: 通过巴基斯坦当地分销参与
- **置信度**: ★★★★★

### 32. 英国Spencer Academies Trust（£1.45M）
- **类型**: 市场情报 — 300+台Aruba PoE交换机
- **价值**: £1,447,865
- **产品**: Aruba CX6100 48口PoE+ (55台), CX6300 48口PoE+ (199台), CX4100i工业(13台)
- **供应商**: AMC-IT Solutions Ltd
- **开发策略**: 英国教育市场大单
- **置信度**: ★★★★★

---

**Batch 11 总计: 32家新客户 + 4条招标情报**

> 关键发现：
> 1. **孟加拉7家** — Trimatrik/Star Tech/Global Brand/Computer Village/CSL/Touch IT/Ryans
> 2. **尼泊尔5家** — First Aid Nepal(睿捷授权)/All Nepal Sales/Gigabyte Exim/Nicofire/Gadget House
> 3. **斯里兰卡3家** — ICT Distribution(4国覆盖)/MM Sri Lanka/DCL Engineering
> 4. **巴基斯坦2家** — MB Communication/Ultra Tech
> 5. **全球品牌4家** — ZKTeco/Linovision USA/Omnitron/Petenet
> 6. **竞品6家** — GZCOM/Winstars/Benchu/Rubytech/CTC Union/Proscend/NVT Phybridge
> 7. **政府招标** — 哈萨克/印度(10邦)/巴基斯坦/英国(£1.45M)极活跃
