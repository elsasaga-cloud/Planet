# Batch 15 — 门禁对讲生态 + 中美洲加勒比 + 数字标牌 + PoE照明
> 深度挖掘 Round 35-38 (2026-10-25)
> 方法论：门禁对讲PoE生态 / 中美洲加勒比分销 / 数字标牌PoE / PoE照明生态

---

## 一、B类：门禁/对讲 PoE生态

### 1. Security Wholesalers（澳大利亚）
- **类型**: C类 — Dahua对讲机+PoE交换机套装
- **网站**: securitywholesalers.com.au
- **产品**: Dahua DHI-KTP01套件 (VTO门机+VTH室内机+DH-PFS3005 PoE交换机)
- **开发策略**: 澳洲安防批发，对讲套装含PoE交换机
- **置信度**: ★★★★★

### 2. CCTV Guru（澳大利亚）
- **类型**: C类 — Dahua对讲套装分销
- **网站**: cctvguru.com.au
- **产品**: Dahua套装含IP-COM F1106P-4-63W PoE交换机
- **开发策略**: 澳洲CCTV零售，对讲机+PoE
- **置信度**: ★★★★★

### 3. ITcommart（泰国）
- **类型**: C类 — Hikvision对讲套装
- **网站**: itcommart.com
- **产品**: Hikvision DS-KIS603-P IP对讲套装 (PoE门机+监视器)
- **价格**: DS-KIS603-P 6,980 THB
- **开发策略**: 泰国安防分销
- **置信度**: ★★★★☆

### 4. Megateh（欧洲/保加利亚）
- **类型**: C类 — Dahua对讲分销
- **网站**: megateh.eu
- **产品**: Dahua VTO2202F-P-S3 (PoE, 2MP, IP65, IK07)
- **开发策略**: 东欧安防分销
- **置信度**: ★★★★☆

### 5. Lisintec（欧洲）
- **类型**: C类 — Dahua对讲套装
- **网站**: lisintec.com
- **产品**: KTP01-F/S套件含PFS3005-4ET-60 PoE交换机
- **开发策略**: 欧洲对讲PoE套装
- **置信度**: ★★★★☆

### 6. SecureYourWorld（澳大利亚）
- **类型**: C类 — Dahua对讲PoE
- **网站**: secureyourworld.com.au
- **产品**: Dahua VTO6210对讲PoE交换机 (6口, DC24V)
- **开发策略**: 澳洲安防零售
- **置信度**: ★★★★☆

---

## 二、中美洲 + 加勒比

### 7. Panacompu（巴拿马）
- **类型**: C类 — 网络设备零售
- **网站**: panacompu.com
- **产品**: Ubiquiti Dream Machine PoE ($623)
- **开发策略**: 巴拿马IT零售
- **置信度**: ★★★★☆

### 8. Camarasdeseguridad（危地马拉）
- **类型**: C类 — CCTV+PoE交换机
- **网站**: camarasdeseguridad.com.gt
- **产品**: PoE交换机 (安防/网络/CCTV)
- **开发策略**: 危地马拉安防专业分销
- **置信度**: ★★★★★

### 9. Chipcom S.A.（危地马拉）
- **类型**: C类 — 网络设备分销
- **网站**: chipcom.com.gt
- **产品**: Ubiquiti USW-LITE-8-POE (8口, 4 PoE+, 52W)
- **开发策略**: 危地马拉IT分销
- **置信度**: ★★★★☆

### 10. Grupo Orotec（危地马拉）
- **类型**: C类 — ZKTeco授权分销
- **网站**: tiendaoficialorotec.com
- **产品**: ZKTeco PoE交换机 (4口/8口)
- **开发策略**: 危地马拉ZKTeco独家，门禁PoE
- **置信度**: ★★★★★

### 11. TiendaEncr（哥斯达黎加）
- **类型**: C类 — PoE交换机零售
- **网站**: tiendaencr.com
- **产品**: 4口PoE交换机 ₡32,500 CRC (802.3af/at)
- **开发策略**: 哥斯达黎加网络零售
- **置信度**: ★★★★☆

### 12. PRWE（特立尼达和多巴哥）
- **类型**: C类 — 东加勒比IT供应商
- **网站**: prwe.com
- **产品**: 24口PoE+交换机 (12口PoE)
- **电话**: (868) 285-9779
- **地点**: Aranguez/Chaguanas/PrincesTown/WoodBrook/Tobago
- **开发策略**: 东加勒比头部IT供应商
- **置信度**: ★★★★★

### 13. EEN（美国/拉美）
- **类型**: C类 — PoE交换机分销
- **网站**: een.com
- **拉美联系**: +52 55 8526 4926
- **开发策略**: 美国+拉美加勒比分销
- **置信度**: ★★★★☆

---

## 三、数字标牌 PoE

### 14. GPO Display（美国）
- **类型**: B类 — PoE全景LCD显示器
- **网站**: gpodisplay.com
- **产品**: PoE全景LCD (27"到50"), 需PoE++交换机
- **开发策略**: PoE数字标牌显示器品牌
- **置信度**: ★★★★★

### 15. Bluefin Displays（美国）
- **类型**: B类 — PoE数字标牌
- **网站**: thebluefin.com
- **产品**: PoE数字标牌 (即插即用)
- **开发策略**: PoE标牌品牌
- **置信度**: ★★★★☆

### 16. Premio Inc（美国）
- **类型**: B类 — PoE面板PC
- **网站**: premioinc.com
- **产品**: PoE数字标牌面板PC
- **开发策略**: PoE工业面板PC
- **置信度**: ★★★★☆

### 17. SSA Electronic（深圳）
- **类型**: B类 — PoE数字标牌
- **网站**: ssa-digital.com
- **产品**: PoE数字标牌 (10.1"到21.5"+)
- **开发策略**: 深圳PoE标牌厂商
- **置信度**: ★★★★☆

### 18. Winmate（台湾）
- **类型**: B类 — PoE触控显示器
- **网站**: winmate.com
- **产品**: PoE触控显示器 (工业/数字标牌)
- **开发策略**: 台湾工业PoE显示器
- **置信度**: ★★★★★

---

## 四、PoE照明生态

### 19. Signify (Philips Lighting)（荷兰）
- **类型**: A类竞品 — 全球PoE照明#1
- **网站**: signify.com
- **产品**: PoE灯具+传感器+Interact平台
- **规模**: 6000万+Philips Hue灯泡
- **开发策略**: PoE照明全球领袖，交换机需求巨大
- **置信度**: ★★★★★

### 20. Acuity Brands（美国）
- **类型**: A类 — PoE照明nLight平台
- **网站**: acuitybrands.com
- **产品**: nLight PoE照明 (4000+节点/交换机)
- **合作**: Cisco PoE交换机
- **开发策略**: 美国PoE照明品牌，大量PoE交换机需求
- **置信度**: ★★★★★

### 21. PoEWit Technologies（美国）
- **类型**: B类 — PoE照明+交换机
- **网站**: poewit.com
- **产品**: PoE灯具+PoE交换机+传感器+UPS
- **成立**: 2019年
- **开发策略**: PoE照明全方案商
- **置信度**: ★★★★★

### 22. PoE Texas（美国）
- **类型**: B类 — PoE照明套件
- **网站**: poetexas.com / shop.poetexas.com
- **产品**: 24V LED驱动器+PoE开关+无线开关
- **地点**: Austin, TX
- **开发策略**: PoE照明套件品牌
- **置信度**: ★★★★★

### 23. Versa Technology（美国）
- **类型**: B类 — PoE LED照明+UPoE交换机
- **网站**: versatek.com
- **产品**: VX-GPU2626 (24口UPoE 2000W) + PoE LED照明
- **开发策略**: UPoE 2000W交换机+照明
- **置信度**: ★★★★★

### 24. MHT Technologies（美国/纽约）
- **类型**: B类 — Inspextor PoE硬件平台
- **网站**: mht-technologies.com
- **产品**: Inspextor PoE节点+控制器 (照明/传感器/窗帘)
- **覆盖**: 北美+中美洲+欧洲
- **开发策略**: PoE建筑控制平台
- **置信度**: ★★★★★

### 25. Sinclair Digital（美国）
- **类型**: B类 — X-PoE照明系统
- **网站**: sinclair-digital.com
- **产品**: X-PoE交换机 (48-57V DC, 25000流明高棚灯)
- **开发策略**: 创新X-PoE照明方案
- **置信度**: ★★★★☆

### 26. LAMAR LED（美国）
- **类型**: B类 — Genisys PoE照明
- **网站**: lamarled.com
- **产品**: Genisys PoE照明系统 (PoE+ 30W/UPoE 60W)
- **开发策略**: PoE照明LED品牌
- **置信度**: ★★★★☆

### 27. IPCamPower（美国）
- **类型**: B类 — PoE照明系统
- **网站**: ipcampower.com
- **产品**: PoE照明接收器+LED驱动器+无线开关
- **开发策略**: PoE照明简化方案
- **置信度**: ★★★★☆

### 28. Tycon Systems（美国）
- **类型**: B类 — PoE照明电源
- **网站**: tyconsystems.com
- **产品**: PoE注入器/交换机/中跨 (802.3bt LED照明)
- **开发策略**: PoE照明电源方案
- **置信度**: ★★★★☆

### 29. Axis Lighting（加拿大）
- **类型**: B类 — PoE照明
- **网站**: axislighting.com
- **产品**: PoE LED灯具
- **开发策略**: 加拿大PoE照明品牌
- **置信度**: ★★★★☆

### 30. Deco Lighting（美国）
- **类型**: B类 — PoE照明
- **产品**: PoE灯具
- **开发策略**: 美国PoE照明品牌
- **置信度**: ★★★★☆

---

## 五、新PoE交换机品牌

### 31. Linovision USA（美国）
- **类型**: B类 — 宽压PoE交换机
- **网站**: linovision.com
- **产品**: POE-Switch0504GD (5口全千兆, DC9-54V输入, 升压)
- **开发策略**: 宽压输入PoE，特殊应用
- **置信度**: ★★★★☆

### 32. Hi-Net Technology（深圳）
- **类型**: 竞品 — PoE交换机专业厂商
- **网站**: poe switch.net
- **成立**: 2010年
- **产品**: L2/L3/10G/2.5G/bt PoE交换机
- **地点**: 深圳宝安区福海街道
- **开发策略**: 深圳PoE交换机竞品
- **置信度**: ★★★★★

### 33. Ewind Technology（深圳）
- **类型**: 竞品 — 工业PoE交换机
- **网站**: ewindnet.com
- **成立**: 7+年, 200人, 5000m², 100+国家
- **投资**: 5067万美金
- **产品**: 工业PoE/PoE注入器/分配器/光纤收发器
- **开发策略**: 深圳工业PoE竞品
- **置信度**: ★★★★★

### 34. Omada Networks（TP-Link子品牌）
- **类型**: 竞品 — TP-Link独立PoE品牌
- **网站**: store.omadanetworks.com
- **产品**: ES205GP(5口)/SG2016P(16口) PoE交换机
- **开发策略**: TP-Link独立品牌，管理型PoE
- **置信度**: ★★★★★

---

## 六、海关贸易情报

### 厄瓜多尔
- **进口**: 364批次, 117买家, 145供应商
- **来源**: 中国/美国/台湾 (占84%)

### 美国出口
- **PoE交换机出口**: 2559批次, 209出口商, 312买家
- **主要目的地**: 印度/哥斯达黎加/秘鲁

### 韩国出口
- **PoE交换机出口**: 333批次, 96供应商, 125买家
- **Top出口商**: SOLTECH(26%), HYUNDAI ROTEM(15%)

---

**Batch 15 总计: 34家新客户/情报**

> 关键发现：
> 1. **门禁对讲6家** — 澳洲3+泰国1+欧洲2，对讲套装标配PoE交换机
> 2. **中美洲加勒比7家** — 巴拿马/危地马拉3/哥斯达黎加/特立尼达/拉美
> 3. **数字标牌5家** — GPO Display/Bluefin/Premio/SSA/Winmate
> 4. **PoE照明12家** — Signify/Acuity/PoEWit/PoE Texas/Versa/MHT/Sinclair/LAMAR/IPCamPower/Tycon/Axis/Deco
> 5. **新PoE品牌4家** — Linovision/Hi-Net/Ewind/Omada
> 6. **海关情报**: 厄瓜多尔117买家/美国出口→印度哥斯达黎加秘鲁/韩国SOLTECH#1
