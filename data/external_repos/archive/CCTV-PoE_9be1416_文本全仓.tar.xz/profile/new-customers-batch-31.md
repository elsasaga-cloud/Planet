# Batch 31 — 医疗PoE深挖 + 油气/太阳能 + 非洲4国深挖
> 深度挖掘 Round 103-106 (2026-10-25)
> 方法论：医疗IoT PoE / 油气+太阳能农场 / 尼日利亚+加纳+坦桑尼亚+乌干达

---

## 一、医疗PoE深挖 ★★★★★

> **市场数据**: 医疗PoE交换机 17.8%全球份额 (2025), CAGR 8.7%

### 1. Versa Technology Healthcare
- **类型**: B类 — 医疗PoE方案
- **产品**: 管理PoE (802.1X/MAC/VLAN分段, UPS+冗余uplink)
- **应用**: 安全+监控+通讯+护士呼叫
- **开发策略**: 美国医疗PoE方案
- **置信度**: ★★★★★

### 2. Omnitron IoT医院
- **类型**: B类 — 医院IoT PoE
- **产品**: RuggedNet G Mi 1
- **应用**: 患者监护/智能输液泵/护士呼叫/资产追踪/远程医疗
- **开发策略**: 美国医院IoT PoE方案
- **置信度**: ★★★★★

### 3. PKOWS Healthcare PoE
- **类型**: B类 — 医疗PoE
- **网站**: pkows.com
- **应用**: 患者监护+智能床+电子健康档案+远程医疗
- **开发策略**: 医疗PoE方案
- **置信度**: ★★★★☆

### 4. Versitron
- **类型**: B类 — 医疗PoE
- **网站**: versitron.com
- **应用**: 医院WiFi/IP通讯/患者监控/安防
- **开发策略**: 美国医疗PoE品牌
- **置信度**: ★★★★☆

### 5. NETGEAR医疗PoE中继
- **类型**: 竞品 — 医疗设备PoE
- **方案**: 高功率PoE交换机 (15W/30W) + PoE中继交换机 (医疗设备内部再分配)
- **优势**: 48V弱电流安全, 国际统一接口 (无电源制式问题)
- **开发策略**: NETGEAR医疗设备PoE方案
- **置信度**: ★★★★★

---

## 二、油气 / 太阳能农场 PoE

### 6. FICOTEK（深圳）★
- **类型**: A类 — 太阳能PoE交换机Top 1
- **网站**: ficotek.cn
- **产品**: 工业级防雷PoE (VLAN/QoS/RSTP/ERPS/SNMP/PoE控制/链路聚合)
- **应用**: 石油/储能/高铁/风电/安防
- **案例**: 200MW沙漠太阳能, 500台24口PoE+双光纤+ERPS环+IP68, -20~65°C, 2年零宕机
- **政策**: 1年换/3年修/终身技术支持
- **开发策略**: 深圳太阳能PoE领先品牌
- **置信度**: ★★★★★

### 7. Planet巴西太阳能农场
- **类型**: B类 — 太阳能PoE案例
- **产品**: IGS-624HPT (4xGbE PoE+ + 2xSFP, 12-54V冗余DC, IP40, -40~75°C, 6KV浪涌)
- **案例**: 32个光伏电站, PoE IP摄像头+门禁
- **开发策略**: 巴西太阳能PoE标杆案例
- **置信度**: ★★★★★

### 8. ONV太阳能+风电监控
- **类型**: B类 — 绿色能源PoE
- **网站**: onvcom.com
- **应用**: 太阳能光伏+风电设备监控
- **开发策略**: 绿色能源PoE方案
- **置信度**: ★★★★☆

### 9. Cisco IE 3000/4000工业
- **类型**: 竞品 — 油气+太阳能PoE
- **产品**: PoE+/PoE++, 极端温度/振动/浪涌
- **应用**: 太阳能农场/油气/交通
- **开发策略**: Cisco工业PoE竞品
- **置信度**: ★★★★★

---

## 三、非洲4国深挖（尼日利亚/加纳/坦桑尼亚/乌干达）★★★★★

> **Volza数据**: Uganda 78买家 154出货 / Nigeria Jumia 137产品

### 10. RapidBTS（尼日利亚）
- **类型**: C类 — PoE零售
- **网站**: rapidbts.ng
- **品牌**: EnGenius EGS5110P/Grandstream GWN7700P-7803P全线
- **价格**: ₦12K-3M
- **开发策略**: 尼日利亚PoE零售
- **置信度**: ★★★★★

### 11. Prestensys（尼日利亚）
- **类型**: C类 — 多品牌分销
- **网站**: prestensys.com
- **品牌**: Cisco/Ubiquiti/D-Link/TP-Link/Juniper/Aruba/MikroTik/Grandstream
- **地点**: Ikeja + Abuja
- **开发策略**: 尼日利亚多品牌分销
- **置信度**: ★★★★★

### 12. Jumia Nigeria PoE
- **类型**: C类 — 电商平台
- **数据**: 137 PoE产品
- **品牌**: Cisco C1300/Grandstream/Ubiquiti/Optimax
- **开发策略**: 尼日利亚PoE电商
- **置信度**: ★★★★☆

### 13. Deus Ghana
- **类型**: C类 — 加纳网络分销
- **网站**: deus.com.gh
- **产品**: 10/100/Gigabit/PoE/管理/非管理全线
- **开发策略**: 加纳网络分销
- **置信度**: ★★★★☆

### 14. Jiji Ghana 8口市场
- **类型**: C类区域市场
- **品牌**: Hikvision DS-3e0510p/Ubiquiti USW-Lite-8-PoE/TP-Link TL-SG2210P/CUDY
- **价格**: GH₵385-1350
- **开发策略**: 加纳PoE零售市场
- **置信度**: ★★★★☆

### 15. Empire Tanzania
- **类型**: C类 — 坦桑尼亚PoE
- **网站**: empire.co.tz
- **品牌**: TP-Link/BDCOM/Ubiquiti (USW-Lite-8-PoE TZS 744,800)
- **开发策略**: 坦桑尼亚PoE分销
- **置信度**: ★★★★☆

### 16. Gadgetronix Tanzania
- **类型**: C类 — 坦桑尼亚Dahua
- **网站**: gadgetronix.net
- **地点**: Arusha + Dar Es Salaam (4门店)
- **品牌**: Dahua PoE
- **开发策略**: 坦桑尼亚Dahua PoE
- **置信度**: ★★★★☆

### 17. Onet Tanzania
- **类型**: C类 — 坦桑尼亚WI-TEK
- **网站**: onet.co.tz
- **品牌**: WI-TEK PoE (TZS 360K-1.1M)
- **开发策略**: 坦桑尼亚WI-TEK PoE
- **置信度**: ★★★☆☆

### 18. TalindaExpress Kenya
- **类型**: C类 — 肯尼亚+东非
- **网站**: talindaxpress.com
- **品牌**: MikroTik+全线
- **覆盖**: Kenya+Uganda+Tanzania+Congo+South Sudan+Rwanda+Zambia
- **开发策略**: 东非6国PoE分销
- **置信度**: ★★★★★

### 19. TDK Tech Kenya
- **类型**: C类 — 肯尼亚PoE
- **网站**: tdk.co.ke
- **覆盖**: Nairobi+东非 (Juba/Kampala/Dar/Kigali)
- **开发策略**: 肯尼亚PoE分销
- **置信度**: ★★★★☆

### 20. CTC Kenya
- **类型**: C类 — 肯尼亚多品牌
- **网站**: ctcsolutions.co.ke
- **品牌**: Ubiquiti/TP-Link/MikroTik/D-Link
- **开发策略**: 肯尼亚多品牌
- **置信度**: ★★★★☆

### 21. Jiji Uganda市场
- **类型**: C类区域市场
- **品牌**: D-Link 16口PoE USh 450K / 24口 USh 750K
- **开发策略**: 乌干达PoE零售
- **置信度**: ★★★☆☆

---

**Batch 31 总计: 21家新客户/情报**

> 关键发现：
> 1. **医疗5家** — Versa Healthcare 802.1X/Omnitron RuggedNet医院IoT/PKOWS智能床/Versitron/NETGEAR PoE中继医疗设备
> 2. **油气/太阳能4家** — FICOTEK深圳Top1 200MW沙漠500台/Planet巴西32电站/ONV绿色能源/Cisco IE 3000/4000
> 3. **非洲12家** — RapidBTS尼日利亚/Prestensys 8品牌/Jumia 137产品/Deus加纳/Jiji加纳Hikvision/Ubiquiti/Empire坦桑/Gadgetronix Dahua/Onet WI-TEK/TalindaExpress东非6国/TDK肯尼亚/CTC肯尼亚/Jiji乌干达
