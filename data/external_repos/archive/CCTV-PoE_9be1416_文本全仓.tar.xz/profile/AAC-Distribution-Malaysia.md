# 客户档案：AAC Distribution — 马来西亚

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司全称 | AAC Distribution Sdn. Bhd. |
| 国家 | 马来西亚 |
| 类型 | CCTV/安防/网络设备进口批发分销商 |
| 网站 | aacgroup.com.my |
| 客户级别 | **A级（核心）** |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 中央销售办公室 | +603 8062 3919 |
| WhatsApp | +6016-227 1728（即时回复） |
| 邮箱 | sales@aacgroup.com.my |
| 总部 (Johor Bahru) | +607 557 7725 / 25, Jalan Emas Putih, Taman Sri Putri, 81300 Skudai |
| KL办公室 | +603 6252 5855 / 90, Jalan Metro Perdana Barat 13, Kepong, 52100 KL |
| JB办公室 | +607 355 1725 / 55-01, Jalan Ros Merah 2/1, Taman Johor Jaya, 81100 |
| 营业时间 | Mon-Fri 9am-6pm |

### 4个办公室！全马来西亚覆盖

## 公司深度分析

### 品牌组合
| 品牌 | 品类 |
|------|------|
| **Hikvision** | CCTV全线（ColorVu, AcuSense, 热成像, ANPR） |
| **Hanwha Vision** (三星) | CCTV |
| **i-PRO** (松下) | CCTV |
| **EZVIZ** | 消费级安防 |
| **Ruijie / Reyee** | 网络设备（**PoE交换机、路由器、AP、云网络**） |
| **Belden** | 线缆 |
| UPS系统 | 电源备份 |

### 产品生态
- AI CCTV摄像头（ColorVu、AcuSense、热成像、车牌识别）
- NVR / DVR
- **企业网络（PoE交换机、路由器、AP、云网络）** ← 直接对口！
- 结构化布线与数据通信线缆
- GPON与光纤方案
- 门禁与安防方案

## 推荐Saga产品

### 主推（替代Ruijie/Reyee PoE交换机）
| Saga型号 | 规格 | FOB($) | 对标 |
|----------|------|--------|------|
| STC-028GFP | 10口百千兆PoE | $13-15 | Reyee RG-ES109G-P (~$50) |
| STC-1216GFP | 18口百千兆PoE | $29-32 | Reyee RG-NBS3100-24GT4SFP (~$200) |
| STC-228GP | 12口千兆PoE+SFP | $24-28 | Reyee RG-ES209GC-P (~$80) |
| STC-1224GFP | 26口百千兆PoE | $41-45 | 无直接对标 |

### 配套产品
| 型号 | 推荐理由 |
|------|---------|
| PoE延长器 | 配合远距离监控 |
| 光纤收发器 | 配合Belden线缆方案 |
| STC-08GE/10160D | 以太网交换机配套网络 |

### 核心卖点
1. **"比Ruijie/Reyee便宜60-70%"** — 直接对标，价格碾压
2. **"完美兼容Hikvision"** — 你已卖Hikvision摄像头，Saga PoE是最佳搭配
3. **"250米超长PoE"** — Ruijie只有100米标准
4. **"金属外壳+VLAN隔离+PoE看门狗"** — 专业级品质
5. **"OEM贴牌"** — 帮AAC发展自有品牌PoE交换机
6. **"4个办公室统一供货"** — 覆盖全马来西亚

## 跟进计划

| 阶段 | 行动 | 时间 |
|------|------|------|
| 1 | WhatsApp +6016-227 1728 首联 | 本周 |
| 2 | 邮件sales@aacgroup.com.my，附Saga vs Ruijie对标表 | 本周 |
| 3 | 电话+603 8062 3919找采购部 | 1周内 |
| 4 | 寄送样品（82GN + 162G各2台）到Puchong办公室 | 2周内 |
| 5 | 提出马来西亚独家/区域代理方案 | 1个月后 |

## 预期订单

| 阶段 | 预估金额 |
|------|---------|
| 首单 | $5,000-10,000 |
| 年供货 | $50,000-100,000+ |
