# 客户档案：Intertrade Security Distributors — 南非

## 联系信息
| 渠道 | 信息 |
|------|------|
| 网站 | intertradesecurity.co.za |
| 国家 | 南非 |
| 类型 | 安防设备批发商 |
| 成立 | 1988年（38年） |
| 主营 | 入侵检测、CCTV、门禁 |

## 推荐Saga产品
| 型号 | FOB($) | 推荐理由 |
|------|--------|---------|
| STC-028GFP | $13-15 | CCTV项目标配 |
| STC-1216GFP | $29-32 | 中型项目 |
| STC-228GP | $24-28 | 高端+SFP |
| STC-1224GFP | $41-45 | 大型项目 |
| PoE延长器 | $4-7 | 配套 |
| STC-08GE | $8 | 以太网配套 |

### 卖点：①38年安防批发经验，渠道成熟 ②比Dahua/Hikvision PoE便宜70-90% ③金属壳+250米+看门狗+VLAN ④CE/FCC认证 ⑤OEM贴牌

## 预期：首单$3K-10K，年$30K-80K
