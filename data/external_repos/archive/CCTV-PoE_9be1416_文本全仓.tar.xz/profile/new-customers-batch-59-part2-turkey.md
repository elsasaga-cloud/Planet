# Batch 59 Part 2: 土耳其深度挖掘 Part 2
## 8渠道: ISP+酒店+数据中心+国防+太阳能+政府采购+机场+技术社区
_2026-10-27 | 45 entries | Turkey Deep Mining Part 2_

---

### 渠道H: ISP/电信 (9家)
- **99.1 TurkNet** 🇹🇷 A类 | GigaFiber, 17 Teknopark + **129国立大学**, 对称1Gbps
- **99.2 Türk Telekom** 🇹🇷 B类 | 最大ISP, 60B TL, 2个Tier III DC
- **99.3 Turkcell Superonline** 🇹🇷 B类 | 自有光纤, **4个Tier III DC**(Ankara/Gebze/Izmir/Tekirdağ)
- **99.4 Vodafone Net** 🇹🇷 C类 | Esenyurt Tier III DC
- **99.5 Türksat Kablonet** 🇹🇷 C类 | 有线电视
- **99.6 Millenicom** 🇹🇷 D类
- **99.7 Netspeed** 🇹🇷 D类
- **99.8 Surnet** 🇹🇷 C类 | Diyarbakır WISP
- **99.9 TURKISS** 🇹🇷 D类

### 渠道I: 酒店连锁 (8家+行业情报)
- **99.10 Wyndham** 🇹🇷 A类 | **76设施**(最大连锁)
- **99.11 Hilton** 🇹🇷 A类 | **63设施, 12,674房间**(最大房间数)
- **99.12 Accor** 🇹🇷 B类 | 48设施
- **99.13 Marriott** 🇹🇷 B类 | 29设施, 5,616房间
- **99.14 IHG** 🇹🇷 B类 | 27设施
- **99.15 Rixos** 🇹🇷 B类 | 23设施, 30K+房间, **跨国**(Dubai/Egypt/Croatia/Kazakhstan)
- **99.16 Titanic** 🇹🇷 C类 | 13设施
- **99.17 行业情报** | **57连锁, 628设施, 145,450房间**, 80M+外国游客

### 渠道J: 数据中心 (10家+行业情报)
- **99.18 İş Bankası ATLAS** 🇹🇷 A类 | **Tier IV Gold**(土耳其最高)
- **99.19 Garanti BBVA Pendik** 🇹🇷 A类 | Tier IV
- **99.20 KKB Anadolu** 🇹🇷 A类 | Ankara Tier IV
- **99.21 IBB Kent Yönetim** 🇹🇷 A类 | 市政府Tier IV
- **99.22 Akbank** 🇹🇷 B类 | Kocaeli Tier III Silver
- **99.23 Halkbank** 🇹🇷 B类 | Tier III Gold
- **99.24 Ziraat Bankası** 🇹🇷 B类 | Tier III Gold
- **99.25 IGA机场DC** 🇹🇷 B类 | Tier III
- **99.26 Star of Bosphorus** 🇹🇷 B类 | Tier III
- **99.27 行业情报** | 250MW(2025) → **1GW(2030目标, 4倍增长)**

### 渠道K: 国防工业 (5家)
- **99.28 ASELSAN** 🇹🇷 A类 | 10,000人, 84国出口, Defense News #48, R&D $1.36B
- **99.29 HAVELSAN** 🇹🇷 B类 | 2,600人, 120B TL, 24+国
- **99.30 ROKETSAN** 🇹🇷 B类 | 3,800人, 火箭+导弹
- **99.31 TUSAŞ/TAI** 🇹🇷 B类 | 13,500人, 战斗机+无人机
- **99.32 Meteksan Savunma** 🇹🇷 B类 | Bilkent Group, 传感器+雷达

### 渠道L: 太阳能GES/SCADA (5家)
- **99.33 Kalyon Karapınar** 🇹🇷 A类 | **1.35 GW**, $523M, 欧洲最大太阳能之一
- **99.34 Sungen Solar** 🇹🇷 B类 | 780 MW, 100+项目
- **99.35 Güneş Pili** 🇹🇷 B类 | Konya, GES+SCADA, 50+项目
- **99.36 BAUTEK** 🇹🇷 B类 | GES SCADA系统
- **99.37 GÜNDER协会** 🇹🇷 渠道 | 20+企业会员(CW 1.8GW/HSA 1GW/Kıvanç 1.2GW)

### 渠道M: EKAP政府采购 (2渠道)
- **99.38 EKAP** 🇹🇷 渠道 | **₺1.6万亿(2023), 82K招标+110万直接采购**
- **99.39 TTK Genel Müdürlüğü** 🇹🇷 B类 | 活跃"管理交换机采购"招标

### 渠道N: 机场/交通 (2家)
- **99.40 İGA Istanbul机场** 🇹🇷 A类 | 90M旅客, Tier III DC
- **99.41 TGS** 🇹🇷 B类 | 全土耳其机场地面服务

### 渠道O: 技术社区 (4家)
- **99.42 UniFi Türkiye** 🇹🇷 B类 | 756+产品, PoE全线
- **99.43 Keenetic Türkiye** 🇹🇷 B类 | **2026.5新进入**交换机市场
- **99.44 Ertel Bilişim** 🇹🇷 C类 | PoE选购指南
- **99.45 ÇözümPark** 🇹🇷 渠道 | IT专业社区

---

## 关键发现

### 土耳其PoE交换机6大隐藏市场
1. **129所国立大学** (TurkNet GigaFiber覆盖) — 校园PoE需求
2. **628家酒店设施** (57连锁, 145K房间) — IP摄像头+AP+IP电话
3. **数据中心4倍增长** (250MW→1GW by 2030) — PoE基础设施
4. **1.35 GW太阳能项目** (Kalyon Karapınar) — SCADA工业PoE
5. **₺1.6万亿政府采购** (EKAP) — 交换机公开招标
6. **90M旅客机场** (IGA Istanbul) — 机场PoE网络

### 竞争情报
- **Keenetic** 2026年5月新进入土耳其交换机市场 (5/8/16/24口+PoE++2.5G)
- **UniFi Türkiye** 已有756+产品在线
- 土耳其本土6+品牌(BESTA/ARNA/KR/Dayline/Hadron/QPORT)全部中国OEM
