# Batch 10 — 越南分销 + 中亚进口商 + ISC West展会 + OEM竞品
> 深度挖掘 Round 15-18 (2026-10-25)
> 方法论：越南语搜索 / Volza海关数据 / ISC West展商 / Made-in-China竞品

---

## 一、C类：越南PoE交换机分销商（15家）

### 1. Vũ Hoàng Telecom（胡志明市）
- **类型**: C类 — 越南安防分销16年
- **网站**: vuhoangtelecom.vn
- **税号**: 0306524177
- **邮箱**: info@vuhoangtelecom.vn
- **电话**: 02835166166
- **品牌**: Hikvision, Dahua, Ruijie/Reyee, Scodeno, TP-Link
- **地址**: 3A Trần Quý Cáp, P.12, Q.Bình Thạnh, HCM
- **开发策略**: 越南最大安防分销之一，51-200员工
- **置信度**: ★★★★★

### 2. Viễn Thông Xanh（河内）
- **类型**: C类 — 网络设备分销
- **网站**: vienthongxanh.vn
- **税号**: 0107619297
- **电话**: 0989395445
- **品牌**: Cisco, Dahua, TP-Link, Planet, IP-COM, HDTec, BTON, UPCOM
- **地址**: Số 2 Ngõ 53 Phạm Tuấn Tài, Cầu Giấy, Hà Nội
- **开发策略**: 河内网络分销，多品牌组合
- **置信度**: ★★★★★

### 3. Thiết Bị Mạng Việt Nam (VNS)（越南）
- **类型**: C类 — Nettek PoE交换机分销
- **网站**: thietbimangvietnam.vn
- **电话**: 0979.300.098 / 0981.189.881
- **邮箱**: info@thietbimangvietnam.vn
- **品牌**: Nettek (NT-P242G2S等)
- **开发策略**: 越南网络设备专业分销
- **置信度**: ★★★★★

### 4. SLA Company Limited（胡志明市）
- **类型**: C类 — ShareTech PoE交换机分销
- **网站**: sla.vn
- **地址**: 127 Hoang Van Thu, Phu Nhuan, HCM
- **电话**: 0789 708 807
- **邮箱**: sales@sla.vn
- **产品**: CCTV PoE交换机（4/8/16/24/48口）
- **开发策略**: 越南IT分销+服务
- **置信度**: ★★★★★

### 5. An Phát（胡志明市）
- **类型**: C类 — 网络设备分销20年+
- **网站**: anphat.vn
- **成立**: 2004年
- **地址**: 286/1 Trần Hưng Đạo, P.Nguyễn Cư Trinh, Q.1, HCM
- **开发策略**: 越南老牌网络分销
- **置信度**: ★★★★★

### 6. 3onedata Vietnam（河内/胡志明市）
- **类型**: C类 — 3onedata工业PoE交换机
- **网站**: 3onedatavietnam.com.vn
- **河内**: NO7C-LK19 Hồ Học Lãm, Hà Đông
- **胡志明**: 736/182 Lê Đức Thọ, Gò Vấp
- **电话**: 0948.40.70.80
- **开发策略**: 中国3onedata越南独家分销
- **置信度**: ★★★★★

### 7. Siêu Thị Mạng（河内/胡志明市）
- **类型**: C类 — Cablexa PoE交换机
- **网站**: sieuthimang.vn
- **河内**: Số 1 Ngõ 86 Lê Trọng Tấn, Thanh Xuân
- **胡志明**: 259/11 Cách Mạng Tháng 8, Tân Bình
- **电话**: 0344 699 886 / 0335 866 266
- **邮箱**: baogia@sieuthimang.vn
- **开发策略**: 越南Cisco/Juniper/Cablexa分销
- **置信度**: ★★★★★

### 8. MC&TT（河内）
- **类型**: C类 — 工业PoE交换机分销
- **网站**: tudonghoa24.com
- **地址**: LK12-8, Ngô Thì Nhậm, Hà Đông, Hà Nội
- **电话**: 0904251826
- **邮箱**: sales@mctt.vn
- **品牌**: 3Onedata, Four-Faith, ICP DAS, JHA Tech
- **开发策略**: 工业传输/自动化专业分销
- **置信度**: ★★★★★

### 9. Vietnam Network / Đức Mỹ（岘港）
- **类型**: C类 — 网络设备分销
- **网站**: vietnamnetwork.vn
- **地址**: 31 Nguyễn Đức Trung, Thanh Khê, Đà Nẵng
- **电话**: 086.2020.068 / 089.8171.134
- **邮箱**: vietnamnetwork.vn@gmail.com
- **品牌**: Aruba, Ruijie, Maipu, Cambium, Cisco, TP-Link
- **开发策略**: 中部分销，多品牌
- **置信度**: ★★★★★

### 10. PANACO（胡志明市）
- **类型**: C类 — ONV PoE交换机
- **网站**: panaco.vn
- **地址**: 32/39 Bùi Đình Túy, Bình Thạnh, HCM
- **电话**: 0989 352 251
- **邮箱**: info@panaco.vn
- **开发策略**: ONV品牌越南渠道
- **置信度**: ★★★★☆

### 11. Thiên Tân Telecom（越南）
- **类型**: C类 — GNETCOM/HOLINK PoE交换机
- **网站**: vienthongthientan.com
- **电话**: (0243) 2363.999 / 0838 242 122 / 0888 303 636
- **开发策略**: 光纤设备分销
- **置信度**: ★★★★☆

### 12. VFV Telecom（河内/胡志明市）
- **类型**: C类 — ZINCOM PoE交换机
- **网站**: thietbiquangvn.com
- **河内**: 53 An Dương Vương, Phú Thượng, Tây Hồ
- **胡志明**: 25/1 Đường 30, KP.7, P.Linh Đông, Thủ Đức
- **电话**: 0988588880 / 0944954466
- **邮箱**: vfvtelecom@gmail.com
- **开发策略**: 越南光纤/网络设备分销
- **置信度**: ★★★★☆

### 13. Việt Tuấn（河内/胡志明市）
- **类型**: C类 — 多品牌网络分销
- **网站**: viettuans.vn
- **河内**: Tầng 6, 23 Tô Vĩnh Diện, Khương Đình
- **电话**: 0903.209.123 (Mr. Minh)
- **品牌**: Unifi, MikroTik, Draytek, Synology, Ruckus, Fortinet, QNAP
- **开发策略**: 2012年成立，专业网络分销
- **置信度**: ★★★★★

### 14. DNG Corp（越南）
- **类型**: C类 — Soltech网络交换机
- **网站**: dngcorp.vn
- **电话**: 0983 959 796 / 0988 712 159
- **开发策略**: 越南网络设备分销
- **置信度**: ★★★★☆

### 15. Hikvision Vietnam（河内/胡志明市）
- **类型**: C类 — Hikvision PoE交换机
- **网站**: hikvision.vn
- **河内**: 88-90 Yên Lãng, Đống Đa
- **胡志明**: 299/3 Lý Thường Kiệt, Phú Thọ
- **电话**: 024.3762.3200 / 028.38.685.689
- **邮箱**: info.nhaantoan@gmail.com
- **开发策略**: 海康PoE交换机越南渠道
- **置信度**: ★★★★★

---

## 二、B/C类：中亚进口商 — 哈萨克斯坦 + 乌兹别克斯坦（10家）

### 16. Distribution Center Ying Ko（哈萨克斯坦）
- **类型**: B类 — PoE交换机进口商
- **产品**: PoE switches
- **开发策略**: 哈萨克PoE交换机活跃进口商
- **置信度**: ★★★★☆

### 17. Marvel Kazakhstan LLP（哈萨克斯坦）
- **类型**: B类 — Cisco PoE交换机进口
- **产品**: Cisco Catalyst 2960L/3650 PoE交换机
- **开发策略**: 哈萨克IT分销，可推Saga性价比替代
- **置信度**: ★★★★★

### 18. Komptek（哈萨克斯坦）
- **类型**: B类 — Cisco PoE交换机进口
- **产品**: Cisco SF350-48P 48口PoE管理型交换机
- **开发策略**: 哈萨克Cisco渠道
- **置信度**: ★★★★☆

### 19. OOO Zenit Exim（乌兹别克斯坦）
- **类型**: B类 — TP-Link PoE交换机进口
- **产品**: TP-Link TL-SG3452P 52口千兆L2管理型PoE+
- **开发策略**: 乌兹别克活跃进口商
- **置信度**: ★★★★★

### 20. OOO Fort Pro Trade（乌兹别克斯坦）
- **类型**: B类 — PoE交换机进口
- **开发策略**: Volza确认的乌兹别克活跃进口商
- **置信度**: ★★★★☆

### 21. OOO Smart IT Support（乌兹别克斯坦）
- **类型**: B类 — PoE交换机进口
- **开发策略**: 乌兹别克IT服务+进口
- **置信度**: ★★★★☆

### 22. Kamol System Service LLC（乌兹别克斯坦）
- **类型**: B类 — 工业PoE交换机进口
- **产品**: Genata GNT-IG1210FP-AC 8口千兆工业PoE+2SFP
- **开发策略**: 乌兹别克系统集成商
- **置信度**: ★★★★☆

### 23. Noud Trading LLC（乌兹别克斯坦）
- **类型**: B类 — 工业PoE交换机进口
- **产品**: FR-7N3208P 非管理型工业PoE
- **开发策略**: 乌兹别克贸易商
- **置信度**: ★★★★☆

### 24. Kcell JSC（哈萨克斯坦）
- **类型**: B类 — 电信设备进口
- **行业**: 电信运营商
- **出货量**: 310+/月
- **开发策略**: 哈萨克最大电信公司之一
- **置信度**: ★★★★★

### 25. TechnoDom Operator LLP（哈萨克斯坦）
- **类型**: B类 — 电子产品进口
- **出货量**: 280+/月
- **开发策略**: 哈萨克大型电子零售/分销
- **置信度**: ★★★★★

---

## 三、B类：ISC West 2026展会 — PoE相关展商（5家）

### 26. Intellinet Network Solutions（美国佛罗里达）
- **类型**: B类 — PoE交换机+配件品牌
- **网站**: intellinetsolutions.com
- **地址**: Oldsmar, FL
- **展位**: ISC West #2037
- **产品**: 18口PoE++交换机(16千兆+2SFP), 10G PoE++注入器
- **开发策略**: 美国PoE品牌，可能需要中国OEM
- **置信度**: ★★★★★

### 27. Altronix（美国纽约）
- **类型**: B类 — 硬化PoE解决方案
- **网站**: solutions.altronix.com
- **展位**: ISC West #11073
- **产品**: NetWay系列（90W/端口+光纤上行）, 277VAC输入
- **开发策略**: 美国安防电源/PoE品牌
- **置信度**: ★★★★★

### 28. VIVOTEK（台湾）
- **类型**: 竞品 — 网络交换机+Milestone/Genetec插件
- **网站**: vivotek.com
- **展位**: ISC West #22043
- **产品**: 商用/工业/户外网络交换机, PoE扩展器/注入器
- **开发策略**: 台湾品牌，其渠道可争取
- **置信度**: ★★★★★

### 29. ETS（美国）
- **类型**: B类 — IP Kill Switches
- **网站**: etsnm.com
- **展位**: ISC West #8137
- **产品**: EDKS-8-1G-VE-RM (1G 2-8通道IP Kill Switch)
- **开发策略**: 安防PoE设备控制
- **置信度**: ★★★★☆

### 30. Hyconext（全球）
- **类型**: B类 — 2.5G PoE交换机品牌
- **网站**: hyconext.com
- **产品**: NextWav 2.5G PoE交换机系列
- **开发策略**: 正在招募全球分销
- **置信度**: ★★★★☆

---

## 四、竞品情报：中国制造（5家）

### 31. SDAPO（深圳）
- **类型**: 竞品 — PoE专业制造商
- **网站**: sdapo.net
- **成立**: 2012年
- **产品**: PoE模块/注入器/分配器/交换机/线缆/扩展器
- **开发策略**: 深圳PoE专业竞品
- **置信度**: ★★★★☆

### 32. Ewind（深圳）
- **类型**: 竞品 — 工业PoE交换机
- **网站**: ewindnet.com
- **投资**: 5067万美元, 5000+平方米
- **产品线**: 工业PoE交换机/PoE交换机/注入器/分配器/媒体转换器
- **开发策略**: 深圳大型竞品
- **置信度**: ★★★★☆

### 33. HoweVision（深圳）
- **类型**: 竞品 — AI PoE交换机
- **网站**: howevision.com
- **成立**: 2010年
- **产品**: AI PoE交换机（5/8/16/24口）
- **开发策略**: 深圳AI PoE竞品
- **置信度**: ★★★★☆

### 34. TAKFLY Communications（中国）
- **类型**: 竞品 — FTTH+PoE交换机
- **员工**: 350人
- **出口**: 亚洲/澳洲/中南美/东欧/中东非洲/北美/西欧
- **开发策略**: 大型OEM/ODM竞品
- **置信度**: ★★★★☆

### 35. Dongguan Phynam Comtech（东莞）
- **类型**: 竞品 — PoE交换机
- **产品**: TP2624F (24口PoE+2千兆上行)
- **开发策略**: 东莞竞品
- **置信度**: ★★★☆☆

---

**Batch 10 总计: 35家新客户**

> 关键发现：
> 1. **越南15家PoE分销商** — Vũ Hoàng(16年)/Viễn Thông Xanh/VNS/SLA/An Phát/3onedata VN/Siêu Thị Mạng/MC&TT/Vietnam Network/PANACO/Thiên Tân/VFV/Việt Tuấn/DNG/Hikvision VN
> 2. **中亚10家进口商** — 哈萨克(Distribution Ying Ko/Marvel/Komptek/Kcell/TechnoDom) + 乌兹别克(Zenit Exim/Fort Pro/Smart IT/Kamol/Noud)
> 3. **ISC West展会5家** — Intellinet/Altronix/VIVOTEK/ETS/Hyconext
> 4. **竞品5家** — SDAPO/Ewind/HoweVision/TAKFLY/Phynam
