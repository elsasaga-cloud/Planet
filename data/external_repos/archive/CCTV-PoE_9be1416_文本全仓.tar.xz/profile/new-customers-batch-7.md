# Batch 7 — 按新方法论挖掘：A类OEM品牌商 + B类竞品渠道反挖
> 深度挖掘 Round 6 (2026-10-25)
> 方法论：Saga公司背景信息 + Agent搜索客户方法论

---

## ⚠️ 方法论调整说明

之前6批（225家）主要聚焦D类客户（CCTV分销商/集成商）。
根据`Saga公司背景信息.docx`和`Agent搜索客户方法论.docx`，客户优先级应为：
- **A类（最高）**: OEM/ODM品牌商 — 有自有品牌，需要定制/贴牌
- **B类（高）**: 已有中国供应商经验的客户 — 正在进口Utepo/ONV/HRUI/Scodeno等
- **C类（中）**: 台湾品牌渠道 — 正在卖Planet/Oring/Edgecore，可能愿意加个性价比更高的品牌
- **D类（可跟）**: CCTV/分销/集成商

本批次聚焦A/B/C类。

---

## 一、B类：竞品渠道反挖（UTEPO/Scodeno/HRUI客户）★最高价值★

### 1. Viskou System Pte Ltd（新加坡）
- **类型**: B类 — UTEPO分销商
- **网站**: viskou.sg（UTEPO全系列PoE交换机在售）
- **电话**: +65 87119844
- **邮箱**: sales@viskou.com
- **证据**: 官网有完整的UTEPO产品线（UTP3-GSW0802-TSP120, UTP7308GE-POE, UTP3218TS-PSB等）
- **开发策略**: 正在卖UTEPO，说明已熟悉中国PoE品牌。Saga可用更好的Marvell方案+深度定制能力来争取
- **置信度**: ★★★★★ 已确认UTEPO在售

### 2. PT Konexindo Unitama（印尼雅加达）
- **类型**: B类 — Scodeno印尼独家分销
- **网站**: scodenoindonesia.com, konexindo.co.id
- **地址**: Jln. Tanjung Selor No. 1B, Cideng, Jakarta Pusat 10150
- **证据**: Scodeno Indonesia官网明确标注 "Distributed by PT Konexindo Unitama"
- **开发策略**: 正在卖Scodeno工业交换机，Saga的工业PoE可作为替代/补充
- **置信度**: ★★★★★ 已确认Scodeno独家

### 3. Shop4Power（荷兰）
- **类型**: B+C类 — Scodeno Benelux独家 + Planet交换机
- **网站**: shop4power.nl
- **地址**: 荷兰
- **证据**: 官网明确标注"EXCLUSIEVE Scodeno importeur van de Benelux"，同时销售Planet工业交换机
- **开发策略**: 同时卖Scodeno和Planet，说明需要性价比更高的替代方案。Saga可用Marvell方案+价格优势切入
- **置信度**: ★★★★★ 已确认Scodeno+Planet在售

### 4. Antek Vietnam（越南）
- **类型**: B类 — Scodeno越南分销
- **网站**: antek.vn, scodeno.vn
- **证据**: scodeno.vn标注"Nhà phân phối: Công ty TNHH Công nghệ Antek Việt Nam"
- **开发策略**: 正在卖Scodeno全系列工业交换机，可争取第二供应商
- **置信度**: ★★★★★ 已确认

### 5. CNTTshop.vn（越南）
- **类型**: B类 — Scodeno分销 + 多品牌
- **网站**: cnttshop.vn
- **产品线**: Cisco/Cambium/Aruba/Fortinet/HPE/Dell/Allied Telesis/Maipu/MikroTik/H3C + Scodeno
- **开发策略**: 多品牌分销商，已有Scodeno，Saga可作为补充
- **置信度**: ★★★★☆

### 6. chuyenpoe.com（越南）
- **类型**: B类 — UTEPO PoE专业
- **网站**: chuyenpoe.com
- **电话**: 0916.799.345
- **证据**: 专业UTEPO PoE交换机销售
- **开发策略**: PoE交换机专业渠道，正好匹配Saga核心产品
- **置信度**: ★★★★★

### 7. Infrateq.com（印尼）
- **类型**: B类 — HRUI + MAISVCH在售
- **网站**: infrateq.com
- **证据**: 官网产品列表中有HRUI和MAISVCH工业PoE交换机
- **开发策略**: **已经在卖HRUI！** 这意味着他们认识Saga的供应商。可直接联系争取更好的价格/定制方案
- **置信度**: ★★★★★ 已确认HRUI在售

---

## 二、C类：台湾品牌渠道反挖（Edgecore分销商）

### 8. SAPPLY Pty Ltd（澳大利亚）
- **类型**: C类 — Edgecore SI/VAR
- **地址**: 25 Dickson Avenue, Artarmon, NSW 2064
- **电话**: +61 2 9439 8887
- **开发策略**: 正在卖Edgecore（台湾），Saga可用更高性价比替代
- **置信度**: ★★★★★ Edgecore官网确认

### 9. D2UNet Pty Ltd（澳大利亚）
- **类型**: C类 — Edgecore分销商
- **地址**: 8 Darter Street, The Ponds, NSW 2769
- **电话**: (02) 9629 8780
- **置信度**: ★★★★★ Edgecore官网确认

### 10. Endy Australia
- **类型**: C类 — Edgecore分销商
- **地址**: 1/14 Wellington Street, Acacia Ridge Brisbane QLD 4110
- **电话**: 1300 725 323
- **置信度**: ★★★★★

### 11. Newgen Systems（澳大利亚）
- **类型**: C类 — Edgecore分销商
- **地址**: Suite 401, 737 Burwood Road, Hawthorn East 3123
- **电话**: +61 (0) 3 9894 5130
- **置信度**: ★★★★★

### 12. Snapper Network Distributors（新西兰）
- **类型**: C类 — Edgecore分销商
- **地址**: 13 Beatrice Tinsley Crescent, Albany, Auckland
- **电话**: +64 9 415 4182
- **置信度**: ★★★★★

### 13. ASBIS Middle East FZE（阿联酋迪拜）
- **类型**: C类 — Edgecore分销商，覆盖30+国家
- **地址**: P.O. Box 17706, Jebel Ali South, S10806, Dubai
- **电话**: +971 4 8863850
- **覆盖**: 东欧/中东/非洲/CIS 30+国家
- **开发策略**: **超大型分销商**，覆盖AL/AM/AZ/BA/BG/CI/HR/CY/CZ/EE/GE/GH/GR/HU/KZ/KE/LV/LT/MT/MD/MA/NG/PL/RO/RS/SK/SI/ZA/TJ/TZ/TN/TM/UA/AE/UZ
- **置信度**: ★★★★★ Edgecore官方+ASBIS官网确认

### 14. MBUZZ（沙特阿拉伯）
- **类型**: C类 — Edgecore分销商
- **地址**: Building CS-01, Al-Raidah, Digital City, Riyadh
- **电话**: +966 53 037 8192
- **置信度**: ★★★★★

### 15. Evollabs Tech FZ-LLC（阿联酋迪拜）
- **类型**: C类 — Edgecore分销商
- **地址**: Dubai Internet City, DIC-Bldg.05-118
- **电话**: +971 4 529 9011
- **置信度**: ★★★★★

### 16. ADN GmbH（德国）
- **类型**: C类 — Edgecore分销商
- **地址**: Josef-Haumann-Str. 10, 44866 Bochum
- **电话**: +49 2327 9912-0
- **开发策略**: 德国网络分销，可推Saga Marvell方案
- **置信度**: ★★★★★

### 17. STORDIS GmbH（德国）
- **类型**: C类 — Edgecore分销商
- **地址**: Rübteile 24, 72574 Bad Urach + Rosenwiesstr. 17, 70567 Stuttgart
- **电话**: +49 (0)711 342 158 0
- **置信度**: ★★★★★

### 18. Fionis GmbH（奥地利）
- **类型**: C类 — Edgecore SI/VAR
- **地址**: Anton-Hubmann-Platz 2, 8071 Goessendorf
- **电话**: +43 3135 40 960-0
- **置信度**: ★★★★★

### 19. Alyseo（法国）
- **类型**: C类 — Edgecore SI/VAR
- **地址**: 44 rue Armand Carrel, 93100 Montreuil
- **电话**: +33 (0)1 83 35 10 10
- **置信度**: ★★★★★

### 20. CELERIS Informatique（法国）
- **类型**: C类 — Edgecore SI/VAR
- **地址**: 6 rue de l'Abbé Hazard, 92000 Nanterre
- **电话**: 01 71 12 60 23
- **置信度**: ★★★★★

### 21. Pine Networks（法国）
- **类型**: C类 — Edgecore SI/VAR
- **地址**: 219, Grande Rue, 92380 Garches
- **电话**: +33 1 88 94 77 04
- **置信度**: ★★★★★

### 22. ScaleIL（以色列）
- **类型**: C类 — Edgecore分销商
- **地址**: 1 Zarchin St., Raanana 4366229
- **电话**: 052-665-2070
- **置信度**: ★★★★★

### 23. ООО NAGTECH（乌兹别克斯坦）
- **类型**: C类 — Edgecore CIS分销
- **地址**: 52, 7th Sairam Street, Mirzo-Ulugbek District, Tashkent
- **电话**: +998 55 508 0660
- **置信度**: ★★★★★

### 24. Richman Informatics（孟加拉）
- **类型**: C类 — Edgecore分销商
- **地址**: Navana DH Tower, Suite #502, 6 Panthopath, Dhaka-1215
- **电话**: +880 (2) 9143683
- **置信度**: ★★★★★

### 25. SanSo Networks（印度德里）
- **类型**: C类 — Planet交换机经销商
- **网站**: industrialswitches.co.in
- **证据**: 官网明确"Planet Switch dealer, suppliers & distributor in Delhi"
- **开发策略**: 正在卖Planet（台湾），Saga可以更高性价比替代
- **置信度**: ★★★★★

---

## 三、A类：OEM/ODM品牌商 + 技术型品牌

### 26. BENCHU GROUP
- **类型**: A类 — PoE交换机OEM/ODM厂商
- **网站**: benchu-group.com
- **产品**: PoE交换机、工业网络产品、光纤方案
- **开发策略**: 同行OEM厂商，了解其客户群可反挖
- **置信度**: ★★★★☆

### 27. Rubytech（台湾）
- **类型**: A类竞品 — 台湾ODM，40年经验，230+ SKU
- **网站**: rubytech.com.tw
- **产品**: ODM PoE/以太网/工业交换机，NDAA/TAA
- **开发策略**: 台湾竞品，了解其客户可作为反挖目标
- **置信度**: ★★★★★

### 28. EtherWAN（台湾）
- **类型**: A类竞品 — 台湾OEM工业交换机
- **网站**: etherwan.com
- **产品**: OEM工业以太网/PoE/千兆交换机，台湾制造
- **开发策略**: 台湾竞品，其客户可能有兴趣Saga的性价比
- **置信度**: ★★★★★

### 29. VVDN Technologies（印度）
- **类型**: A类 — 网络交换机设计制造服务
- **网站**: vvdntech.com
- **芯片**: NXP/Microchip/Marvell/Broadcom/Mediatek/Realtek
- **产品**: 白牌L2/L3交换机参考设计，自有SDK
- **开发策略**: 印度设计服务商，其NEM客户可能是Saga目标
- **置信度**: ★★★★★

### 30. LINKOH（中国深圳）
- **类型**: A类竞品 — 12年以太网交换机OEM/ODM
- **网站**: linkohnet.com
- **芯片**: Vitesse/Marvell/Microsemi/TI/MPS
- **证据**: 有德国客户评价，Tier-1/Tier-2品牌客户
- **开发策略**: 深圳竞品，其海外品牌客户可反挖
- **置信度**: ★★★★★

### 31. Lanbras / Lanaotek（中国）
- **类型**: A类竞品 — Marvell/Broadcom/CENTEC交换机OEM
- **网站**: lanaotek.com
- **产品**: 数据中心/企业/工业交换机，OEM/ODM
- **开发策略**: 使用相同芯片方案的竞品，其客户可反挖
- **置信度**: ★★★★☆

---

## 四、B类延伸：MikroTik渠道（Marvell Prestera用户）

### 32. MikroTik经销商网络
- **类型**: B类 — MikroTik使用Marvell Prestera芯片
- **证据**: MikroTik官方文档确认CRS3xx系列使用Marvell Prestera
- **开发策略**: MikroTik经销商可能愿意增加一个性价比更高的Marvell方案品牌
- **潜在目标**: 已有CNTTshop(越南)等同时在卖MikroTik

---

**Batch 7 总计: 32家新客户（A类3家, B类7家, C类18家, 竞品情报4家）**

> 关键发现：
> 1. **Infrateq印尼已经在卖HRUI** — 这意味着他们认识Saga的供应商，可直接联系
> 2. **Shop4Power荷兰同时卖Scodeno和Planet** — 完美匹配"性价比替代"策略
> 3. **ASBIS覆盖30+国家** — 如果拿下ASBIS，等于一次性打开东欧/中东/非洲/CIS市场
> 4. **越南chuyenpoe.com是PoE专业渠道** — 正好匹配Saga核心产品
> 5. **Marvell Prestera被MikroTik使用** — MikroTik经销商是潜在B类客户
