# Batch 5 新发现海外客户档案
> 深度挖掘 Round 1-4 (2026-10-25)
> 新增约70家客户，覆盖15+新国家/地区

---

## 一、哥斯达黎加 (Costa Rica)

### 1. SEKUNET S.A.
- **国家**: 哥斯达黎加
- **网站**: sekunet.com
- **电话**: +506 2290 5585
- **邮箱**: info@sekunet.com
- **地址**: San José, Costa Rica
- **业务**: Hikvision哥斯达黎加官方授权分销商
- **产品线**: CCTV/门禁/报警/网络
- **采购潜力**: $10K-30K/批
- **开发策略**: Hikvision官方渠道，PoE交换机为核心产品

### 2. IntradeABC
- **国家**: 哥斯达黎加
- **网站**: intradeabc.com
- **地址**: La Uruca, San José
- **业务**: 38年+大型批发分销商
- **产品线**: Dahua/CCTV/报警/门禁/消防/网络
- **采购潜力**: $10K-30K/批
- **开发策略**: 老牌批发商，Dahua为主

### 3. ICB Technologies
- **国家**: 哥斯达黎加
- **网站**: icbtechscr.com
- **地址**: 5个分支（San José/Alajuela/Cartago/Heredia）
- **业务**: Dahua/Hikvision/Uniview/Imou/TP-Link授权
- **产品线**: CCTV/网络/安防全品类
- **采购潜力**: $10K-20K/批
- **开发策略**: 多品牌授权，网络覆盖广

### 4. JWKvision
- **国家**: 哥斯达黎加
- **网站**: jwkvision.com
- **电话**: 2100-6905, 4033-4033
- **地址**: San Pedro + Zapote, San José
- **业务**: 中国进口CCTV/电脑
- **产品线**: Hikvision进口商
- **采购潜力**: $5K-15K/批
- **开发策略**: 直接从中国进口

### 5. Tectel CR
- **国家**: 哥斯达黎加
- **网站**: tectelcr.com
- **电话**: 226-DAHUA
- **业务**: 大型批发分销商
- **产品线**: Dahua/Teklink/DSC/Imou
- **采购潜力**: $10K-20K/批
- **开发策略**: Dahua批发为主

### 6. SmartSec Latam
- **国家**: 哥斯达黎加/波多黎各
- **电话**: +86 155 5353 9262
- **业务**: CCTV & AIOT，Dahua专注
- **采购潜力**: $5K-15K/批
- **开发策略**: 拉美区域覆盖

---

## 二、厄瓜多尔 (Ecuador)

### 7. IDC Mayoristas
- **国家**: 厄瓜多尔
- **网站**: idcmayoristas.com
- **地址**: Quito + Guayaquil
- **业务**: Hikvision/Dahua批发
- **产品线**: PoE交换机（Hik DS-3E0105D $6.33）
- **采购潜力**: $10K-30K/批
- **开发策略**: 双城市覆盖，价格敏感

### 8. MACROQUIL S.A.
- **国家**: 厄瓜多尔
- **网站**: macroquil.com
- **邮箱**: ventasgye@macroquil.com
- **电话**: 042380484
- **地址**: 6城市（Guayaquil/Quito/Cuenca/Manta/Machala/Ambato）
- **业务**: Hikvision官方全国分销20年+
- **产品线**: CCTV/网络/安防全品类
- **采购潜力**: $20K-50K/批
- **开发策略**: 厄瓜多尔最大Hikvision分销商

### 9. Intcomex del Ecuador
- **国家**: 厄瓜多尔
- **网站**: intcomex.com
- **邮箱**: info.ec@intcomex.com
- **电话**: (593) 2.397.3000
- **地址**: 4办公室（Quito/Guayaquil/Manta/Cuenca）
- **业务**: 2008年成立，IT分销
- **采购潜力**: $10K-30K/批
- **开发策略**: 拉美IT分销巨头

### 10. ELECNA
- **国家**: 厄瓜多尔
- **网站**: elecna.net
- **地址**: Guayaquil
- **业务**: 30年+，Hikvision + Motorola(Avigilon)
- **产品线**: Hik PoE交换机（DS-3E0526P/DS-3E0518P/DS-3E0510P）
- **采购潜力**: $10K-20K/批
- **开发策略**: 老牌分销，已有Hik PoE

### 11. ICO Internacional
- **国家**: 厄瓜多尔
- **网站**: ico-ecuador.com
- **电话**: (593-2) 3520-335
- **地址**: Quito + Guayaquil
- **业务**: Dahua直接进口
- **产品线**: Dahua PoE交换机
- **采购潜力**: $10K-20K/批
- **开发策略**: Dahua直接进口

### 12. Full Tecnologia / FullTec
- **国家**: 厄瓜多尔
- **地址**: Guayaquil/Quito
- **业务**: $1M+ Hikvision政府采购，人脸识别Quito $602K
- **采购潜力**: $20K-50K/批
- **开发策略**: 政府项目大单

### 13. Orizontel
- **国家**: 厄瓜多尔
- **网站**: orizontel.ec
- **业务**: Hikvision/Dahua/DSC/Risco/ZKTeco
- **采购潜力**: $5K-15K/批
- **开发策略**: 多品牌分销

---

## 三、东欧 (Eastern Europe)

### 14. AETEK (CCTV Baltic)
- **国家**: 波兰/波罗的海
- **网站**: cctvbaltic.pl
- **业务**: PoE交换机L2/L2+管理型，Milestone XProtect + Avigilon Unity集成，IP67工业级，天花板安装专利，NDAA/TAA
- **产品线**: 监控专用PoE，台湾品牌
- **采购潜力**: $20K-50K/批
- **开发策略**: **直接竞争对手**，AETEK是台湾PoE品牌，专注监控，Saga可对位竞争

### 15. JANEX Poland
- **国家**: 波兰
- **业务**: 1992年成立，报警+CCTV进口
- **采购潜力**: $10K-20K/批
- **开发策略**: 老牌波兰进口商

### 16. Connection Technology Systems (CTS)
- **国家**: 波兰
- **地址**: Katowice
- **业务**: PoE交换机+光纤网关+媒体转换器，FTTX P2P
- **产品线**: 网络设备专业分销
- **采购潜力**: $10K-20K/批
- **开发策略**: 网络设备专业，Saga光纤转换器匹配

### 17. Atu TECH Romania
- **国家**: 罗马尼亚
- **地址**: Sibiu
- **业务**: Hikvision区域分销
- **采购潜力**: $5K-15K/批
- **开发策略**: Hikvision渠道

### 18. Avaris s.r.o.
- **国家**: 捷克
- **地址**: Prague
- **业务**: 1995年成立，门禁系统
- **采购潜力**: $5K-10K/批
- **开发策略**: 门禁配套PoE

### 19. General Security SRL
- **国家**: 罗马尼亚
- **业务**: 全国分销，5办公室（Cluj/Brasov/Timisoara/Iasi/Bucharest）
- **采购潜力**: $10K-20K/批
- **开发策略**: 罗马尼亚全国覆盖

---

## 四、西非 (West Africa)

### 20. Get4Less Ghana
- **国家**: 加纳
- **网站**: get4lessghana.com
- **电话**: +233 55 563 7666
- **邮箱**: info@get4lessghana.com
- **地址**: Oxford St, Osu, Accra
- **业务**: Hikvision全国分销2023年起
- **产品线**: PoE 4端口₵415, 8端口₵580-990, 24端口₵2645, 52端口₵26550
- **采购潜力**: $10K-30K/批
- **开发策略**: 加纳Hikvision新分销，价格已明确

### 21. Safety Hub Ghana / Turxin Engineering
- **国家**: 加纳
- **网站**: safetyhubghana.com
- **电话**: +233 535 132 652
- **邮箱**: info@safetyhubghana.com
- **地址**: Spintex Rd, Accra
- **业务**: Hikvision PoE 8端口₵1130, 24端口₵3763
- **采购潜力**: $5K-15K/批
- **开发策略**: 价格已明确，可直接报价

### 22. CompuGhana LTD
- **国家**: 加纳
- **业务**: ICT+安防，Hikvision合作伙伴
- **采购潜力**: $5K-15K/批
- **开发策略**: ICT综合分销

### 23. IV Pro International
- **国家**: 加纳/贝宁/多哥
- **电话**: +233 55 442 0946
- **邮箱**: info@ivprodistribution.com
- **业务**: 西非区域分销
- **采购潜力**: $5K-15K/批
- **开发策略**: 西非多国覆盖

### 24. Stanificent Global
- **国家**: 尼日利亚
- **网站**: stanificentglobal.com
- **地址**: Lagos/Abuja/Port Harcourt全国
- **业务**: Hikvision 8端口PoE
- **采购潜力**: $5K-15K/批
- **开发策略**: 尼日利亚全国覆盖

### 25. Channel Security Store
- **国家**: 尼日利亚
- **网站**: channelsecuritystore.com
- **业务**: Hikvision产品
- **采购潜力**: $3K-10K/批
- **开发策略**: 安防专业

### 26. Hawkvision Technologies
- **国家**: 肯尼亚
- **网站**: hawkvision.co.ke
- **电话**: +254 799 222 999
- **邮箱**: sales@hawkvision.co.ke
- **业务**: Hikvision全国分销，CCTV/门禁/交换机/HDD
- **采购潜力**: $10K-20K/批
- **开发策略**: 肯尼亚Hikvision主力分销

---

## 五、澳大利亚/新西兰 (Australia/New Zealand)

### 27. Security Wholesalers
- **国家**: 澳大利亚
- **网站**: securitywholesalers.com.au
- **业务**: Hikvision官方合作伙伴+Dahua/HiLook/Hanwha/Axis/VIGI，3年质保，全国配送
- **产品线**: PoE 4端口$64AUD, DS-3E1105P-EI $60.72AUD
- **采购潜力**: $20K-50K/批
- **开发策略**: 澳洲Hikvision官方，价格已明确

### 28. CCTV Tradie / CCTV Importers
- **国家**: 澳大利亚
- **网站**: cctvimporters.com.au
- **地址**: Noble Park, VIC
- **业务**: 2016年成立，Hikvision/Dahua/TP-Link授权
- **采购潜力**: $10K-20K/批
- **开发策略**: 直接从中国进口

### 29. CCTV Masters
- **国家**: 澳大利亚
- **网站**: cctvmasters.com.au
- **电话**: (02) 8106 0888
- **地址**: 173 Chapel Rd, Bankstown, NSW
- **业务**: 2005年成立，Dahua合作伙伴
- **产品线**: Hik 4端口$91AUD, Dahua 8端口$155AUD
- **采购潜力**: $10K-20K/批
- **开发策略**: 价格已明确

### 30. Tello Wholesaler
- **国家**: 澳大利亚
- **网站**: tellowholesaler.com.au
- **业务**: Hikvision PoE批发
- **产品线**: 4端口$79AUD, 8端口$159AUD, 16端口$469AUD, 24端口$529AUD
- **采购潜力**: $10K-20K/批
- **开发策略**: 价格已明确，批发专注

### 31. Atlas Gentech
- **国家**: 新西兰
- **网站**: atlasgentech.co.nz
- **电话**: +64 9 574 2700
- **邮箱**: orders@atlasgentech.co.nz
- **地址**: 76 Carbine Rd, Mt Wellington, Auckland
- **业务**: Hikvision/3M/Sony/Milestone/Paradox
- **采购潜力**: $10K-20K/批
- **开发策略**: 新西兰老牌分销

### 32. NFS (National Fire & Security)
- **国家**: 新西兰
- **网站**: nfs.co.nz
- **邮箱**: sales@nfs.co.nz
- **地址**: Penrose, Auckland
- **业务**: 1991年成立
- **采购潜力**: $5K-15K/批
- **开发策略**: 新西兰老牌安防

---

## 六、中东 (Middle East)

### 33. Hyvision Technology LLC
- **国家**: 阿联酋
- **网站**: hyvisionuae.com
- **电话**: +971-4-5146878
- **邮箱**: info@hyvisionuae.com
- **地址**: Business Bay, Dubai
- **业务**: 2011年起Hikvision战略级全国分销，最大库存，独立RMA
- **采购潜力**: $30K-100K/批
- **开发策略**: 阿联酋#1 Hikvision分销

### 34. Smartplus Co. LLC
- **国家**: 沙特
- **网站**: smartplus.com.sa
- **邮箱**: hello@smartplus.com.sa
- **地址**: Al Laban, Riyadh
- **业务**: Hikvision战略级全国分销
- **采购潜力**: $30K-100K/批
- **开发策略**: 沙特Hikvision主力

### 35. Seven Sectors Trading
- **国家**: 沙特
- **网站**: 7sectors.com
- **业务**: AETEK PoE授权合作伙伴，Milesight/HID
- **采购潜力**: $10K-30K/批
- **开发策略**: **AETEK渠道**，Saga可对位

### 36. Vodatel Jordan
- **国家**: 约旦
- **网站**: vodatel.com.jo
- **业务**: Hikvision/Dahua/Longse，覆盖约旦/伊拉克/巴勒斯坦/叙利亚/黎巴嫩/海湾
- **采购潜力**: $20K-50K/批
- **开发策略**: 中东多国覆盖

### 37. ESE (Electronic Supplies Est.)
- **国家**: 约旦
- **业务**: 38年+，Dahua分销，CCTV/门禁/自动化
- **采购潜力**: $10K-20K/批
- **开发策略**: 约旦老牌分销

### 38. Al Kawther
- **国家**: 卡塔尔
- **业务**: 2009年成立，Dahua分销
- **采购潜力**: $5K-15K/批
- **开发策略**: 卡塔尔Dahua渠道

### 39. Nexgen Techno / Al Bareeq
- **国家**: 科威特
- **网站**: albareeqkw.com
- **电话**: +965-96696753
- **业务**: Hikvision PoE 16端口KWD 49.9 (~$162), 24端口KWD 64.9 (~$211)
- **采购潜力**: $5K-15K/批
- **开发策略**: 价格已明确

---

## 七、阿根廷 (Argentina)

### 40. ARGSEGURIDAD SRL
- **国家**: 阿根廷
- **网站**: argseguridad.com
- **电话**: 011-4717-5111
- **地址**: Mons. Larumbe 1654 Martinez + Av Rivadavia 8617 CABA, Buenos Aires
- **业务**: Hikvision官方分销
- **采购潜力**: $10K-20K/批
- **开发策略**: 阿根廷Hikvision官方

### 41. Tienda Hikvision / OFIT SRL
- **国家**: 阿根廷
- **网站**: tiendahikvision.com.ar
- **邮箱**: ventas@tiendahikvision.com.ar
- **电话**: 1158823919
- **地址**: Saraza 1376, CABA
- **业务**: Hikvision阿根廷官方网店
- **产品线**: PoE交换机DS-3E1309P-EI
- **采购潜力**: $10K-20K/批
- **开发策略**: 官方网店，价格透明

### 42. Giganet
- **国家**: 阿根廷
- **业务**: 30年，技术分销领导者
- **采购潜力**: $10K-30K/批
- **开发策略**: 阿根廷IT分销巨头

---

## 八、法国/西班牙/德国/意大利 (Western Europe)

### 43. TKH Security / Aasset Security
- **国家**: 法国/荷兰
- **网站**: tkhsecurity.fr
- **邮箱**: info.fr@tkhsecurity.com
- **地址**: 153 rue Michel Carré, 95100 Argenteuil, France
- **业务**: Hikvision分销，荷兰TKH集团
- **采购潜力**: $20K-50K/批
- **开发策略**: 欧洲安防集团

### 44. Ubitech
- **国家**: 法国
- **网站**: ubitech.fr
- **电话**: 01 85 400 410
- **邮箱**: contact@ubitech.fr
- **地址**: 4 rue des frères lumière, 78370 Plaisir
- **业务**: "欧洲第1家Hikvision官方e-distributeur"，PoE交换机Hikvision/Dahua/TP-Link
- **采购潜力**: $10K-30K/批
- **开发策略**: 法国Hikvision电商主力

### 45. ADI Global Distribution France
- **国家**: 法国
- **地址**: 5 Rue Charles de Gaulle, 94140 Alfortville
- **业务**: 全球200+分支，安防/低压产品批发
- **采购潜力**: $30K-100K/批
- **开发策略**: 全球安防分销巨头

### 46. erdkreis VIDEO GmbH
- **国家**: 德国
- **地址**: Buchenstraße 15, 64385 Reichelsheim
- **业务**: 40年，Hikvision 10年+合作伙伴
- **采购潜力**: $10K-20K/批
- **开发策略**: 德国老牌视频安防

### 47. ADI Global Spain
- **国家**: 西班牙
- **电话**: +34 91 419 17 20
- **邮箱**: pedidos.es@adiglobal.com
- **地址**: Av. de Italia 7, 28821 Coslada, Madrid
- **采购潜力**: $20K-50K/批
- **开发策略**: ADI西班牙分支

### 48. ABES SRL
- **国家**: 意大利
- **电话**: 011 2290703
- **邮箱**: info@abes.it
- **地址**: Via Traversella 13a, 10148 Torino
- **业务**: Hikvision分销
- **采购潜力**: $5K-15K/批
- **开发策略**: 意大利Hikvision渠道

### 49. Computer Gross SPA
- **国家**: 意大利
- **电话**: 0571 9977
- **邮箱**: info@computergross.it
- **业务**: IT分销，全国覆盖
- **采购潜力**: $10K-30K/批
- **开发策略**: 意大利IT分销巨头

### 50. RIEL Elektronikai Kft.
- **国家**: 匈牙利
- **业务**: 25年，Hikvision区域领先分销，视频/消防/报警/门禁
- **采购潜力**: $10K-20K/批
- **开发策略**: 匈牙利Hikvision主力

---

## 九、秘鲁/智利 (Peru/Chile)

### 51. DENCHI S.A.C. (Hikvision Peru官方)
- **国家**: 秘鲁
- **网站**: hikvision-peru.com
- **电话**: 01-6409957, +51 924 616 170
- **邮箱**: Ventas@hikvision-peru.com
- **地址**: Av. Aviación 2410, 3er piso, tiendas 182-183, San Borja, Lima
- **业务**: Hikvision秘鲁官方授权分销
- **产品线**: PoE交换机DS-3E0505P-E/M
- **采购潜力**: $10K-30K/批
- **开发策略**: 秘鲁Hikvision官方网店

### 52. Datacam Peru
- **国家**: 秘鲁
- **网站**: datacamperu.com
- **电话**: 924 380 257
- **业务**: Dahua分销，PoE交换机PFS4204-2GT-DP
- **采购潜力**: $10K-20K/批
- **开发策略**: 秘鲁Dahua主力

### 53. Compudiskett
- **国家**: 秘鲁
- **业务**: 35年+，2023年新晋Dahua官方分销
- **采购潜力**: $10K-20K/批
- **开发策略**: 秘鲁老牌IT分销

### 54. Hikvision Lima EIRL
- **国家**: 秘鲁
- **网站**: hikvisionlima.pe
- **电话**: 982 965 779
- **邮箱**: hikvisionlima.pe@gmail.com
- **地址**: Av. Garcilaso de la Vega 1348, Tienda SSA-151, Lima
- **业务**: Hikvision授权分销
- **产品线**: DS-3E0516-E ₡190, DS-3E0524-E ₡230
- **采购潜力**: $5K-15K/批
- **开发策略**: 价格已明确

### 55. SSTT SpA
- **国家**: 智利
- **网站**: sstt.cl
- **邮箱**: ventas@sstt.cl
- **地址**: General José Artigas 3028, Ñuñoa, Santiago
- **业务**: Dahua区域分销12年+，PoE交换机
- **采购潜力**: $10K-20K/批
- **开发策略**: 智利Dahua区域主力

### 56. KAPS
- **国家**: 智利
- **网站**: kaps.cl
- **地址**: Bueras 570
- **业务**: Imou/Ezviz/Hikvision/Dahua官方分销，网络设备
- **采购潜力**: $5K-15K/批
- **开发策略**: 多品牌+网络设备

### 57. AltaSec
- **国家**: 智利
- **网站**: altasec.cl
- **业务**: Hikvision进口/分销，全国支持
- **采购潜力**: $5K-15K/批
- **开发策略**: 智利Hikvision进口商

---

## 十、韩国/香港/埃及/孟加拉 (Asia/Africa)

### 58. CynexZone (씨넥스존)
- **国家**: 韩国
- **业务**: 2006年成立，Hikvision韩国全国分销，B2B+B2C，CCTV+网络
- **采购潜力**: $20K-50K/批
- **开发策略**: 韩国Hikvision主力分销

### 59. UTG
- **国家**: 香港
- **网站**: utg.hk
- **电话**: +852 3905 2118
- **邮箱**: sales@utg.hk
- **业务**: Hikvision分销
- **采购潜力**: $10K-30K/批
- **开发策略**: 香港Hikvision渠道

### 60. Speed 4 Trading
- **国家**: 埃及
- **业务**: 1999年成立，Hikvision CCTV/门禁/报警/网络线缆/交换机/显示器
- **采购潜力**: $10K-30K/批
- **开发策略**: 埃及Hikvision老牌分销

### 61. 1shop.com.bd / Techlink
- **国家**: 孟加拉
- **网站**: 1shop.com.bd
- **业务**: Hikvision授权分销，PoE交换机
- **采购潜力**: $5K-15K/批
- **开发策略**: 孟加拉Hikvision官方

---

## 十一、印度深度挖掘 (India)

### 62. Montronics Electronics Pvt Ltd
- **国家**: 印度
- **地址**: Ground Floor, 374, Skyking Chambers, Lamington Road, Grant Road East, Mumbai 400007
- **电话**: +91-7942821707
- **业务**: 15年，Dahua/Syrotech PoE
- **采购潜力**: $10K-20K/批
- **开发策略**: 孟买老牌PoE分销

### 63. Mahadev Computers
- **国家**: 印度
- **网站**: mahadevcomputers.co.in
- **地址**: 1st Floor, Shop No. 27, Kartar Mansion, Tribhuvan Road, Grant Road, Mumbai 400004
- **业务**: Hikvision/D-Link/Netgear PoE批发
- **产品线**: Netgear GS308P ₹2183, Hik DS-3E1510P-SI
- **采购潜力**: $5K-15K/批
- **开发策略**: 孟买PoE批发

### 64. Optima Technologies
- **国家**: 印度
- **电话**: +91-8046055756
- **地址**: 3rd Floor, Tower F, Century Central, Bengaluru 560062
- **业务**: PoE交换机零售
- **采购潜力**: $5K-10K/批
- **开发策略**: 班加罗尔

### 65. Signellent Technologies
- **国家**: 印度
- **网站**: signellent.com
- **地址**: Pune/Ahmedabad/Bengaluru/Coimbatore/Bhubaneswar/Ghaziabad
- **业务**: Hikvision授权合作伙伴/分销/安装/批发
- **采购潜力**: $10K-20K/批
- **开发策略**: 印度多城市Hikvision授权

### 66. Ruchi Telecom Pvt Ltd
- **国家**: 印度
- **地址**: New Delhi
- **业务**: 17年，PoE交换机
- **采购潜力**: $5K-15K/批
- **开发策略**: 德里老牌电信

### 67. Yugan Info India Pvt Ltd
- **国家**: 印度
- **地址**: Sahakara Nagar, Bengaluru
- **业务**: Hikvision PoE批发，DS-3E0109P-E ₹5180
- **采购潜力**: $5K-10K/批
- **开发策略**: 班加罗尔Hikvision

---

## 十二、D2C品牌/OEM机会 (Direct Competitors)

### 68. LINOVISION
- **国家**: 美国/中国
- **网站**: linovision.com, eBay "unitedsecuritycameras"
- **业务**: 15年+，100+国家，工业PoE专业（POE-SW508G），PoE延长器
- **产品线**: 工业级PoE，8端口全千兆$102-120USD
- **采购潜力**: **OEM/ODM机会**
- **开发策略**: 深圳公司，可谈OEM贴牌

### 69. Cudy
- **国家**: 中国/全球
- **网站**: cudy.com
- **业务**: 全线PoE：FS1006P(4PoE)/FS1010P(8PoE)/GS1005P(4GE)/IG1005P(工业)/IG1008P(工业)
- **采购潜力**: **OEM/ODM机会**
- **开发策略**: 深圳品牌，Amazon/eBay热销

### 70. ienRon
- **国家**: 中国/全球
- **业务**: 6端口/10端口PoE，AI检测，金属外壳，2.5G型号
- **采购潜力**: **OEM/ODM机会**
- **开发策略**: Amazon热销品牌

---

## 十三、展会发现 (Exhibition Leads)

### 71. Intellinet Network Solutions (IC Intracom)
- **国家**: 美国/全球
- **网站**: intellinetsolutions.com
- **地址**: Oldsmar, Florida
- **业务**: PoE交换机/注入器/延长器，70+国家
- **展会**: ISC West 2026 booth #2037
- **采购潜力**: $20K-50K/批
- **开发策略**: ISC West PoE专业参展商

---

**Batch 5 总计: 71家新客户**
**覆盖国家/地区: 哥斯达黎加、厄瓜多尔、波兰、捷克、罗马尼亚、加纳、尼日利亚、肯尼亚、澳大利亚、新西兰、阿联酋、沙特、约旦、卡塔尔、科威特、阿根廷、法国、德国、西班牙、意大利、匈牙利、秘鲁、智利、韩国、香港、埃及、孟加拉、印度、美国 = 29个**

---

## 价格基准更新

| 国家 | 型号 | 价格 | 备注 |
|------|------|------|------|
| 哥斯达黎加 | Hik PoE | ₡6,102+IVA | 含增值税 |
| 厄瓜多尔 | DS-3E0105D 5端口 | $6.33 | 批发价 |
| 加纳 | 4端口 | ₵415 (~$35) | 零售价 |
| 加纳 | 8端口 | ₵580-990 (~$49-83) | 零售区间 |
| 加纳 | 24端口 | ₵2,645 (~$222) | 零售价 |
| 澳大利亚 | 4端口 | $64-91AUD (~$42-60) | 批发价 |
| 澳大利亚 | 8端口 | $150-159AUD (~$99-105) | 批发价 |
| 澳大利亚 | 16端口 | $469AUD (~$309) | 批发价 |
| 澳大利亚 | 24端口 | $529-618AUD (~$349-407) | 批发价 |
| 科威特 | 16端口 | KWD 49.9 (~$162) | 批发价 |
| 科威特 | 24端口 | KWD 64.9 (~$211) | 批发价 |
| 秘鲁 | 16端口 | ₡190 (~$50) | 零售价 |
| 秘鲁 | 24端口 | ₡230 (~$61) | 零售价 |
| 印度 | Netgear GS308P | ₹2,183 (~$26) | 批发价 |
| 印度 | Hik DS-3E0109P-E | ₹5,180 (~$62) | 批发价 |

---

## 竞争情报

**AETEK (台湾)**
- PoE交换机品牌，专注监控
- L2/L2+管理型，IP67工业级
- Milestone XProtect + Avigilon Unity直接集成
- 天花板安装专利snap-fit
- NDAA/TAA合规
- 分销：CCTV Baltic (波兰), Seven Sectors (沙特)
- **对Saga的启示**: 直接竞争对手，Saga可对标其VMS集成策略

**LINOVISION/Cudy/ienRon**
- 深圳D2C品牌，Amazon/eBay热销
- 工业级PoE，金属外壳
- OEM/ODM机会，可谈贴牌合作

---

> Batch 5 完成于 2026-10-25，深度挖掘4轮，覆盖29个国家/地区，71家新客户
