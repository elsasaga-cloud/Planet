# Batch 42 — 高端工业PoE：双电源 + Bypass + 90W PoE++ + IEC 61850

**日期**: 2026-10-25  
**搜索轮次**: Round 154-158  
**新增客户/情报**: 25 家  
**聚焦**: 双电源冗余, Bypass网络冗余, 90W/100W PoE++, 工业级极端环境

---

## 🔌 一、双电源冗余 PoE (Dual Redundant Power)

### 1. TRENDnet 双电源工业系列 (美国)
- **类型**: B类 - 工业PoE专家
- **产品**:
  - TI-PE80 V2: 8口100M PoE+, 200W, IP50, -40~75°C, 双电源冗余
  - TI-PE50 V2: 4口100M PoE+, 90W, IP50, -40~75°C, 双电源
  - TI-PG62B: 4口千兆PoE+ + 2 SFP, 120W@24-55V, -40~75°C
  - TI-PG541: 4口千兆PoE+, -40~70°C, 双电源
  - TI-BG104 V2: 10口千兆PoE++, NDAA/TAA, -40~75°C, 双电源
- **特点**: 过载保护, 电源故障报警继电器
- **开发策略**: 美国工业PoE双电源专家 ★★★★★

### 2. Linovision 双电源系列 (中国+美国)
- **类型**: A类 - 工业PoE+太阳能
- **产品**:
  - POE-Switch0504GD: 5口千兆, DC9-54V升压, 双DC9-54V冗余输入, -40~80°C, IP40
  - POE-SW508G2: 8口千兆, 4x90W PoE++ + 4x30W PoE+, DC48-56V冗余, 360W
  - 8口千兆BT90W: 4x90W + 4x30W, DC48-56V冗余, 120W/240W可选
- **特点**: 自动故障切换, 8针同时供电, PoE Mode A/B输出
- **开发策略**: 中国+美国双电源工业PoE ★★★★★

### 3. Intellinet 双电源工业 (美国)
- **类型**: B类 - 工业PoE
- **产品**:
  - 508254: 4口千兆PoE+ + 2 SFP, 120W, DC44-57V冗余, 6KV浪涌, 电源故障报警
  - 508995: 4口千兆PoE++ + 2 SFP, DC48-57V冗余, 802.3bt/at/af
- **特点**: 接地保护, I/O端子块
- **开发策略**: 美国双电源工业PoE ★★★★★

### 4. Planet Technology 双电源系列 (台湾)
- **类型**: B类 - 工业PoE
- **产品**:
  - GS-6322-24P4X: L3 24口802.3bt PoE + 2x10G-T + 2x10G SFP+, 双模块化电源, 2032W/2377W, TAA
  - IGS-6325-24UP4X: 工业L3 24口802.3bt + 4x10G SFP+, 单电源720W/双电源1440W, 16x90W PD
- **特点**: 双电源时功率翻倍
- **开发策略**: 台湾双电源高功率PoE ★★★★★

### 5. D-Link 双电源PoE (美国)
- **类型**: B类 - 企业PoE
- **产品**: 802.3bt PoE++交换机, 双电源960W, 90W/口 (端口1-8)
- **开发策略**: D-Link双电源企业PoE ★★★★★

---

## 🔀 二、Bypass网络冗余 PoE

### 6. Come-Star Bypass技术 (中国)
- **类型**: 技术情报
- **原理**: 电源故障时内部继电器连接两端口, 铜缆/光纤信号直通
- **应用**: 线性拓扑 (输送带, 隧道, 远程机柜)
- **恢复**: 电源恢复时继电器释放, 交换机接管
- **开发策略**: Bypass技术情报 ★★★★★

### 7. ORing Bypass工业系列 (台湾)
- **类型**: B类 - Bypass工业PoE
- **产品**:
  - DGS-9812GP-AIO_S: 8口千兆 + 12 SFP, Bypass, 双电源, 9.6KB Jumbo Frame
  - O-Ring冗余: <30ms恢复 (250连接)
  - 支持: Open-Ring, MSTP/RSTP/STP
- **应用**: HD图像, 大数据传输
- **开发策略**: 台湾Bypass工业PoE ★★★★★

### 8. Planet Technology Bypass系列 (台湾)
- **类型**: B类 - 光纤Bypass
- **产品**:
  - IFB-244-MSC: 工业2通道光纤Bypass交换机, 4 duplex SC, 多模850nm/1300nm, 双DC9-48V, TAA/NDAA, $400.20
- **特点**: 反向极性保护, 24V AC支持
- **开发策略**: 台湾光纤Bypass PoE ★★★★★

### 9. Hi-Net Bypass工业PoE (中国)
- **类型**: A类 - Bypass工业PoE
- **协议**: MRP (<200ms, 50节点), PROFINET IRT (31.25µs), HSR/PRP (IEC 62439-3, 零中断)
- **应用**: IEC 61850保护继电器架构
- **特点**: 双24V DC输入, PoE看门狗, SNMP电源监控+SCADA集成
- **开发策略**: 中国Bypass工业PoE ★★★★★

---

## ⚡ 三、90W/100W PoE++ (802.3bt Type 4)

### 10. Planet Technology 90W/95W系列 (台湾)
- **类型**: B类 - 高功率PoE++
- **产品**:
  - IGS-824UPT: 工业4口802.3bt PoE++ (95W) + 2千兆 + 2 SFP, 非管理, 240W@52-54V / 160W@48-51V
  - IGS-6329-8UP2S2X: 工业L3 8口90W 802.3bt + 2x1G/2.5G SFP + 2x10G SFP+, 95W PoH模式, 4对强制模式
- **特点**: UPoE技术, 4对Cat5e/6供电
- **开发策略**: 台湾90W/95W PoE++专家 ★★★★★

### 11. Perle IDS-710HP/IDS-110HP (加拿大)
- **类型**: B类 - 100W工业PoE
- **产品**:
  - IDS-710HP: 10口管理, 8x千兆90W 802.3bt + 2 SFP (2.5G), 450W总功率, 5口同时90W, -10~60°C
  - IDS-110HP: 10口, 8x千兆90W 802.3bt + 2 SFP, -10~60°C
- **应用**: 工业自动化, 政府, 军事, 油气, 采矿, 户外
- **开发策略**: 加拿大100W工业PoE ★★★★★

### 12. Linovision 90W工业系列 (中国+美国)
- **类型**: A类 - 90W工业PoE
- **产品**:
  - 8口千兆BT90W: 4x90W PoE++ (端口1-4) + 4x30W PoE+ (端口5-8), DC48-56V冗余, 120W/240W, -40~75°C, IP40
  - 工业8口BT90W: 4x90W + 4x30W, DC48-56V冗余, PoE看门狗, UL认证电源
- **应用**: PoE监控, PoE照明, PTZ摄像头
- **开发策略**: 中国+美国90W工业PoE ★★★★★

### 13. PROCET 90W工业系列 (中国)
- **类型**: A类 - 90W工业PoE
- **产品**:
  - PT-PIS4PB1T: 4口90W/口, DC48-55V, 360W总功率
  - PT-PIS4PB1T-AC: AC/DC双输入, 360W/200W
  - PT-PIS4PB1T-E: DC12-55V升压, 120W@12V/240W@24V/360W@48V, -40~65°C
  - PT-PIS4PB1S/S-AC/S-E: 光纤版本
- **特点**: 智能PoE检测, 802.3af/at/bt自动识别
- **开发策略**: 中国90W工业PoE专家 ★★★★★

### 14. Versa Technology D40-044-91 (美国)
- **类型**: B类 - 90W工业PoE
- **产品**: D40-044-91-DC, 4口90W 802.3bt + 2 RJ45 + 2 SFP, DC12-56V, IP30, 6KV浪涌, -40~75°C, $535
- **开发策略**: 美国90W工业PoE ★★★★★

### 15. AD-Net 90W工业 (台湾)
- **类型**: B类 - 90W工业PoE
- **产品**: 4口90W/口 (360W总), 管理千兆 + 2 SFP (含SM/MM模块), 802.3bt Type 4, DIN轨, 温湿度传感器, 终身保修
- **开发策略**: 台湾90W工业PoE ★★★★★

### 16. Microchip PD-9601GCI (美国)
- **类型**: B类 - 90W工业midspan
- **产品**: PD-9601GCI, 单口90W 802.3bt工业midspan, 千兆以太网
- **应用**: 工业自动化, 智能工厂, 交通, 户外
- **特点**: 无需更换现有交换机
- **开发策略**: 美国90W工业midspan ★★★★★

---

## ⚙️ 四、IEC 61850-3 变电站PoE

### 17. Westermo Lynx系列 (瑞典)
- **类型**: B类 - 变电站PoE
- **产品**:
  - Lynx 3510-E-F2G-P8G-LV: L3 PoE+, 8口千兆PoE + 2 SFP, 240W总功率, 30W/口, -40~70°C, IEC 61850-3
  - Lynx 5612-E-F4G-T8G-LV: L3, 8口千兆 + 4 SFP, IEC 61850-3
  - RedFox-5728: L3 19"机架, 24 SFP + 4千兆, 双低压DC24-48V
- **开发策略**: 瑞典变电站PoE专家 ★★★★★

### 18. Antaira IEC 61850系列 (美国)
- **类型**: B类 - 变电站PoE
- **产品**:
  - LMP-2004G-SFP: 20口L3管理, 16x千兆30W PoE+ + 4 SFP, DC48-55V, $2599
  - LMP-2004G-SFP-T: 宽温-40~75°C, $2699
  - LMX-2004G-SFP: 20口千兆L3, 16口 + 4 SFP, $1849
- **开发策略**: 美国变电站PoE ★★★★★

### 19. Cisco Catalyst IE9300 (美国)
- **类型**: 竞品 - 变电站PoE
- **产品**: IE9300 Rugged Series, 1RU机架, 28口, IEC 61850-3 + IEEE 1613, PRP/HSR (3 SKU)
  - IE-9320-26S2C, IE-9320-22S2C4X, IE-9310-16P8S4X
- **案例**: Enedis (法国电网)变电站现代化
- **特点**: 铜PoE + 光纤, 未来10年可靠网络
- **开发策略**: Cisco变电站PoE竞品 ★★★★★

### 20. ORing IEC 61850系列 (台湾)
- **类型**: B类 - 变电站PoE
- **产品**:
  - IGPS-P9084GP-LA: 紧凑IEC 61850-3 PoE交换机, 现场设备/监控
  - RGS-PR9000: 24+4 10G口L3模块化, IEC 61850-3 + IEEE 1613 + EN50155铁路
- **特点**: HSR/PRP冗余, 8级QoS (GOOSE/SV优先), VLAN分段, -40~85°C
- **开发策略**: 台湾变电站PoE ★★★★★

### 21. RAD PowerFlow-2 (以色列)
- **类型**: B类 - 变电站PoE
- **产品**: PowerFlow-2, PoE/PoE+/PoE++ (60W), xSTP/ERPS, PF-Ring/chain超快恢复, EN 50121-4/IEC 61850-3/IEEE 1613/NEMA TS2
- **开发策略**: 以色列变电站PoE ★★★★★

---

## 🏭 五、极端环境工业PoE

### 22. Moxa 极端环境 (台湾)
- **类型**: B类 - 极端工业PoE
- **产品**: EDS-G4012-4GS-HV, 802.3bt PoE++, 370W, 8 RJ45 + 4 SFP, -40~75°C, MRP/RSTP/Ring
- **应用**: 离岸油气 (Reddit推荐)
- **开发策略**: 台湾极端环境PoE ★★★★★

### 23. Antaira M12系列 (美国)
- **类型**: B类 - M12防振PoE
- **产品**: M12工业以太网交换机, X-coded/A-coded, PoE选项, IP67金属外壳, -40~75°C
- **应用**: 油气, 铁路, 自动化 (极端振动)
- **开发策略**: 美国M12防振PoE ★★★★★

### 24. Crystal Group + RUCKUS (美国)
- **类型**: B类 - 加固PoE
- **产品**: Ruggedized RUCKUS网络交换机
- **应用**: 自动驾驶, 油气, 电力分配, 采矿, 气象雷达
- **开发策略**: 美国加固PoE ★★★★★

### 25. Allied Telesis IE220系列 (美国)
- **类型**: B类 - 加固工业PoE
- **产品**: IE220 Series, 工业级, 10G PoE++, -40~75°C, IEC 60068-2环境压力测试
- **应用**: OT网络, 户外安装, 电磁噪声, 高湿度, 振动
- **开发策略**: 美国加固工业PoE ★★★★★

---

## 📊 Batch 42 统计

- **新增客户/情报**: 25 家
- **聚焦技术**: 双电源冗余, Bypass网络冗余, 90W/100W PoE++, IEC 61850-3变电站
- **覆盖国家**: +3 (瑞典, 以色列, 加拿大已有)

---

## 🎯 关键技术发现

1. **双电源冗余**: TRENDnet, Linovision, Intellinet, Planet, D-Link (过载保护+报警继电器)
2. **Bypass网络冗余**: Come-Star技术, ORing DGS-9812GP, Planet IFB-244-MSC, Hi-Net MRP/HSR/PRP
3. **90W/100W PoE++**: Planet 95W, Perle 100W, Linovision 90W, PROCET 90W, Versa 90W, AD-Net 90W, Microchip 90W midspan
4. **IEC 61850-3变电站**: Westermo (瑞典), Antaira, Cisco IE9300, ORing, RAD PowerFlow-2
5. **极端环境**: Moxa (离岸油气), Antaira M12 (防振), Crystal Group (加固), Allied Telesis IE220

---

## 📈 累计统计

- **总客户/情报数**: 1,151 家 (1126 + 25)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 44 次
- **超额完成**: 164% (目标 700客户)
