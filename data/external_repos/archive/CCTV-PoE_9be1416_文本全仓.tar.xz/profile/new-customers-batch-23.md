# Batch 23 — 大洋洲PoE + 医疗PoE + Cambium WISP + 海事PoE
> 深度挖掘 Round 71-74 (2026-10-25)
> 方法论：NZ/太平洋分销 / 医疗PoE方案 / Cambium WISP生态 / 海事/军用PoE

---

## 一、大洋洲/太平洋PoE分销

### 1. Go Wireless NZ（新西兰）
- **类型**: C类 — PoE全电压分销
- **网站**: gowifi.co.nz
- **品牌**: MikroTik+Ubiquiti+Netonix+Tycon Power+Teltonika+Grandstream
- **产品**: Passive PoE/802.3af/at/bt/PoE++全电压
- **地点**: Rangiora 7400, NZ
- **开发策略**: 新西兰PoE专业分销
- **置信度**: ★★★★★

### 2. Leading Solutions（新西兰）
- **类型**: C类 — PoE Texas NZ授权
- **网站**: leadingsolutions.co.nz
- **产品**: PoE Texas注入器/分离器/交换机/USB-C转换器
- **地点**: Auckland
- **开发策略**: NZ PoE Texas授权批发
- **置信度**: ★★★★★

### 3. PBTech（新西兰）
- **类型**: C类 — IT零售
- **网站**: pbtech.co.nz
- **规模**: 13家门店
- **开发策略**: 新西兰IT零售连锁
- **置信度**: ★★★★☆

### 4. Clear Digital（新西兰）
- **类型**: C类 — 安防PoE
- **网站**: cleardigital.co.nz
- **品牌**: Uniview/Dahua PoE交换机
- **开发策略**: NZ安防PoE分销
- **置信度**: ★★★★☆

---

## 二、医疗PoE方案

> **市场数据**: 医疗PoE占全球17.8%份额(2025), 第二大终端市场

### 5. NVT Phybridge Healthcare（加拿大）
- **类型**: B类 — 医疗PoE方案
- **网站**: nvtphybridge.com/healthcare
- **案例**: Blanchard Valley Health System多院区IP升级
- **开发策略**: PoE医疗长距离方案专家
- **置信度**: ★★★★★

### 6. Yamaha SWX2322P-16MT（日本）
- **类型**: B类 — 医疗PoE SDVoE
- **产品**: 10G/multi-gig智能L2 PoE交换机, SDVoE医疗影像
- **案例**: 帝京大学病院沟口 (530+例检查/治疗)
- **开发策略**: 日本医疗PoE方案
- **置信度**: ★★★★★

### 7. Thinlabs（美国）
- **类型**: B类 — PoE All-in-One PC
- **网站**: thinlabs.com
- **应用**: 医疗(护士站/病人登记/推车)/教育/政府/零售
- **开发策略**: PoE电脑品牌，需PoE++交换机配套
- **置信度**: ★★★★☆

### 8. Cybernet Manufacturing（美国）
- **类型**: B类 — PoE医疗电脑
- **网站**: cybernetman.com
- **成立**: 1996年
- **产品**: 医疗面板PC+加固平板 (PoE供电)
- **开发策略**: PoE医疗电脑品牌
- **置信度**: ★★★★★

### 9. PROCET Medical PoE（中国）
- **类型**: B类 — 医疗PoE电源
- **网站**: procetpoe.com
- **产品**: 802.3bt 60-100W医疗PoE, PoE→USB-C 60W
- **开发策略**: 医疗PoE电源方案
- **置信度**: ★★★★☆

---

## 三、Cambium Networks WISP生态

> **情报**: Cambium (NASDAQ:CMBM) 从Motorola Canopy拆分(2011), 2025年净利润$38.5M, 700员工, 10M+无线设备, Wi-Fi 7 X7系列

### 10. Cambium cnMatrix EX系列
- **类型**: 竞品 — WISP/Enterprise PoE
- **产品**: EX1000(8口)/EX2000(8-52口)/EX3000(24-52口), 90W/口, cnMaestro云管理, L2/L3
- **开发策略**: Cambium PoE竞品全线
- **置信度**: ★★★★★

### 11. 4Networks（德国）
- **类型**: C类 — Cambium VAD德国
- **网站**: 4networks.de
- **产品**: Cambium全线 (Wi-Fi/ePMP/PMP/PTP/cnMatrix/cnMaestro)
- **市场**: WISP/酒店/教育/政府军事(PTP 700)
- **开发策略**: 德国Cambium增值分销
- **置信度**: ★★★★★

### 12. Cyber Distribution（UK）
- **类型**: C类 — Cambium分销
- **网站**: cyberdistribution.co.uk
- **开发策略**: 英国Cambium分销
- **置信度**: ★★★★☆

### 13. OMG（德国）
- **类型**: C类 — Cambium cnMatrix
- **网站**: omg.de
- **开发策略**: 德国Cambium分销
- **置信度**: ★★★★☆

### 14. MiRO Distribution（南非）
- **类型**: C类 — Cambium SADC
- **网站**: miro.co.za
- **覆盖**: 南非+SADC全区域
- **合作**: 2015年起Cambium分销
- **开发策略**: 南部非洲Cambium分销
- **置信度**: ★★★★★

---

## 四、海事/军用PoE

> **市场洞察**: 海事PoE是利基高价值市场，需DNV/IEC认证，X-Ring/ERPS<20ms冗余

### 15. Winmate（台湾）
- **类型**: B类 — 海事PoE交换机
- **网站**: winmate.com
- **产品**: EACSW/EACSW-L2 (8口PoE+2口GbE/SFP, X-Ring Pro <20ms, 24-48VDC冗余, DIN/壁挂)
- **应用**: 船舶桥梁摄像头/雷达/ECDIS/WiFi
- **开发策略**: 台湾海事PoE专业品牌
- **置信度**: ★★★★★

### 16. Quark-Elec（荷兰）
- **类型**: B类 — 海事PoE交换机
- **网站**: quark-elec.com
- **产品**: R043 (8口GbE PoE+2xSFP, OneNet NMEA, DC9-35V, IP40, €209)
- **应用**: 小型/中型船舶/码头
- **开发策略**: 荷兰海事PoE品牌
- **置信度**: ★★★★★

### 17. SmartMarine（荷兰）
- **类型**: C类 — 海事PoE零售
- **网站**: smartmarine.nl
- **产品**: Quark-Elec R043零售
- **开发策略**: 荷兰海事电子零售
- **置信度**: ★★★★☆

### 18. Techaya（以色列）
- **类型**: B类 — 军用PoE
- **网站**: techaya.com
- **产品**: MILTECH 402 PoE交换机+PDU, ISPDS单兵系统
- **开发策略**: 以色列军用PoE品牌
- **置信度**: ★★★★☆

### 19. Milpower Source（美国）
- **类型**: B类 — 军用/海事以太网
- **网站**: militaryethernet.com
- **成立**: 30+年
- **产品**: MIL-STD-1399/IP67海事UPS+交换机
- **开发策略**: 美国军用/海事网络品牌
- **置信度**: ★★★★☆

### 20. Raymarine RNS-8（英国）
- **类型**: B类 — 海事PoE
- **产品**: RNS-8 Gigabit RayNet PoE交换机 £829
- **开发策略**: 海事电子大牌PoE
- **置信度**: ★★★★☆

---

## 五、工业PoE收入排名（2025）

| 排名 | 品牌 | 工业PoE管理交换机收入 | 增速 |
|------|------|----------------------|------|
| 2 | **Siemens** | $101M | ~8.2% |
| 3 | **Hirschmann/Belden** | $86.4M | ~8.0% |
| 7 | **Phoenix Contact** | $34.56M | ~7.8% |
| 10 | **Kyland Technology (北京)** | $23.76M | 海外+9.5% |

### 21. Kyland Technology（北京）
- **类型**: 竞品 — 工业PoE
- **网站**: kyland.com
- **收入**: $23.76M (2025), 海外业务+9.5%
- **市场**: 电力/交通/能源
- **开发策略**: 北京工业PoE竞品
- **置信度**: ★★★★★

---

**Batch 23 总计: 21家新客户/情报**

> 关键发现：
> 1. **大洋洲PoE 4家** — Go Wireless NZ全电压/Leading Solutions PoE Texas NZ授权/PBTech 13店/Clear Digital安防
> 2. **医疗PoE 5家** — NVT Phybridge/Yamaha日本医疗SDVoE/Thinlabs PoE PC/Cybernet医疗/PROCET Medical
> 3. **Cambium WISP 5家** — cnMatrix全线/4Networks德国VAD/Cyber UK/OMG德国/MiRO南非SADC
> 4. **海事/军用PoE 6家** — Winmate台湾海事/Quark-Elec荷兰海事/SmartMarine荷兰/Techaya以色列军用/Milpower美国30年/Raymarine英国
> 5. **工业PoE收入排名1家** — Kyland北京$23.76M海外+9.5%
