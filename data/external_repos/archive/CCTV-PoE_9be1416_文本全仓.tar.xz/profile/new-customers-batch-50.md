# Batch 50 — 终端设备PoE：VoIP电话 + 数字标牌 + IoT网关 + 楼宇自动化BMS + 工业自动化PLC/SCADA

**日期**: 2026-10-25  
**搜索轮次**: Round 194-198  
**新增客户/情报**: 30 家  
**聚焦**: VoIP IP电话, 数字标牌, IoT LoRaWAN网关, 楼宇自动化BMS/HVAC, 工业自动化PLC/SCADA

---

## 📞 一、VoIP IP电话 PoE

### 1. Yealink 亿联 (中国)
- **类型**: B类 - 全球VoIP#1
- **产品**: T33G (双千兆PoE), T46U (16 SIP+PoE+双千兆), T54W (中端商务WiFi+PoE), T31P (2线PoE入门), T57W (触摸WiFi蓝牙)
- **价格**: $100-200中端 (vs Cisco $200-400+/Poly $150-350)
- **PoE**: 802.3af 3-15W, 所有型号内置PoE, YLPOE30 PoE适配器兼容
- **特点**: 市场份额#1, 性价比, 开放SIP, 3年保修
- **开发策略**: 中国全球VoIP#1 (PoE电话) ★★★★★

### 2. Poly/Polycom (美国)
- **类型**: B类 - 企业VoIP耐用
- **产品**: VVX201 (2线), VVX310 (6线), VVX410 (12线), VVX500 (16线触摸), VVX600 (20线触摸), IP6000会议 (始终PoE), MP54 Teams
- **PoE**: 802.3af 6W典型, 自动配置802.3af, 侧车模块默认启用请求15.4W (需禁用EM-Power)
- **特点**: 硬件质量+音频清晰度, Microsoft Teams, 重型使用, $150-350
- **开发策略**: 美国企业VoIP耐用 (Microsoft Teams) ★★★★★

### 3. Cisco IP Phone (美国)
- **类型**: B类 - 企业深度集成
- **产品**: CP-7975G (5.6"触摸8线PoE Class 3+KEM), SPA504G (4线), SPA525G2 (5线)
- **PoE**: 802.3af, 深度Cisco Unified SIP+专有Call Manager集成
- **特点**: 企业集成+高管, Webex, 噪声消除+HD语音, $200-400+
- **开发策略**: 美国企业深度集成 (Webex) ★★★★★

### 4. PoE VoIP市场情报
- **类型**: 市场情报
- **PoE需求**: 入门SIP 3-5W (802.3af), 中端彩屏5-10W, 触摸/高管WiFi/蓝牙10-15W, 会议10-25W (802.3at PoE+)
- **案例**: 24口PoE 150W预算支持约20标准桌面电话@6W+网络设备余量
- **管理交换机**: QoS语音优先+VLAN分段+PoE管理可见性
- **开发策略**: VoIP PoE市场潜力高 ★★★★☆

---

## 📺 二、数字标牌 PoE

### 5. GPO Display PoE全景LCD (美国)
- **类型**: B类 - PoE大屏
- **产品**: PoE全景LCD 27-50" (对角线), 业界首个完整大格式拉伸宽高比LCD系列
- **PoE**: PoE+或PoE++交换机 (根据型号), 单以太网电缆供电+数据
- **开发策略**: 美国PoE大屏 (27-50") ★★★★★

### 6. SSA Electronic PoE标牌 (中国深圳)
- **类型**: A类 - PoE标牌制造
- **产品**: 15.6" PoE数字标牌, 电容触摸10点, RK3288 CPU 2GB RAM 16GB, Android 8.1, 1280×800, WiFi+以太网+蓝牙4.0, PoE vs传统 (单电缆 vs 双电缆, IT安装 vs 电工, 100m灵活 vs 插座限制, 低压DC安全 vs 110/220V AC, 远程管理 vs 无)
- **开发策略**: 中国深圳PoE标牌制造 ★★★★★

### 7. Premio PoE标牌 (美国)
- **类型**: C类 - PoE标牌方案
- **产品**: PoE数字标牌系列, VoIP+IP摄像头+WiFi AP+IPTV解码器+POS+照明控制+工业+挂钟+安防
- **开发策略**: 美国PoE标牌方案 ★★★★☆

### 8. Kontech PoE标牌 (中国)
- **类型**: A类 - PoE标牌制造
- **产品**: 15.6" PoE数字标牌, 触摸/非触摸, PoE交换机连接单电缆供电+数据
- **开发策略**: 中国PoE标牌制造 ★★★★☆

### 9. TRENDnet PoE标牌 (美国)
- **类型**: B类 - PoE标牌注入器
- **产品**: PoE监视器+PoE注入器简化会议室标牌+状态显示, 单以太网电缆数据+电力, GPO Display PoE监视器+全景LCD配合
- **开发策略**: 美国PoE标牌注入器 ★★★★★

### 10. PoE标牌市场情报
- **类型**: 市场情报
- **PoE标准**: 802.3af 15.4W (10.1"小信息屏), 802.3at PoE+ 25.5W (15.6"中会议室), 802.3bt PoE++ 71.3W (21.5"+大交互亭)
- **优势**: 单电缆 vs 双电缆, IT安装 vs 电工许可, 100m灵活 vs 插座限制, 低压DC安全, 远程管理+UPS应急, 即插即用扩展
- **开发策略**: PoE标牌市场潜力高 ★★★★☆

---

## 📡 三、IoT LoRaWAN网关 PoE

### 11. Seeed Studio SenseCAP M2 (中国)
- **类型**: B类 - LoRaWAN PoE网关
- **产品**: SenseCAP M2, 8通道室内网关, Semtech SX1302芯片, 内置ChirpStack网络服务器, PoE PD支持, 26dBm TX, -139dBm RX, 以太网10/100M+WiFi 2.4G+可选蜂窝
- **开发策略**: 中国LoRaWAN PoE网关 ★★★★★

### 12. Milesight UG系列 (中国)
- **类型**: B类 - LoRaWAN PoE网关
- **产品**: UG63 (USB/DC 5-12V+PoE 802.3af splitter), UG65/UG67 (DC/USB 5V+PoE 802.3af注入器), UG85 (室内3G+4G+GPS+PoE), 室内/户外, Semtech SX1301
- **开发策略**: 中国LoRaWAN PoE网关 ★★★★★

### 13. PUSR USR-LG280 (中国)
- **类型**: B类 - 户外LoRaWAN PoE
- **产品**: USR-LG280户外LoRaWAN网关, IP67防水, -40~70°C, 四核1.5GHz 64位ARM, 802.3af PoE输入/12VDC M12, 3.6W典型4.8W最大, 1GE RJ45 PoE PD, 以太网+WiFi+4G蜂窝
- **开发策略**: 中国户外LoRaWAN PoE IP67 -40~70°C ★★★★★

### 14. Linovision IoT PoE (中国+美国)
- **类型**: A类 - AIoT PoE专家
- **产品**: 户外LoRaWAN网关内置WEB+多云平台兼容, PoE交换机+蜂窝+太阳能系统, PoE over Coax EoC, Mini 2口PoE扩展器, 5口DC9-54V升压千兆, 12口L2+云管DC8-57V升压, 工业8口PoE++ 4×BT90W DC48-56V冗余, 4口Mini太阳能PTZ+无线桥接, 4口MPPT太阳能安防+IoT, 4口96W 802.3bt, PoE注入器90W 802.3bt
- **开发策略**: 中国+美国AIoT PoE专家 ★★★★★

### 15. Lanbras IoT网关 (中国)
- **类型**: B类 - IoT网关
- **产品**: 高性能IoT网关, 边缘设备+云平台无缝连接, 协议转换+边缘计算+安全传输, WiFi+蓝牙+LTE+LoRaWAN, 降低延迟+可扩展 (工业自动化+智慧城市+远程监控)
- **开发策略**: 中国IoT网关 ★★★★☆

---

## 🏢 四、楼宇自动化BMS PoE

### 16. Honeywell PoE Switch Module (美国)
- **类型**: B类 - BMS PoE模块
- **产品**: PoE Switch Module (INNCOM LTC 4267-1), IEEE 802.3af PD接口+电流模式开关稳压器, B574完整供电方案, 8口交换机 (4标准+4 PoE), Honeywell Hospitality品牌 (已停产)
- **开发策略**: 美国BMS PoE模块 (已停产) ★★★★☆

### 17. Honeywell HPOE3X (美国)
- **类型**: B类 - BMS长距离PoE
- **产品**: HPOE3X 4口长距离PoE交换机, 二层, 4×10/100M PoE (802.3af/at 300m) + 1×1000M RJ45 + 1×1000M SFP, IEEE+E100双模式, 8K MAC, MDI/MDIX自适应, 金属结构, 48VDC, 150×100×30mm
- **开发策略**: 美国BMS长距离PoE 300m ★★★★★

### 18. Omnitron OmniConverter BMS (美国)
- **类型**: B类 - BMS PoE光纤
- **产品**: OmniConverter PoE Media Converters+PoE Fiber Switches, 光纤距离扩展+PoE/PoE+/HPoE全RJ-45口最多8 IP摄像头, IP管理 (Web/Telnet/串口), 服务器间PoE交换机+铜UTP连接+光纤延长100m外
- **开发策略**: 美国BMS PoE光纤 ★★★★★

### 19. PoE Partner Texas Switch (德国)
- **类型**: B类 - 智能建筑PoE
- **产品**: PoE Texas Switch, PoE+/PoE++, 智能建筑中央心脏, 单点供电+管理所有建筑技术组件, 90W/口 100m IEEE 802.3bt
- **开发策略**: 德国智能建筑PoE 90W ★★★★★

### 20. Patton FiberPlex BMS (美国)
- **类型**: B类 - 工业PoE BMS
- **产品**: FiberPlex工业级PoE网络交换机, 铁路+水处理+变电站自动化+公路隧道+工厂自动化+IP监控+楼宇自动化系统 (BAS)+楼宇管理系统 (BMS), FP1008EAT EFT/ESD保护, FP1008AT DIN轨+壁挂 -40~75°C
- **开发策略**: 美国工业PoE BMS ★★★★★

### 21. Versa Technology BMS (美国)
- **类型**: B类 - PoE智能建筑
- **产品**: PoE技术智能建筑安装, BMS互操作 (HVAC+照明+安防统一控制), 数据共享优化建筑性能
- **开发策略**: 美国PoE智能建筑BMS ★★★★★

---

## 🏭 五、工业自动化PLC/SCADA PoE

### 22. Siemens SCALANCE (德国)
- **类型**: B类 - 工业PoE自动化领导者
- **产品**: SCALANCE XC-200 PoE, SCALANCE XR-300系列, SCALANCE XP-200管理交换机
- **2025营收**: USD $101M工业PoE管理交换机, CAGR 8.20%
- **特点**: 加固交换机+PROFINET+TSN就绪, 深度集成TIA Portal+SCADA+PoE交换机, 与领先机器制造商合作开发参考架构
- **优势**: 自动化+PLC+SCADA深度集成, 制造+过程工业强安装基础, 先进工业协议支持
- **劣势**: 供应商锁定感知, 高价格, 纯IT网络吸引力有限
- **开发策略**: 德国工业PoE自动化领导者 (PROFINET+TSN) ★★★★★

### 23. Cisco IE + Allen-Bradley Stratix (美国)
- **类型**: B类 - 工业PoE工厂
- **产品**: Cisco IE 2000/3000/4000 (管理+PoE+模块化SFP), Allen-Bradley Stratix (Cisco硬件重品牌+Rockwell FactoryTalk+Studio 5000自动化配置)
- **2024营收**: Cisco USD $120M工业PoE管理交换机#1
- **特点**: 工厂+户外外壳, 意图网络+高级PoE++安全, IT+OT桥接全球生态系统
- **开发策略**: 美国工业PoE工厂 (Cisco+Rockwell) ★★★★★

### 24. Perle IDS PROFINET/Modbus (加拿大)
- **类型**: B类 - 工业PoE协议
- **产品**: IDS-300/IDS-500 PRO功能集, PROFINET/Modbus TCP管理 (PLC/NMS/HMI/SCADA), IDS-509PP 9口管理8×PoE/PoE+ -10~60°C, IDS-710HP加固耐腐蚀+可编程控制器安全+扩展温度+NERC CIP, 无风扇+双电源
- **特点**: 40年Modbus+PROFINET转以太网经验, 最坚固以太网交换机
- **开发策略**: 加拿大工业PoE协议 (PROFINET+Modbus TCP) ★★★★★

### 25. Moxa PROFINET/Modbus/EtherNet/IP (台湾)
- **类型**: B类 - 工业PoE OT
- **产品**: PoE/PoE+/PoE++ 90W/口, 智能交换机简单配置+快速安装+现场监控, 设计简单连接+SCADA/HMI监控+增强可控性, L2智能交换机多工业协议 (PROFINET+Modbus+EtherNet/IP), 多种安装方式, 工业级4kV浪涌/口, Smart PoE管理简化部署+维护
- **2024营收**: USD $70M工业PoE管理交换机#4
- **特点**: 铁路+海事+工厂自动化, 宽温PoE+边缘网关+串口转以太网, 加固部署+OT渠道合作伙伴强
- **开发策略**: 台湾工业PoE OT (PROFINET+Modbus+EtherNet/IP) ★★★★★

### 26. Advantech EKI SCADA (台湾)
- **类型**: B类 - 工业PoE IIoT
- **产品**: EKI-7700系列管理PoE交换机, EKI-9500G加固平台, ProView系列SCADA集成, PoE交换机+边缘网关+AI推理盒捆绑, 云集成扩展 (WISE-PaaS), 目标智慧城市+交通招标
- **2024营收**: USD $55M工业PoE管理交换机#5
- **特点**: 智慧城市+制造+能源, PoE交换机边缘计算+IoT集成, IIoT硬件+网络基础设施融合定位
- **开发策略**: 台湾工业PoE IIoT (SCADA+边缘+AI) ★★★★★

### 27. Antaira LMP-1802-M12-10G (美国)
- **类型**: B类 - 工业PoE汽车制造
- **产品**: LMP-1802-M12-10G-SFP-67-24-T PoE管理以太网交换机, 16口千兆PoE+ M12连接器 30W/口 (802.3af/at) + 2×10G SFP
- **案例**: 汽车制造商项目, M12高振动/冲击/灰尘/液体/气体区域极紧连接
- **开发策略**: 美国工业PoE汽车制造 (M12 10G) ★★★★★

### 28. Phoenix Contact FL SWITCH (德国)
- **类型**: B类 - 工业PoE控制柜
- **产品**: 自动化组件+工业连接, DIN轨管理PoE交换机紧密集成控制柜
- **2025营收**: USD $34.56M工业PoE管理交换机, 网络+通信方案段CAGR 7.80%
- **开发策略**: 德国工业PoE控制柜 ★★★★★

### 29. Westermo 极端加固 (瑞典)
- **类型**: B类 - 工业PoE极端
- **产品**: 极端加固+长距离以太网+现场资产PoE
- **2024营收**: USD $38M工业PoE管理交换机#6
- **特点**: 铁路+海事+公用事业, 极端加固细分领导者
- **开发策略**: 瑞典工业PoE极端加固 (铁路+海事+公用) ★★★★★

### 30. 工业自动化PoE市场情报
- **类型**: 市场情报
- **应用**: 制造+自动化 (PLC+SCADA), 智慧城市+交通 (铁路+公路+监控), 能源+公用 (电网+变电站+风电), 油气 (海上平台+管道)
- **SCADA演进**: 从串口协议到IP, 设备成本更低, 带宽扩展到端站10Gbps+骨干100Gbps, PLC+RTU+传感器+终端设备全PoE供电
- **案例**: 汽车制造商Antaira 16×PoE+ M12 10G SFP, SCADA以太网接入网络PoE受益
- **开发策略**: 工业自动化PoE市场潜力极高 (PLC+SCADA+IIoT) ★★★★★

---

## 📊 Batch 50 统计

- **新增客户/情报**: 30 家
- **聚焦行业**: VoIP IP电话, 数字标牌, IoT LoRaWAN网关, 楼宇自动化BMS, 工业自动化PLC/SCADA
- **覆盖国家**: +2 (加拿大, 德国已有)

---

## 🎯 关键技术发现

1. **VoIP电话**: Yealink全球#1 $100-200 (中国), Poly/Polycom企业耐用Microsoft Teams $150-350 (美国), Cisco企业深度Webex $200-400+ (美国), 802.3af 3-25W, 管理交换机QoS+VLAN+PoE可见性
2. **数字标牌**: GPO Display PoE全景LCD 27-50" (美国), SSA Electronic 15.6"触摸 (中国深圳), Premio方案 (美国), Kontech制造 (中国), TRENDnet注入器 (美国), PoE++ 802.3bt 40-70W
3. **IoT LoRaWAN**: Seeed SenseCAP M2 SX1302 PoE PD+ChirpStack (中国), Milesight UG63/65/67/85 PoE (中国), PUSR USR-LG280 IP67 -40~70°C (中国), Linovision AIoT PoE专家 (中国+美国), Lanbras IoT网关 (中国)
4. **楼宇自动化BMS**: Honeywell INNCOM LTC 4267-1 PoE模块8口 (美国, 停产), Honeywell HPOE3X 4口300m (美国), Omnitron OmniConverter PoE光纤 (美国), PoE Partner Texas 90W/口 (德国), Patton FiberPlex BAS/BMS (美国), Versa BMS HVAC+照明+安防 (美国)
5. **工业自动化PLC/SCADA**: Siemens SCALANCE PROFINET+TSN $101M (德国#2), Cisco IE+Allen-Bradley Stratix $120M (美国#1), Perle IDS PROFINET+Modbus TCP (加拿大), Moxa 90W PROFINET+Modbus+EtherNet/IP $70M (台湾#4), Advantech EKI SCADA+边缘+AI $55M (台湾#5), Antaira M12 10G汽车制造 (美国), Phoenix Contact DIN轨控制柜 $34.56M (德国), Westermo极端加固 $38M (瑞典#6)

---

## 📈 累计统计

- **总客户/情报数**: 1,321 家 (1291 + 30)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 52 次
- **超额完成**: 189% (目标 700客户)
