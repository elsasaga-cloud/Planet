# Batch 59 Part 5: 土耳其住房+零售+银行+港口+油气
## 5渠道: TOKİ世纪住房+BİM/A101/ŞOK/Migros+Ziraat/İşbank/Garanti+Mersin/Ambarlı港+TPAO/BOTAŞ
_2026-10-27 | 17 entries | Turkey Deep Mining Part 5_

---

### 渠道Y: 住房建设 (2家)
- **101.24 TOKİ** 🇹🇷 A类 | **500,000新房**+455,357重建, ₺1.5万亿, 1.76M已建
- **101.25 Emlak Konut GYO** 🇹🇷 A类 | TOKİ旗下REIT, 高端项目

### 渠道Z: 零售连锁 (4家 = 41,217门店)
- **101.26 BİM** 🇹🇷 A类 | **12,751门店**, TL 721B, 70物流中心
- **101.27 A101** 🇹🇷 A类 | **13,600门店**(最多), RICON 4G路由器替换xDSL, 省$4.5M/年
- **101.28 ŞOK** 🇹🇷 B类 | **11,074门店**, Yıldız/Ülker旗下
- **101.29 Migros** 🇹🇷 A类 | **3,792门店**, TL 412.8B, 1954第一家超市, Fitch AA+

### 渠道AA: 银行 (5家 = 5,565分行)
- **101.30 Ziraat Bankası** 🇹🇷 A类 | **1,773分行**, ₺8.47T资产, Ziraat Teknoloji IT子公司
- **101.31 İş Bankası** 🇹🇷 A类 | **1,195分行**, Cisco LAN/WAN升级, 24.3M客户
- **101.32 Garanti BBVA** 🇹🇷 B类 | **797分行**, BBVA 86%, 18.1M移动用户
- **101.33 Akbank** 🇹🇷 C类 | 900+分行
- **101.34 Yapı Kredi** 🇹🇷 C类 | 900+分行

### 渠道AB: 港口 (4港 = 5,000+ PoE)
- **101.35 Mersin MIP** 🇹🇷 A类 | **3.6M TEU, 559 CCTV**, PSA运营, $455M EMH2
- **101.36 Ambarlı** 🇹🇷 A类 | **3.17M TEU**, Kumport用中国招商局CTOS系统
- **101.37 İzmir Alsancak** 🇹🇷 A类 | **$1.5B升级**(2027-2029)
- **101.38 Tekirdağ Asyaport** 🇹🇷 B类 | 2.14M TEU, 转运枢纽

### 渠道AC: 油气 (2家)
- **101.39 TPAO** 🇹🇷 A类 | **Sakarya气田785 bcm**, 9.5→40 mcm/天, Filyos处理厂
- **101.40 BOTAŞ** 🇹🇷 A类 | **90%+国家管网**, TANAP/TurkStream, 3座LNG终端

---

## 关键发现

### 土耳其PoE端口总潜力: 3,300,000+

| 领域 | PoE端口 |
|------|---------|
| TOKİ住房 | 2,500,000+ |
| 4大连锁门店 | 254,000+ |
| 5大银行分行 | 55,000+ |
| 港口 | 5,000+ |
| 油气 | 1,000+ |

### 最佳切入点
1. **A101**: 已在做7,000+门店网络升级(RICON 4G), PoE需求紧迫
2. **Ambarlı Kumport**: 已用中国招商局系统, 接受中国设备
3. **İzmir Alsancak**: $1.5B升级2027启动, 全新PoE采购窗口
4. **BİM**: 年开1,000新店, 持续PoE需求
5. **Ziraat Teknoloji**: IT子公司自研系统, 可嵌入PoE采购链
