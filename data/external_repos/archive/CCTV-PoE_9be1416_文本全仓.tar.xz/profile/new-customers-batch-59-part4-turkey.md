# Batch 59 Part 4: 土耳其二手市场+商会+医院+商场+自贸区
## 5渠道: sahibinden二手+ITO/ATO商会+1514医院+428 AVM+19自贸区
_2026-10-27 | 25 entries | Turkey Deep Mining Part 4_

---

### 渠道T: 二手/翻新市场 (6家)
- **101.1 Trunk.tr** 🇹🇷 B类 | Ataşehir/Istanbul, 服务器+网络+GPU+防火墙
- **101.2 LonglineStore.com** 🇹🇷 B类 | Cisco/Juniper/D-Link/Planet翻新
- **101.3 ServerPark.com.tr** 🇹🇷 B类 | Juniper/Cisco二手
- **101.4 ikincielaliyoruz.com** 🇹🇷 C类 | HP交换机(PoE 10-60K TL)
- **101.5 sahibinden.com渠道** | TP-Link 600TL / Juniper 26K / Cisco 2960X 8.5K / 活跃卖家ADRES/BİLGE/KORKMAZ/AVANTAJ/Logi/Pinet
- **101.6 LonglineNetwork.com** 🇹🇷 C类 | PoE技术教育

### 渠道U: 商会 (4家)
- **101.7 İTO** 🇹🇷 A类 | 1882年, 土耳其最大商会, ito.org.tr, +90 212 455 6000
- **101.8 ATO** 🇹🇷 A类 | 1923年, $31.6M收入, atonet.org.tr
- **101.9 TOBB** 🇹🇷 A类 | 全国商会联合会
- **101.10 企业验证工具** | MERSIS + Trade Registry + 各商会

### 渠道V: 医院 (4家+情报)
- **101.11 Ankara Bilkent Şehir** 🇹🇷 A类 | **3,711床**(欧洲最大), 10,001+员工
- **101.12 İstanbul Sancaktepe Şehir** 🇹🇷 A类 | **4,000床**(2025, 欧洲最大)
- **101.13 Acıbadem** 🇹🇷 B类 | 22医院+18诊所(最大私立连锁)
- **101.14 Memorial** 🇹🇷 B类 | 11医院
- **101.15 行业情报** | **1,514医院**, 21家Şehir Hastanesi, 33,000新床位在建, 99.6B TL预算

### 渠道W: 商场AVM (3家+情报)
- **101.16 Forum İstanbul** 🇹🇷 A类 | 286店铺
- **101.17 ANKAmall** 🇹🇷 A类 | 330+店铺, 120,000m²
- **101.18 Mall of Istanbul** 🇹🇷 A类 | 最大综合体
- **101.19 行业情报** | **428家商场**, Istanbul 100+家

### 渠道X: 自贸区 (3区+情报)
- **101.20 Avrupa Serbest Bölgesi** 🇹🇷 A类 | Çorlu, 150+企业(3M/Foxconn), $2.5B
- **101.21 Ege Serbest Bölgesi** 🇹🇷 A类 | Izmir, 土耳其最大, 港口
- **101.22 Mersin Serbest Bölgesi** 🇹🇷 B类 | 最大集装箱港, 1985
- **101.23 行业情报** | **19自贸区, 2000+企业, $25B贸易**, 0%企业所得税+0%VAT+0%关税

---

## 关键发现

### 土耳其PoE六大隐藏市场
1. **1,514家医院** — 每家需IP摄像头+AP+护士呼叫+门禁
2. **428家商场** — 每家需摄像头+WiFi+停车+门禁
3. **19个自贸区** — 0%税进口PoE交换机+分销
4. **341个工业区** — 55,000企业PoE需求
5. **628家酒店** — 145K房间PoE需求
6. **129所大学** — 校园PoE需求

### 自贸区 = Saga理想分销基地
- Avrupa FZ(Çorlu): 150+国际企业, 紧邻Istanbul
- Ege FZ(Izmir): 港口+中东/非洲出口
- Mersin FZ: 最大港口, 中东跳板
- **0%企业所得税 + 0% VAT + 0%关税** = 极低成本进口
