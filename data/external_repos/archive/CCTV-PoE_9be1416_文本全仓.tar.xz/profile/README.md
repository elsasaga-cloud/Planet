# 客户档案目录 (Customer Profile Index)

> 本文件夹包含所有海外目标客户的详细分析档案。  
> 每个MD文件包含：公司信息、市场分析、需求特点、联系人信息、跟进计划等。

---

## A级客户（核心 - 立即跟进）

| 文件名 | 客户名称 | 国家 | 类型 | 年采购潜力 |
|--------|---------|------|------|-----------|
| [AAC-Distribution-Malaysia.md](AAC-Distribution-Malaysia.md) | AAC Distribution | 马来西亚 | 进口/批发 | $50K-$100K |
| [Mahadev-Computers-India.md](Mahadev-Computers-India.md) | Mahadev Computers | 印度 | 批发/分销 | $30K-$60K |
| [Regal-Security-SouthAfrica.md](Regal-Security-SouthAfrica.md) | Regal Security | 南非 | 分销龙头 | $100K-$200K |
| [Security-Warehouse-SouthAfrica.md](Security-Warehouse-SouthAfrica.md) | Security Warehouse | 南非 | 分销 | $50K-$100K |
| [CCTV-CameraWorld-USA.md](CCTV-CameraWorld-USA.md) | CCTV Camera World | 美国 | OEM/直销 | $200K-$500K |
| [DSE-Torino-Italy.md](DSE-Torino-Italy.md) | DSE Torino | 意大利 | OEM/零售 | €50K-€150K |
| [GCTL-Bangladesh.md](GCTL-Bangladesh.md) | GCTL | 孟加拉 | 进口/分销 | $20K-$40K |
| [CCTV-Direct-SouthAfrica.md](CCTV-Direct-SouthAfrica.md) | CCTV Direct | 南非 | 零售/分销 | $20K-$50K |

## B级客户（重点 - 积极开发）

| 文件名 | 客户名称 | 国家 | 类型 | 年采购潜力 |
|--------|---------|------|------|-----------|
| [AlAqili-UAE.md](AlAqili-UAE.md) | Al Aqili Future Technologies | UAE | 区域分销 | $50K-$150K |
| [Bluvalue-UAE.md](Bluvalue-UAE.md) | Bluvalue | UAE/沙特 | 解决方案 | $40K-$100K |
| [Intertrade-Security-SouthAfrica.md](Intertrade-Security-SouthAfrica.md) | Intertrade Security | 南非 | 批发 | $30K-$80K |
| [Paktron-Pakistan.md](Paktron-Pakistan.md) | Paktron | 巴基斯坦 | 安装商 | $15K-$30K |
| [OMEIO-Singapore.md](OMEIO-Singapore.md) | OMEIO International | 新加坡 | 区域分销 | $30K-$60K |
| [PT-Pasifik-Indonesia.md](PT-Pasifik-Indonesia.md) | PT. Pasifik Teknologi | 印尼 | 分销 | $20K-$50K |
| [AVExport-LatinAmerica.md](AVExport-LatinAmerica.md) | AV Export | 拉美/加勒比 | 分销 | $20K-$50K |

## C级客户及其他（储备 + 批量档案）

| 文件名 | 客户列表 | 备注 |
|--------|---------|------|
| [other-customers-batch.md](other-customers-batch.md) | 12+客户批量档案 | 包含Speed4Trading/EPM/EET Europarts等 |

---

## 跟进优先级建议

### 第一周行动（A级客户）
1. ✅ AAC Distribution — 马来西亚（邮件+LinkedIn）
2. ✅ Mahadev Computers — 印度（邮件+WhatsApp）
3. ✅ Regal Security — 南非（老板亲自邮件）
4. ✅ Security Warehouse — 南非（邮件+电话）
5. ✅ CCTV Camera World — 美国（OEM合作邮件）
6. ✅ DSE Torino — 意大利（OEM合作邮件）

### 第二周行动
7. GCTL — 孟加拉（WhatsApp）
8. CCTV Direct — 南非（邮件）
9. Al Aqili — UAE（邮件）
10. Bluvalue — UAE/沙特（邮件+LinkedIn）

### 第三周行动
11. Intertrade Security — 南非
12. Paktron — 巴基斯坦
13. OMEIO — 新加坡
14. PT. Pasifik Teknologi — 印尼

### 第四周行动
15. EET Europarts — 欧洲
16. Speed 4 Trading — 埃及
17. AV Export — 拉美
18. 其他C级客户

---

## 统计

| 指标 | 数量 |
|------|------|
| 总客户数 | 46 |
| A级客户 | 8 |
| B级客户 | 12 |
| C级客户 | 26 |
| 覆盖国家 | 20+ |
| 预估年采购总额 | $1M-$2.5M |
