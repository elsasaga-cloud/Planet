# Batch 12 — 泰国分销 + 柬埔寨缅甸 + 全球展会 + 品牌扩展
> 深度挖掘 Round 23-26 (2026-10-25)
> 方法论：泰语搜索 / 东南亚小国分销 / 全球展会分析 / 品牌扩展情报

---

## 一、C类：泰国PoE交换机分销商（13家）

### 1. JRP Distribution（曼谷）
- **类型**: C类 — Ruijie/Reyee/Teltonika分销
- **网站**: jrp.co.th
- **地址**: 230/51 Soi Krungthonburi 6, Khlong San, BKK 10600
- **电话**: 02-4371210
- **邮箱**: sale@cyn.co.th
- **品牌**: Ruijie Reyee (全线PoE: RG-NBS3200/3100/5300/ES2系列)
- **开发策略**: 泰国Ruijie专业分销，可推Saga替代
- **置信度**: ★★★★★

### 2. Zeus-IT Thailand（曼谷）
- **类型**: C类 — CCTV/网络/光纤
- **网站**: zeus-it-thailand.com
- **品牌**: Ruijie Reyee PoE交换机 (RG-ES05F/08F/106F-P/110F-P/NBS3100)
- **开发策略**: 泰国安防+网络设备
- **置信度**: ★★★★☆

### 3. ThaiCCTVShop / ANA System（曼谷）
- **类型**: C类 — Hikvision/Dahua PoE
- **网站**: thaicctvshop.com
- **地址**: 79/54 Thanon Chaeng Watthana, Bang Khen, BKK 10220
- **电话**: 02-970-1181-2 / 082-444-5171 / 099-392-5654
- **邮箱**: info@thaicctvshop.com
- **品牌**: Hikvision (DS-3E0318P-E/DS-3E0109P-E)
- **开发策略**: 泰国CCTV专业分销
- **置信度**: ★★★★★

### 4. ITK Connecting（曼谷）
- **类型**: C类 — 多品牌PoE交换机
- **网站**: itk.co.th
- **电话**: 02-4609200
- **品牌**: Ubiquiti/Cisco/HP/Aruba/ONV
- **开发策略**: 曼谷IT分销，Cisco全线
- **置信度**: ★★★★★

### 5. 108connect（泰国）
- **类型**: C类 — 多品牌网络交换机
- **网站**: 108connect.co.th
- **品牌**: Hikvision/Ruijie/Ubiquiti/PLANET/D-Link
- **开发策略**: 泰国网络交换机零售
- **置信度**: ★★★★☆

### 6. PBA Supply（泰国）
- **类型**: C类 — Hyperlink PoE交换机
- **网站**: pbasupply.net
- **产品**: Hyperlink HP8EP+2E (8CH+2LAN 790THB), HP16EP+2G+2F (16CH+2G+2SFP 2850THB)
- **开发策略**: 泰国安防配件分销
- **置信度**: ★★★★☆

### 7. Sysnetcenter（泰国）
- **类型**: C类 — Reyee PoE交换机
- **网站**: sysnetcenter.com
- **品牌**: Reyee (RG-NBS3200-48GT4XS-P-V2 L2 管理型PoE 48口 370W)
- **开发策略**: 泰国Reyee渠道
- **置信度**: ★★★★☆

### 8. TotalIT（泰国）
- **类型**: C类 — TP-Link Omada PoE全线
- **网站**: totalit.co.th
- **品牌**: TP-Link Omada (ES206XPP-M2/ES205GP/ES228GP/SX3832MPP/SG3210XHP-M2等)
- **开发策略**: 泰国TP-Link专业渠道
- **置信度**: ★★★★★

### 9. E-Express（泰国）
- **类型**: C类 — Glink/Ubiquiti/TP-Link
- **网站**: e-express.co.th
- **品牌**: Glink (GPOE-04工业PoE), Ubiquiti, TP-Link
- **开发策略**: 泰国网络设备零售
- **置信度**: ★★★★☆

### 10. SAT Digital（曼谷）
- **类型**: C类 — 光纤/PoE交换机
- **网站**: satsdigital.com
- **地址**: 88/468 Sampeng 2, Soi 5/4, Bang Khae, BKK 10160
- **开发策略**: 曼谷光纤/PoE专业分销
- **置信度**: ★★★★☆

### 11. Sysinfo（泰国）
- **类型**: C类 — TP-Link PoE + 技术支持
- **网站**: sysinfo.co.th
- **品牌**: TP-Link (TL-SG1008MP 8口千兆PoE+ 153W)
- **开发策略**: 有技术支持的IT零售
- **置信度**: ★★★★☆

### 12. Advice（泰国）
- **类型**: C类 — 大型IT零售连锁
- **网站**: advice.co.th
- **品牌**: TP-Link (TL-SG1008P 8口千兆PoE 64W)
- **开发策略**: 泰国最大IT零售之一
- **置信度**: ★★★★★

### 13. SiamLancard（泰国）
- **类型**: C类 — PoE交换机评测+销售
- **网站**: siamlancard.com
- **品牌**: TP-Link/Ubiquiti/Cisco/Netgear
- **开发策略**: 泰国网络设备专业零售
- **置信度**: ★★★☆☆

---

## 二、C类：缅甸 + 柬埔寨（3家）

### 14. ICT Myanmar（仰光）
- **类型**: C类 — PoE交换机
- **网站**: ict.com.mm
- **地址**: 369 Laydaungkan Road, Thingangyun 11071 Yangon
- **电话**: 0976 544 1707/08/09/10
- **开发策略**: 缅甸IT设备在线零售
- **置信度**: ★★★★★

### 15. Root IT Support（金边，柬埔寨）
- **类型**: C类 — Huawei/Wi-Tek PoE
- **网站**: rootitsupport.com
- **品牌**: Huawei (S110-24T2SR), Wi-Tek (WI-PS328GF 24口千兆PoE+4SFP)
- **开发策略**: 柬埔寨IT服务商
- **置信度**: ★★★★☆

### 16. PTC Computer（柬埔寨）
- **类型**: C类 — Hikvision/Planet PoE
- **网站**: ptc-computer.com.kh
- **品牌**: Hikvision (DS-3E1526P-SI/DS-3E1552P-SI/DS-3E1518P-SI/DS-3E0526P-E), Planet (MGS-910XP)
- **开发策略**: 柬埔寨Hikvision PoE渠道
- **置信度**: ★★★★★

---

## 三、展会情报（2026年全球安防展）

### 17. Securex South Africa 2026（约翰内斯堡）
- **日期**: 2026年6月2-4日
- **地点**: Gallagher Convention Centre
- **规模**: 270+展商, 30+国家, 7129+访客
- **联系**: zelda.jordaan@montgomerygroup.com
- **开发策略**: 非洲最大安防展，已有Batch 1-4客户基础
- **置信度**: ★★★★★

### 18. Securex Uzbekistan 2026（塔什干）
- **日期**: 2026年11月10-12日
- **地点**: Uzexpocentre NEC
- **开发策略**: 乌兹别克安防展，配合Batch 10中亚客户
- **置信度**: ★★★★★

### 19. Securex Egypt 2026（开罗）
- **日期**: 2026年6月23-25日
- **地点**: Egypt International Exhibition Center
- **开发策略**: 北非/中东安防展
- **置信度**: ★★★★★

### 20. Securex Poland 2026（波兹南）
- **日期**: 2026年4月14-16日
- **地点**: Poznań
- **开发策略**: 东欧安防展
- **置信度**: ★★★★☆

### 21. ISAF 2026（伊斯坦布尔）
- **日期**: 2026年10月7-10日
- **地点**: Istanbul Expo Center (IFM)
- **开发策略**: 土耳其安防展
- **置信度**: ★★★★★

### 22. Expo Seguridad México 2026（墨西哥城）
- **日期**: 2026年6月2-4日
- **开发策略**: 拉丁美洲安防展
- **置信度**: ★★★★☆

### 23. GISEC Global 2026（迪拜）
- **日期**: 2026年5月5-7日
- **地点**: Dubai Exhibition Centre, Expo City
- **规模**: 750+网络安全品牌
- **开发策略**: 中东网络安全展
- **置信度**: ★★★★☆

---

## 四、品牌/技术情报

### 24. Hexatronic（瑞典/全球）
- **类型**: B类 — InOne光纤PoE方案
- **网站**: hexatronic.com
- **产品**: InOne Powered Fiber — CCTV/IoT的未来网络
- **开发策略**: PoE光纤混合方案，技术趋势
- **置信度**: ★★★★☆

### 25. Mayflex（英国）
- **类型**: C类 — 英国PoE交换机分销
- **网站**: mayflex.com
- **品牌**: Axis T8504-E户外PoE, Reyee, SilverNet
- **开发策略**: 英国网络设备分销
- **置信度**: ★★★★☆

### 26. QSFPTEK（中国/全球）
- **类型**: 竞品 — PoE交换机
- **网站**: qsfptek.com
- **市场**: 老挝等东南亚国家
- **开发策略**: PoE交换机竞品
- **置信度**: ★★★☆☆

### 27. NextStore（科威特）
- **类型**: C类 — 科威特网络设备零售
- **网站**: nextstore.com.kw
- **品牌**: Tenda (5口/9口/24口L3 PoE)
- **开发策略**: 科威特IT零售
- **置信度**: ★★★★☆

---

**Batch 12 总计: 27家新客户 + 7条展会情报**

> 关键发现：
> 1. **泰国13家PoE分销商** — JRP(Ruijie)/ThaiCCTVShop/ITK/108connect/PBA/TotalIT/E-Express/Advice等
> 2. **缅甸+柬埔寨3家** — ICT Myanmar/Root IT Cambodia/PTC Computer Cambodia
> 3. **2026年全球7个安防展** — Securex南非/乌兹别克/埃及/波兰 + ISAF土耳其 + Expo墨西哥 + GISEC迪拜
> 4. **品牌情报4家** — Hexatronic/ Mayflex/QSFPTEK/NextStore科威特
