# Batch 34 — 采矿/水处理/工厂自动化 + 边缘计算 + 更多中东 + 中国OEM新
> 深度挖掘 Round 115-118 (2026-10-25)
> 方法论：采矿PoE / 边缘计算 / 工厂自动化 / 黎巴嫩+约旦+伊拉克+阿曼+巴林 / 中国新OEM

---

## 一、采矿/水处理/油气 PoE

### 1. UTEPO采矿方案
- **类型**: B类 — 采矿PoE
- **网站**: utepo.net
- **产品**: UTP7208E-POE-A1工业接入 + 10G核心环网
- **特色**: Fast Ring+ERPS 20ms自愈, -40~75°C, 6KV浪涌, PoE Watchdog, L2/L3管理
- **开发策略**: 深圳采矿PoE方案
- **置信度**: ★★★★★

### 2. Westermo LKAB Kiruna矿 (瑞典)
- **类型**: B类 — 采矿PoE案例
- **产品**: Viper (IP65 M12 EN50155) + RedFox工业路由交换机
- **应用**: IP电话+WiFi AP, PoE统一备份电源
- **开发策略**: 瑞典采矿PoE标杆
- **置信度**: ★★★★★

### 3. Maestro Digital Mine SuperBrite (加拿大)
- **类型**: B类 — 地下采矿PoE显示
- **事件**: 2026.2 PoE SuperBrite Marquee Display
- **应用**: 实时环境+通风数据 (气流/气体/湿度/温度)
- **集成**: Vigilante AQS + Zephyr AQS空气质量监测
- **开发策略**: 地下采矿PoE IoT品牌
- **置信度**: ★★★★★

### 4. Patton FiberPlex工业PoE
- **类型**: B类 — 工业PoE
- **产品**: FP1008E/AT (10口30W, -40~75°C) + FP2008E/AB (12口4x90W+4x30W双冗余光纤环)
- **开发策略**: 美国工业PoE+双冗余
- **置信度**: ★★★★★

### 5. Perle工业PoE (734型号)
- **类型**: B类 — 工业PoE全线
- **产品**: 734型号, -40~75°C, 100W PoE, PROFINET/Modbus TCP
- **开发策略**: 加拿大工业PoE全线
- **置信度**: ★★★★★

---

## 二、边缘计算 / Micro Data Center ★★★★★

> **市场数据**: 边缘计算 $83.72B (2024) → $1531B (2035) CAGR 30.23%, 边缘数据中心 $40.46B→$109.2B CAGR 16.5%, AI数据中心交换机 $4B→$19B CAGR 29.9%

### 6. Lantronix SmartEdge.ai + SmartSwitch.ai
- **类型**: B类 — Edge AI PoE
- **产品**: SmartEdge.ai 5G网关 (Qualcomm QCS6490) + SmartSwitch.ai PoE+聚合+AI
- **事件**: CES 2026 Jan 6首发
- **开发策略**: 边缘AI+PoE融合方案
- **置信度**: ★★★★★

### 7. Cisco Unified Edge
- **类型**: 竞品 — 边缘AI
- **事件**: Partner Summit 2025 Nov 3, 网络+计算+存储+安全一体化
- **开发策略**: Cisco边缘AI竞品
- **置信度**: ★★★★★

### 8. Supermicro边缘AI
- **类型**: 竞品 — 边缘AI硬件
- **产品**: Intel NPU + GPU + 32GB VRAM, 零售/制造/安防/物流
- **开发策略**: Supermicro边缘AI竞品
- **置信度**: ★★★★★

### 9. Duos Edge AI + Accu-Tech
- **类型**: B类 — 边缘AI合作
- **事件**: 2025.7战略合作
- **开发策略**: 边缘AI部署合作
- **置信度**: ★★★★☆

### 10. PoliCloud (法国)
- **类型**: B类 — 微型边缘数据中心
- **事件**: 2025.6 €7.5M融资, 欧洲微型边缘数据中心扩张
- **开发策略**: 欧洲微型边缘数据中心
- **置信度**: ★★★★☆

---

## 三、更多中东（黎巴嫩/约旦/伊拉克/阿曼/巴林）★★★★★

### 11. HI-GAIN Lebanon (贝鲁特)
- **类型**: C类 — 黎巴嫩分销
- **网站**: hi-gain.net
- **成立**: 1990 (35年), Dora Beirut
- **品牌**: MikroTik/Ubiquiti/Cambium/Mimosa
- **开发策略**: 黎巴嫩PoE老牌分销
- **置信度**: ★★★★★

### 12. Tech Store Lebanon
- **类型**: C类 — Ubiquiti全线
- **网站**: techstorelb.com
- **产品**: USW-PRO-48-POE/USW-PRO-24-POE/USW-24-POE
- **开发策略**: 黎巴嫩Ubiquiti分销
- **置信度**: ★★★★☆

### 13. Al-Ruwwad Jordan (安曼)
- **类型**: C类 — 约旦Dahua
- **网站**: al-ruwwad.com
- **产品**: Dahua S4100/PFS4218/PFS3211/PFS3008全线PoE (JD 12-245)
- **开发策略**: 约旦Dahua PoE分销
- **置信度**: ★★★★★

### 14. Smart Systems Lebanon
- **类型**: C类 — Dahua黎巴嫩
- **事件**: Dahua黎巴嫩分销商
- **开发策略**: 黎巴嫩Dahua分销
- **置信度**: ★★★★☆

### 15. Microless Kuwait + UAE
- **类型**: C类 — 海湾电商
- **网站**: microless.com
- **产品**: D-Link DES-1018P Kuwait + TP-Link Omada ES220GMP UAE
- **开发策略**: 海湾PoE电商
- **置信度**: ★★★★☆

### 16. Emirtech Technology Abu Dhabi
- **类型**: C类 — 系统集成
- **网站**: emirtech.ae
- **认证**: ADMCC批准
- **应用**: 小办公室到大型政府/工业
- **开发策略**: 阿布扎比PoE集成
- **置信度**: ★★★★☆

---

## 四、工厂自动化 PoE ★★★★★

> **市场数据**: 工业PoE管理交换机制造应用 28.3%份额 $0.56B (2025), 15-25管理交换机/工厂, 40-80边缘设备/交换机

### 17. Omnitron RuggedNet机器人工厂
- **类型**: B类 — 机器人制造PoE
- **产品**: RuggedNet GHPoEBT (100W PoE++/口, 管理型)
- **应用**: 自动机器人装配线
- **开发策略**: 机器人制造PoE案例
- **置信度**: ★★★★★

### 18. Molex工业以太网交换机
- **类型**: 竞品 — 工业PoE
- **产品**: IP20/IP67, 5/8口, 10/100/1000, EtherNet/IP + PROFINET
- **开发策略**: Molex工业PoE竞品
- **置信度**: ★★★★★

### 19. Allen-Bradley Stratix
- **类型**: 竞品 — 工厂自动化
- **产品**: Cisco IE贴牌+Rockwell FactoryTalk/Studio 5000
- **开发策略**: Rockwell工厂PoE竞品
- **置信度**: ★★★★★

### 20. E-Lins Industrial PoE
- **类型**: B类 — IIoT PoE
- **产品**: 工业PoE (Modbus/PROFINET/EtherNet/IP, IEC 60068)
- **开发策略**: IIoT工业PoE
- **置信度**: ★★★★☆

---

## 五、中国OEM新品牌

### 21. Lanao Communication (深圳)
- **类型**: A类 — 工业PoE OEM
- **网站**: lanaotek.com
- **产品**: 工业快速以太网PoE, L2+管理 (24xGbE + 4x1G/2.5G SFP)
- **开发策略**: 深圳工业PoE OEM
- **置信度**: ★★★★☆

### 22. ONV (深圳光网视频)
- **类型**: A类 — PoE全线OEM大厂
- **网站**: onvcom.com
- **规模**: 30000m²工厂 (钣金/电源/交换机/中央实验室/数字仓储/PoE自动化, 6xSMT+6xDIP)
- **出口**: 120+国
- **开发策略**: 深圳PoE OEM龙头
- **置信度**: ★★★★★

### 23. ELINPOE / Dongguan Elink
- **类型**: A类 — 工业PoE OEM
- **网站**: elinkpoe.com
- **产品**: 工业交换机/PoE/电源/光纤, SMT+DIP全线
- **开发策略**: 东莞工业PoE OEM
- **置信度**: ★★★★☆

### 24. SYPOE / DeepRock (深圳)
- **类型**: A类 — PoE OEM大厂
- **规模**: 5000m², 15+工程师, Yamaha/Fuji SMT, 50000台/月
- **认证**: CE/FCC/RoHS/ISO 9001
- **开发策略**: 深圳PoE OEM大厂
- **置信度**: ★★★★★

### 25. Cobtel Precision Electronics (广东)
- **类型**: A类 — OEM
- **规模**: 60工程师R&D, 100% QC, 11年
- **开发策略**: 广东PoE OEM
- **置信度**: ★★★☆☆

### 26. Hzgws Technologies (广东)
- **类型**: A类 — OEM大厂
- **规模**: 110+员工, 13000m², 100%交付
- **开发策略**: 广东PoE OEM大厂
- **置信度**: ★★★☆☆

### 27. Beijing Fengyuan Tengda (北京)
- **类型**: A类 — OEM
- **规模**: 37%复购率, $190K在线收入
- **开发策略**: 北京PoE OEM
- **置信度**: ★★★☆☆

---

**Batch 34 总计: 27家新客户/情报**

> 关键发现：
> 1. **采矿/油气5家** — UTEPO Fast Ring+ERPS 20ms/Westermo LKAB Kiruna IP65/Maestro 2026.2 SuperBrite PoE/Patton FP2008E双冗余/Perle 734型号PROFINET
> 2. **边缘计算5家** — Lantronix SmartEdge.ai+SmartSwitch.ai CES 2026/Cisco Unified Edge 2025.11/Supermicro Intel NPU+GPU/Duos+Accu-Tech/PoliCloud法国€7.5M
> 3. **更多中东6家** — HI-GAIN黎巴嫩35年MikroTik/Tech Store LB Ubiquiti/Al-Ruwwad约旦Dahua JD/Smart Systems LB Dahua/Microless Kuwait+UAE/Emirtech ADMCC
> 4. **工厂自动化4家** — Omnitron RuggedNet机器人/Molex IP20/IP67 PROFINET/Allen-Bradley Stratix Rockwell/E-Lins IIoT
> 5. **中国OEM 7家** — Lanao工业L2+/ONV 30000m² 120+国龙头/ELINPOE东莞/SYPOE 5000m² 50K台/Cobtel 60工程师/Hzgws 13000m²/Fengyuan Tengda 37%复购
