# Batch 44 — 危险环境+交通PoE：ATEX防爆 + 交通路口 + 机场 + 智能停车

**日期**: 2026-10-25  
**搜索轮次**: Round 164-168  
**新增客户/情报**: 24 家  
**聚焦**: 矿山ATEX/IECEx, 炼油厂防爆, 交通路口, 机场航空, 智能停车

---

## ⚠️ 一、矿山/炼油厂防爆 PoE (ATEX/IECEx)

### 1. Axis Ex Connection Rail (瑞典)
- **类型**: B类 - 防爆PoE专家
- **产品**:
  - Ex Connection Rail 4-port PoE PS24: 4口30W PoE, ATEX+IECEx Ex d IIC/IIIC, 单模/多模光纤, 耐腐蚀
  - ExConnection Rail 4-Port POE++: 管理千兆4口PoE++ 60W/口 240W + 2xRJ45 + 2xSFP, ATEX+IECEx+EAC-Ex, IP66, -40°C
- **应用**: 危险区域 (Hazardous Areas), 连接防爆网络摄像头
- **开发策略**: 瑞典防爆PoE专家 ★★★★★

### 2. SAMCON ExConnection Rail (德国)
- **类型**: B类 - 防爆PoE
- **产品**: T04 ExConnection Rail系列, 压力密封外壳, 高性能PoE交换机, 4口ExCam, ATEX+IECEx, IP66, -60°C极寒
- **特点**: 24VDC 4x摄像头加热器供电
- **开发策略**: 德国防爆PoE ★★★★★

### 3. Larson Electronics ATEX-EXP-IP-POE-INJ (美国)
- **类型**: B类 - 防爆PoE注入器
- **产品**: ATEX-EXP-IP-POE-INJ-24V-30W-HLP, 30W防爆PoE注入器, ATEX+IECEx, Ex II 2 G/D, IP66, NEMA 3/4/4X/7/9, 24V 1.25A, $1,470
- **应用**: 防爆摄像头+传感器PoE功能
- **开发策略**: 美国防爆PoE注入器 ★★★★★

### 4. Hirschmann BOBCAT BRS22 (德国)
- **类型**: B类 - 工业PoE Class 1 Div 2
- **产品**:
  - BRS22-8TX-HL: 8口100M PoE, DIN轨, 冗余48/54VDC, 0~60°C, cUL61010 + C1D2, HiOS L2管理, $2,476
  - BRS22-8TX-EEC-HL: 扩展温度版本
- **开发策略**: 德国工业PoE Class 1 Div 2 ★★★★★

---

## 🛢️ 二、油气炼油厂 PoE

### 5. Perle IDS-110HP (加拿大)
- **类型**: B类 - 工业PoE 90W
- **产品**: IDS-110HP, 10口: 8x千兆90W 802.3bt + 2xSFP, 管理, 继电器, -10~60°C, DIN轨
- **应用**: 工业自动化, 政府, 军事, 油气, 矿业, 户外
- **开发策略**: 加拿大工业PoE 90W油气 ★★★★★

### 6. Versa Technology 油气PoE (美国)
- **类型**: B类 - 油气PoE方案
- **产品**: 4款PoE油气解决方案, 90W PoE++, 单电缆传输电力+数据
- **特点**: 降低安装维护成本, 设备位置灵活
- **开发策略**: 美国油气PoE方案 ★★★★★

### 7. barox 油气炼油厂 (全球)
- **类型**: B类 - 炼油厂以太网
- **案例**: 中东最大区域石油公司旗舰项目, PKE Gulf WLL安装barox专业以太网交换机, 提供可靠视频传输+PoE
- **开发策略**: 全球炼油厂以太网PoE ★★★★★

### 8. Veilux SVEX防爆摄像头 (美国)
- **类型**: B类 - 防爆摄像头 (PoE应用)
- **产品**: SVEX系列, ATEX+IECEx双认证, 316L不锈钢, IP68, PTZ 30x变焦, 2MP-8MP
- **应用**: 油气设施防爆摄像头 (2025最佳)
- **开发策略**: 美国防爆摄像头PoE应用 ★★★★★

---

## 🚦 三、交通路口 PoE (ITS)

### 9. Transition Networks NYC交通 (美国)
- **类型**: B类 - 交通PoE大项目
- **案例**: 纽约市交通局 (NYCDOT) 10,000+交通路口, SISPM1040-384-LRT-C管理加固千兆PoE+, 8口30W/口, TAA合规
- **特点**:
  - Auto Power Reset (APR): 远程重启, 几分钟修复, 消除车道关闭
  - Device Management System (DMS): 交互地图查看所有连接设备
  - 户外环境, 连接+供电+管理交通数据
- **开发策略**: 美国交通PoE大项目专家 ★★★★★

### 10. Planet Technology 交通系列 (台湾)
- **类型**: B类 - 交通PoE
- **产品**:
  - 高速公路&交通: 16口千兆PoE+ 36W/口 320W + 2xSFP + 2上行, ERPS环+快速恢复, -40~75°C, 防雷, SNMP
  - IGT-805AT: 壁挂工业PoE, 8口千兆4xPoE+, 144W, -40~75°C
  - IPOE-162: 混合太阳能PoE, 5口+SFP, 太阳能+DC+电池, 65W, 250m扩展, -20~65°C
- **开发策略**: 台湾交通PoE ★★★★★

### 11. Omnitron Systems RuggedNet (美国)
- **类型**: B类 - 交通PoE
- **产品**:
  - OmniConverter 10G/M: 10G以太网交换机
  - RuggedNet GHPoEBT/Mi: 工业PoE, 4口千兆802.3bt 100W
  - 交通灯网络: RSU数据收集器/发射器, 抢占系统, PTZ摄像头, 交通灯
- **开发策略**: 美国交通PoE ★★★★★

### 12. Vigitron Vi30208 (美国)
- **类型**: B类 - 交通PoE
- **产品**: Vi30208, 4+2口10/100/1000/2500Mbps, 90W 802.3bt 495W总输入, -40~70°C NEMA-TS 2, G.8032 V1/V2快速环
- **应用**: 关键交通应用测试
- **开发策略**: 美国交通PoE NEMA-TS 2 ★★★★★

### 13. AXIS D8208-R 高速公路 (瑞典)
- **类型**: B类 - 工业PoE++交通
- **产品**: D8208-R, 管理工业PoE++ 8口千兆90W 480W + 2xSFP+ 10G, 加固, -40~60°C, 抗震振动
- **应用**: 高速公路, 隧道, 工业, 户外, 铁路, 港口
- **开发策略**: 瑞典工业PoE++交通 ★★★★★

### 14. Korenix Jetnet 3908G-M12 (台湾)
- **类型**: B类 - 交通PoE M12
- **产品**: Jetnet 3908G-M12, 工业全千兆非管理升压PoE, 8口千兆PoE/PSE + 设备故障Bypass, M12连接器, EN50155+EN50121-4+E-Mark+ITxPT, 10K Jumbo Frame, DC54V升压, 旋转开关电源延迟关闭+点火感应
- **应用**: 铁路交通, 地铁, IP监控恶劣环境
- **开发策略**: 台湾交通PoE M12 ★★★★★

### 15. AVCOMM 6000-PoE (美国)
- **类型**: B类 - 智能交通系统
- **产品**: AVCOMM 6000-PoE + AVCOMM 8000系列工业以太网交换机, 96Gbps带宽, 全千兆, QoS
- **案例**: 100个摄像头CCTV PTZ系统, 每摄像头4-8MB, 总400-800MB交换容量
- **特点**: 全千兆+PoE工业交换机适合路边安装, 节省布线成本
- **开发策略**: 美国智能交通系统PoE ★★★★★

### 16. e-link 智能交通 (美国)
- **类型**: B类 - 智能交通
- **应用**: 交通路口控制, 紧凑工业管理交换机路边机柜, VLAN分段关键交通数据, QoS优先信号命令
- **开发策略**: 美国智能交通PoE ★★★★★

---

## ✈️ 四、机场航空 PoE

### 17. Omnitron 机场案例 (美国)
- **类型**: B类 - 机场PoE
- **案例**: 主要国际机场WiFi+监控, iConverter千兆媒体转换器19模块机箱+SNMP管理, 18路千兆光纤分发, OmniConverter PoE媒体转换器光纤转铜+PoE+供电WiFi AP
- **特点**: 远程重启WiFi AP (光纤端口关闭/断开), 无需物理访问设备, 无需昂贵AC电源插座
- **开发策略**: 美国机场PoE专家 ★★★★★

---

## 🅿️ 五、智能停车 PoE

### 18. Omnitron 智能停车 (美国)
- **类型**: B类 - 智能停车PoE
- **方案**: OmniConverter 10G PoE+交换机控制中心, PoE交换机战略性部署停车设施, 创建稳健高效网络基础设施
- **开发策略**: 美国智能停车PoE ★★★★★

### 19. Conduent 智能停车 (美国)
- **类型**: C类 - 智能停车大厂商
- **2024营收**: $1,100M, CAGR 12%
- **2025亮点**: 扩展智能交通+停车方案到20+美国城市
- **开发策略**: 美国智能停车大厂商 ★★★★☆

### 20. SKIDATA 智能停车 (奥地利)
- **类型**: C类 - 智能停车
- **2024营收**: $950M, CAGR 13%
- **2025亮点**: 发布云端AI驱动门禁控制 (机场+体育场), 收购ePARK (瑞典APP智能停车)
- **开发策略**: 奥地利智能停车 ★★★★☆

### 21. Amano McGann (美国/日本)
- **类型**: C类 - 智能停车
- **2024营收**: $870M, CAGR 11%
- **2025亮点**: 东京+纽约部署机器人停车系统
- **开发策略**: 美国/日本智能停车 ★★★★☆

### 22. Streetline 智能停车 (美国)
- **类型**: C类 - 智能停车
- **2024营收**: $420M, CAGR 15%
- **2025亮点**: 发布AI驱动分析优化市政停车
- **开发策略**: 美国智能停车AI ★★★★☆

### 23. Cisco 智能停车 (美国)
- **类型**: C类 - 智能停车
- **2024营收**: $1,500M, CAGR 10%
- **2025亮点**: 集成IoT停车+全球智能城市网络
- **开发策略**: 美国智能停车IoT ★★★★☆

### 24. ParkMobile/Arrive (美国/瑞典)
- **类型**: C类 - 智能停车
- **背景**: 2025年1月EasyPark收购Flowbird, 6月重组为Arrive
- **2025亮点**: 集成EV充电+移动支付, 6500万用户基础
- **开发策略**: 美国/瑞典智能停车 ★★★★☆

---

## 📊 Batch 44 统计

- **新增客户/情报**: 24 家
- **聚焦行业**: 矿山ATEX/IECEx, 油气炼油厂, 交通路口, 机场航空, 智能停车
- **覆盖国家**: +2 (奥地利, 日本已有)

---

## 🎯 关键技术发现

1. **ATEX/IECEx防爆**: Axis Ex Connection Rail 4口PoE/POE++ (瑞典), SAMCON T04 -60°C (德国), Larson $1,470 (美国), Hirschmann C1D2 (德国)
2. **油气炼油厂**: Perle IDS-110HP 90W (加拿大), Versa 90W方案 (美国), barox中东炼油厂 (全球), Veilux SVEX防爆摄像头
3. **交通路口**: Transition Networks NYC 10,000路口 (美国), Planet 16口320W ERPS (台湾), Omnitron RuggedNet 100W (美国), Vigitron NEMA-TS 2 (美国), AXIS D8208-R 90W (瑞典), Korenix M12 Bypass (台湾), AVCOMM 96Gbps (美国)
4. **机场**: Omnitron iConverter+OmniConverter远程重启 (美国)
5. **智能停车**: Omnitron 10G PoE+ (美国), Conduent $1.1B (美国), SKIDATA $950M (奥地利), Amano McGann $870M (美国/日本), Streetline $420M (美国), Cisco $1.5B (美国), ParkMobile/Arrive (美国/瑞典)

---

## 📈 累计统计

- **总客户/情报数**: 1,195 家 (1171 + 24)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 46 次
- **超额完成**: 171% (目标 700客户)
