# Batch 24 — 中东GCC深度 + AV over IP新赛道 + 零售酒店PoE
> 深度挖掘 Round 75-78 (2026-10-25)
> 方法论：GCC PoE分销 / AVoIP SDVoE/Dante生态 / 零售酒店PoE方案

---

## 一、中东GCC PoE分销（沙特/UAE/科威特/卡塔尔/阿曼）

### 1. AETEK（台湾）
- **类型**: A类 — PoE专业品牌
- **网站**: aetek.com.tw
- **成立**: 2015年 (台北), 50+国家
- **产品**: 室内管理PoE/工业PoE/户外IP67 IK10 PoE/Ceiling PoE(世界首创)/90W bt/EX-PoE 250m/NTS拓扑
- **认证**: NDAA/TAA合规, 6KV PoE浪涌, 40KV电源浪涌, -40~+75°C
- **开发策略**: 台湾PoE专家，沙特Aramco级工业
- **置信度**: ★★★★★

### 2. Seven Sectors Trading（沙特）
- **类型**: C类 — AETEK沙特授权
- **网站**: 7sectors.com
- **成立**: 2024年11月
- **产品**: AETEK+Milesight+HID+SPON
- **特色**: Jeddah本地库存, 项目报价, Vision 2030
- **开发策略**: 沙特PoE安防分销新进入者
- **置信度**: ★★★★★

### 3. Magtel Systems（UAE）
- **类型**: C类 — Ruijie Reyee GCC
- **网站**: magtelsystems.com
- **覆盖**: UAE/Oman/Qatar/Bahrain/Saudi/Kuwait
- **开发策略**: UAE Ruijie Reyee授权GCC分销
- **置信度**: ★★★★★

### 4. Fourteck（UAE）
- **类型**: C类 — 多品牌PoE
- **网站**: fourteck.com
- **品牌**: Cisco/Aruba/Ubiquiti/TP-Link
- **覆盖**: Dubai/Abu Dhabi/Sharjah/Ajman/RAK/UAQ/Al Ain/Kuwait/Kenya/Uganda
- **开发策略**: UAE多品牌PoE集成+非洲
- **置信度**: ★★★★★

### 5. Centrix（科威特）
- **类型**: C类 — MikroTik VAD + Ubiquiti Elite
- **网站**: centrixkw.com
- **成立**: 2018年
- **品牌**: MikroTik CRS+Ubiquiti UniFi+Cisco+Aruba
- **开发策略**: 科威特MikroTik VAD+Ubiquiti Elite
- **置信度**: ★★★★★

### 6. VDS AE（UAE）
- **类型**: C类 — PABX/IT/MEA
- **网站**: vdsae.com
- **覆盖**: UAE全国+沙特/阿曼/卡塔尔/科威特/巴林/约旦/埃及/东非/西非
- **开发策略**: UAE PABX/IT分销覆盖MEA
- **置信度**: ★★★★☆

### 7. Al-Khaleej Al-Awwal（沙特）
- **类型**: C类 — Rugged PoE授权
- **网站**: khaleejalawwal.com
- **产品**: Omniswitch 6865/Rugged PoE
- **覆盖**: Riyadh/Dammam/Jeddah+全国
- **开发策略**: 沙特通信/安防授权分销
- **置信度**: ★★★★★

### 8. SecureNet FZC（UAE）
- **类型**: C类 — IP-COM授权
- **产品**: IP-COM PoE/非PoE交换机/Mesh/路由器
- **市场**: UAE+阿曼SMB渠道
- **开发策略**: UAE增值分销
- **置信度**: ★★★★☆

### 9. Al Mashreq Distribution（卡塔尔）
- **类型**: C类 — Wi-Tek PoE授权
- **网站**: almashreq-qatar.com
- **地点**: Doha (Barwa Commercial Avenue + Barwa Village展厅)
- **开发策略**: 卡塔尔Wi-Tek PoE授权
- **置信度**: ★★★★★

### 10. Vector Digital Systems（UAE）
- **类型**: C类 — Ubiquiti授权43国
- **网站**: vectordigitals.net
- **覆盖**: UAE全境 + 43国 (非洲+中东+中亚+高加索)
- **开发策略**: UAE Ubiquiti授权，广泛出口
- **置信度**: ★★★★★

### 11. IP-COM Networks（中国）
- **类型**: B类 — SMB PoE品牌
- **网站**: ip-com.com.cn
- **产品**: PoE/非PoE交换机/Mesh/路由器/PoE路由器
- **开发策略**: 中国SMB PoE品牌出海
- **置信度**: ★★★★☆

---

## 二、AV over IP PoE新赛道（SDVoE/Dante/AES67）★★★★★

> ⚠️ **市场洞察**: AVoIP是PoE交换机高附加值新赛道，10G PoE++需求强劲。SDVoE/Dante/AES67需要QoS预配置，专业AV交换机溢价高。

### 12. AVPro Edge（美国）
- **类型**: B类 — AVoIP PoE交换机
- **网站**: avproglobal.com
- **产品**: AC-MXNET-10G-SW24C (24口10G PoE++/PoE+, Dante/AES67/SDVoE QoS预配置, **首家**AV厂商)
- **保修**: 10年高级替换
- **开发策略**: 美国AVoIP PoE领先品牌
- **置信度**: ★★★★★

### 13. NETGEAR AV Line M4250（美国）
- **类型**: 竞品 — AVoIP交换机全线
- **网站**: netgear.com/business/wired/switches/fully-managed/m4250/avline
- **协议**: Dante/Q-SYS/AES67/AVB/NVX/SVSI/NDI/ZeeVee/Aurora/Kramer/Atlona/SDVoE/Biamp
- **开发策略**: AVoIP交换机竞品标杆
- **置信度**: ★★★★★

### 14. Ubiquiti EAV Enterprise AV（美国）
- **类型**: 竞品 — 高端AVoIP
- **产品**: EAV-XG-24-PoE (24口10G PoE+++ 4x100G QSFP28, SMPTE ST 2110/Dante/AES67/SDVoE, OCXO时钟, GPS grandmaster)
- **开发策略**: AVoIP高端竞品
- **置信度**: ★★★★★

### 15. Yealink RCH240（中国）
- **类型**: B类 — AVoIP交换机
- **网站**: yealink.com
- **产品**: RCH240 24口L2+ AV交换机 (Dante/AES67/Yealink AVoIP/MTR)
- **开发策略**: Yealink AVoIP方案
- **置信度**: ★★★★★

### 16. ZeeVee（美国）
- **类型**: B类 — SDVoE编解码
- **网站**: zeevee.com
- **产品**: ZyPer4K-XS SDVoE解码器 (Dante AES67 + USB 2.0)
- **开发策略**: SDVoE编解码品牌，需PoE交换机
- **置信度**: ★★★★★

---

## 三、零售/酒店PoE方案

> **市场数据**: 零售PoE 12.4%份额(2025), 管理PoE 61.2%(CAGR 8.9%), 云管理订阅$50-150/设备/年

### 17. Newbridge（中国）
- **类型**: B类 — 零售连锁PoE方案
- **网站**: cnnewbridge.com
- **案例**: 50家便利店 (TP-Link TL-SG1016PE + H3C iMC云管)
- **方案**: 总部→区域→门店三层架构
- **开发策略**: 中国零售PoE方案商
- **置信度**: ★★★★☆

### 18. Svelol Networks（全球）
- **类型**: B类 — 农业PoE
- **网站**: poeswitches.com
- **产品**: 工业管理PoE交换机 (精准灌溉/环境监测/温室/畜牧)
- **开发策略**: 农业IoT PoE专业品牌
- **置信度**: ★★★★☆

---

**Batch 24 总计: 18家新客户/情报**

> 关键发现：
> 1. **中东GCC 11家** — AETEK台湾PoE专家(50+国)/Seven Sectors沙特Jeddah库存/Magtel UAE GCC/Fourteck UAE+非洲/Centrix科威特VAD+Elite/VDS AE MEA/Al-Khaleej沙特/SecureNet UAE/Al Mashreq卡塔尔/Vector 43国/IP-COM中国
> 2. **AV over IP 5家** — AVPro Edge 24口10G PoE++(首家Dante QoS)/NETGEAR M4250全线/Ubiquiti EAV 10G 100G/Yealink RCH240/ZeeVee SDVoE
> 3. **零售/农业2家** — Newbridge零售/Newbridge 50便利店案例/Svelol农业
> 4. **市场数据**: 零售12.4%份额, 管理PoE 61.2%(CAGR 8.9%), 非管理38.8%(17.6M台均价$75), 云管理$50-150/年
