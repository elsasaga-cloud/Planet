# 波兰深度挖掘 Part 1 - 10个渠道 (104-113)

**日期**: 2026-10-27  
**国家**: 波兰 (Poland)  
**渠道数**: 10  
**PoE端口估算**: 1,385,000+ 端口

---

## 104. 安防分销商 (Hikvision/Dahua/Uniview授权)

### Hikvision Poland
- **MWS Sp. z o.o.** - National Distributor, Katowice, www.mwsecurity.pl
- **Alkam Security** - 6分支机构 (Warsaw, Katowice, Toruń, Wrocław, Kraków, Łódź)
- **ADI - Ultrak Security Systems** - 4分支机构 (Szczecin, Wrocław, Warsaw, Kraków)
- **MKJ Systemy zabezpienień** - Szczecin
- **Eltrox Sp. z o.o.** - 多分支机构 (Szczecin, Olsztyn, Białystok, Nowy Sącz)
- **DIPOL sp. z o.o.** - Kraków
- **PROMITEL Sp. z o.o. Sp. k.** - Chorzów
- **A-LAN** - Katowice

### Dahua Poland
- **Dahua Technology Sp. z o.o.** - Warsaw (直接子公司)
- **Eltrox** - 授权分销商

### Uniview Poland
- **Vidicon** - Wrocław总部, 20+年经验, 30+国家销售
- 提供售前咨询/产品演示/培训/项目支持

**PoE端口**: ~50,000+ 端口

---

## 105. 国防工业 (NATO最高国防支出4.8% GDP)

### 关键数据
- **国防预算2026**: PLN 200B ($55B, 4.8% GDP, NATO最高)
- **军队规模**: 216,100现役人员 (NATO第3大)
- **主要采购**: F-35A, K2坦克, K9自行火炮, HIMARS, M1A1, Patriot导弹

### 主要企业
- **PGZ (Polska Grupa Zbrojeniowa)** - 国有军工集团, ~50子公司
  - 收入2025: PLN 13.9B (+50% YoY)
  - 产品: K2PL坦克, Krab自行火炮, Borsuk IFV, Piorun防空导弹
  - 投资: €565M新建3座弹药工厂 (2025.7)
- **WB Group** - 私营国防企业
  - 产品: Warmate巡飞弹, FlyEye无人机, Gladius无人侦察打击系统
  - 合同2026: PLN 60B (步兵战车/自行火炮/军车)
- **HSW (Huta Stalowa Wola)** - Krab 155mm自行火炮, Borsuk IFV
- **Mesko** - Piorun MANPADS, 155mm炮弹, €565M三工厂扩建

**PoE端口**: ~15,000+ 端口 (工厂CCTV, 生产线网络, 测试设施)

---

## 106. 能源基础设施 (PSE + 5大DSO, 2,166变电站)

### 关键数据
- **输电线路**: 75,550 km (400/220/110 kV)
- **变电站**: 2,166个 (400/220/110 kV)
- **投资计划**: PLN 66B (2025-2034)
- **新建**: 4,700 km 400kV线路, 28个新变电站, 110个现代化

### 主要企业
- **PSE (Polskie Sieci Elektroenergetyczne)** - 输电系统运营商
  - 总部: Konstancin-Jeziorna
  - 规模: 98.5%国家电网, 2,166变电站
  - 投资: PLN 66B (2025-2034)
- **PGE Dystrybucja** - 配电系统运营商 (波兰东部/中部)
  - 母公司: PGE (35.8%发电份额)
  - 投资: PLN 9.13B (RRF贷款, 2025.5)
- **Tauron Dystrybucja** - 配电系统运营商 (波兰南部)
  - 投资: PLN 4.87B (2025.9)
- **Enea Operator** - 配电系统运营商 (波兰西部)
  - 现代化: 450 km电网, 6,500+变电站
- **Energa Operator** - 配电系统运营商 (波兰北部)

### 网络安全事件 (2025.12.29)
- **攻击**: 30+风电/光伏场站 + 1座CHP热电厂
- **影响**: 50万客户供热中断
- **向量**: FortiGate VPN漏洞 + 默认凭据
- **恶意软件**: DynoWiper, LazyWiper
- **归因**: 俄罗斯FSB Centre 16 (Berserk Bear/Dragonfly)

**PoE端口**: ~170,000+ 端口 (变电站CCTV, SCADA网络, 控制中心, 可再生能源场站)

---

## 107. 铁路运输 (PKP PLK 18,915 km)

### 关键数据
- **铁路线路**: 18,915 km
- **平交道口**: 11,519个
- **道岔**: 37,380组
- **列车**: 5,000+客货列车/日
- **员工**: 35,836 (PKP PLK)
- **投资**: PLN 170B (国家铁路计划2030)

### PKP Polskie Linie Kolejowe (PKP PLK)
- **总部**: Warsaw
- **规模**: 18,915 km线路, 2,563车站/站点
- **CCTV系统**: 
  - 2017前: 仅170车站有CCTV (100个模拟过时)
  - 现在: PSIM集成平台, 全覆盖IP CCTV
  - Warsaw Railway Junction: CCTV + ACS + IDS + 辐射检测 + 消防
- **投资**: 
  - ERTMS/ETCS: 3,500 km线路 (Level 2)
  - GSM-R: 15,200 km线路
  - WAN网络: 1,800+站点连接

### 安全事件
- **2023.8**: 无线电黑客攻击 (150 MHz未加密, $30设备即可触发紧急制动)
- **2025.11**: Warsaw-Lublin线路爆炸 (俄罗斯情报归因)
- **2025.11**: CHARLIE警报级别 (铁路区域, 延长至2026.5)

**PoE端口**: ~200,000+ 端口 (车站CCTV, 轨道监控, 变电站/信号)

---

## 108. 零售连锁 (Biedronka 3,802店, Dino 3,033店)

### 主要连锁
- **Biedronka (Jerónimo Martins)** - 3,802店, PLN 108B收入, 85,000员工
  - 扩张: 2025新增130-150店
  - 物流中心: 11个
- **Lidl Polska (Schwarz Group)** - 937店, PLN 41.3B收入
- **Dino Polska** - 3,033店, PLN 33.6B收入, 55,900员工
  - 扩张: 2025新增345店
  - 物流中心: 12个
- **Żabka** - 12,300+便利店

**PoE端口**: ~100,000+ 端口 (门店CCTV, 物流中心)

---

## 109. 机场 (15个商业机场, 59.5M旅客)

### 主要机场
- **Warsaw Chopin Airport (WAW)** - 24.1M旅客 (2025, +13.2%)
  - CT扫描仪 (C3标准, 2L液体OK)
  - 15个新安检通道 (2026夏)
  - 30个自动边境控制门 (ABC)
  - 集成安防系统 (CCTV + ACS + IDS)
- **Kraków Airport (KRK)** - 13.2M旅客 (+19.6%)
  - 10个CT扫描仪 (首个波兰机场)
- **Gdańsk Lech Wałęsa Airport (GDN)** - 7.4M旅客 (+10.1%)
  - 2个ATRS通道 (Smiths Detection CTiX)
- **Katowice Airport (KTW)** - 5.6M旅客 (2024)
- **Wrocław Airport (WRO)** - 4.2M旅客 (2024)

### CPK (Centralny Port Komunikacyjny) - 新机场
- **位置**: Warsaw-Łódź之间
- **投资**: €9B (2028)
- **安全**: 362个安检设备采购 (2026.5)

**PoE端口**: ~40,000+ 端口 (15个商业机场 + CPK新机场)

---

## 110. 制造业 (汽车/电池/半导体)

### 关键数据
- **汽车产量**: 332,043辆 (2024, +7.6% YoY)
- **电池产能**: 86 GWh (2024) → 115 GWh (2025) → 122 GWh (2027)
- **半导体投资**: Intel $4.6B (Miękinia)

### 主要企业
- **LG Energy Solution Wrocław** - 欧洲最大锂电池工厂, 86 GWh
  - 客户: Audi, BMW, Ford, Porsche, VW
  - 投资: PLN 1.3B (一期), 扩建至115 GWh
- **Volkswagen Poznań** - 9,500员工, 200,000+辆/年
  - 产品: Caddy, Crafter, MAN TGE
  - 投资: €800M (Września新工厂, 2016)
- **Stellantis Tychy** - 250,000辆/年产能
  - 产品: Fiat 500, Jeep Avenger, Fiat 600, Alfa Romeo Junior
- **Toyota Motor Manufacturing Poland** - 3,000员工, PLN 7B投资
  - 产品: 混合动力驱动系统
- **Mercedes-Benz Jawor** - $1.45B投资 (电动商用车工厂)
- **Intel Miękinia** - $4.6B半导体组装测试, 2,000员工

**PoE端口**: ~30,000+ 端口 (汽车工厂, 电池工厂, 半导体)

---

## 111. 酒店连锁 (532连锁酒店, 74,138房间)

### 主要连锁
- **Accor** - 88酒店, 14,644房间 (#1)
  - 品牌: Novotel, Ibis, Mercure, Sofitel, Mövenpick
- **Hilton Worldwide** - 32酒店, 5,028房间
  - 品牌: Hilton, DoubleTree, Hampton, Canopy
- **Polski Holding Hotelowy (PHH)** - 46酒店, 4,944房间
- **Marriott International** - 27酒店, 4,604房间
  - 品牌: Marriott, Sheraton, Westin, Courtyard, Moxy, AC Hotels
  - 扩张: 10+新酒店 (2024-2026)
- **Radisson Hotel Group** - 18酒店, 4,091-4,182房间
- **IHG Hotels & Resorts** - 30+酒店 (含pipeline)
  - 品牌: InterContinental, Crowne Plaza, Holiday Inn, voco

**PoE端口**: ~90,000+ 端口 (532连锁酒店 + 数千家独立酒店)

---

## 112. 医疗 (2,781医院)

### 关键数据
- **医院总数**: 2,781家 (2026)
- **地区分布**: Mazowieckie 392, Śląskie 294, Wielkopolskie 208

### 主要医院
- **University Hospital Krakow** - 1,265床, 28科室, 31临床病房, 22手术室
  - 患者: 60,000住院/年, 350,000门诊/年
  - 投资: 欧洲最大医疗投资 (108,000 m², 2019)
- **University Clinical Center Warsaw** - 1,200床, 550+医生
- **Maria Skłodowska-Curie Memorial Institute of Oncology** - 肿瘤学领先
- **Children's Memorial Health Institute (Warsaw)** - 儿科最大
- **John Paul II Hospital (Kraków)** - 1,300床, 3,700+员工

**PoE端口**: ~330,000+ 端口 (2,781医院 + 数千家诊所/门诊)

---

## 113. 大学 (~130所, 1.2M学生)

### 主要大学
- **University of Warsaw** - 40,500学生, 成立1816
  - 安全: Office for Security Affairs (2025.7), CCTV全覆盖, 门禁系统
- **Jagiellonian University (Kraków)** - 35,100学生, 成立1364
  - 安全: VDG Sense视频分析 (1,000+摄像头), 车牌识别, NIS 2合规
- **Warsaw University of Technology** - 22,700学生, 工程/IT/航空航天
- **AGH University of Science and Technology (Kraków)** - 19,000学生
  - 专业: 矿业/材料/计算机, Cybersecurity Centre (ECSO成员)
- **Wrocław University of Science and Technology** - 21,500学生

**PoE端口**: ~360,000+ 端口 (~130大学 + 数千栋学生宿舍)

---

## 总结

### 10个渠道 PoE端口估算

| # | 渠道 | PoE端口估算 |
|---|------|-------------|
| 104 | 安防分销商 | 50,000+ |
| 105 | 国防工业 | 15,000+ |
| 106 | 能源基础设施 | 170,000+ |
| 107 | 铁路运输 | 200,000+ |
| 108 | 零售连锁 | 100,000+ |
| 109 | 机场 | 40,000+ |
| 110 | 制造业 | 30,000+ |
| 111 | 酒店连锁 | 90,000+ |
| 112 | 医疗 | 330,000+ |
| 113 | 大学 | 360,000+ |
| | **Part 1总计** | **1,385,000+ 端口** |

### 关键发现
1. **国防支出NATO最高**: 4.8% GDP ($55B), PGZ 50子公司
2. **能源网络安全事件**: 2025.12.29俄罗斯攻击30+风电场, 50万客户供热中断
3. **铁路CCTV全覆盖**: 2,563车站, PSIM集成, 2017前仅170车站
4. **零售三巨头**: Biedronka 3,802店 + Lidl 937店 + Dino 3,033店 = 7,772店
5. **电池制造领先**: LG 86 GWh (欧洲最大), 扩建至115 GWh
6. **医疗规模**: 2,781医院, University Hospital Krakow 1,265床 (欧洲最大投资)
7. **大学数量**: ~130所, 1.2M学生, Jagiellonian成立1364 (欧洲最古老之一)

### 下一步
- **Part 2**: 购物中心/物流中心/港口/体育场/政府/数据中心
- **Part 3**: 更多垂直行业 (矿业/农业/媒体)
