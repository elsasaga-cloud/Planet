# Batch 39 — 矩阵深挖：演播室/广播 + 银行金融 + 石油天然气 + 电影院

**日期**: 2026-10-25  
**搜索轮次**: Round 139-143  
**新增客户/情报**: 14 家

---

## 📺 一、演播室/广播 PoE

### 1. Ikan (美国)
- **类型**: B类 - PoE演播室照明
- **产品**:
  - Lyra LBX8-POE: 50W 802.3bt, 双色3200-5600K, 97 CRI, Art-Net/sACN/DMX-over-IP
  - Lyra LBX10-POE: 85W 1x1面板, 110°光束
  - Lyra LBX20-POE: 170W, 1000W钨灯等效
- **套件**: 预配Netgear Ultra90 PoE++交换机 (380W非管理/720W管理)
- **集成**: Q-SYS认证插件 (256灯/宇宙)
- **开发策略**: 美国PoE演播室照明 ★★★★★

### 2. Gwinnett County Public Schools (Georgia, 美国)
- **类型**: B类 - 教育广播PoE照明
- **规模**: 40+广播工作室
- **方案**: Ikan PoE照明 (无需电气许可证)
- **开发策略**: 美国教育广播PoE案例 ★★★★★

### 3. Versa Technology PoH (PoE over HDBaseT)
- **类型**: B类 - 广播PoH
- **产品**: D60-044-91管理工业PoE (4口90W 802.3bt + 2铜 + 2 SFP, 360W, 6KV浪涌, -40~+75°C)
- **应用**: 演播室摄像头, 现场监视器, 对讲系统, 分配放大器
- **开发策略**: 美国广播PoH ★★★★★

### 4. Studio Technologies Model 214 (美国)
- **类型**: B类 - 广播PoE控制台
- **产品**: Model 214播音员控制台 (单PoE以太网连接)
- **应用**: 学生体育制作, 教室教学
- **案例**: Mt. San Antonio College (光纤+PoE交换机)
- **开发策略**: 美国广播PoE控制台 ★★★★★

---

## 🏦 二、银行/金融 PoE

### 5. VERSITRON 银行方案
- **类型**: B类 - 银行PoE
- **产品**: PoE media converter + 交换机
- **应用**: 视频/音频/图像数据传输, 加密安全
- **开发策略**: 美国银行PoE ★★★★★

### 6. HFCL IO (印度)
- **类型**: B类 - 银行PoE+
- **产品**: PoE+交换机 (ATM/IP电话/CCTV), L2/L3智能
- **案例**: Bank of Baroda Pidari分行 (24口非PoE L2管理)
- **开发策略**: 印度银行PoE ★★★★★

### 7. Lantronix 银行金融
- **类型**: B类 - 银行PoE
- **行业**: Banking & Financial Services
- **开发策略**: Lantronix银行PoE ★★★★☆

---

## ⛽ 三、石油/天然气/采矿 PoE

### 8. UTEPO 石油天然气 (中国)
- **类型**: A类 - 油气工业PoE
- **产品**: 工业PoE交换机 (60W Hi-PoE, PoE Watchdog, One-key Smart)
- **开发策略**: 中国油气工业PoE ★★★★★

### 9. Perle IDS-110HP (加拿大)
- **类型**: B类 - 极端工业PoE
- **产品**: IDS-110HP (10口: 8x千兆90W 802.3bt + 2xSFP, -10~+60°C, DIN轨)
- **应用**: 工业自动化, 政府, 军事, 油气, 采矿, 户外
- **开发策略**: 加拿大极端工业PoE ★★★★★

### 10. Black Box LIE401A (美国)
- **类型**: B类 - 极端温度PoE
- **产品**: LIE401A (4口千兆PoE + 1xSFP)
- **应用**: 工厂, 油气田, 军车/船舶, HVAC, 安防
- **特点**: 智能报警 (电源/端口故障)
- **开发策略**: 美国极端温度PoE ★★★★★

### 11. Antaira 10G油气采矿 (美国)
- **类型**: B类 - 10G工业PoE
- **产品**: 10G非管理PoE+ (12口, 802.3at 30W/口)
- **应用**: 户外/恶劣工业自动化, 安防监控, ITS交通, 油气采矿
- **开发策略**: 美国10G油气PoE ★★★★★

---

## 🎬 四、电影院 PoE

### 12. Film-Tech Forum 情报
- **类型**: 市场情报
- **应用**: IP摄像头 (PoE), WiFi AP, 多电源设备简化
- **趋势**: 新安装偏向PoE交换机替代多个注入器
- **开发策略**: 电影院PoE情报 ★★★★☆

---

## 📊 Batch 39 统计

- **新增客户/情报**: 12 家
- **新增行业**: 演播室/广播PoE, 银行金融PoE, 石油天然气PoE, 电影院PoE

---

## 🎯 关键发现

1. **演播室PoE**: Ikan (50-170W PoE照明+Q-SYS+Art-Net), Gwinnett 40+工作室, Versa PoH, Studio Technologies 214
2. **银行PoE**: VERSITRON, HFCL IO (印度Bank of Baroda), Lantronix
3. **油气PoE**: UTEPO, Perle IDS-110HP, Black Box LIE401A, Antaira 10G
4. **电影院PoE**: IP摄像头+WiFi趋势

---

## 📈 累计统计

- **总客户/情报数**: 1,103 家 (1091 + 12)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 41 次
- **超额完成**: 158% (目标 26 commits)
