# Batch 30 — POS零售 + 智慧农业 + 中亚深挖 + 广播工作室
> 深度挖掘 Round 99-102 (2026-10-25)
> 方法论：POS连锁零售 / PoE精准农业 / 中亚3国进口数据 / NDI广播制作

---

## 一、POS零售连锁PoE

> **市场数据**: 71M POS终端全球部署 (2024), NCR 19%/Square 15%份额, 440K新安装/年

### 1. Newbridge零售PoE方案
- **类型**: B类 — 连锁零售PoE
- **网站**: cnnewbridge.com
- **案例**: 50家便利店 (TP-Link TL-SG1016PE + Huawei AR1220E + H3C iMC云管理)
- **方案**: VLAN分区 (POS V10/摄像头V20/AP V30)
- **开发策略**: 连锁零售PoE+VLAN方案
- **置信度**: ★★★★★

### 2. GK Software / Fujitsu
- **类型**: B类 — 全球POS软件第1
- **份额**: 10%全球新部署
- **客户**: Shoprite (南非), Lidl (欧洲多国)
- **开发策略**: 全球POS软件领先 (需PoE网络)
- **置信度**: ★★★★★

### 3. Telpo Technology（中国）
- **类型**: A类 — POS终端
- **产品**: M8/M1/K10/K20/K106自助, 40000店便利店 (交易步骤8→4, -35%时间)
- **开发策略**: 中国POS终端品牌
- **置信度**: ★★★★★

### 4. Yum! Poseidon POS (自研)
- **类型**: B类 — 自研POS
- **部署**: Taco Bell + KFC美国
- **开发策略**: 餐饮自研POS案例
- **置信度**: ★★★★☆

---

## 二、智慧农业PoE

### 5. Svelol Networks
- **类型**: B类 — 农业PoE交换机
- **网站**: poeswitches.com
- **产品**: 工业管理PoE, 宽温, DIN Rail
- **应用**: 精准灌溉+环境监测
- **开发策略**: 农业PoE专业品牌
- **置信度**: ★★★★★

### 6. PoE精准灌溉方案
- **类型**: 应用情报
- **设备**: 土壤湿度/盐度探头 (PoE) + 电磁阀 (PoE控制)
- **网络**: 管理型PoE (VLAN传感器/摄像头分离, QoS灌溉优先)
- **开发策略**: 农业PoE闭环应用
- **置信度**: ★★★★★

### 7. PoE温室/牧场应用
- **类型**: 应用情报
- **设备**: 温度/湿度/PAR/CO2传感器 + 通风扇/补光灯 + 工业PoE HD摄像头
- **开发策略**: 温室+牧场PoE应用
- **置信度**: ★★★★☆

---

## 三、中亚3国深挖（哈萨克斯坦/乌兹别克/吉尔吉斯）★★★★★

> **Volza数据**: Kazakhstan 4759 PoE进口 (4%全球) / Uzbekistan 2219 (2.2%)

### 8. Uzbekistan PoE 8口市场
- **类型**: C类区域市场
- **数据**: 271出货, 39进口商, $1.55M (2025), 35海外供应商
- **开发策略**: 乌兹别克PoE进口大国
- **置信度**: ★★★★★

### 9. TOO Distribution Center YING KO（哈萨克斯坦）
- **类型**: C类 — 哈萨克斯坦分销
- **产品**: PoE Switches
- **开发策略**: 哈萨克斯坦PoE分销
- **置信度**: ★★★★☆

### 10. Marvel Kazakhstan LLP
- **类型**: C类 — 哈萨克斯坦分销
- **品牌**: Fortinet + Cisco 2960L/3650/2960X PoE
- **开发策略**: 哈萨克斯坦Cisco/Fortinet分销
- **置信度**: ★★★★★

### 11. TOO Komptek（哈萨克斯坦）
- **类型**: C类 — 哈萨克斯坦集成
- **产品**: Cisco SF350-48P 48口PoE管理/SG350-52P 52口PoE管理/2960L 8口PoE
- **开发策略**: 哈萨克斯坦Cisco PoE集成
- **置信度**: ★★★★☆

### 12. Distribution-Kazakhstan Shelters
- **类型**: C类 — 哈萨克斯坦分销
- **产品**: Cisco Catalyst 3650 24口PoE 640W/2960-CX 8口PoE/2960-X 24口PoE 370W
- **开发策略**: 哈萨克斯坦Cisco分销
- **置信度**: ★★★★☆

### 13. TLESHOV MUKHTAR KALYMZHANOVICH（哈萨克斯坦）
- **类型**: C类 — 哈萨克斯坦进口商
- **产品**: PoE IEEE802.3at Injector千兆30W
- **开发策略**: 哈萨克斯坦PoE注入器进口
- **置信度**: ★★★☆☆

### 14. OLX.kz哈萨克斯坦市场
- **类型**: C类区域市场
- **数据**: 273 PoE交换机广告
- **品牌**: Dahua 4口PoE/H3C PoE
- **开发策略**: 哈萨克斯坦PoE零售市场
- **置信度**: ★★★☆☆

---

## 四、广播/NDI工作室PoE

### 15. Tenveo 4K NDI PTZ Bundle
- **类型**: B类 — NDI工作室套装
- **产品**: 3x 4K 20X NDI PTZ (AI人脸跟踪) + 7" joystick + 8口PoE交换机
- **应用**: 直播制作/流媒体/活动
- **开发策略**: NDI PoE工作室套装
- **置信度**: ★★★★★

### 16. vMix NDI PoE需求
- **类型**: 应用情报
- **推荐**: NETGEAR AV/HP/ZyXel/MikroTik (8口+ PoE)
- **开发策略**: NDI多机位PoE需求
- **置信度**: ★★★★☆

---

**Batch 30 总计: 16家新客户/情报**

> 关键发现：
> 1. **POS零售4家** — Newbridge 50便利店VLAN/GK Software 10%全球/Telpo中国40K店/Yum! Poseidon自研
> 2. **智慧农业3家** — Svelol Networks农业PoE/精准灌溉闭环/温室+牧场
> 3. **中亚7家** — Uzbekistan 271出货$1.55M 39进口商/YING KO哈萨克斯坦/Marvel Fortinet+Cisco/Komptek SF350-48P/Shelters 3650 640W/TLESHOV PoE注入器/OLX 273广告
> 4. **广播2家** — Tenveo NDI PTZ+PoE套装/vMix NETGEAR推荐
