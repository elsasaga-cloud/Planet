# Batch 8 — FCC ID反查 + VMS生态品牌 + 工业品牌渠道 + ERPS技术品牌
> 深度挖掘 Round 7-10 (2026-10-25)
> 方法论：FCC ID反查 / VMS生态搜索 / 竞品渠道反挖(工业品牌) / ERPS芯片指纹

---

## 一、A类：FCC ID反查 — 美国市场PoE品牌商

### 1. Grandstream Networks（美国波士顿）
- **类型**: A类 — 自有品牌，L3管理型交换机
- **网站**: grandstream.com
- **FCC Grantee Code**: YZZ
- **地址**: 126 Brookline Ave, 3rd Floor, Boston MA 02215
- **联系人**: Junwei Wang, pwang@grandstream.com, +1 617-566-9300
- **产品**: GWN7823P (L3 Multi-Gigabit), GWN7816P (L3 Managed), GWN7712P (L2 PoE), GWN7801PC (L2+ Compact)
- **证据**: FCC 2026-08-26最新申请，持续推出新交换机型号
- **开发策略**: 美国VoIP/网络品牌，持续推新品，需要中国OEM供应商。Marvell方案匹配
- **置信度**: ★★★★★ FCC确认

### 2. Kmetech Electronics Limited
- **类型**: A类 — PoE交换机品牌
- **FCC ID**: 2AQ65-PSE2624GR
- **产品**: PSE2624GR PoE Switch
- **开发策略**: FCC注册品牌，需要中国代工
- **置信度**: ★★★★☆

### 3. STEAMEMO（Amazon品牌）
- **类型**: A类 — Amazon自有品牌PoE交换机
- **网站**: Amazon storefront
- **产品**: STMGPS204 (5端口千兆PoE+, 52W, APP管理)
- **证据**: "We have our own factory, independent R&D and independent production"
- **开发策略**: 有自有工厂但仍需OEM合作，可争取第二供应商
- **置信度**: ★★★★☆

### 4. Goalake（Amazon品牌）
- **类型**: A类 — Amazon PoE交换机品牌
- **产品**: PS104G (5端口千兆PoE+, 52W, VLAN/QoS)
- **证据**: FCC/FCE认证，Amazon Best Seller rank #34
- **开发策略**: Amazon白牌品牌，可能有OEM需求
- **置信度**: ★★★★☆

---

## 二、B/C类：VMS生态品牌 — Milestone XProtect集成PoE交换机

### 5. Transition Networks / Lantronix（美国）
- **类型**: B类 — PoE交换机已集成Milestone XProtect
- **网站**: lantronix.com
- **产品**: TAA合规PoE+/PoE++交换机（6/8/16/24端口），DMS软件集成
- **开发策略**: **已有Milestone集成**，说明技术实力强。Saga可以ERPS+Marvell方案争取OEM
- **置信度**: ★★★★★ Milestone官方确认

### 6. Allied Telesis（日本/全球）
- **类型**: B类 — PoE交换机有Milestone插件
- **网站**: alliedtelesis.com
- **产品**: x930/x230/FS980M/GS970M/IE340系列PoE交换机
- **开发策略**: 大型网络品牌，其PoE交换机渠道可作为Saga切入目标
- **置信度**: ★★★★★ Milestone官方确认

### 7. Alcatel-Lucent Enterprise（法国）
- **类型**: B类 — OmniSwitch有Milestone插件
- **证据**: 2023年10月推出OmniSwitch Milestone Plugin
- **开发策略**: 大型企业品牌，其分销渠道可争取
- **置信度**: ★★★★★

### 8. Barox Kommunikation AG（瑞士）
- **类型**: B类 — Smart-barox集成Milestone XProtect
- **网站**: barox.com
- **证据**: 2026年10月Smart-barox集成Milestone
- **开发策略**: 瑞士安防网络品牌，专注VMS集成
- **置信度**: ★★★★★

### 9. AETEK Inc（台湾/已在Batch 7）
- **类型**: B类 — AETEK PoE Solutions Plugin for Milestone
- **补充证据**: Milestone官方marketplace确认，L2 PRO PoE Switch/outdoor/industrial/commercial
- **开发策略**: 已在Batch 7，此为加强确认

---

## 三、B/C类：工业交换机品牌渠道反挖（Moxa/Antaira/Hirschmann/Perle）

### 10. SCN AB（瑞典）
- **类型**: C类 — Moxa官方分销
- **网站**: switches.shop
- **邮箱**: moxa@switches.shop
- **电话**: +46 8 668 21 00, +44 1634 300 900
- **地址**: Truckvägen 16B, 194 52 Upplands Väsby, Sweden
- **开发策略**: Moxa瑞典分销，Saga工业PoE可作为性价比替代
- **置信度**: ★★★★★

### 11. Complete Control Solutions（美国宾州）
- **类型**: C类 — Antaira授权分销
- **网站**: ccs-automation.com
- **区域**: Pennsylvania + Mid-Atlantic
- **开发策略**: Antaira新授权分销，可能愿意增加Saga品牌
- **置信度**: ★★★★★

### 12. Madison Technologies（澳大利亚）
- **类型**: C类 — Moxa授权分销15年+
- **网站**: madison.tech
- **产品**: Moxa全线（交换机/路由器/串口/网关/边缘计算）
- **认证**: MTSC (Moxa Technical Support Certification)
- **开发策略**: 澳洲工业网络专业分销，可推Saga工业PoE
- **置信度**: ★★★★★

### 13. RSP Supply（美国）
- **类型**: C类 — Moxa + Hirschmann分销
- **网站**: rspsupply.com
- **产品**: Moxa EDS/SDS系列 + Hirschmann全系列
- **开发策略**: 同时卖Moxa和Hirschmann，可能需要性价比替代
- **置信度**: ★★★★★

### 14. DigitX（意大利）
- **类型**: C类 — Moxa意大利合作伙伴
- **网站**: digitx.it
- **产品**: Moxa工业以太网交换机/串口转换/多端口板
- **开发策略**: 意大利Moxa渠道
- **置信度**: ★★★★★

### 15. Cogent Distribution（英国/爱尔兰）
- **类型**: C类 — Perle Systems分销
- **网站**: cogentdistribution.com
- **产品**: Perle工业以太网交换机 + RADWIN/SAF/Teltonika/Peplink/RF elements
- **开发策略**: 英国工业网络分销，多品牌组合
- **置信度**: ★★★★★

### 16. Radiant Info Solutions（印度德里）
- **类型**: C类 — Hirschmann授权合作伙伴
- **网站**: radiant.in
- **产品**: Hirschmann MACH100/RS30/SPIDER全系列
- **开发策略**: 印度Hirschmann渠道，Saga可以性价比替代
- **置信度**: ★★★★★

### 17. Yello-net（德国）
- **类型**: C类 — Hirschmann Preferred Distribution Partner
- **网站**: yello-net.de
- **开发策略**: 德国Hirschmann优选分销
- **置信度**: ★★★★★

### 18. Rexel（法国）
- **类型**: C类 — Hirschmann分销（691款产品）
- **网站**: rexel.fr
- **开发策略**: 法国大型电气分销，Hirschmann在售
- **置信度**: ★★★★★

### 19. SanSo Networks（印度德里）
- **类型**: C类 — Moxa + Planet + Hirschmann + HI-Scom
- **网站**: industrialswitches.co.in
- **开发策略**: **同时卖4个工业品牌**，完美匹配"增加一个性价比更高的品牌"策略
- **置信度**: ★★★★★ 已在Batch 7中

### 20. Manuauto（加拿大）
- **类型**: C类 — Moxa加拿大分销
- **网站**: manuauto.com
- **开发策略**: 加拿大工业自动化Moxa渠道
- **置信度**: ★★★★★

---

## 四、A类：ERPS技术品牌（与Saga ERPS能力匹配）

### 21. Link Vue System（新加坡/印度）
- **类型**: A类 — ERPS PoE交换机OEM制造商
- **网站**: 印度新德里，母公司新加坡
- **成立**: 2015年
- **产品**: ERPS (G.8032) PoE管理型交换机，工业级以太网组件
- **业务**: OEM制造/批发/进出口
- **开发策略**: 新加坡母公司，印度制造，ERPS能力匹配Saga
- **置信度**: ★★★★★

### 22. Olycom（深圳）
- **类型**: A类竞品 — ERPS工业PoE交换机
- **网站**: industrialnetworkswitch.com
- **产品**: IM-FP21008GW (ERPS 90W PoE++ 720W), IM-FP888GW (8口2.5G SFP ERPS)
- **认证**: CE/RoHS/FCC/ISO9001
- **开发策略**: 深圳竞品，ERPS+工业PoE，了解其客户可反挖
- **置信度**: ★★★★★

### 23. CENTROPOWER
- **类型**: A类 — ERPS PoE交换机工厂
- **网站**: centropower.com
- **产品**: PoE-7106F-4I, PoE-7110F-8I, PoE-7212F-8I, PoE-7216F-8I (ERPS环网)
- **业务**: 工厂直销，接受OEM
- **开发策略**: ERPS PoE工厂，竞品情报
- **置信度**: ★★★★☆

### 24. ATOP（台湾）
- **类型**: A类竞品 — ERPS工业PoE管理型交换机
- **网站**: industrialcomms.com
- **产品**: EH7520系列（16口+4 Combo, ERPS <20ms recovery）
- **开发策略**: 台湾工业品牌，ERPS能力，竞品情报
- **置信度**: ★★★★★

### 25. WoMaster（台北）
- **类型**: A类竞品 — 铁路认证EN50155 L2/L3 PoE交换机
- **网站**: womaster.eu
- **产品**: MP310/MP614（铁路认证PoE+交换机）
- **合资**: IEI×QNAP Group, HMS Industrial Networks, HolyStone Group
- **开发策略**: Saga不做铁路（无E-mark/EN50155），仅竞品情报
- **置信度**: ★★★★★

### 26. AE Connect（印度）
- **类型**: A类 — 印度ERPS PoE管理型交换机品牌
- **网站**: aeconnect.co.in
- **产品**: AE-PS8082SFT-M (8口千兆L2管理PoE+ 2SFP)
- **口号**: "Engineered in India, Empowering the World"
- **开发策略**: 印度品牌，可能有OEM需求
- **置信度**: ★★★★☆

### 27. Hasivo
- **类型**: A类 — ERPS管理型PoE交换机
- **网站**: u-hasivo.com
- **产品**: S1100WP-8G-2S (8千兆PoE+2SFP, ERPS环网一键设置)
- **开发策略**: 小品牌，可能有OEM需求
- **置信度**: ★★★☆☆

---

## 五、B类延伸：Amazon/eBay白牌卖家

### 28. TRENDnet（美国）
- **类型**: B类 — 美国网络设备品牌，NDAA/TAA合规
- **网站**: trendnet.com
- **产品**: 全品类PoE/工业/管理型交换机
- **开发策略**: 美国品牌，部分产品中国制造，可能有OEM需求
- **置信度**: ★★★★★

### 29. Linovision（已在Batch 5）
- **类型**: B类 — Amazon工业PoE品牌
- **补充**: NDAA合规，DIN-Rail工业交换机
- **置信度**: ★★★★★

---

**Batch 8 总计: 29家新客户**

> 关键发现：
> 1. **Grandstream** (波士顿) — FCC持续注册新交换机型号，美国VoIP/网络品牌，需要中国OEM
> 2. **VMS生态5品牌** (Transition Networks/Allied Telesis/Alcatel-Lucent/Barox/AETEK) — 已集成Milestone XProtect，技术实力强
> 3. **Moxa/Hirschmann渠道8家** — SCN瑞典/Madison澳洲/RSP Supply美国/DigitX意大利/Cogent英国/Radiant印度/Yello-net德国/Rexel法国
> 4. **ERPS技术品牌7家** — Link Vue/Olycom/CENTROPOWER/ATOP/WoMaster/AE Connect/Hasivo
> 5. **SanSo Networks印度同时卖Moxa+Planet+Hirschmann+HI-Scom** — 完美目标
