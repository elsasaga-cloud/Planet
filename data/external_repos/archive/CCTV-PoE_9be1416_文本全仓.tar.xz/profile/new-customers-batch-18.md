# Batch 18 — Realtek芯片生态 + 工业交换机 + ERPS + 白牌品牌完整映射
> 深度挖掘 Round 47-54 (2026-10-25)
> 方法论：芯片方案反查(Realtek/Marvell) / ERPS G.8032 / 工业交换机OEM / 白牌FCC/Amazon品牌

---

## 一、★核心情报：Realtek芯片→白牌品牌完整映射

> 来源: GitHub (nijave) 逆向工程 + OpenWrt论坛 + STH拆解 + IPCamTalk

### Hasivo（四川海思沃电子）生态 — Realtek RTL8373-CG + RTL8224-CG
| 白牌品牌 | 证据强度 | OEM来源 |
|---------|---------|---------|
| **MokerLink** | ★★★★★ PCB标注Hasivo, "HS_"固件前缀 | Hasivo |
| **NICGIGA** | ★★★★★ Hasivo官网OEM页, STH拆解PCB一致 | Hasivo (深圳立讯联科技持有品牌) |
| **Sodola** (部分) | ★★★★ PCB标注"Hasivo S1100-8XGT" | Hasivo |
| **POEPLUS** | ★★★★★ Ghidra反编译品牌切换代码确认 | Hasivo |
| **ONTi** | ★★★★★ OpenWrt论坛确认, 收到JT-COM固件 | Hasivo生态 |
| **OMAY** | ★★★★★ OpenWrt确认, 启动日志匹配Hasivo | Hasivo |
| **JT-COM** | ★★★★★ 固件交叉污染ONTi | Hasivo生态 |
| **HICOMDATA** | ★★★★ svanheule.net同硬件 | Hasivo生态 |
| **YuanLey** | ★★★★ IPCamTalk "100%同厂" | Hasivo (深圳元乐科技) |
| **Aumox** | ★★★★ IPCamTalk确认与MokerLink相同 | Hasivo |
| **GiGaPlus** | ★★★★ STH发现PCB与NICGIGA几乎一致 | Hasivo |

### HRUI/宏雅视讯 生态 — Realtek RTL8382M
| 白牌品牌 | 证据强度 | OEM来源 |
|---------|---------|---------|
| **Horaco** | ★★★★★ HRUI固件/Web界面, 与OptFocus字节一致 | HRUI/Hongyavision |
| **Sodola** (部分) | ★★★★ 管理型千兆线使用HRUI固件 | HRUI |
| **XikeStor** | ★★★★★ HRUI Terraform provider确认 | HRUI (安徽寻客电子) |
| **KeepLink** | ★★★★★ HRUI Terraform + Prometheus | HRUI (深圳爱科曼) |
| **AmpCom** | ★★★★ HRUI Terraform兼容品牌列表 | HRUI |
| **OptFocus** | ★★★★★ 固件字节一致 | HRUI |

### Realtek芯片型号→产品对应
| 芯片 | 类型 | 代表产品 |
|------|------|---------|
| RTL8367N | 5口非管理 | TP-Link LS1005G |
| RTL8370 | 8口非管理 | D-Link DGS-1008A, Netgear GS208 |
| RTL8370M | 8口管理PoE | D-Link DGS-1100-08P |
| RTL8370N | 8口非管理/智能 | TP-Link TL-SG108E, TRENDnet TEG-S82g |
| RTL8372N | 2.5G智能PoE | MokerLink 4口2.5G PoE |
| RTL8380M | 8口管理 | TP-Link TL-SG2008, TL-SG2008P PoE |
| RTL8382M | 16/24口管理 | TP-Link TL-SG116E, T1600G-28TS |
| RTL8373-CG | 2.5G高端 | Hasivo/MokerLink 2.5G系列 |
| RTL9303 | 10G | Hasivo 10G系列 |

**⚠️ Simon的竞争分析**: Saga使用Realtek方案，与Hasivo/HRUI在同一芯片平台上竞争。白牌品牌在Amazon/eBay低价销售，硬件平台几乎相同，差异化需要在固件/管理/服务/认证上建立壁垒。

---

## 二、ERPS G.8032 工业交换机品牌

### 1. WoMaster（欧洲/巴塞罗那）
- **类型**: B类 — ERPS先驱
- **网站**: womaster.eu
- **产品**: DS310/DP310(工业PoE)/DS409/MP310(M12铁路)/MP614(L3 M12)
- **特点**: 20+年工业经验, <50ms ERPS, 铁路/电力/交通
- **开发策略**: ERPS技术标杆，可合作或参考
- **置信度**: ★★★★★

### 2. Olycom（深圳）
- **类型**: 竞品 — 工业PoE ERPS
- **网站**: industrialnetworkswitch.com
- **产品**: IM-FP21008GW (8口PoE 90W, ERPS V1/V2, 480-720W)
- **地址**: 宝安区石岩爱群路同富裕工业区2-3栋
- **开发策略**: 深圳工业ERPS竞品
- **置信度**: ★★★★★

### 3. Antaira Technologies（美国）
- **类型**: B类 — 工业ERPS
- **网站**: antaira.com
- **产品**: LNP-C800G-T (8口千兆PoE+, -40~75°C)
- **开发策略**: 美国工业PoE品牌
- **置信度**: ★★★★★

### 4. AOA Technology（深圳）
- **类型**: 竞品 — 工业ERPS <20ms
- **网站**: aoatech.com
- **产品**: L2/L3管理型工业PoE, ERPS <20ms, 10+年
- **地址**: 宝安区石岩南岗工业园2A栋
- **开发策略**: 深圳工业ERPS竞品
- **置信度**: ★★★★★

### 5. Wanglink（深圳）
- **类型**: 竞品 — ERPS环网OEM/ODM
- **网站**: wanglink.net
- **产品**: 环网交换机 (<50ms ERPS, RSTP, MRP)
- **开发策略**: 深圳环网OEM竞品
- **置信度**: ★★★★★

### 6. Lantech（台湾）
- **类型**: 竞品 — G.8032 ERPS先驱
- **特点**: 最早推广G.8032标准的厂商之一
- **开发策略**: 台湾工业ERPS竞品
- **置信度**: ★★★★★

### 7. Fiberroad（中国）
- **类型**: 竞品 — 工业ERPS
- **网站**: fiberroad.com
- **开发策略**: ERPS技术文档丰富
- **置信度**: ★★★★☆

---

## 三、工业交换机OEM/ODM新品

### 8. Benchu Group（深圳）
- **类型**: 竞品 — 工业交换机OEM/ODM
- **网站**: benchu-group.com
- **产品**: IES7221(16口)/IES7521(24口工业PoE++ 90W), SP7500(L3 ERPS)
- **地址**: 光明区马田街道光铭工业园5栋5楼
- **电话**: +86-755-23246531
- **开发策略**: 深圳工业交换机ODM，L3 ERPS
- **置信度**: ★★★★★

### 9. YuHang Switch（深圳）
- **类型**: 竞品 — "中国最大工业交换机制造商"
- **网站**: yh-switch.com
- **产品**: L2+管理型工业PoE, G.8032 ERPS <20ms, 250环/环
- **开发策略**: 深圳工业交换机大厂竞品
- **置信度**: ★★★★★

### 10. Maisvch（中国）
- **类型**: B类 — 定制工业PoE OEM
- **网站**: maisvch.com
- **产品**: 定制工业交换机(-40~85°C), 固件/外壳/认证定制
- **开发策略**: 工业PoE OEM方案商
- **置信度**: ★★★★☆

### 11. JHA-Tech / Jinhaoan（深圳金豪安）
- **类型**: 竞品 — 工业交换机
- **网站**: jha-tech.com
- **产品**: 管理型工业PoE (8口+2SFP, L2/L3, -40~85°C)
- **开发策略**: 深圳工业交换机竞品
- **置信度**: ★★★★☆

### 12. COME-STAR（中国）
- **类型**: 竞品 — DIN Rail交换机
- **网站**: come-star.com
- **产品**: 工业DIN Rail交换机 (100M/千兆, -40~85°C)
- **开发策略**: 工业DIN Rail竞品
- **置信度**: ★★★★☆

### 13. Tianbo Communication / TINCAM（深圳）
- **类型**: 竞品 — 工业交换机
- **网站**: sztincam.com
- **产品**: TBC-GF2505/2508 (5/8口工业PoE, DC12-52V)
- **开发策略**: 深圳工业交换机竞品
- **置信度**: ★★★★☆

### 14. Longxing Industrial（深圳）
- **类型**: 竞品 — L3管理型工业PoE
- **网站**: Made-in-China
- **产品**: MT-FI8416M (16口千兆PoE+ + 4x10G SFP+, L3, -40~75°C, $145)
- **开发策略**: 深圳L3工业PoE竞品
- **置信度**: ★★★★★

### 15. UTP Fiber Technology（深圳, 2018年）
- **类型**: 竞品 — L2+管理型工业
- **网站**: utpfiber.com
- **产品**: L2+管理型工业交换机, 10G SFP+
- **开发策略**: 深圳工业光纤交换机竞品
- **置信度**: ★★★★☆

### 16. N-net High-Tech（深圳）
- **类型**: 竞品 — L2管理型PoE
- **网站**: szn-net.com
- **产品**: NC31612GM(28口)/NC3082SGM(10口)/NC3244GM(28口L2)
- **开发策略**: 深圳管理型PoE竞品
- **置信度**: ★★★★☆

### 17. POECAM / Xintengda（深圳鑫腾达）
- **类型**: B类 — Realtek交换模块
- **网站**: Alibaba
- **产品**: RTL8367N交换模块 ($7.95-9.90), 5口PoE模块PCBA
- **开发策略**: Realtek交换模块供应商
- **置信度**: ★★★★★

### 18. MESTECHS（中国）
- **类型**: B类 — Realtek嵌入式交换方案
- **产品**: RTL8304/8305/8309/8316/8364/8367/8370/8380/8382/8391全套方案
- **服务**: 一站式CDK/SDK/OEM/ODM
- **开发策略**: Realtek芯片方案商
- **置信度**: ★★★★★

### 19. SYPOE / DeepRock Technology（深圳）
- **类型**: 竞品 — PoE交换机FCC认证OEM
- **网站**: sypoe.com
- **产品**: 4-24口PoE交换机, FCC/CE, OEM/ODM 100台起
- **开发策略**: 深圳PoE OEM，FCC认证白牌
- **置信度**: ★★★★★

### 20. Lanwee Technology（深圳）
- **类型**: 竞品 — L2管理型PoE
- **网站**: Made-in-China
- **产品**: Hasivo S5800WP-24G-2S (24口千兆PoE, L2管理, Realtek)
- **开发策略**: Hasivo管理型PoE
- **置信度**: ★★★★★

---

## 四、白牌品牌补充（Amazon/eBay）

### 21. Primeda-telecom
- **类型**: 白牌 — 24口PoE交换机
- **平台**: eBay
- **产品**: PMD-PoE-24GE-2SFP (24口千兆PoE, 400W, $264?)
- **开发策略**: eBay白牌品牌
- **置信度**: ★★★☆☆

### 22. U-speed
- **类型**: 白牌 — PoE交换机
- **平台**: eBay
- **产品**: 6口PoE (4 PoE+ + 2上行, 63W)
- **开发策略**: eBay白牌
- **置信度**: ★★★☆☆

### 23. Sinotchous / Sinotchnous
- **类型**: 白牌 — PoE交换机
- **平台**: eBay
- **产品**: 6口千兆PoE (4 PoE+ + 2上行, 65W)
- **开发策略**: eBay白牌
- **置信度**: ★★★☆☆

---

## 五、国际工业品牌竞品情报

### 24. Westermo（瑞典）
- **类型**: 高端竞品 — 铁路/海事工业PoE
- **网站**: westermo.com
- **产品**: Lynx 3510系列 (L2/L3 PoE+, 8口, 240W, -40~70°C)
- **开发策略**: 瑞典工业PoE高端竞品
- **置信度**: ★★★★★

### 25. Hirschmann / Belden（德国/美国）
- **类型**: 高端竞品 — 工业PoE
- **产品**: MACH104/OCTOPUS/BOBCAT系列, IP67, $7,664+
- **开发策略**: 工业PoE最高端
- **置信度**: ★★★★★

### 26. Phoenix Contact（德国）
- **类型**: 高端竞品 — 工业PoE
- **产品**: FL SWITCH 2308-8POE (8口PoE+, 240W, -40~70°C)
- **特点**: 比Moxa便宜25%, 比Siemens Ruggedcom便宜40%
- **开发策略**: 德国工业PoE中高端
- **置信度**: ★★★★★

### 27. iComTech（美国）
- **类型**: C类 — 工业PoE分销
- **网站**: icomtechinc.com
- **品牌**: Moxa/Advantech/Hirschmann全线
- **价格**: Moxa EDS-P510A $2,106, Hirschmann MACH104 $7,664
- **开发策略**: 美国工业PoE分销
- **置信度**: ★★★★★

### 28. Patton（美国）
- **类型**: B类 — 美国制造工业PoE
- **网站**: patton.com
- **产品**: FiberPlex工业PoE (802.3af/at)
- **开发策略**: 美国工业PoE品牌
- **置信度**: ★★★★☆

### 29. Dymec（美国）
- **类型**: B类 — 工业PoE++ Broadcom
- **网站**: dymec.com
- **产品**: Broadcom SoC, 802.3bt PoE++ (95W/口, 360W, -40~85°C)
- **开发策略**: 美国工业PoE++品牌
- **置信度**: ★★★★☆

---

## 六、Marvell方案情报

### 30. Lanbras / Lanao Communication（深圳）
- **类型**: B类 — Marvell数据中心交换机OEM
- **网站**: lanaotek.com
- **产品**: Marvell Prestera/Alaska芯片数据中心交换机 (400G)
- **开发策略**: Marvell方案OEM，数据中心方向
- **置信度**: ★★★★☆

---

**Batch 18 总计: 30家新客户/情报**

> 关键发现：
> 1. **Realtek芯片→白牌完整映射** — Hasivo系11品牌(MokerLink/NICGIGA/Sodola/YuanLey/Aumox等) + HRUI系6品牌(Horaco/XikeStor/KeepLink/OptFocus等)
> 2. **ERPS G.8032品牌7家** — WoMaster/Olycom/Antaira/AOA/Wanglink/Lantech/Fiberroad
> 3. **工业交换机OEM新品13家** — Benchu/YuHang/Maisvch/JHA/COME-STAR/TINCAM/Longxing/UTP Fiber/N-net/POECAM/MESTECHS/SYPOE/Lanwee
> 4. **白牌品牌3家** — Primeda-telecom/U-speed/Sinotchous
> 5. **国际工业品牌6家** — Westermo/Hirschmann/Phoenix Contact/iComTech/Patton/Dymec
> 6. **Marvell方案1家** — Lanbras
> 7. **核心竞争情报**: Saga与Hasivo/HRUI使用相同Realtek芯片平台，Amazon白牌品牌硬件几乎一致
