# 波兰深度挖掘 Part 6 (渠道 139-145)

**日期**: 2026-10-27  
**国家**: 波兰 (Poland)  
**渠道数**: 7 (电商/安防行业/分销/展会/海关)  
**PoE端口**: 490,500+ 端口

---

### 139. Amazon波兰 → 6,500+
- 12 FC (Sady/Bielany/Sosnowiec/Kołbaskowo/Pawlikowice/Łódź/Okmiany/Gliwice/Świebodzin/Gorzyczki/Dobromierz)
- 总投资: €10B+ (2012-2025), PLN 23B (2026-2028)
- 19K直接 + 30K间接 = 70K+岗位, 波兰最大美国雇主
- Dobromierz: 200K sqm, 5K机器人, 2026.10开业
- 3 ADCP (Warsaw/Gdańsk/Kraków): Alexa/Ring/Blink/Echo/Polly/Kindle
- AWS Warsaw

### 140. 电商生态 → 150,000+
- €30B+ GMV, 32M+在线购物者, 88.1%互联网渗透
- Allegro: 22.91M月活, €15B+ GMV, 38.8%份额, 130K+卖家, Smart! 7M订阅
- Temu: 10.53M月活, 2025.3曾超Allegro (18.1M vs 17.8M)
- AliExpress: 6.38M, Amazon.pl: 6.89M, Empik: 8.19M, Erli: 5.97M
- Allegro One Fulfillment: 3仓库 + 11K One Box柜 + 中央枢纽Piotrków (2026Q4)
- BLIK: 72%使用, 83%包裹柜, InPost 29K+
- Kaufland.pl 2024.8, Shein, Ceneo 19M+月访问

### 141. 安防集成商/安装商 → 250,000+
- 3,607+安防公司, 1,052 CCTV, 731系统集成商, 1,006中央监控
- Solid Security: 10,001+员工 (最大)
- Alkam Security: 51-200, 批发分销
- BAER Polska/DTiQ/Elstech/POLIXEL/TAP/Janex/IFTER/ISM EuroCenter/Sprint SA
- CCTV Baltic: i-PRO/CredoID/PACOM, PL+Baltics
- Delta-OPTI: 1988起, CCTV全线
- NSS System (BCS品牌), PPHU SUMA, Akom, DTS System, Microsystem

### 142. 智能家居/IoT/KNX → 46,000+
- 52智能家居公司 (Tracxn), $3.39M融资, 1 IPO (Fibaro→Nice)
- Fibaro (Poznań, Z-Wave), Grenton (Kraków, 51-200), Ampio (25国), DOMIQ (18年)
- Blebox/SUPLA/SMARTBOB/Appartme/AVSystem/Banalytics
- KNX Poland: 国家组, 推广+教育+认证集成商
- Smart Home Expo: 8,044访客 (2026, +47% YoY, 31国)
- IoT市场: $5.15B (2025)

### 143. IT分销商 → 33,000+
- AB S.A.: PLN 15.4B, #1波兰IT, #1 CEE, EU Top 5, 1,300员工, 36年
- ALSO Polska: PLN 5.67B
- Ingram Micro Poland: PLN 3.17B, 5-10K员工
- Action S.A.: 1991起, 600员工, IT→多品类含CCTV
- TD SYNNEX Poland, Exclusive Networks Poland
- AB: 100K+ SKU, 1,000+加盟门店, Dell/Lenovo/Microsoft/Samsung/Canon年度最佳

### 144. 安防/IT展会 → 5,000+
- SECUREX (Poznań): 15,091访客 (2026), 29国, CEE最大安防展
  - Honeywell/Hanwha/TP-Link/Johnson Controls/Linc/Delta Opti
  - 2027起改年度, +PROTEGA危机管理展
  - Hosted Buyers: 突尼斯/摩洛哥/阿塞拜疆/波罗的海
- Smart Home & IoT Expo (Warsaw): 8,044访客 (2026, +47%)
- MSPO (Kielce): 中东欧最大国防展
- POLSECURE (Kielce), MILITARIA (Lublin)

### 145. 海关/贸易数据 → 市场容量级
- 总进口: $420-488B (2025)
- 电子电气: $49.89B (11.9%)
- 摄像头 (HS8525.80): **$810M** (中国$334M=41%, 德国$140M)
- 网络交换 (HS8517.62): 德国35-40%, 荷兰15-20%, 美国10-15%
- PoE交换机 (HS8517.62.90): 0-3.7%关税, VAT 23%
- 波兰出口摄像头: 乌克兰$306M + 德国$145M + 美国$111M
- **中国→波兰安防设备**: $334M+ (增长中, +$46M YoY)

---

## 波兰全部 6 Part 汇总

| Part | 渠道 | PoE端口 |
|------|------|---------|
| Part 1 (104-113) | 分销/国防/能源/铁路/零售/机场/制造/酒店/医疗/大学 | 1,385,000+ |
| Part 2 (114-118) | 购物中心/物流/港口/体育场/政府 | 413,000+ |
| Part 3 (119-123) | 数据中心/矿业/食品/媒体/办公楼 | 275,000+ |
| Part 4 (124-133) | 边境/教会/油气/监狱/包裹/消防/公路/影院/乐园/NATO | 945,000+ |
| Part 5 (134-138) | 水利/疗养/博物馆/海上风电/森林 | 235,500+ |
| Part 6 (139-145) | Amazon/电商/安防集成/智能家居/IT分销/展会/海关 | 490,500+ |
| **总计** | **42渠道** | **3,744,000+ 端口** |
