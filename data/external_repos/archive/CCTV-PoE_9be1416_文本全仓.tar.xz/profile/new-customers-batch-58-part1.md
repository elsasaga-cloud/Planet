# Batch 58 Part 1: 深度矩阵变关键词深挖 (5维度)
## 西语拉美安防分销+法语非洲PoE+智慧灯杆+白盒交换机+SCADA工控
_2026-10-27 | 30 entries | 5 cross-domain deep dimensions_

---

### 拉美西语安防分销 (10)
- **95.1 Sily.mx** | 墨西哥 | A类 | 370品牌32K SKU B2B批发, Hikvision/Dahua/Ubiquiti/Grandstream/MikroTik/Ruijie
- **95.2 Gictronics** | 墨西哥Querétaro | A类 | Extreme/Aerohive/Huawei/Cisco/Meraki/AirLive/Axis/Moxa/Siemens, 4城市
- **95.3 TVCenLínea** | 墨西哥 | A类 | 20分支, Dahua/Ubiquiti/Vivotek/ZKTeco
- **95.4 ITC Vision** | 墨西哥 | B类 | Ajax/Dahua/Hikvision安防批发
- **95.5 Vigilantec** | 墨西哥 | B类 | TP-Link Omada/Ubiquiti/Dahua PoE
- **95.6 Relematic** | 墨西哥 | B类 | Allied Telesis/Epcom PoE, CCTV+IoT+GPS
- **95.7 TiendaBlue** | 墨西哥Veracruz | D类 | Hikvision/Huawei/Hytera授权
- **95.8 By Demes Group** | 西班牙 | A类 | 欧洲CCTV分销领导者
- **95.9 SEVITEC** | 西班牙 | B类 | Ajax/videovigilancia专业分销
- **95.10 SSTT SpA** | 智利Santiago | D类 | Dahua 12年

### 法语非洲PoE分销 (7)
- **95.11 Tissaf** | 摩洛哥+西非 | B类 | IT批发领导者, 摩洛哥+毛里塔尼亚+塞内加尔+科特迪瓦+马里
- **95.12 NGT** | 摩洛哥 | A类 | Ruijie Reyee授权+NETGEAR/TP-Link/Ubiquiti/Grandstream/Fortinet/HP/D-Link/Cisco
- **95.13 IRIS.ma** | 摩洛哥Casablanca | B类 | Reyee/Huawei/TP-Link/Ubiquiti PoE, WhatsApp下单
- **95.14 Visionair Maroc** | 摩洛哥 | B类 | TP-Link/Hikvision PoE
- **95.15 ISMAHAUOSS/PrixInfo** | 摩洛哥 | B类 | Ubiquiti进口分销
- **95.16 TTH Groupe** | 摩洛哥Tanger+北非 | B类 | Dahua分销+8非洲国家出口
- **95.17 Kabirex** | 塞内加尔 | D类 | Hikvision/TP-Link PoE零售

### 智慧灯杆Smart Pole (6)
- **95.18 Lanaotek/Lanbras** | 中国深圳 | A类 | 工业8口PoE+(130W)+L3 24口PoE+灯杆网关, 三层架构
- **95.19 Bivocom** | 中国 | A类 | TG473 Smart Pole Gateway(2-SFP+8-RJ45+RS485+WiFi+4G/5G), OpenWrt SDK
- **95.20 Tvilight** | 荷兰 | B类 | OpenSky IoT Pole-Mount(LTE Cat1, 400W, DALI-2, Gateway-Free)
- **95.21 WE-EF** | 德国 | B类 | LSC180(PoE+Ruckus WiFi 6+Milesight LoRaWAN+HD+audio), IP66
- **95.22 Fiberroad** | 中国深圳 | A类 | 工业PoE++ 90W/口 -40~75°C, 智慧灯杆+IIoT
- **95.23 Ubicquia** | 美国 | B类 | AI智慧路灯$106M融资(2025)

### 白盒/开放网络 (2)
- **95.24 Asterfusion** | 中国 | A类 | 商用硅+SONiC白盒交换机
- **95.25 Stordis** | 德国 | B类 | 欧洲开放网络分销(Edgecore/Delta/Barefoot)

### SCADA工控 (5)
- **95.26 Advantech EKI** | 台湾 | B类 | EKI-5526I/5726I工业交换机(ATEX -40~75°C Modbus/TCP SCADA)
- **95.27 RAD Data** | 以色列 | B类 | ETS-1-1G/10G/100G+PowerFlow-2 PoE, 油气SCADA
- **95.28 Comnet** | 美国 | B类 | SCADA网络(加固 -40~75°C <10ms环网)
- **95.29 ITG India** | 印度 | D类 | SCADA集成(Advantech EKI+ADAM)
- **95.30 Distk India** | 印度 | D类 | SCADA 2026指南(Ignition/AVEVA/Siemens/Rockwell)

---

## 关键市场数据

### 拉美安防市场
- 拉美videovigilancia: $3.88B(2024)→$14.27B(2034)
- 墨西哥: 拉美第二大市场, 有能力设计+集成+运营复杂安防系统
- Seguritech(墨西哥): 30+年, 哥伦比亚2018+, 扩展美国

### 智慧灯杆市场
- $132B市场规模
- PoE作为统一电源+数据总线(单Cat5e/Cat6)
- 三层架构: Pole-top(8口PoE 30-60W) + Field Aggregation(24口PoE+ 10G SFP+) + Citywide(光纤环网)
- Phoenix: 100,000灯杆可承载IoT, LED改造节电53%年省$3.5M
- 模块化设计: 杆体20-30年寿命 vs IoT设备3-5年, Zhaga-D4i标准接口

### 白盒交换机市场
- $3.24B(2025)→$7.78B(2034), CAGR 13.7%
- Accton+Celestica占90%市场份额
- ODM直供数据中心增长150% YoY(3Q25, IDC)
- 超大规模70-75%交换机来自ODM白盒

### SCADA工控
- 协议栈: Modbus TCP(最广泛)+DNP3(北美电力)+IEC 61850(变电站)+EtherNet/IP(Rockwell)+OPC UA(跨厂商)
- 加固交换机: -40~75°C, ATEX/IEC 61850-3/IEEE 1613, <10ms环网恢复
- 水处理SCADA: PLC+RTU+HMI+ historian, Modbus/DNP3/MQTT
