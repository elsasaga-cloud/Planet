# Batch 19 — CENTEC芯片生态 + EV/停车PoE + 展会参展商 + 评测品牌 + 美国制造商
> 深度挖掘 Round 55-58 (2026-10-25)
> 方法论：CENTEC芯片方案 / EV充电桩PoE / CPSE/ISE展会 / 评测品牌 / ThomasNet美国制造商

---

## 一、★CENTEC芯片生态（hohunet供应商）

### 1. CENTEC Networks / 盛科通信（苏州）
- **类型**: A类 — Simon的L3/核心层芯片供应商
- **网站**: centecnetworks.com / centec.com
- **上市**: 2023年科创板
- **2025年营收**: 11.51亿元 (+6.35%)
- **芯片产品线**:
  - CTC5160 (GreatBelt 120Gbps, 45nm) — 接入层
  - CTC8096 (GoldenGate 1.2T, 32nm) — 汇聚层
  - CTC7148 (DUET2 640Gbps, 32nm) — 多速率企业
  - CTC7132 (TsingMa) — 5G承载/边缘
  - CTC8180 (TsingMa.MX) — 400G
  - Arctic Series — 数据中心(2024小批量)
- **白盒交换机**: E550/E580/V580/E350系列
- **支持协议**: ERPS/G.8031/G.8032, MPLS-TP, VXLAN, CAPWAP, MACSec
- **开发策略**: hohunet的芯片供应商，Simon的核心层方案来源
- **置信度**: ★★★★★

### 2. Axellence GmbH（德国）
- **类型**: C类 — CENTEC欧洲分销
- **网站**: axellence.de
- **产品**: CENTEC全线交换机+芯片
- **开发策略**: CENTEC德国分销渠道
- **置信度**: ★★★★☆

### 3. CECport（中国电子港）
- **类型**: B类 — CENTEC大客户
- **事件**: 2026年8月签约>1亿元CENTEC芯片长期合同
- **开发策略**: CENTEC最大客户之一
- **置信度**: ★★★★☆

### 4. Lanaotek / Lanbras（深圳）
- **类型**: B类 — CENTEC+Marvell数据中心OEM
- **网站**: lanaotek.com
- **产品**: Centec数据中心交换机 + Marvell数据中心交换机
- **开发策略**: 数据中心OEM，双芯片方案
- **置信度**: ★★★★★

---

## 二、EV充电桩 / 停车场 PoE

### 5. Omnitron Systems（美国）
- **类型**: B类 — EV充电桩PoE方案
- **网站**: omnitron-systems.com
- **产品**: RuggedNet 10G/Mi (8口工业) + RuggedNet 10GPoEBT/Mi (4口PoE++ 100W)
- **应用**: EV充电站网络+监控
- **开发策略**: 美国工业PoE，EV充电方案
- **置信度**: ★★★★★

### 6. D-Link EV Charging（全球）
- **类型**: B类 — EV充电桩PoE方案
- **网站**: dlink.com/us/en/for-industry/application/business-retail/ev-charging
- **产品**: 工业PoE交换机 + M2M路由器 (4-10+充电桩+NVR+IP摄像头)
- **开发策略**: D-Link EV充电垂直方案
- **置信度**: ★★★★★

### 7. LifeSafety Power（美国）
- **类型**: B类 — 门禁PoE电源
- **网站**: lifesafetypower.com
- **产品**: PoE交换机+电源管理系统 (门禁)
- **地点**: Phoenix, AZ
- **开发策略**: 美国门禁PoE电源品牌
- **置信度**: ★★★★☆

### 8. TPS Electric LLC（美国）
- **类型**: B类 — PoE交换机制造
- **网站**: ThomasNet
- **产品**: PoE千兆交换机 (停车场/仓库/酒店/校园)
- **成立**: 2000年
- **开发策略**: 美国PoE交换机制造
- **置信度**: ★★★★☆

---

## 三、展会参展商情报

### 9. SilverNet（英国）
- **类型**: B类 — 最小工业PoE交换机
- **网站**: silvernet.co.uk
- **展会**: The Security Event 2026 (Stand 5/L87)
- **产品**: 35mm×120mm×90mm 350g, PoE+, 光纤菊花链, 双电源
- **认证**: ISO 9001:2015
- **开发策略**: 英国紧凑工业PoE品牌
- **置信度**: ★★★★★

### 10. HRUI / 宏雅视讯（深圳）
- **类型**: 竞品 — CEIC 2026参展
- **展会**: CEIC 2026 (福州) — 高速公路数字基础设施
- **开发策略**: 已确认竞品，高速公路PoE
- **置信度**: ★★★★★

### 11. YuHang（深圳）
- **类型**: 竞品 — CPSE 2025参展
- **展会**: CPSE 2025 (深圳会展中心, 2025.10.28-31)
- **产品**: 全国产化工业交换机(L2/L3/M12铁路/Apollo网管)
- **开发策略**: 深圳最大工业交换机竞品
- **置信度**: ★★★★★

### 12. Hi-Net（深圳）
- **类型**: 竞品 — ISE 2025 + ISC West 2024
- **展会**: ISE 2025 (AVoIP), ISC West 2024 (安防)
- **产品**: 100G核心/10G PoE/AVoIP
- **开发策略**: 深圳PoE竞品，展会活跃
- **置信度**: ★★★★★

---

## 四、评测网站发现的新品牌

### 13. Sodola 8P 2.5G PoE
- **类型**: 白牌 (Hasivo OEM确认)
- **评测**: wiredhaus.com
- **规格**: 6口PoE+, 120W, 2.5G, $130
- **开发策略**: Amazon白牌竞品
- **置信度**: ★★★★☆

### 14. MokerLink POE-10G07110GSM
- **类型**: 白牌 (Hasivo OEM确认)
- **评测**: computingforgeeks.com
- **规格**: 7口10G铜缆PoE++ 90W, $340
- **开发策略**: Amazon 10G白牌竞品
- **置信度**: ★★★★☆

### 15. REOLINK RLA-PS1
- **类型**: B类 — 摄像头品牌跨界PoE
- **评测**: beboivn.com/digitechbytes.com
- **规格**: 8口PoE, 120W, 即插即用
- **开发策略**: 摄像头品牌→PoE交换机
- **置信度**: ★★★★★

### 16. UGREEN 10口PoE交换机
- **类型**: B类 — 配件品牌跨界PoE
- **评测**: digitechbytes.com
- **规格**: 10口, 60W
- **开发策略**: 配件品牌→PoE交换机
- **置信度**: ★★★★☆

### 17. Foredge AI1010
- **类型**: B类 — AI PoE新品牌
- **评测**: propelrc.com
- **规格**: 8口
- **开发策略**: AI PoE新品牌
- **置信度**: ★★★☆☆

### 18. HPE Instant On 1930
- **类型**: 竞品 — HPE SMB PoE
- **评测**: propelrc.com
- **规格**: 24口PoE, 195W, 云管理, L2+
- **开发策略**: HPE SMB PoE线
- **置信度**: ★★★★★

---

## 五、ThomasNet美国PoE制造商

### 19. Micro-ray Electronics（美国）
- **类型**: B类 — PoE分销/制造
- **成立**: 1976年
- **应用**: 汽车/医疗/机器人/能源
- **开发策略**: 美国老牌PoE
- **置信度**: ★★★★☆

### 20. AEI Intelligent Technologies（美国）
- **类型**: B类 — PoE交换机定制
- **成立**: 1998年
- **产品**: 以太网卡/PoE交换机/线缆 (COTS+定制)
- **开发策略**: 美国嵌入式PoE
- **置信度**: ★★★★☆

### 21. Rugged CCTV（美国）
- **类型**: C类 — 工业PoE分销
- **成立**: 1993年
- **地点**: Kemp, TX
- **产品**: 工业PoE交换机 (安防摄像头)
- **开发策略**: 美国安防PoE
- **置信度**: ★★★★☆

### 22. Unicom Electric（美国）
- **类型**: B类 — PoE交换机制造
- **成立**: 1986年
- **产品**: PoE交换机/媒体转换器/收发器/网络卡
- **开发策略**: 美国网络设备制造
- **置信度**: ★★★★☆

### 23. Panduit（美国）
- **类型**: B类 — PoE电源系统
- **网站**: panduit.com
- **产品**: FMPS Class 4 PoE电源系统
- **规模**: 5001-10000员工
- **开发策略**: 美国PoE基础设施大牌
- **置信度**: ★★★★★

### 24. ZDAAS LLC（美国）
- **类型**: C类 — 工业PoE分销
- **成立**: 2008年
- **开发策略**: 美国工业PoE分销
- **置信度**: ★★★☆☆

### 25. AVCOMM Technologies（美国）
- **类型**: B类 — 工业PoE/IoT
- **地点**: Houston, TX
- **产品**: PoE交换机/无线路由/工业服务器/传感器
- **开发策略**: 美国工业IoT+PoE
- **置信度**: ★★★★☆

---

## 六、Metoree PoE交换机品牌排名（美国）

| 排名 | 品牌 | 点击份额 |
|------|------|---------|
| 1 | Allied Telesis | 25.2% |
| 2 | Phoenix Contact | 22.5% |
| 3 | Proscend (台湾) | 12.6% |
| 4 | HPE | 11.9% |
| 5 | Moxa | 11.3% |
| 6 | TP-Link | 9.9% |
| 7 | Advantech | 6.6% |

---

## 七、Commercial PoE Switch市场报告关键玩家

> 来源: Market Research Reports 2024-2032

TP-Link, EtherWAN, Netgear, Cisco, Siemens, Fortinet, ComNet, **Cayee Network Systems**, **FIBERROAD**, **IEIdata**, **aopre**, **Uni·Link**, **HRUI**, **UTEPO**, **GSZY**, **NATYWISH**

### 新发现品牌:
- **Cayee Network Systems** — 商业PoE竞品
- **IEIdata** — 商业PoE竞品
- **aopre** — 商业PoE竞品
- **Uni·Link** — 商业PoE竞品
- **GSZY** — 商业PoE竞品
- **NATYWISH** — 商业PoE竞品

---

**Batch 19 总计: 32家新客户/情报**

> 关键发现：
> 1. **CENTEC芯片生态4家** — 盛科通信(科创板上市,11.51亿营收)/Axellence德国/CECport/Lanbras
> 2. **EV充电PoE 4家** — Omnitron/D-Link/LifeSafety Power/TPS Electric
> 3. **展会参展商4家** — SilverNet英国/HRUI CEIC/YuHang CPSE/Hi-Net ISE+ISC
> 4. **评测品牌6家** — Sodola/MokerLink 10G/REOLINK/UGREEN/Foredge/HPE Instant On
> 5. **美国制造商7家** — Micro-ray/AEI/Rugged CCTV/Unicom/Panduit/ZDAAS/AVCOMM
> 6. **市场报告品牌6家** — Cayee/IEIdata/aopre/Uni·Link/GSZY/NATYWISH
> 7. **Metoree排名**: Allied Telesis 25.2% > Phoenix Contact 22.5% > Proscend 12.6%
