# Batch 40 — 矩阵深挖：教堂/宗教 + 建筑工地 + 餐饮连锁 + 智能家居

**日期**: 2026-10-25  
**搜索轮次**: Round 144-148  
**新增客户/情报**: 15 家

---

## ⛪ 一、教堂/宗教 PoE

### 1. ChurchSetup.com 情报
- **类型**: 市场情报
- **应用**: PTZ摄像头 + PoE交换机 (教堂直播)
- **方案**: ATEM切换器 + PoE PTZ + 简洁布线
- **关键**: 志愿者友好, 快速故障定位
- **开发策略**: 教堂PoE情报 ★★★★☆

### 2. Politon Inc (美国)
- **类型**: B类 - 教堂网络安装
- **案例**: Christian Campus Community
- **方案**: Ubiquiti Unifi (网关 + 24口PoE交换机 + 5个AP)
- **开发策略**: 美国教堂PoE安装 ★★★★★

### 3. FoMaKo BK20Uh3 (教堂PTZ)
- **类型**: B类 - 教堂PTZ摄像头
- **产品**: 4K 20X PTZ (NDI/HDMI/USB3.0, PoE, AI自动跟踪)
- **应用**: 教堂礼拜, 教育
- **开发策略**: 教堂PoE PTZ ★★★★☆

---

## 🏗️ 二、建筑工地 PoE

### 4. Planet Technology USA 建筑工地
- **类型**: B类 - 工地临时PoE
- **方案**: 非管理PoE交换机 (临时设置, 成本效益)
- **应用**: 工地监控, 临时WiFi
- **开发策略**: 美国工地临时PoE ★★★★★

### 5. LanaoTek 工地太阳能
- **类型**: A类 - 工地太阳能PoE
- **产品**: 太阳能户外PoE交换机
- **应用**: 偏远道路, 农场, 建筑工地, 太阳能农场, 环境监测站
- **开发策略**: 工地太阳能PoE ★★★★★

### 6. VERSITRON 建筑智能
- **类型**: B类 - 建筑PoE
- **应用**: 
  - 楼宇自动化系统
  - 电梯/HVAC PoE控制器
  - 临时工地监控
  - 智能楼宇IP电话
  - IoT照明+能源系统
- **开发策略**: 美国建筑智能PoE ★★★★★

### 7. Reyee 建筑工地
- **类型**: B类 - 工地PoE
- **场景**: 建筑工地 (与酒店/学校/零售/工厂/仓库/能源并列)
- **方案**: 云管理PoE + WiFi 6/7 AP + 工业交换机
- **开发策略**: Reyee工地PoE ★★★★☆

---

## 🍔 三、餐饮连锁 PoE

### 8. RBI (Restaurant Brands International) 情报
- **类型**: 市场情报
- **品牌**: Burger King, Popeyes, Tim Hortons, Firehouse Subs
- **规模**: 33,000餐厅, 120+国家, $49B年销售
- **应用**: POS系统, 数字标牌, 厨房显示, WiFi
- **开发策略**: 餐饮连锁PoE情报 ★★★★★

### 9. Toast POS 情报
- **类型**: 市场情报
- **客户**: Applebee's (2025.4切换)
- **应用**: POS终端, 手持设备, 厨房显示
- **开发策略**: 餐饮POS PoE情报 ★★★★☆

### 10. McDonald's 扩张情报
- **类型**: 市场情报
- **规模**: 38,000门店, 98国家 (2025)
- **2025新增**: 147家美国门店 (20年来最快)
- **应用**: POS, WiFi, 数字菜单板, 监控
- **开发策略**: McDonald's PoE情报 ★★★★★

---

## 🏠 四、智能家居/住宅 PoE

### 11. On-Q DA8800WH (美国)
- **类型**: B类 - 住宅PoE
- **产品**: DA8800WH (8口PoE+ 120W, 结构化布线)
- **应用**: 智能家居, 结构化布线机箱
- **开发策略**: 美国住宅PoE ★★★★★

### 12. Cleerline SSF-2x8POE-RUGGED (美国)
- **类型**: B类 - 加固PoE
- **产品**: SSF-2x8POE-RUGGED (2x8加固PoE交换机)
- **开发策略**: 美国加固PoE ★★★★☆

### 13. Netgear Insight 8口 (SOHO)
- **类型**: B类 - SOHO云PoE
- **产品**: Insight管理8口PoE (370W总预算, 云零触摸配置)
- **目标**: SOHO市场
- **开发策略**: Netgear SOHO PoE ★★★★★

### 14. 智能家居PoE趋势
- **类型**: 市场情报
- **驱动**: IP门铃, 智能锁, 室内摄像头, 全屋WiFi mesh
- **趋势**: 4-8口非管理PoE <$80 (TP-Link/TRENDnet/Netgear)
- **开发策略**: 智能家居PoE趋势 ★★★★★

### 15. 住宅PoE增长
- **类型**: 市场情报
- **状态**: 相对新兴但快速增长
- **驱动**: 技术熟练房主DIY智能家居项目
- **开发策略**: 住宅PoE增长情报 ★★★★☆

---

## 📊 Batch 40 统计

- **新增客户/情报**: 15 家
- **新增行业**: 教堂/宗教PoE, 建筑工地PoE, 餐饮连锁PoE, 智能家居/住宅PoE

---

## 🎯 关键发现

1. **教堂PoE**: ChurchSetup情报, Politon (Ubiquiti 24口+5AP), FoMaKo 4K PTZ NDI
2. **工地PoE**: Planet USA临时, LanaoTek太阳能, VERSITRON建筑智能, Reyee工地
3. **餐饮PoE**: RBI 33000门店120国, Toast POS (Applebee's), McDonald's 38000门店98国
4. **住宅PoE**: On-Q DA8800WH 120W, Netgear Insight 370W SOHO, 4-8口<$80趋势

---

## 📈 累计统计

- **总客户/情报数**: 1,118 家 (1103 + 15)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 42 次
- **超额完成**: 162% (目标 26 commits)
