# Batch 60 Part 6: UK电影院+主题公园+学生公寓+加油站+快餐
## 5渠道: Odeon+Cineworld+Vue 840院/Merlin Alton Towers 2.5M/PBSA 755K床位800K端口/11K加油站/Greggs 2797+McDonald's 1505 £1B
_2026-10-27 | 17 entries | UK Deep Mining Part 6_

---

### 渠道Z: 电影院 (5条)
- **102.106 Odeon** 🇬🇧 A类 | **120 UK站**, 960屏幕, 欧洲最大(AMC), Dolby Cinema UK首家
- **Cineworld** 🇬🇧 A类 | 109 UK站, 1,099屏幕, 全球#2(9,139), IMAX+4DX
- **Vue** 🇬🇧 A类 | 91 UK站, 905屏幕, £140M capex, Epic大屏2025
- **Picturehouse+Curzon** 🇬🇧 B类 | 27+16精品
- **UK总计** 🇬🇧 A类 | 840院4,000屏幕, 2012全数字

### 渠道AA: 主题公园 (3条)
- **102.107 Merlin** 🇬🇧 A类 | 130+景点22国, **63M游客**, Alton Towers 2.5M/Legoland 2.4M/Thorpe Park Hyperia, CCTV+bodycam+ANPR+面部识别+闸机+Wi-Fi, £500M Universal UK
- **Blackpool+Paultons** 🇬🇧 B类 | 独立
- **UK总计** 🇬🇧 A类 | 30+主题乐园, **14,000+端口**

### 渠道AB: 学生公寓PBSA (8条)
- **102.108 Unite Students** 🇬🇧 A类 | **72,000床**, 22城市, FTSE 250, **1Gbps Wi-Fi**, CCTV+24/7
- **Homes for Students** 🇬🇧 A类 | 60,000+床, 200+物业
- **iQ (Blackstone)** 🇬🇧 A类 | 35,000床, 85物业
- **UPP+Greystar+Dot Group** 🇬🇧 B类 | 各35,000床
- **Vita Student** 🇬🇧 B类 | 17城市, **250Mbps**, 高端全包
- **Wi-Fi 7标准** 🇬🇧 A类 | 25-35W PoE++ per AP, 1 AP/间, Cat6A, 700W/层, 10Gbps
- **UK总计** 🇬🇧 A类 | **755,000床位**, £5.6B投资, **800,000+ PoE端口!**

### 渠道AC: 加油站 (5条)
- **102.109 Esso** 🇬🇧 A类 | **1,537站**(UK #1), 13.5%份额
- **BP** 🇬🇧 A类 | 1,375站, BP Pulse 225站+500新/年, M&S Food
- **Shell** 🇬🇧 A类 | 1,222站, Shell Recharge 1,000+品牌+70,000合作
- **MFG** 🇬🇧 A类 | 1,557站(UK最大独立), £2.5B Morrisons收购, EV Power
- **UK总计** 🇬🇧 A类 | **11,000+站**, 超市44.6%, **330,000+端口**

### 渠道AD: 快餐连锁 (7条)
- **102.110 Greggs** 🇬🇧 A类 | **2,797店**(UK #1!), £1.8B+, iFacility CCTV控制室, 3,000+目标
- **McDonald's** 🇬🇧 A类 | 1,505店, **£1B 200新餐厅**(4年), 数字菜单+自助点餐
- **Costa** 🇬🇧 B类 | 14,001 Express+2,618 Store
- **Subway+KFC+BK** 🇬🇧 B类 | 2,300+1,000+600
- **Domino's** 🇬🇧 B类 | 披萨外送领导者
- **UK总计** 🇬🇧 A类 | 25,954店, +59%(10年), **375,000+端口**

---

## 关键发现
- **PBSA 800,000+ PoE端口** = UK最大单一PoE市场!
- **快餐375,000+端口** = Greggs 2,797 + McDonald's £1B扩张
- **加油站330,000+端口** = 11K站 × EV充电转型
- **Wi-Fi 7 PoE++** = 25-35W/AP, PBSA标准, 700W/层
- **Merlin安防全套** = CCTV+bodycam+ANPR+面部识别+闸机
