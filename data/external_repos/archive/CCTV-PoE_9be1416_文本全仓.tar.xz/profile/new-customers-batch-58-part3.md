# Batch 58 Part 3: 欧洲深度5渠道深挖
## 德国电商+爱尔兰+展会+Europages B2B+Amazon欧洲卖家
_2026-10-27 | 34 entries | 5 channels_

---

### 渠道A: 德国在线电商 (10家)
- **97.1 Nextag.de** 🇩🇪 B类 | PoE比价1,756结果
- **97.2 Idealo.de** 🇩🇪 A类 | 德国最大比价, 每型号50+报价
- **97.3 Alternate.de** 🇩🇪 A类 | 大型电子零售
- **97.4 Conrad.de** 🇩🇪+🇪🇺 A类 | 电子零售巨头多国
- **97.5 Otto.de** 🇩🇪 A类 | 德国最大电商之一
- **97.6 Dealsan.de** 🇩🇪 B类 | 18,703 PoE优惠
- **97.7 Wlan.net** 🇩🇪 B类 | PoE评测推荐
- **97.8 OMG.de** 🇩🇪 B类 | UniFi专业零售
- **97.9 eBay.de** 🇩🇪 B类 | 二手+新品市场
- **97.10 BroadbandBuyer** 🇬🇧 B类 | PoE专业零售

### 渠道B: 爱尔兰 (6家)
- **97.11 Eurieka** 🇮🇪 A类 | Dublin 15大型IT分销(HPE/Planet/TP-Link/NETGEAR)
- **97.12 Wood Communications** 🇮🇪 B类 | Dublin 22通信设备
- **97.13 ITbits.ie** 🇮🇪 B类 | Dublin 10 IT零售
- **97.14 Satworld** 🇮🇪 B类 | Dublin 12 Reyee 48口PoE
- **97.15 Cians Tech World** 🇮🇪 D类 | Cavan
- **97.16 FreeTV.ie** 🇮🇪 B类 | PoE全线(白牌需求大)

### 渠道C: 安防展会 (4展会)
- **97.17 Security Essen 2026** 🇩🇪 渠道 | 500+参展商36国, HRUI+ONV+barox+ADI+OPTEX
- **97.18 IFSEC London** 🇬🇧 渠道 | 600参展商, Distributor Network(ADI/DVS/CIE/Oprema/Nimans)
- **97.19 SICUR Madrid** 🇪🇸 渠道 | 650公司, 47,000访客83国, €1.2亿影响
- **97.20 barox** 🇨🇭 A类 | 瑞士PoE品牌, Genetec TPP, Essen+SICUR参展

### 渠道D: Europages/Kompass B2B (6家+情报)
- **97.21 Europages数据** 🇪🇺 情报 | switch制造商4,319+分销1,973+电子批发16,164
- **97.22 KTI Distribution** 🇩🇪 A类 | KTI Networks德语区独家, 201产品, 工业PoE
- **97.23 Avanis GmbH** 🇩🇪 B类 | 20年网络/WLAN/安全
- **97.24 FS.COM GmbH** 🇩🇪 A类 | PoE交换机S3150+SFP全线
- **97.25 ECHOLLAND** 🇳🇱 B类 | 荷兰电子元件分销5年
- **97.26 Anixter/WESCO** 🇪🇺 A类 | 全球分销巨头20+欧洲国

### 渠道E: Amazon欧洲卖家 (8家)
- **97.27 UGREEN** 🇨🇳→🇪🇺 A类 | Amazon UK崛起(6口30£+2.5G 39£)
- **97.28 MERCUSYS** 🇨🇳 B类 | TP-Link子品牌(MS105GP 29£ 5.9K评价)
- **97.29 YuanLey** 🇨🇳→🇪🇺 B类 | Amazon UK(10口45£ 1.2K评价)
- **97.30 Goalake** 🇨🇳→🇪🇺 D类 | Amazon UK(5口AI 250m)
- **97.31 Reolink** 🇨🇳→🇪🇺 B类 | eBay.de RLA-PS1 75€ 203已售
- **97.32 MokerLink** 🇨🇳→🇪🇺 B类 | eBay.de 8口46€ OpenWrt
- **97.33 Coolblue.nl** 🇳🇱 A类 | 荷兰大型零售24店
- **97.34 QSFPTEK** 🇨🇳→🇪🇺 B类 | 挪威/波兰/葡萄牙/爱尔兰本地化

---

## 关键数据

### 德国比价平台PoE交换机覆盖
- Idealo.de: 每款50+报价商(竞争极激烈)
- 价格带: TP-Link TL-SG1005P 31€ → Ubiquiti USW-Pro-48-PoE 817€
- MikroTik CRS328-24P: 438€(25报价)

### Amazon UK PoE畅销品牌排名
1. TP-Link: LS105GP £28 60.2K评价 | LS108GP 20.8K评价
2. NETGEAR: GS305P £40 | GS308EP £66 | GS308EPP £120
3. Ubiquiti: USW-ULTRA £101 | USW-FLEX-MINI £35
4. UGREEN: 6口 £30 | 2.5G 5口 £39
5. MERCUSYS: MS105GP £29 5.9K评价

### Europages B2B数据 (switch品类)
| 类型 | 总数 | 德国 | 英国 | 法国 | 意大利 |
|------|------|------|------|------|--------|
| 制造商 | 4,319 | 2,196 | 211 | 281 | 297 |
| 分销商 | 1,973 | 831 | 229 | 180 | 134(西) |
| 电子批发 | 16,164 | 9,640 | 5,330 | 604 | 1,240 |
| 工业交换机 | 1,091(仅德国) | — | — | — | — |

### 欧洲安防展会矩阵
| 展会 | 地点 | 参展商 | 访客 | 下次时间 |
|------|------|--------|------|----------|
| Security Essen | 德国Essen | 500+ | 20,000+(86国) | 2026.9.22-25 |
| IFSEC | 英国London | 600 | 20,000+ | 2025.11 |
| SICUR | 西班牙Madrid | 650 | 47,000(83国) | 2026.2.24-27 |
| EUDEX | 德国Essen | 与Essen同期 | NATO 400+军官 | 2026.9 |

### 爱尔兰PoE市场
- Eurieka(Dublin 15): 最大IT分销, HPE Aruba CX €3,201+
- FreeTV.ie: 白牌PoE全线(6口€57→16口€150)
- Satworld: Reyee 48口L2云管PoE €1,137
