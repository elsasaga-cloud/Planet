# Batch 57 Part 2: 跨域矩阵深挖 (5维交叉)
## 酒店IPTV+SD-WAN分支+智能建筑IoT传感器+零售连锁PoE+水产养殖水下PoE
_2026-10-25 | 20 entries | 5 cross-domain dimensions_

---

### 93.1 Omada Networks (TP-Link Business) | 国际 | B类
- **网站**: omadanetworks.com
- **业务**: 酒店全套网络(PoE交换机+AP+IPTV+IP电话+POS+摄像头), SG3452XMPP 48口PoE++8口+4×10G SFP+
- **PoE需求**: WiFi6/7 AP 15-30W+IP电话7-12W+IoT 5W+智能灯控10W
- **策略**: B类(参考竞品), 开发酒店专用PoE产品线

### 93.2 EnGenius Technologies | 美国+台湾 | A类
- **网站**: engeniusnetworks.com
- **业务**: ECW515 Wi-Fi 7壁板AP(4口GbE PoE输出供IPTV/VoIP/Smart TV/IoT)
- **PoE需求**: 配套PoE交换机供壁板AP级联
- **策略**: A类(AP品牌OEM), 酒店niche

### 93.3 Moss-Link | 国际 | B类
- **网站**: moss-link.com
- **业务**: 酒店WiFi设计+零售连锁方案(S802E 8口PoE 96W/店)
- **PoE需求**: PoE交换机(酒店24/48口+零售8口紧凑)
- **策略**: B类(设计集成), 双市场

### 93.4 Pronto Networks | 国际 | A类
- **网站**: prontonetworks.com
- **业务**: SC24P 24口PoE云管交换机(200W), SD-WAN多站点, ZTP
- **PoE需求**: 云管PoE交换机OEM
- **策略**: A类(SD-WAN OEM), 规模化白标

### 93.5 Monnit | 美国(Utah) | A类
- **网站**: monnit.com
- **业务**: PoE传感器全系列(温度/湿度/占用/空气质量), 802.3af
- **PoE需求**: PoE交换机(802.3af)供传感器网络
- **策略**: A类(PoE传感器品牌), 智能建筑IoT

### 93.6 ISTL | 英国 | A类
- **网站**: istl.com
- **业务**: 全球最先进PoE多功能传感器(PIR+光+温度+湿度+VOC+噪音), 802.3at
- **PoE需求**: PoE交换机(802.3at)供传感器
- **策略**: A类(PoE传感器), 英国智能建筑

### 93.7 Milesight | 中国(厦门) | B类
- **网站**: milesight.com
- **业务**: 智能建筑IoT(BACnet/KNX/MQTT/PoE), 62栋建筑4400传感器
- **PoE需求**: PoE交换机供IoT网关
- **策略**: B类(中国同行), 合作配套

### 93.8 Newbridge (力特光电) | 中国(深圳) | B类
- **网站**: cnnewbridge.com
- **业务**: 零售连锁PoE方案(总部-区域-门店三级), VLAN(POS/监控/AP)
- **策略**: B类(中国参考), 零售PoE方案

### 93.9 DBSI | 美国(California) | D类
- **网站**: dbsi.net
- **业务**: 零售网络布线(Cat6A+光纤), PoE摄像头/门禁/AP
- **策略**: D类(零售布线), 项目制

### 93.10 Eline Technology | 国际 | D类
- **网站**: elinetechnology.com
- **业务**: 零售(24口PoE)+餐饮(16口PoE), VLAN分离
- **策略**: D类(零售/餐饮), 项目制

### 93.11 LINOVISION | 中国(深圳)+国际 | A类
- **网站**: linovision.com
- **业务**: 4K PoE水下摄像头(IPC608UW), IP67 50m, 304不锈钢, 802.3af 7.5W, Amazon全球
- **PoE需求**: PoE交换机供水下摄像头
- **策略**: A类(中国水下品牌), 配套PoE

### 93.12 BarlusCam | 国际 | A类
- **网站**: barluscam.com
- **业务**: 5MP 25FPS PoE水下(10-80m), 批量折扣
- **策略**: A类(水下监控), 批量配套

### 93.13 Tidal (Alphabet) | 美国+挪威 | B类
- **网站**: tidal.no
- **业务**: Orca AI水下系统(自动喂食+行为分析+BioShield), 2024独立
- **策略**: B类(参考竞品), AI水产趋势

### 93.14 Innovasea | 美国+国际 | B类
- **网站**: innovasea.com
- **业务**: 水下摄像头+AI生物量+水质(80+农场), AquaEyes
- **策略**: B类(AI水产平台), 配套PoE

### 93.15 Ace Aquatec | 英国(Scotland) | A类
- **网站**: aceaquatec.com
- **业务**: A-BIOMASS AI摄像头(鲑鱼生物量), 2023
- **策略**: A类(英国AI水产), 配套PoE

### 93.16 ReelData | 加拿大 | A类
- **网站**: reeldata.ai
- **业务**: ReelVision AI(行为+喂食+健康), 2mm检测, 99%在线
- **策略**: A类(加拿大AI水产), 配套PoE

### 93.17 GroAqua | 丹麦(Faroe) | A类
- **网站**: groaqua.io
- **业务**: GroCamera FHD 25FPS PoE(50m, 142°, 0.4kg), 2年质保
- **策略**: A类(丹麦水产), PoE配套

### 93.18 Imenco | 英国+挪威 | A类
- **网站**: imenco.com
- **业务**: 多摄像头(喂养+检查+福利), 生物量+虱子+健康
- **策略**: A类(英/挪水产设备), 配套PoE

### 93.19 FishSpeak | 马来西亚+印尼 | D类
- **网站**: fishspeak.live
- **业务**: ASEAN首个无传感器AI(罗非鱼/白虾), WhatsApp, 50+农场
- **策略**: D类(东南亚AI水产), 小项目

### 93.20 Eruvaka Technologies | 印度+东南亚 | D类
- **网站**: eruvaquatech.com
- **业务**: 语音喂食器+实时仪表盘(2024东南亚), IoT水产
- **策略**: D类(印度水产科技), 东南亚项目

---

## 关键技术趋势

### 酒店PoE交换机需求模型 (每间房)
- Wi-Fi 6/7 AP: 15-30W
- IP电话/VoIP: 7-12W
- IoT网关(Zigbee/Matter): 5W
- 智能灯控: 10W
- **每间房合计: 37-57W → 需PoE++ 60-90W交换机**

### SD-WAN/SD-Branch PoE需求
- Fortinet FortiSwitch + FortiGate: 单窗管理
- ZTP(Zero-Touch Provisioning): 工厂发货→自动配置
- 每分支: 8-24口PoE交换机 + SD-WAN网关
- 5-500+站点规模

### 智能建筑IoT传感器 PoE需求
- PoE传感器: 802.3af(15.4W)即可
- 多功能(PIR+温度+湿度+VOC+噪音+光): 一体化
- 密度: 占用1/15-25m², 空气质量1/200-400m²
- PoE优势: 无需电池, 无需电工, 即插即用

### 零售连锁PoE需求 (每店)
- POS: 3-4口/收银台
- 摄像头: 4-8口(入口/收银/库房/外部)
- WiFi AP: 2-4口
- 数字标牌: 2-4口
- **单店: 8-24口PoE交换机 + VLAN分段(POS/监控/Guest/Signage)**

### 水产养殖水下PoE需求
- 4K水下摄像头: 802.3af 7.5W
- 传输距离: ≤100m(Cat6 PoE)或≤800m(光纤+PoE中继)
- 防护: IP67/IP68, 304/316L不锈钢, 50m深度
- AI分析: 生物量估算+喂食控制+虱子计数+行为分析
- 市场: 挪威/苏格兰/加拿大/丹麦/东南亚
