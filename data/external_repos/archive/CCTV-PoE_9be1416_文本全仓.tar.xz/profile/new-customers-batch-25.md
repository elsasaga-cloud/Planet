# Batch 25 — Edgecore白盒 + 门禁PoE + 南非/摩洛哥/埃及 + GITEX展会
> 深度挖掘 Round 79-82 (2026-10-25)
> 方法论：Edgecore/SONiC白盒生态 / ZKTeco门禁PoE / 非洲三国 / GITEX/Intersec展会

---

## 一、Edgecore Networks白盒交换机生态

> **情报**: Edgecore (Accton子公司, 2004年, 新竹) 开放网络领导者, 1G-800G, 首个TIP OpenLAN PoE交换机, 102.4T AI交换机

### 1. Edgecore Networks（台湾）
- **类型**: B类 — 白盒交换机先驱
- **网站**: edge-core.com
- **产品**: ECS4125-10P (首个TIP OpenLAN PoE), AIS1600-64O/AIS800-128O (102.4T AI), 1G-800G全线
- **NOS**: SONiC/OcNOS/RTBrick/Big Switch/Cumulus/Pica8/OpenSwitch
- **开发策略**: 白盒交换机竞品标杆
- **置信度**: ★★★★★

### 2. Avnet（美国）
- **类型**: C类 — Edgecore授权分销
- **网站**: avnet.com
- **开发策略**: Edgecore美洲授权分销
- **置信度**: ★★★★★

### 3. EPS Global（全球）
- **类型**: C类 — Edgecore EMEA+美国
- **网站**: epsglobal.com
- **开发策略**: Edgecore EMEA+美国分销
- **置信度**: ★★★★★

### 4. ASBIS（EMEA）
- **类型**: C类 — Edgecore官方
- **网站**: asbis.com
- **开发策略**: Edgecore EMEA官方分销
- **置信度**: ★★★★★

### 5. Distri X（荷兰）
- **类型**: C类 — Edgecore分销
- **网站**: distri-x.nl
- **NOS**: SONiC/OcNOS/RTBrick
- **开发策略**: 荷兰Edgecore分销
- **置信度**: ★★★★☆

### 6. Upstream ICT Alliance（中东欧）
- **类型**: C类 — Edgecore CEE
- **网站**: edgecore.io
- **覆盖**: 中东欧+CSP/Telco/Enterprise
- **开发策略**: 中东欧Edgecore分销
- **置信度**: ★★★★☆

### 7. Asterfusion（中国）
- **类型**: B类 — 白盒交换机
- **网站**: asterfusion.com
- **产品**: 1G-400G白盒交换机, Enterprise SONiC/P4
- **开发策略**: 中国白盒交换机竞品
- **置信度**: ★★★★☆

---

## 二、门禁PoE生态（ZKTeco）

> **情报**: ZKTeco (中控智慧) 全球生物识别+门禁领导者，自有PoE交换机线，250m扩展，门禁配套

### 8. ZKTeco PoE交换机全线
- **类型**: B类 — 门禁PoE配套
- **网站**: zkteco.com
- **产品**: PE04-60/PE08-120/PE082-120-C/PE16-180/PE24-240/PE242-300-G
- **规格**: 4-24口, 60-300W, 100M/1G, 250m扩展, IEEE 802.3af/at
- **开发策略**: 门禁PoE配套品牌
- **置信度**: ★★★★★

### 9. ZKTeco PoE配件
- **类型**: B类 — PoE门禁配件
- **产品**: AMT-POE注入器/分离器(12V 2A), inBio160 PoE Bundle (门禁面板+25W PoE分离器)
- **开发策略**: 门禁PoE配件
- **置信度**: ★★★★★

### 10. ADI Global Distribution（美国/波多黎各）
- **类型**: C类 — ZKTeco PoE分销
- **网站**: adiglobaldistribution.pr
- **开发策略**: ZKTeco PoE全球安防分销
- **置信度**: ★★★★★

### 11. DWG（美国）
- **类型**: C类 — ZKTeco PoE分销
- **网站**: dwg.us
- **品牌**: ZKTeco+Suprema+HID+Vivotek等
- **开发策略**: 美国安防PoE分销
- **置信度**: ★★★★★

---

## 三、南非/摩洛哥/埃及PoE分销

### 12. Evetech（南非）
- **类型**: C类 — 交换机零售
- **网站**: evetech.co.za
- **产品**: 千兆/2.5GbE/10GbE管理/非管理/PoE
- **开发策略**: 南非交换机零售
- **置信度**: ★★★★☆

### 13. MiRO Distribution（南非）
- **类型**: C类 — ICT分销
- **网站**: miro.co.za
- **产品**: PoE交换机+无线+VoIP+IoT+安防
- **覆盖**: 南非+SADC
- **开发策略**: 南非ICT分销(已有Cambium)
- **置信度**: ★★★★★

### 14. DA3M（埃及）
- **类型**: C类 — PoE零售
- **网站**: da3m.net
- **品牌**: Grandstream/TP-Link/Huawei/Aruba
- **产品**: L2/L3管理PoE, 千兆/10G Multi-Gigabit
- **开发策略**: 埃及PoE零售
- **置信度**: ★★★★★

### 15. Technopedia（埃及）
- **类型**: C类 — MikroTik/Mimosa
- **网站**: technopedia.io
- **地点**: Heliopolis, Cairo
- **开发策略**: 埃及MikroTik分销
- **置信度**: ★★★★☆

### 16. Jumia Egypt
- **类型**: C类 — PoE电商平台
- **网站**: jumia.com.eg
- **规模**: 63款PoE交换机在线
- **开发策略**: 埃及PoE电商平台
- **置信度**: ★★★☆☆

### 17. IRIS.ma（摩洛哥）
- **类型**: C类 — PoE零售
- **网站**: iris.ma
- **品牌**: TP-Link PoE全线
- **产品**: TL-SG1210P/LS1210P/SG2005P-PD (户外PoE++)
- **开发策略**: 摩洛哥PoE零售
- **置信度**: ★★★★★

### 18. Visionair Maroc（摩洛哥）
- **类型**: C类 — TP-Link/Hikvision
- **网站**: visionair.ma
- **地点**: Casablanca
- **开发策略**: 摩洛哥TP-Link/Hikvision PoE
- **置信度**: ★★★★☆

### 19. NGT（摩洛哥）
- **类型**: C类 — Ruijie Reyee授权
- **网站**: ngt.ma
- **品牌**: Ruijie Reyee授权 + NETGEAR/TP-Link/Ubiquiti/Grandstream/Fortinet/HP/D-Link/Cisco
- **开发策略**: 摩洛哥Ruijie Reyee授权+多品牌
- **置信度**: ★★★★★

### 20. Simplifi Networks（肯尼亚/乌干达）
- **类型**: C类 — UniFi Master东非
- **网站**: simplifinetworks.com
- **产品**: UniFi USW Pro 24 PoE等全线
- **开发策略**: 肯尼亚+乌干达UniFi Master Distributor
- **置信度**: ★★★★★

### 21. DSR Tech（UAE）
- **类型**: C类 — Cisco/Ubiquiti PoE
- **网站**: dsrtech.ae
- **覆盖**: Dubai+非洲
- **开发策略**: UAE Cisco/Ubiquiti PoE分销
- **置信度**: ★★★★☆

### 22. Terrabyt（UAE）
- **类型**: C类 — D-Link工业PoE
- **网站**: terrabyt.com
- **产品**: D-Link DIS-200G/DIS-100G工业PoE + Ubiquiti
- **开发策略**: UAE D-Link工业PoE分销
- **置信度**: ★★★★☆

### 23. GearNet Technologies（UAE）
- **类型**: C类 — IT批发MEA
- **网站**: gntme.com
- **产品**: 网络/服务器/存储/安防全线
- **开发策略**: UAE IT批发MEA覆盖
- **置信度**: ★★★★☆

---

## 四、GITEX/Intersec展会参展商情报

### 24. Lanbras @ GITEX 2023 Dubai
- **事件**: GITEX 2023迪拜展位
- **产品**: 工业通信+IoT+智慧城市
- **开发策略**: 已确认GITEX参展
- **置信度**: ★★★★★

### 25. Lanbras @ Intersec Dubai 2025
- **事件**: Intersec 2025迪拜
- **产品**: PoE+CCTV+工业+IoT+L3工业PoE
- **开发策略**: 安防展参展
- **置信度**: ★★★★★

### 26. CTC Union @ GITEX 2023
- **事件**: GITEX 2023迪拜 (Booth H21-02)
- **产品**: E-Mark/EN50155/L3 10G/90W Ultra-PoE/Modbus Gateway
- **开发策略**: 台湾工业PoE GITEX参展
- **置信度**: ★★★★★

### 27. HRUI @ Network X 2024 + Security Essen
- **事件**: Network X 2024 + Security Essen
- **产品**: PoE全线
- **开发策略**: HRUI欧洲展会参展
- **置信度**: ★★★★★

### 28. Netis @ GITEX
- **事件**: GITEX迪拜
- **产品**: 全线 (WiFi/PoE/PON/DSL/OLT/APAC/CCTV)
- **开发策略**: Netis GITEX参展
- **置信度**: ★★★★☆

### 29. Lanbras @ MWC 2026 Barcelona
- **事件**: Mobile World Congress 2026巴塞罗那
- **产品**: 光传输+以太网+数据中心交换机
- **开发策略**: Lanbras MWC参展
- **置信度**: ★★★★★

---

**Batch 25 总计: 29家新客户/情报**

> 关键发现：
> 1. **Edgecore白盒7家** — Edgecore台湾先驱(102.4T AI)/Avnet/EPS Global/ASBIS/Distri X荷兰/Upstream CEE/Asterfusion中国
> 2. **门禁PoE 4家** — ZKTeco全线(PE04-24口)/ZKTeco PoE配件(inBio160)/ADI Global/DWG美国
> 3. **非洲三国12家** — 南非(Evetech/MiRO)/埃及(DA3M/Technopedia/Jumia)/摩洛哥(IRIS/Visionair/NGT Ruijie授权)/东非(Simplifi UniFi Master)/UAE(DSR/Terrabyt/GearNet)
> 4. **展会参展商6家** — Lanbras GITEX 2023+Intersec 2025+MWC 2026/CTC Union GITEX 2023/HRUI Network X+Security Essen/Netis GITEX
