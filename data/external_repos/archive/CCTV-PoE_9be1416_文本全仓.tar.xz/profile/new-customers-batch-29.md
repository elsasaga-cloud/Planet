# Batch 29 — 北欧市场 + 体育场PoE + 停车系统 + 教育PoE + 中国OEM新
> 深度挖掘 Round 95-98 (2026-10-25)
> 方法论：北欧4国 / 体育场案例 / 停车PoE / 教育K-12+高校 / GlobalSources/Made-in-China新品牌

---

## 一、北欧市场（瑞典/芬兰/丹麦/挪威）

### 1. Omada Nordic（北欧）
- **类型**: C类 — TP-Link北欧官方
- **网站**: omadanetworks.com/nordic
- **产品**: PoE+ 30W/PoE++ 60W/PoE++ 90W, 4-24口
- **开发策略**: TP-Link PoE北欧市场
- **置信度**: ★★★★★

### 2. Westermo（瑞典）
- **类型**: 竞品 — 工业PoE
- **网站**: westermo.com
- **覆盖**: AT/DK/FI/FR/DE/SE/CH
- **特色**: EN50155铁路认证
- **开发策略**: 瑞典工业PoE竞品
- **置信度**: ★★★★★

### 3. Acandia（瑞典）
- **类型**: C类 — 瑞典工业分销
- **网站**: acandia.se
- **产品**: DIN-skena/PoE/云管理/EN50155铁路交换机
- **开发策略**: 瑞典工业PoE分销
- **置信度**: ★★★★★

### 4. Autic System AS（挪威）
- **类型**: C类 — 挪威工业+海事PoE
- **网站**: autic.se
- **成立**: 20+年挪威市场
- **特色**: 海事认证PoE交换机
- **开发策略**: 挪威工业+海事PoE
- **置信度**: ★★★★★

---

## 二、体育场 / 大型场馆 PoE ★★★★★

> **情报**: 体育场PoE用于WiFi 6高密度/摄像头/视频墙/POS/门禁/AI安防

### 5. Planet Technology USA体育场方案
- **类型**: B类 — 体育场PoE+AVoIP
- **网站**: planetechusa.com
- **产品**: AVS-4210-24HP4X (8xPoE++ + 16xPoE+ + 4x10G SFP+, 450W), IP67 -40~75°C
- **应用**: 摄像头+视频墙16x8+WiFi+PoE AP+10G光纤
- **开发策略**: 美国体育场PoE方案
- **置信度**: ★★★★★

### 6. Perle IDS-710HP-XT + Sport-Club Freiburg Europa-Park Stadium
- **类型**: B类 — 体育场PoE案例
- **产品**: 10口GbE 8x100W PoE + 2xSFP (1G/2.5G/10G/copper), DIN Rail杆装
- **应用**: PTZ摄像头+WiFi AP
- **开发策略**: 德国体育场PoE标杆案例
- **置信度**: ★★★★★

### 7. Versa Technology + Petco Park/华盛顿大学
- **类型**: B类 — PoE私有网体育场
- **应用**: WiFi AP+摄像头+POS+门禁+AV显示
- **开发策略**: 美国体育场PoE私有网
- **置信度**: ★★★★☆

### 8. Extreme Networks体育场WiFi
- **类型**: 竞品 — 体育场WiFi领导者
- **客户**: NFL/MLB/NHL/NASCAR/Manchester United/Liverpool
- **开发策略**: 体育场WiFi竞品
- **置信度**: ★★★★★

### 9. Seven Sectors Saudi + AETEK PoE体育场PA
- **类型**: B类 — Saudi Vision 2030
- **品牌**: ITC (广东) 体育场PA + AETEK PoE交换机 (H系列IP67户外/C系列室内/D系列工业)
- **开发策略**: 沙特体育场PA+PoE方案
- **置信度**: ★★★★★

---

## 三、停车系统PoE

### 10. OmniConverter智能停车方案
- **类型**: B类 — 停车PoE
- **产品**: RuggedNet 10GPoEBT/Mi (2x1/10G + 4x60W/100W PoE) + OmniConverter 10GPoE+/M (2x1/10G + 4/8口PoE)
- **开发策略**: 美国停车PoE方案
- **置信度**: ★★★★★

### 11. Antaira停车监控
- **类型**: B类 — 工业停车PoE
- **产品**: L2管理工业PoE, 宽温, QoS/SNMP/IGMP/802.1Q, PoE远程管理+自动恢复
- **开发策略**: 停车监控PoE方案
- **置信度**: ★★★★☆

### 12. Fastcabling长距PoE停车
- **类型**: B类 — 长距停车PoE
- **产品**: 500m长距PoE+交换机 + PoE扩展器, 30W 300-400m, 户外PoE交换机+无线桥接
- **开发策略**: 长距停车PoE方案
- **置信度**: ★★★★☆

---

## 四、教育K-12+高校 PoE ★★★★★

> **市场数据**: 教育PoE交换机 14.2%全球份额 (2025), CAGR 9.1% (2025-2034)

### 13. Ubiquiti ECS企业校园交换机
- **类型**: 竞品 — 高校PoE
- **产品**: ECS-24S-PoE (16x10GbE+8x2.5GbE PoE+++ 1050W, 4x25G SFP28, 2x100G stacking, $2999) + ECS-48S-PoE (2150W, $3999)
- **开发策略**: Ubiquiti企业校园PoE竞品
- **置信度**: ★★★★★

### 14. PoE Partner教育方案
- **类型**: B类 — 教育PoE
- **产品**: GAT-USBC-PD-V3 PoE转USB-C 25W (美国专利), 90W交换机
- **应用**: iPad/平板充电+连接, 摄像头/PA/AP
- **开发策略**: 教育PoE+USB-C方案
- **置信度**: ★★★★★

### 15. Cisco UPOE+ Academy for International Education Miami
- **类型**: 竞品 — 教育PoE案例
- **产品**: Catalyst UPOE+ 90W交换机 + USB-C dongle (每桌供电+联网)
- **开发策略**: 美国教育PoE标杆案例
- **置信度**: ★★★★★

### 16. Arista VESPA + 710XP
- **类型**: 竞品 — 高校+静音PoE
- **产品**: VESPA (50万漫游客户端, 2025.12) + 710XP无风扇静音PoE (图书馆/小教室)
- **开发策略**: Arista教育PoE竞品
- **置信度**: ★★★★★

### 17. Juniper EX4000
- **类型**: 竞品 — 高校PoE
- **产品**: multi-gig + PoE++全端口, 单一SKU覆盖
- **开发策略**: Juniper教育PoE竞品
- **置信度**: ★★★★★

### 18. Hitachi + UTS + NTT DATA绿色校园
- **类型**: B类 — PoE传感器+AI
- **事件**: 2026.3 PoE传感器+AI HVAC, 20%节能目标
- **开发策略**: 绿色校园PoE案例
- **置信度**: ★★★★☆

### 19. Thaishin International School Thailand (Ruijie案例)
- **类型**: B类 — K-12案例
- **事件**: 2025.11 Ruijie Wi-Fi 7 + PoE交换部署
- **开发策略**: 泰国K-12 Ruijie案例
- **置信度**: ★★★★★

### 20. Vigitron Maxiinet PoE
- **类型**: B类 — 教育PoE+
- **产品**: L2管理PoE+, 37W/口, IP分页+IP摄像头+WiFi AP
- **开发策略**: 教育PoE+品牌
- **置信度**: ★★★★☆

---

## 五、中国PoE OEM新品牌

### 21. LINKOH（中国）
- **类型**: A类 — 交换机OEM/ODM
- **网站**: linkohnet.com
- **成立**: 2009年 (国内), 2014年 (国际)
- **客户**: 200+品牌30+国
- **产品**: PoE/以太网/工业交换机, 2.5G/10G, TSN, 60/90W PoE, 云平台+App
- **开发策略**: 中国交换机OEM/ODM新品牌
- **置信度**: ★★★★★

### 22. Shenzhen Ewind
- **类型**: A类 — PoE OEM大厂
- **网站**: ewindnet.com
- **成立**: 7+年
- **规模**: 200员工, 5000m², $50.67M投资
- **出口**: 100+国
- **开发策略**: 深圳PoE OEM大厂
- **置信度**: ★★★★★

### 23. ONV Brand
- **类型**: A类 — PoE全线OEM
- **网站**: onvcom.com
- **出口**: 120+国 (Europe/North America/SEA/Middle East)
- **产品**: PoE交换机/工业交换机/电源/PoE配件
- **开发策略**: 深圳PoE全线OEM
- **置信度**: ★★★★★

### 24. SYPOE / DeepRock Technology（深圳）
- **类型**: A类 — PoE OEM
- **网站**: sypoe.com
- **成立**: 10+年
- **规模**: 5000m², 50000台/月
- **认证**: FCC/CE/RoHS
- **交付**: USA/Canada 7天
- **开发策略**: 深圳PoE OEM (北美快速交付)
- **置信度**: ★★★★★

---

**Batch 29 总计: 24家新客户/情报**

> 关键发现：
> 1. **北欧4家** — Omada Nordic TP-Link/Westermo瑞典EN50155/Acandia瑞典工业/Autic挪威海事20+年
> 2. **体育场5家** — Planet AVS-4210 8xPoE++ 16xPoE+ 450W IP67/Perle IDS-710HP-XT 8x100W Freiburg案例/Versa Petco Park/Extreme NFL全线/Seven Sectors Saudi AETEK
> 3. **停车3家** — OmniConverter RuggedNet 10GPoEBT/Antaira工业L2/Fastcabling 500m长距
> 4. **教育8家** — Ubiquiti ECS-24S/48S-PoE 1050/2150W/PoE Partner USB-C 25W专利/Cisco UPOE+ Miami/Arista VESPA 50万+710XP静音/Juniper EX4000/Hitachi UTS绿色/Thaishin泰国Ruijie/Vigitron 37W
> 5. **中国OEM 4家** — LINKOH 2009 200+品牌30+国/Ewind $50.67M/ONV 120+国/SYPOE 50K台/月
