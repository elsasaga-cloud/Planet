# Batch 60 Part 2: 英国大学+零售+交通+建筑+制造
## 5渠道: 160+大学£325M/Big4零售7000+店/TfL 77K CCTV/Top10建筑£30B/JLR+Nissan+RR
_2026-10-27 | 39 entries | UK Deep Mining Part 2_

---

### 渠道F: 大学/教育 (9条)
- **102.52 Glasgow** 🇬🇧 A类 | £8.2M年度网络投资(UK最高), Wi-Fi 6试点
- **102.53 Manchester** 🇬🇧 A类 | 47栋Wi-Fi升级, 88栋校园, Network 2030
- **102.54 Imperial** 🇬🇧 A类 | 全校新Wi-Fi, 18个月
- **102.55 LSBU+LBU+Bangor** 🇬🇧 B类 | Extreme Networks选择
- **102.56 BCU** 🇬🇧 B类 | £1M智能门禁
- **102.57-60** Spencer £1.45M / GLF £3M / Connect £325M / DfE £45M

### 渠道G: 零售连锁 (10条)
- **102.61 Tesco** 🇬🇧 A类 | **2,932门店**, £61.47B, 24/7 SOC, bodycam, Auror AI
- **102.62 Sainsbury's** 🇬🇧 A类 | **1,430门店**, Facewatch LFR(**46%犯罪减少**), Smart Charge 150kW
- **102.63 Asda** 🇬🇧 B类 | **1,106门店**, AI平台(CCTV+PoS+数字货架), Amazon Ad Service
- **102.64 Morrisons** 🇬🇧 B类 | **497门店**, UK第一家数字价签(2025)
- **102.65-70** Aldi 1000+ / Lidl 1000+ / Co-op 2400+ / Waitrose 315 / Iceland Facewatch

### 渠道H: 交通 (2条)
- **102.71 TfL** 🇬🇧 A类 | **77,000+ CCTV**, 108,000公交CCTV, £1.5B网络大修, 272站
- **102.72 Network Rail** 🇬🇧 A类 | £11.5B, 20大站, AI CCTV入侵检测

### 渠道I: 建筑 (8条)
- **102.73 Balfour Beatty** 🇬🇧 A类 | **£9.5B**, UK #1, HS2+机场+£833M NZ Teesside
- **102.74 Kier** 🇬🇧 A类 | £4.4B, 21,000km公路, Hinkley Point C
- **102.75 Mace** 🇬🇧 A类 | £2.8B, The Shard+数据中心, Net Zero 2026
- **102.76-80** Morgan Sindall £5B / Laing O'Rourke £2.4B / Wates £2.5B / Galliford Try / Amey

### 渠道J: 制造业 (10条)
- **102.81 JLR** 🇬🇧 A类 | **£18B EV转型**, 33K员工, 4工厂, £4B电池厂
- **102.82 Nissan Sunderland** 🇬🇧 A类 | **£2B投资**, UK最大汽车厂, 3 gigafactory
- **102.83 Rolls-Royce** 🇬🇧 A类 | **£300M UK**(2026), £3B+(2023以来), 20K UK员工
- **102.84 BAE Systems** 🇬🇧 A类 | 欧洲#1国防, 36.4K UK, £5.9B Dreadnought
- **102.85-90** Airbus UK(500新工程师) / MINI £600M / Toyota / Bentley / Aston Martin £2B

---

## 关键发现
- **TfL = 77,000+ CCTV** + 108,000公交CCTV = UK最大PoE客户(100,000+端口)
- **Tesco 2,932门店** × PoE = 23,000+端口
- **Sainsbury's Facewatch LFR** = 46%犯罪减少, 验证PoE+AI需求
- **JLR £18B + Nissan £2B + RR £3B** = 制造业PoE需求爆发
- **£325M Connect the Classroom** + £45M DfE = 教育PoE框架资金
