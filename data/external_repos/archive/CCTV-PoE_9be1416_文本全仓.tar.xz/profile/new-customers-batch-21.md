# Batch 21 — 太阳能PoE + 非洲深度 + 拉美 + Alibaba OEM
> 深度挖掘 Round 63-66 (2026-10-25)
> 方法论：Solar PoE Switch / 非洲安防分销 / 拉美PoE / Alibaba OEM制造商

---

## 一、太阳能PoE交换机（新能源赛道）★★★★★

> ⚠️ **市场洞察**: 太阳能PoE是远程监控/IoT的快速增长赛道。Linovision/FICOTEK/PLANET领先，内置MPPT充电控制器+电池管理+PoE输出一体化。

### 1. PLANET Technology（台湾）
- **类型**: B类 — 太阳能PoE先驱
- **网站**: planet.com.tw
- **产品**: BSP-115HP-5A (5口Hybrid PoE Solar $262), BSP-115PV-15A (5口LCD显示), BSP-360 (L2管理4口PoE+ MPPT), NMS-360系列
- **特色**: 250m扩展, 零碳ESG, TAA合规
- **开发策略**: 台湾太阳能PoE先驱品牌
- **置信度**: ★★★★★

### 2. Linovision（深圳/欧洲）
- **类型**: A类 — 太阳能PoE领先
- **网站**: linovision.com / eu.linovision.com
- **产品**: POE-SW804G-Solar (MPPT $199), POE-SW806GM-Solar (L2管理 $339-$369), POE-SW505GD (DI远程重启首创), POE-SWR612GM-SOLAR (240W@48V)
- **特色**: 内置MPPT/PWM充电控制器, 电池管理, 远程管理, NDAA
- **开发策略**: 深圳太阳能PoE领先品牌，OEM/ODM
- **置信度**: ★★★★★

### 3. FICOTEK / 飞科光电（深圳）
- **类型**: A类 — 太阳能PoE OEM/ODM
- **网站**: ficotek.cn
- **产品**: 太阳能PoE交换机 (MPPT内置, 工业温度-40~75°C, 防雷, VLAN/QoS/RSTP/ERPS/SNMP)
- **特色**: Top 5 Solar PoE品牌, OEM/ODM, 1年换3年保修终身技术支持
- **开发策略**: 深圳太阳能PoE OEM/ODM
- **置信度**: ★★★★★

### 4. LIFEPOE（中国）
- **类型**: B类 — 太阳能PoE升压
- **产品**: 10口千兆太阳能PoE DC12-24V→DC48V升压 120W, Amazon
- **开发策略**: 太阳能PoE升压交换机
- **置信度**: ★★★★☆

### 5. MokerLink Solar PoE（深圳）
- **类型**: 竞品 (Hasivo OEM确认)
- **产品**: 5口工业太阳能UPS PoE DC9-54V→DC48V, IP40, -40~85°C, Amazon
- **开发策略**: Hasivo白牌太阳能PoE竞品
- **置信度**: ★★★★☆

---

## 二、非洲市场深度挖掘（尼日利亚/乌干达/肯尼亚/坦桑尼亚/加纳）

### 6. JBN Security Systems B.V.（荷兰）
- **类型**: B类 — 欧洲B2B安防批发
- **网站**: jbnsecurity.com
- **品牌**: Hikvision/Dahua/TP-Link VIGI/Ajax/Omada/Reyee/Teltonika/Milesight
- **开发策略**: 荷兰B2B安防批发，覆盖非洲
- **置信度**: ★★★★★

### 7. Stanificent Global Technologies（尼日利亚）
- **类型**: C类 — 尼日利亚安防
- **网站**: stanificentglobal.com
- **品牌**: Hikvision PoE交换机
- **覆盖**: Benin City/Lagos/Abuja/Port Harcourt/全国
- **开发策略**: 尼日利亚安防分销
- **置信度**: ★★★★☆

### 8. RapidBTS（尼日利亚）
- **类型**: C类 — PoE零售
- **网站**: rapidbts.ng
- **价格**: ₦12,000 - ₦3,000,000
- **开发策略**: 尼日利亚PoE零售
- **置信度**: ★★★★☆

### 9. Servo Direct（尼日利亚）
- **类型**: C类 — Hikvision/Dahua分销
- **网站**: servostore.ng
- **地点**: Lagos
- **开发策略**: 尼日利亚Hikvision/Dahua分销
- **置信度**: ★★★★☆

### 10. Infinity Networking Ltd（乌干达）
- **类型**: C类 — PoE进口商
- **数据**: 17批PoE交换机进口, 26%市场份额 (Volza)
- **开发策略**: 乌干达最大PoE进口商
- **置信度**: ★★★★★

### 11. Jade E Services Uganda（Kampala）
- **类型**: C类 — TP-Link PoE分销
- **地点**: Ntinda Industrial Area, Kampala
- **开发策略**: 乌干达TP-Link分销
- **置信度**: ★★★★☆

### 12. Pavan Computers（Kampala, Uganda）
- **类型**: C类 — Ruijie PoE分销
- **网站**: computers.co.ug
- **品牌**: Ruijie PoE
- **开发策略**: 乌干达Ruijie分销
- **置信度**: ★★★★☆

### 13. Mercury Computers Limited（Uganda）
- **类型**: C类 — Ruijie PoE分销
- **网站**: mercurycomputerslimited.com
- **产品**: Ruijie RG-NBS3100-48GT4SFP-P USh 3,040,000
- **开发策略**: 乌干达Ruijie分销
- **置信度**: ★★★★☆

### 14. Empire（坦桑尼亚）
- **类型**: C类 — PoE零售
- **网站**: empire.co.tz
- **品牌**: TP-Link/BDCOM/Ubiquiti
- **地点**: Dar es Salaam
- **开发策略**: 坦桑尼亚PoE零售
- **置信度**: ★★★★☆

### 15. HubTech（肯尼亚）
- **类型**: C类 — 东非分销
- **网站**: hubtech.co.ke
- **覆盖**: 肯尼亚全国 + Uganda/Tanzania/Rwanda/South Sudan/Somalia/DRC
- **开发策略**: 东非PoE分销中心
- **置信度**: ★★★★★

### 16. CTC Kenya
- **类型**: C类 — PoE分销
- **网站**: ctcsolutions.co.ke
- **品牌**: Ubiquiti/TP-Link/MikroTik/D-Link
- **开发策略**: 肯尼亚PoE分销
- **置信度**: ★★★★☆

### 17. TDK Tech Store（肯尼亚）
- **类型**: C类 — PoE东非分销
- **网站**: tdk.co.ke
- **覆盖**: Nairobi/Mombasa/Kisumu + Juba/Kampala/Dar es Salaam/Kigali
- **开发策略**: 肯尼亚→东非PoE分销
- **置信度**: ★★★★☆

### 18. SafetyHub Ghana
- **类型**: C类 — PoE零售
- **网站**: safetyhubghana.com
- **产品**: 24口PoE 370W
- **地点**: Tema/Accra
- **开发策略**: 加纳PoE零售
- **置信度**: ★★★☆☆

### 19. Central Bank of Nigeria
- **类型**: B类 — Perle工业PoE案例
- **事件**: 使用Perle工业PoE交换机升级CCTV安防
- **开发策略**: 尼日利亚央行安防升级案例
- **置信度**: ★★★★★

### 20. ONV / Optical Network Video（深圳）
- **类型**: A类 — PoE OEM/ODM
- **网站**: onvcom.com
- **成立**: 2003年
- **产品**: PoE交换机/工业/PoE注入器/分离器/扩展器/媒体转换器
- **覆盖**: 120+国家 (欧洲/北美/东南亚/中东)
- **开发策略**: 深圳PoE OEM，尼日利亚Jumia有售(H1064PLS ₦70,000)
- **置信度**: ★★★★★

---

## 三、拉美市场

### 21. Metacom（智利）
- **类型**: C类 — PoE分销
- **网站**: metacom.cl
- **品牌**: Ubiquiti/D-Link/Planet, 5-48口, 管理/PoE/SFP/工业DIN
- **地点**: Santiago
- **开发策略**: 智利PoE分销
- **置信度**: ★★★★☆

### 22. AleTecno（阿根廷）
- **类型**: C类 — PoE LATAM
- **网站**: aletecno.com.ar
- **产品**: 工业PoE/PoE+ 4/8/16/24口
- **开发策略**: 阿根廷+LATAM PoE分销
- **置信度**: ★★★★☆

### 23. Chile Mayoristas SpA
- **类型**: C类 — 电子批发
- **网站**: electronicapormayor.com
- **产品**: PoE 4+2口批发 $20.937
- **开发策略**: 智利PoE批发
- **置信度**: ★★★☆☆

---

## 四、Alibaba PoE OEM制造商

### 24. Shenzhen Lavid Technology（深圳）
- **类型**: A类 — PoE OEM/ODM
- **成立**: 18年 (2007)
- **规模**: 15条产线, Fortune 500客户
- **开发策略**: 深圳PoE OEM大牌
- **置信度**: ★★★★★

### 25. Hioso Technology（广东）
- **类型**: A类 — PoE OEM
- **成立**: 18年
- **开发策略**: 广东PoE OEM
- **置信度**: ★★★★☆

### 26. Shenzhen E-Linkchina Technology（深圳）
- **类型**: A类 — PoE OEM
- **成立**: 13年, Top 10%询盘
- **开发策略**: 深圳PoE OEM
- **置信度**: ★★★★☆

### 27. Kunshan SVL Electric（昆山）
- **类型**: A类 — PoE OEM
- **规模**: 6条产线, 100%质检
- **开发策略**: 昆山PoE OEM
- **置信度**: ★★★★☆

### 28. Veemco Technology（广东）
- **类型**: A类 — PoE OEM/ODM
- **开发策略**: 广东PoE OEM
- **置信度**: ★★★☆☆

### 29. Shenzhen Ewind Technology（深圳）
- **类型**: A类 — 工业PoE OEM
- **网站**: ewindnet.com
- **成立**: 7年+, 投资5067万USD, 5000㎡
- **产品**: 工业PoE/PoE/注入器/适配器/分离器/媒体转换器
- **开发策略**: 深圳工业PoE OEM, 5条产品线
- **置信度**: ★★★★★

### 30. Hangzhou Fei Chang Technology（杭州）
- **类型**: A类 — PoE OEM
- **成立**: 16年, Top 20%订单美国市场
- **开发策略**: 杭州PoE OEM
- **置信度**: ★★★★☆

### 31. SDAPO（深圳）
- **类型**: A类 — PoE模块/配件
- **网站**: sdapo.net
- **成立**: 2012年
- **产品**: PoE模块/注入器/分离器/驱动/交换机/线缆/扩展器
- **开发策略**: 深圳PoE配件专家
- **置信度**: ★★★★☆

### 32. Intellinet Network Solutions（美国）
- **类型**: B类 — PoE交换机品牌
- **网站**: intellinetsolutions.com
- **成立**: 2006年
- **产品**: PoE/PoE+/UPoE/PoE++交换机
- **开发策略**: 美国PoE品牌
- **置信度**: ★★★★★

### 33. MatchDigi / LB-Link（印度）
- **类型**: B类 — LB-Link印度授权
- **网站**: matchdigi.com
- **产品**: LB-Link PoE交换机独家授权制造+贸易
- **开发策略**: 印度LB-Link PoE独家
- **置信度**: ★★★★☆

### 34. Emirtech（UAE）
- **类型**: C类 — PoE集成
- **网站**: emirtech.ae
- **认证**: ADMCC (Abu Dhabi)
- **产品**: PoE交换机供应+安装 (CCTV/AP/VoIP)
- **开发策略**: 阿布扎比PoE安防集成
- **置信度**: ★★★★☆

### 35. Araknis Networks（美国）
- **类型**: B类 — AV PoE交换机
- **产品**: AN-210-SW-R-24-POE 24口WebSmart L2 PoE+ OvrC云管理
- **开发策略**: 美国AV行业PoE品牌
- **置信度**: ★★★★☆

---

**Batch 21 总计: 35家新客户/情报**

> 关键发现：
> 1. **太阳能PoE 5家** — PLANET台湾先驱/Linovision深圳领先/FICOTEK深圳OEM/LIFEPOE升压/MokerLink太阳能
> 2. **非洲市场15家** — JBN荷兰B2B/尼日利亚6家(Stanificent/RapidBTS/Servo/Hiwales/Zentch/EVAPRAISE)/乌干达5家(Infinity/Jade/Pavan/Mercury/Oscarvision)/坦桑尼亚1家(Empire)/肯尼亚3家(HubTech/CTC/TDK)/加纳1家(SafetyHub)/央行Perle案例/ONV深圳
> 3. **拉美3家** — Metacom智利/AleTecno阿根廷/Chile Mayoristas
> 4. **Alibaba OEM 11家** — Lavid 18年/Hioso/E-Linkchina/SVL/Veemco/Ewind 5000㎡/Fei Chang/SDAPO/Intellinet/MatchDigi LB-Link/Emirtech
> 5. **其他1家** — Araknis AV PoE
