# Batch 16 — 教育/医疗/酒店垂直 + 大洋洲 + 更多PoE品牌
> 深度挖掘 Round 39-42 (2026-10-25)
> 方法论：教育PoE / 医疗PoE / 酒店PoE / 大洋洲分销 / 新PoE品牌

---

## 一、教育垂直

### 1. NVT Phybridge（加拿大）
- **类型**: B类 — 长距离PoE教育方案
- **网站**: nvtphybridge.com
- **产品**: PoLRE管理型交换机 (50W/口, 支持现有UTP/同轴)
- **案例**: McKinney ISD/新墨西哥州立大学(省$1M+)
- **开发策略**: 教育PoE方案专家
- **置信度**: ★★★★★

### 2. PoE Partner（德国）
- **类型**: C类 — PoE Texas欧洲授权分销
- **网站**: poe-partner.com
- **产品**: PoE+交换机/PoE++交换机/注入器/USB-C适配器
- **应用**: IP摄像头/办公室/智慧建筑/工业/户外
- **开发策略**: 德国PoE专业分销
- **置信度**: ★★★★★

### 3. Telecom Depot Direct（美国）
- **类型**: C类 — 校园网络设备
- **网站**: telecomdepotdirect.com
- **产品**: HPE Instant On 1930/Aruba 6100 PoE/Aruba 6200F
- **开发策略**: 美国校园网络分销
- **置信度**: ★★★★☆

### 4. UNDP Samoa（萨摩亚）
- **类型**: D类 — 联合国采购
- **网站**: ungm.org (UNDP-WSM-00208)
- **规格**: 3台24口云管理PoE+交换机, ≥370W, 4x10G上行, L2/L3
- **开发策略**: 联合国太平洋岛国采购
- **置信度**: ★★★★★

### 5. HP State Electronics (印度)
- **类型**: D类 — 大学WiFi招标
- **网站**: hpsedc.in
- **规格**: 49台24口PoE交换机 (802.3af/at, 193W, IGMP Snooping)
- **项目**: Nauni大学WiFi
- **开发策略**: 印度政府教育招标
- **置信度**: ★★★★☆

---

## 二、医疗垂直

### 6. UTEPO（深圳）
- **类型**: 竞品 — 医疗PoE交换机
- **网站**: utepo.net
- **产品**: UTP7624GE-POE-L3管理型PoE交换机 (医疗VLAN)
- **开发策略**: 深圳医疗PoE竞品
- **置信度**: ★★★★★

### 7. Procet PoE（中国）
- **类型**: B类 — 光纤PoE医疗方案
- **网站**: procetpoe.com
- **产品**: 光纤PoE设备 (1G/2.5G/5G/10G, 10-60km)
- **开发策略**: PoE光纤延长方案
- **置信度**: ★★★★☆

### 8. Chesapeake Telephone（美国）
- **类型**: C类 — 医疗PoE部署
- **网站**: chesapeaketelephone.com
- **案例**: 卫生部285台IP电话 (NVT Phybridge PoLRE)
- **开发策略**: 美国医疗通信集成
- **置信度**: ★★★★☆

---

## 三、酒店/度假垂直

### 9. BBINCO（墨西哥）
- **类型**: C类 — 高端酒店技术集成
- **网站**: nvtphybridge.com案例
- **地点**: Baja California Sur / Nayarit
- **品牌**: Ruckus AP + Axis摄像头 + NVT Phybridge PoE
- **开发策略**: 墨西哥豪华度假村集成商
- **置信度**: ★★★★★

### 10. Newbridge（中国）
- **类型**: B类 — 酒店PoE交换机方案
- **网站**: cnnewbridge.com
- **产品**: 三层PoE交换机酒店方案
- **开发策略**: 中国酒店PoE方案商
- **置信度**: ★★★★☆

### 11. Moss-Link（中国）
- **类型**: B类 — 酒店WiFi制造商
- **网站**: moss-link.com
- **产品**: S802E 8口PoE交换机(96W) / XD3001K WiFi 6 AP ($80-120)
- **成本**: $8-12/口PoE, $45-72/房
- **开发策略**: 酒店WiFi+PoE设备制造商
- **置信度**: ★★★★★

### 12. CaliforniaTelecom（美国）
- **类型**: C类 — 酒店WiFi部署
- **网站**: californiatelecom.com
- **服务**: RF调查/PoE预算/VLAN/门户集成
- **开发策略**: 美国酒店WiFi集成
- **置信度**: ★★★★☆

### 13. WiFi OEM（中国）
- **类型**: B类 — 酒店WiFi设备
- **网站**: wifioem.com
- **产品**: 酒店WiFi全套设备（AP+PoE交换机+网关）
- **开发策略**: 酒店WiFi OEM
- **置信度**: ★★★★☆

### 14. Purple.ai（英国）
- **类型**: C类 — 酒店Guest WiFi平台
- **网站**: purple.ai
- **服务**: Guest WiFi分析 + PoE规划
- **开发策略**: 英国酒店WiFi平台
- **置信度**: ★★★★☆

---

## 四、大洋洲/太平洋

### 15. Go Wireless NZ（新西兰）
- **类型**: C类 — PoE交换机专业分销
- **网站**: gowifi.co.nz
- **品牌**: MikroTik/Ubiquiti/Netonix/Tycon/Teltonika/Grandstream/Omada/Cambium
- **地址**: 34 Kingsford Smith Drive, Rangiora 7400
- **电话**: +64 3 741 1339
- **开发策略**: 新西兰PoE专业分销，品牌覆盖广
- **置信度**: ★★★★★

### 16. Leading Solutions NZ（新西兰）
- **类型**: C类 — PoE Texas授权新西兰分销
- **网站**: leadingsolutions.co.nz
- **产品**: PoE Texas注入器/分配器/交换机/USB-C
- **地点**: Auckland仓库
- **开发策略**: 新西兰PoE Texas独家
- **置信度**: ★★★★★

### 17. MakroWisp（拉美/全球）
- **类型**: C类 — Ubiquiti ECS分销
- **网站**: makrowisp.com
- **产品**: ECS-24-PoE (1050W, PoE+++, 90W/口)
- **开发策略**: Ubiquiti企业级PoE分销
- **置信度**: ★★★★☆

---

## 五、更多PoE交换机品牌

### 18. Dasscom（印度）
- **类型**: B类 — PoE交换机品牌
- **网站**: dasscom.com
- **产品**: DES-P82M (8口PoE+, 96W, 802.3af/at)
- **开发策略**: 印度PoE交换机品牌
- **置信度**: ★★★★☆

### 19. ONV（深圳）
- **类型**: 竞品 — PoE交换机专业厂商
- **网站**: onvcom.com
- **成立**: 2003年
- **产品**: PoE交换机/工业交换机/电源/PoE配件
- **出口**: 120+国家
- **开发策略**: 深圳PoE竞品，老牌
- **置信度**: ★★★★★

### 20. SDAPO（东莞）
- **类型**: 竞品 — PoE模块/交换机
- **网站**: sdapo.net
- **成立**: 2012年
- **产品**: PoE模块/注入器/分配器/交换机
- **地址**: 东莞凤岗天安深创谷
- **开发策略**: 东莞PoE竞品
- **置信度**: ★★★★★

### 21. Lakshya Tech Solutions（印度）
- **类型**: C类 — PoE交换机批发
- **网站**: lakshyatechsolutions.com
- **地点**: 新德里
- **开发策略**: 印度PoE批发商
- **置信度**: ★★★★☆

### 22. IPVoice Technologies（印度）
- **类型**: C类 — PoE交换机授权经销
- **网站**: ipvoicetechnologies.in
- **品牌**: TP-Link/D-Link/Cisco/Aruba/Ubiquiti/MikroTik/Grandstream/Cambium/AirPro/Tenda
- **覆盖**: 29000+印度PIN码
- **开发策略**: 印度全境PoE经销
- **置信度**: ★★★★★

### 23. Veracity（英国）
- **类型**: B类 — PoE交换机
- **产品**: CAMSWITCH 8 Plus (802.3at PoE交换机)
- **开发策略**: 英国PoE交换机品牌
- **置信度**: ★★★★☆

---

## 六、关键市场情报更新

### PoE交换机全球市场
- **2025年**: $3.8B → 2034年 $7.9B (CAGR 8.5%)
- **管理型占72.5%出货**（1510万台）vs 非管理型570万台
- **亚太**: 710万台 (34.1%)
- **北美**: 670万台 (32.2%)
- **欧洲**: 490万台 (23.6%)
- **拉美**: 110万台 (5.3%)
- **中东非洲**: 100万台 (4.8%)

### 终端用户分布
- **IT电信**: 31.5% (最大)
- **医疗**: 17.8% (第二大)
- **教育**: 14.2% (CAGR 9.1%)
- **商业**: 40% PoE摄像头最大终端用户

### 校园PoE市场
- 教育占PoE交换机出货15%
- 韩国忠南道教育厅2025年12月部署282台PoE交换机+606台Wi-Fi 6E/7 AP
- 印度多所大学同时招标PoE交换机

### 酒店PoE规划
- Wi-Fi 6 AP: 15W/台 + 20%余量
- Wi-Fi 7 AP: 20W/台 + 20%余量
- 100间酒店: ~684W PoE预算需求
- PoE交换机成本: $8-12/口

---

**Batch 16 总计: 23家新客户/情报**

> 关键发现：
> 1. **教育5家** — NVT Phybridge/PoE Partner德国/Telecom Depot/UNDP萨摩亚/印度大学招标
> 2. **医疗3家** — UTEPO深圳/Procet/Chesapeake
> 3. **酒店6家** — BBINCO墨西哥/Newbridge中国/Moss-Link/CaliforniaTelecom/WiFi OEM/Purple英国
> 4. **大洋洲3家** — Go Wireless NZ/Leading Solutions NZ/MakroWisp
> 5. **PoE品牌6家** — Dasscom印度/ONV深圳/SDAPO东莞/Lakshya印度/IPVoice印度/Veracity英国
> 6. **市场情报**: 全球2080万台出货,管理型72.5%,教育15%,医疗17.8%,酒店PoE $8-12/口
