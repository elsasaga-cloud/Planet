# Batch 13 — 拉美 + 东欧 + 非洲分销 + IP摄像头生态
> 深度挖掘 Round 27-30 (2026-10-25)
> 方法论：拉美分销 / 东欧分销 / 非洲深度 / IP摄像头品牌生态

---

## 一、C类：拉美分销（4家）

### 1. Cables y Redes（墨西哥）
- **类型**: C类 — PoE交换机分销
- **网站**: cablesyredes.mx
- **品牌**: AirLive (ARL-IGR-842POE/IE-840POE/IG-642POE等)
- **开发策略**: 墨西哥网络设备分销
- **置信度**: ★★★★☆

### 2. Prestensys（尼日利亚Lagos/Abuja）
- **类型**: C类 — 多品牌网络交换机
- **网站**: prestensys.com
- **地址**: Ikeja, Lagos / Abuja
- **品牌**: Cisco/Juniper/Grandstream/D-Link/TP-Link/Ubiquiti/Aruba/MikroTik
- **开发策略**: 尼日利亚顶级网络交换机零售/批发
- **置信度**: ★★★★★

### 3. MercadoLibre Argentina
- **类型**: 市场情报 — Dahua PoE交换机零售
- **产品**: Dahua PFS3006-4ET-60 ($62,608 ARS, 500+ sold)
- **开发策略**: 阿根廷Dahua PoE交换机活跃市场
- **置信度**: ★★★★☆

### 4. MercadoLibre Colombia
- **类型**: 市场情报 — IP-COM PoE交换机
- **产品**: IP-COM IP-G1109P-8-102W ($529,900 COP)
- **开发策略**: 哥伦比亚PoE交换机市场
- **置信度**: ★★★★☆

---

## 二、C类：东欧分销（4家）

### 5. Quantix（波兰）
- **类型**: C类 — 网络设备供应商
- **网站**: quantixgpu.com
- **产品**: H3C S6520X (Warsaw Core Switch), CE certified
- **特点**: EU合规, 华沙/克拉科夫系统集成商合作
- **开发策略**: 波兰网络设备供应
- **置信度**: ★★★★☆

### 6. DCN Europe（波兰/欧洲）
- **类型**: C类 — PoE交换机
- **网站**: dcneurope.eu
- **邮箱**: sales@dcneurope.eu
- **产品**: ES430-18P-POE (16口千兆PoE 370W)
- **开发策略**: 欧洲DCN品牌PoE交换机
- **置信度**: ★★★★★

### 7. Telesystem（罗马尼亚）
- **类型**: C类 — PoE交换机授权分销
- **网站**: telesystem.ro
- **开发策略**: 罗马尼亚PoE交换机授权分销
- **置信度**: ★★★★★

### 8. Intellinet Network Solutions Europe（欧洲）
- **类型**: B类 — PoE交换机品牌（2006年起）
- **网站**: intellinetnetwork.eu
- **母公司**: IC Intracom Vertriebs GmbH (德国)
- **产品**: PoE/PoE+/UPoE/PoE++ 全线
- **开发策略**: 欧洲PoE专业品牌
- **置信度**: ★★★★★

---

## 三、C类：非洲分销（肯尼亚/尼日利亚/乌干达 15家）

### 9. Simplifi Networks（肯尼亚/乌干达）
- **类型**: C类 — Ubiquiti授权主分销
- **网站**: simplifinetworks.com
- **邮箱**: kenya@simplifinetworks.com
- **电话**: +254 727 401 262
- **品牌**: Ubiquiti (USW-Pro-24-PoE等全线)
- **区域**: 肯尼亚 + 乌干达
- **开发策略**: Ubiquiti东非授权主分销
- **置信度**: ★★★★★

### 10. CTC Solutions（肯尼亚内罗毕）
- **类型**: C类 — B2B网络设备
- **网站**: ctcsolutions.co.ke
- **品牌**: Ubiquiti/TP-Link/MikroTik/D-Link
- **开发策略**: 肯尼亚B2B网络设备供应商
- **置信度**: ★★★★★

### 11. City Telecom Centre（肯尼亚内罗毕）
- **类型**: C类 — B2B网络/电信
- **网站**: citytelecomcentre.com
- **品牌**: D-Link/TP-Link/Dahua
- **产品**: PoE交换机 8-52口, 最高370W
- **开发策略**: 肯尼亚ISP/企业/政府采购
- **置信度**: ★★★★★

### 12. TDK Tech Store（肯尼亚内罗毕）
- **类型**: C类 — IT/电信/太阳能
- **网站**: tdk.co.ke
- **地址**: Kai Plaza, 4th Flr, Tom Mboya St, Nairobi
- **电话**: +254 717 492 458 / +254 705 061 598
- **覆盖**: 肯尼亚 + 乌干达/坦桑尼亚/卢旺达/南苏丹/布隆迪/埃塞俄比亚/刚果民主
- **开发策略**: 东非7国覆盖
- **置信度**: ★★★★★

### 13. Almiria Techstore（肯尼亚内罗毕）
- **类型**: C类 — Ubiquiti PoE交换机
- **网站**: almiriatechstore.co.ke
- **品牌**: Ubiquiti全线
- **覆盖**: 肯尼亚 + 乌干达/坦桑尼亚/卢旺达/南苏丹/布隆迪/埃塞俄比亚/刚果民主
- **开发策略**: Ubiquiti东非专业渠道
- **置信度**: ★★★★★

### 14. Glantix（肯尼亚）
- **类型**: C类 — TP-Link/Hikvision PoE
- **网站**: glantix.co.ke
- **品牌**: TP-Link (TL-SG2428P 28口PoE+), Hikvision (DS-3E1526P-EI)
- **开发策略**: 肯尼亚网络设备零售
- **置信度**: ★★★★☆

### 15. Data World（肯尼亚内罗毕）
- **类型**: C类 — D-Link交换机经销商
- **网站**: dataworld.co.ke
- **品牌**: D-Link (PoE + 非PoE)
- **开发策略**: 肯尼亚D-Link专业渠道
- **置信度**: ★★★★☆

### 16. WaveTech（肯尼亚）
- **类型**: C类 — Ubiquiti PoE交换机
- **网站**: wavetech.co.ke
- **品牌**: Ubiquiti (USW-48-PoE/USW-24-PoE/USW-16-POE)
- **开发策略**: 肯尼亚Ubiquiti渠道
- **置信度**: ★★★★☆

### 17. Victorock Kenya（肯尼亚）
- **类型**: C类 — Ruijie Reyee PoE
- **网站**: victorockkenya.com
- **品牌**: Ruijie Reyee (RG-NBS3200-24GT4XS-P $689)
- **开发策略**: 肯尼亚Ruijie渠道
- **置信度**: ★★★★☆

### 18. Hikvision Shop Kenya（肯尼亚内罗毕）
- **类型**: C类 — Hikvision PoE交换机
- **网站**: hikvisionshopkenya.co.ke
- **品牌**: Hikvision (DS-3E0326P-E/M 24口PoE)
- **开发策略**: 肯尼亚Hikvision授权
- **置信度**: ★★★★★

### 19. Ubiquiti Shop Kenya（肯尼亚）
- **类型**: C类 — Ubiquiti全线
- **网站**: ubiquitishopkenya.co.ke
- **品牌**: Ubiquiti (USW-Pro-8-PoE/Pro-Max-16-PoE等)
- **开发策略**: 肯尼亚Ubiquiti专业渠道
- **置信度**: ★★★★★

### 20. RapidBTS（尼日利亚）
- **类型**: C类 — PoE交换机零售
- **网站**: rapidbts.ng
- **价格区间**: ₦12,000 - ₦3,000,000+
- **品牌**: TP-Link/Grandstream(预算), MikroTik/D-Link(中端), Ubiquiti/Cisco(高端)
- **开发策略**: 尼日利亚PoE专业渠道
- **置信度**: ★★★★☆

### 21. ShopIT Kenya（肯尼亚内罗毕）
- **类型**: C类 — Ubiquiti/Hikvision PoE
- **网站**: shopit.co.ke
- **品牌**: Ubiquiti (USW-Pro-24-POE KSh 132,000), Hikvision (DS-3E0526P-E KSh 29,000)
- **开发策略**: 肯尼亚网络设备零售
- **置信度**: ★★★★☆

### 22. Litecom（肯尼亚内罗毕）
- **类型**: C类 — D-Link PoE
- **网站**: litecom.co.ke
- **地址**: Revlon Plaza, Mezzanine Floor, Shop#9, Nairobi
- **品牌**: D-Link (DES-F1010P-E 10口PoE KSh 9,600)
- **开发策略**: 内罗毕D-Link渠道
- **置信度**: ★★★★☆

### 23. Jumia Kenya / Nigeria / Ghana
- **类型**: 市场情报 — PoE交换机在线零售
- **品牌**: Dahua/TP-Link/Ubiquiti/Optimax/Cisco
- **开发策略**: 非洲最大电商平台，PoE交换机活跃
- **置信度**: ★★★★★

---

## 四、品牌/技术情报

### 24. ASUS ExpertWiFi（全球）
- **类型**: B类 — ASUS PoE交换机品牌
- **产品**: EBP15 (5口千兆管理型PoE+)
- **销售渠道**: Best Buy
- **开发策略**: ASUS商用网络品牌
- **置信度**: ★★★★★

### 25. Fortinet FortiSwitch（全球）
- **类型**: 竞品 — FortiSwitch PoE
- **产品**: FortiSwitch 108F-POE (8口PoE+ 65W), 148F-FPOE (48口PoE+ 740W)
- **开发策略**: 安全+网络融合品牌
- **置信度**: ★★★★★

### 26. SonicWall Switch（全球）
- **类型**: 竞品 — SWS12-8POE
- **产品**: 8口千兆PoE管理型交换机
- **开发策略**: 安全品牌扩展到PoE交换机
- **置信度**: ★★★★★

### 27. Pinnacle（南非）
- **类型**: C类 — 南非ICT分销
- **网站**: pinnacle.co.za
- **品牌**: Huawei/Hikvision/TP-Link/Mercusys
- **开发策略**: 南非最大ICT分销之一
- **置信度**: ★★★★★

### 28. Network-Switch.com（全球）
- **类型**: B类 — Ruijie全球独家分销
- **网站**: network-switch.com
- **品牌**: Ruijie + Huawei
- **覆盖**: 100+国家
- **开发策略**: Ruijie全球在线分销
- **置信度**: ★★★★★

---

**Batch 13 总计: 28家新客户**

> 关键发现：
> 1. **拉美4家** — Cables y Redes墨西哥/Prestensys尼日利亚/MercadoLibre阿根廷&哥伦比亚
> 2. **东欧4家** — Quantix波兰/DCN Europe/Telesystem罗马尼亚/Intellinet欧洲
> 3. **非洲15家** — 肯尼亚(Simplifi/CTC/City Telecom/TDK/Almiria/Glantix/Data World/WaveTech/Victorock/Hikvision Shop/Ubiquiti Shop/ShopIT/Litecom) + 尼日利亚(RapidBTS/Prestensys) + Jumia非洲
> 4. **品牌情报5家** — ASUS/Fortinet/SonicWall/Pinnacle南非/Network-Switch.com
