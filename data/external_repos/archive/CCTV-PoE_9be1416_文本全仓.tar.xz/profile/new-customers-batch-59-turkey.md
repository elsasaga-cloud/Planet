# Batch 59: 土耳其深度挖掘
## 10渠道: 网络分销+安防+集成+零售+制造/品牌+出口+智慧城市+电商+ISAF展会+Perpa
_2026-10-27 | 55 entries | Turkey Deep Mining_

---

### 渠道A: PoE/网络分销 (17家)
- **98.1 Nokta Elektronik** 🇹🇷 A类 | 25+年, 自有品牌upTech, 200-500人, 土耳其+中东+巴尔干
- **98.2 Poyraz Network** 🇹🇷 A类 | MikroTik土耳其Master Distributor + Ubiquiti/Mimosa/Cambium
- **98.3 Art Sistem** 🇹🇷 A类 | 22年, 135品牌, 5000+经销商, 土耳其最大技术分销
- **98.4 Bimel Elektronik** 🇹🇷 A类 | 1984年, 自有品牌BEEK PoE, 802.3bt 95W
- **98.5 MNS Bilişim** 🇹🇷 B类 | Ruijie+Ubiquiti授权
- **98.6 Öncü Güvenlik** 🇹🇷 B类 | BDCOM土耳其独家(全线PoE+工业)
- **98.7 GelecekBT** 🇹🇷 B类 | CLR Networks 48口PoE 600W
- **98.8 Teknoline** 🇹🇷 B类 | PoE+CCTV+Fiber
- **98.9 Dropsan** 🇹🇷 B类 | Perpa PoE+安防
- **98.10 ITDEPO** 🇹🇷 B类 | Dahua工业PoE
- **98.11 Sunay B2B** 🇹🇷 B类 | S-GUARD自有品牌
- **98.12 Dost Kurumsal** 🇹🇷 B类 | TP-Link PoE
- **98.13 Güvenlik Bayii** 🇹🇷 B类 | Ankara批发
- **98.14 Toptan Güvenlik** 🇹🇷 B类 | Perpa批发
- **98.15 Perpa Elektronik** 🇹🇷 B类 | 工业PoE
- **98.16 Perpa Güvenlik/VENAS/ÖZTEK/POSCAM/ONQAM** 🇹🇷 B类 | Perpa多店PoE
- **98.17 CCTV Depo** 🇹🇷 B类 | 51-200人, Perpa+Güngören

### 渠道B: 安防集成 (12家)
- **98.18 AVENIR Security** 🇹🇷 A类 | 1,500代理商+经销商(土耳其+周边国)
- **98.19 Pronet** 🇹🇷 B类 | 200K订户, 银行+零售
- **98.20 Entegre Satek** 🇹🇷 B类 | 20+年, 土耳其+俄罗斯+哈萨克
- **98.21 ENTPA Elektronik** 🇹🇷 B类 | 领先分销(CCTV+门禁+智能家居)
- **98.22 Koyuncu Elektronik** 🇹🇷 B类 | 全国技术分销
- **98.23 BES Teknoloji** 🇹🇷 B类 | IT+安防分销
- **98.24 Biges Güvenli Hayat** 🇹🇷 B类 | 51-200人, 25+年, 城市安全
- **98.25 Ateksis** 🇹🇷 B类 | 系统集成(机场+银行+医院+大学+城市监控)
- **98.26 NFS Teknoloji** 🇹🇷 B类 | Samsung/Pelco/Schneider分销
- **98.27 Simet Technologies** 🇹🇷 B类 | VAD网络(Ankara)
- **98.28 Rima Elektronik** 🇹🇷 B类 | IP摄像头+网络基础设施
- **98.29 Fescom Engineering** 🇹🇷 B类 | 网络+IP CCTV+数据中心

### 渠道C: 安防零售/安装 (8家)
- **98.30 Y3K Güvenlik** 🇹🇷 C类 | Istanbul 2005
- **98.31 Kasa Elektronik** 🇹🇷 C类 | Ankara 2019
- **98.32 Fides Teknoloji** 🇹🇷 C类 | Ankara 1994, 51-200人
- **98.33 BMG Grup** 🇹🇷 C类 | Izmir 30+年
- **98.34 Aydın Elektronik** 🇹🇷 C类 | Ankara 20+年
- **98.35 Cihan Teknoloji** 🇹🇷 C类 | Ankara Ostim 2006
- **98.36 ESM Teknoloji** 🇹🇷 C类 | Istanbul 2020
- **98.37 Güler Güvenlik** 🇹🇷 C类 | Ruijie Reyee

### 渠道D: 土耳其PoE制造/品牌 (OEM目标, 8家)
- **98.38 STG Engineering** 🇹🇷 A类 | Ankara Ostim, 自研工业PoE交换机(8口802.3at 240W, 12-60V DC, fanless IP30)
- **98.39 BESTA Bilişim** 🇹🇷 A类 | 土耳其PoE品牌(4/8/16/24口全线)
- **98.40 ARNA** 🇹🇷 A类 | 土耳其PoE品牌(4/8/24口)
- **98.41 Dayline** 🇹🇷 B类 | 土耳其品牌(8/16口Gigabit)
- **98.42 Hadron** 🇹🇷 B类 | 土耳其品牌(4+2/8口)
- **98.43 KR品牌** 🇹🇷 B类 | 土耳其品牌(4/8/16/24口, 260-3,124TL)
- **98.44 QPORT** 🇹🇷 B类 | 土耳其品牌(8口10/100+Gigabit)
- **98.45 CLR Networks** 🇹🇷 B类 | 48口600W L2+管理

### 渠道E: 出口商 (3家)
- **98.46 Aglobal Teknoloji** 🇹🇷 B类 | PoE+SFP+CCTV+光纤
- **98.47 Sasmaz Elektrik** 🇹🇷 B类 | PoE全线+NETGEAR+UniFi
- **98.48 IMCA/ISON** 🇹🇷 B类 | 工业PoE

### 渠道F: 智慧城市 (3家)
- **98.49 İBB伊斯坦布尔市政府** 🇹🇷 A类 | 2030智慧计划, 500万→2500万IoT, İSBAK执行
- **98.50 Ankara市政府** 🇹🇷 B类 | SMART Ankara(EU支持)
- **98.51 SMARTKENT/ATRAX 2027** 🇹🇷 渠道 | 智慧城市展

### 渠道G: 电商平台 (4家)
- **98.52 Trendyol** 🇹🇷 渠道 | #1(3000万用户, Alibaba)
- **98.53 Hepsiburada** 🇹🇷 渠道 | #2(NASDAQ上市)
- **98.54 Amazon.com.tr** 🇹🇷 渠道 | #3
- **98.55 Cimri.com** 🇹🇷 渠道 | 比价平台

---

## 关键数据

### 土耳其PoE市场价格情报
- 白牌4+2口10/100: **260 TL (~$8)** — 全球最便宜区间之一
- 白牌8+2口Gigabit 120W: **429 TL (~$13)**
- 白牌24口Gigabit+1SFP 300W: **1,129 TL (~$33)**
- 土耳其本土品牌BESTA/ARNA/KR/Dayline/Hadron/QPORT全线覆盖
- 价格带: $8(4口) → $620(24口Gigabit) → 高端管理

### ISAF展会 (土耳其+地区最大安防展)
- 2026年10月7-10日, Istanbul Expo Center
- 600参展商, 18,000+访客, 87国, 15,300m²
- 30年历史, 安防+CCTV+门禁+报警+网安+消防+智能建筑

### Perpa Ticaret Merkezi
- 土耳其最大电子/安防批发中心(1989年成立)
- A Blok 8-11层: 安防公司集中区
- PoE交换机商铺: Nokta/GelecekBT/Perpa Güvenlik/Dropsan等

### 土耳其PoE市场特征
- 中国进口$49.57B(占14.39%, 最大进口来源)
- 电子关税: 0-5% + 20% VAT
- EU关税同盟(部分)
- 85M人口, 欧洲第4大市场
- 白牌需求巨大(KR/ARNA/BESTA/Dayline/Hadron等本土品牌=中国OEM)
- 6+本土PoE品牌=完美OEM市场

### 最高优先级客户
1. **Nokta Elektronik** — 自有品牌upTech, 200-500人, 土耳其+中东+巴尔干
2. **AVENIR Security** — 1,500代理商网络, 土耳其+周边国
3. **Art Sistem** — 5,000+经销商, 135品牌
4. **Bimel** — 自有品牌BEEK, 40年历史
5. **STG Engineering** — 土耳其唯一自研工业PoE
6. **BESTA/ARNA** — 土耳其本土PoE品牌(OEM)
7. **İBB** — 2030智慧城市, 2500万IoT传感器
8. **Poyraz Network** — MikroTik土耳其总代
