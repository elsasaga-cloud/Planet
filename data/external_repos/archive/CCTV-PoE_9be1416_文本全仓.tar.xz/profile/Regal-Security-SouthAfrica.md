# 客户档案：Regal Security Distributors — 南非

## 基本信息

| 项目 | 内容 |
|------|------|
| 公司全称 | Regal Distributors SA (Pty) Ltd |
| 品牌名 | Regal Security |
| 国家 | 南非 |
| 类型 | 安防设备分销商（南非最成功多品牌分销商之一） |
| 网站 | regalsecurity.co.za |
| 成立 | 1981年（45年历史！） |
| 员工 | 251-500人 |
| 客户级别 | **A级（核心）** |

## 联系信息

| 渠道 | 信息 |
|------|------|
| 总部 (Edenvale, JHB) | +27 11 553 3300 / enquiries@regalsecurity.co.za |
| **出口部** | **+27 87 537 4100 / exports@regalsecurity.co.za** ← 最重要 |
| 在线询价 | +27 10 745 6489 / online@regalsecurity.co.za |
| 技术支持 | +27 11 553 3300 / techsupport@regalsecurity.co.za |
| 地址 | 26 Greenstone Place, Greenstone Hill, Edenvale, 1609 |
| LinkedIn | 搜索"Regal Distributors SA" |

### 分支机构（8+个！）
| 分支 | 电话 | 邮箱 |
|------|------|------|
| Alberton | 087 537 4166 | alberton@regalsecurity.co.za |
| Balfour Park (JHB) | 011 640 2288 | balfour@regalsecurity.co.za |
| Roodepoort | 011 760 1149 | roodepoort@regalsecurity.co.za |
| Strijdom Park | 011 791 4770 | stijdom@regalsecurity.co.za |
| East London | 043 735 4537 | eastlondon@regalsecurity.co.za |
| eMalahleni (Witbank) | 013 656 4140 | emalahleni@regalsecurity.co.za |
| Somerset West (Cape Town) | 021 013 7400 | somerset@regalsecurity.co.za |

**关键：有专门的出口部！覆盖非洲其他国家**

## 公司深度分析

### 业务规模
- **45年历史** — 南非安防行业最资深的分销商
- **251-500员工** — 大型企业
- **8+分支机构** — 覆盖南非全国
- **出口部** — 覆盖非洲其他国家
- **全品类** — CCTV、报警、门禁、自动化、电围栏、太阳能

### 当前品牌组合
Hikvision, Dahua, DSC, Paradox, ZKTeco, Centurion, ET Systems 等

### 为什么是A级
1. **南非最大安防分销商之一** — 45年历史，8+分支
2. **有专门出口部** — 可覆盖整个非洲
3. **PoE交换机是刚需** — 每个CCTV项目都需要
4. **多品牌经营** — 容易引入新品牌
5. **251-500员工** — 规模大，采购量大

## 推荐Saga产品

### 主推产品
| Saga型号 | 规格 | FOB($) | 推荐理由 |
|----------|------|--------|---------|
| STC-028GFP | 10口百千兆PoE | $13-15 | 安防标配爆款，配合Hikvision/Dahua摄像头 |
| STC-1216GFP | 18口百千兆PoE | $29-32 | 中型项目标配 |
| STC-1224GFP | 26口百千兆PoE | $41-45 | 大型项目 |
| STC-228GP | 12口千兆PoE+SFP | $24-28 | 高端项目+光纤联网 |
| STC-128GFP | 11口百千兆PoE+SFP | $18-20 | 带SFP光口，远距离传输 |
| PoE延长器 | 100m→250m | $4-7 | 非洲远距离部署必备 |
| STC-08GE | 8口千兆以太网 | $8 | ICT网络配套 |

### 核心卖点
1. **"南非市场最低价"** — 6口PoE FOB $7.5，10口PoE FOB $13-15
2. **"250米PoE传输"** — 标准100米的2.5倍，减少布线成本
3. **"金属外壳+PoE看门狗"** — 专业安防级，非塑料壳白牌
4. **"完美兼容Hikvision/Dahua"** — 你现有的摄像头品牌
5. **"OEM Regal品牌"** — 可贴Regal Security品牌
6. **"出口部对接"** — 可通过出口部覆盖非洲其他国家

## 跟进计划

| 阶段 | 行动 | 时间 |
|------|------|------|
| 1 | 邮件发exports@regalsecurity.co.za（出口部！） | 本周 |
| 2 | 同时发enquiries@regalsecurity.co.za | 本周 |
| 3 | 电话+27 87 537 4100（出口专线） | 1周内 |
| 4 | 寄送样品到Edenvale总部 | 2周内 |
| 5 | 讨论南非全国8分支+非洲出口供货方案 | 1个月后 |

## 预期订单

| 阶段 | 预估金额 |
|------|---------|
| 首单 | $10,000-20,000 |
| 年供货 | $100,000-300,000 |
| 出口部合作后 | $200,000-500,000+ |
