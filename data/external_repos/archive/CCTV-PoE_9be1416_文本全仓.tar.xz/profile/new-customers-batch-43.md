# Batch 43 — 交通运输PoE：铁路EN50155 + 海事DNV GL + 军事MIL-STD + 可再生能源

**日期**: 2026-10-25  
**搜索轮次**: Round 159-163  
**新增客户/情报**: 22 家  
**聚焦**: 铁路轨道交通, 海事船舶, 军事国防, 太阳能/风能

---

## 🚄 一、铁路轨道交通 PoE (EN50155)

### 1. TRENDnet EN50155铁路系列 (美国)
- **类型**: B类 - 铁路PoE专家
- **产品**:
  - TI-XPG50 V1: 5口M12千兆PoE+, 4xPoE+1, 120W@56V, IP67户外, EN50155/EN50121-3/4
  - TI-TPG80: 8口M12千兆PoE+, 200W@48V/100W@24V, IP40, EN50155, 终身保修
  - TI-XPG102: 10口M12千兆PoE+, 8xPoE+2 Bypass, 200W@56V, IP40, NDAA/TAA, -40~75°C
- **特点**: M12 X-coded连接器, 振动/冲击防护, 列车/公交/电信应用
- **开发策略**: 美国EN50155铁路PoE专家 ★★★★★

### 2. ORing TGPS-9084GT铁路系列 (台湾)
- **类型**: B类 - 铁路PoE+Bypass
- **产品**: TGPS-9084GT-M12X-BP2-24V, 管理千兆PoE, 8xPoE 30W/口 + 4上行 + 2 Bypass端口组
- **标准**: EN50155铁路/交通, 滚动库存/车载网络
- **特点**: Bypass保持网络完整性 (电源故障/维护时)
- **开发策略**: 台湾铁路PoE+Bypass专家 ★★★★★

### 3. Inmax M12铁路系列 (中国)
- **类型**: A类 - 铁路PoE
- **产品**:
  - 16口X-code M12: 车载交通地铁铁路千兆管理, 16xM12 PoE 15.4W/30W, EN50155
  - 8口M12 D-coded: 48V M12铁路以太网交换机, 8xPoE
- **开发策略**: 中国M12铁路PoE ★★★★★

### 4. MEN Mikro Elektronik (德国)
- **类型**: B类 - 铁路以太网
- **产品**: 8口加固以太网交换机, EN50155 + ISO 7637-2, -40~70°C (85°C 10分钟Tx), PoE+可选
- **应用**: 道路, 铁路, 工业 (恶劣环境)
- **开发策略**: 德国铁路PoE ★★★★★

---

## 🚢 二、海事船舶 PoE (DNV GL)

### 5. VOLKTEK DNV系列 (台湾)
- **类型**: B类 - DNV海事认证
- **产品**:
  - INS-8005M: 5口10/100非管理, DNV海事认证
  - INS-8405M: 5口千兆非管理, DNV海事
  - INS-8405EM: 5口千兆高级非管理, DNV海事
  - INS-8408AM: 8口千兆非管理, DNV海事
  - IEN-9648M: 8口千兆+4 SFP管理, DNV海事 (防腐蚀海洋环境)
- **开发策略**: 台湾DNV海事PoE专家 ★★★★★

### 6. Sbjlink DNV GL系列 (中国)
- **类型**: A类 - DNV GL海事
- **产品**:
  - RPT-1005-DNV-X3: 5口100M工业, DNV GL海事
  - RPT-1005G-DNV-X3: 5口千兆工业, DNV GL海事
  - RPT-1008G-DNV-X3: 8口千兆工业, DNV GL海事
- **开发策略**: 中国DNV GL海事PoE ★★★★★

### 7. Westermo DNV系列 (瑞典)
- **类型**: B类 - DNV海事+海上
- **产品**:
  - Lynx 3510-F2G2.5-P8G-LV Gen 2: L2 2.5G PoE+, IEC 62443-4-2 SL2, 8口千兆PoE + 2x2.5G SFP
  - Lynx 3510-E-F2G2.5-P8G-LV: L3 PoE+, 8口千兆 + 2x2.5G SFP, 240W, 30W/口, -40~70°C
  - Lynx 3510-E-F2G2.5-T8G-LV: L3千兆, 8口 + 2x2.5G SFP, DC12-48V
- **应用**: 海事+海上 (Maritime & Offshore)
- **开发策略**: 瑞典DNV海事PoE ★★★★★

### 8. Danbit DNV GL (丹麦)
- **类型**: B类 - DNV GL海事
- **产品**: 5口千兆DNV GL海事认证, DC9-48V, 4W, -40~75°C, IP30, DIN轨, 110x74x24mm, 160g
- **特点**: 瞬态/浪涌保护, 极性保护
- **开发策略**: 丹麦DNV GL海事PoE ★★★★★

### 9. Kaira Global DNV GL (印度)
- **类型**: C类 - DNV GL分销
- **产品**: VOLKTEK IEN-9648M (8口千兆+4 SFP管理, DNV GL, 防腐蚀海洋/海上)
- **开发策略**: 印度DNV GL海事分销 ★★★★☆

---

## 🎖️ 三、军事国防 PoE (MIL-STD)

### 10. Milpower Source MILTECH系列 (美国)
- **类型**: B类 - 军事PoE专家
- **产品**:
  - MILTECH 610-PoE: 8口100M PoE, 240W总功率, MIL-STD-810/461/1275/704, IP67, D38999连接器, -45~85°C
  - MILTECH 9020: 26口L2/L3管理, Cisco硬件+IOS-XE, MIL-STD-810/461, IP67, -40~71°C, DC18-48V
  - MILTECH 402: 微型加固PoE, 2xPoE+3铜, SCE2连接器, MIL-STD-810/461, IP67
  - MILTECH 910-PoE: 8口千兆PoE+管理, D38999连接器
  - MILTECH 908: 8口千兆管理, MIL-STD-810F/461E/1275B, 无风扇被动冷却
  - MILTECH 24FO: 24口1G光纤管理, MIL-STD-810F, Amphenol SIM连接器, -45~85°C
- **应用**: 军事/航空/地面移动, COTS PoE摄像头/WiFi/网格节点
- **开发策略**: 美国军事PoE专家 ★★★★★

### 11. 7STARLAKE THOR200系列 (台湾)
- **类型**: B类 - 军事加固PoE
- **产品**:
  - THOR200-P16: 12口千兆+4x10G SFP+, L2+管理
  - THOR200-PE8D: 8口千兆PoE 30W/口 120W@24V + 16口千兆 + D38999, L2管理, -40~70°C
  - THOR200-PE20: 8口千兆PoE 30W/口 120W@24V + 4 SFP DDM, L2+管理, -40~70°C
- **特点**: 2U半加固, 战场网络, IP摄像头/传感器/无线电/AP实时态势感知
- **开发策略**: 台湾军事加固PoE ★★★★★

### 12. Techaya MILTECH (以色列)
- **类型**: B类 - 军事PoE
- **产品**: MILTECH 610-PoE, 8口100M PoE+, 240W, MIL-STD-810F/461E/1275B, IP67, 加固冲击/振动
- **开发策略**: 以色列军事PoE ★★★★★

### 13. Bel Aerospace Defense (美国)
- **类型**: B类 - 军事PoE
- **产品**: MILTECH 610PoE, 8口100M PoE 30W/口 240W, 802.3af/at, 加固入侵/冲击/振动, 被动冷却无运动部件
- **开发策略**: 美国军事航空PoE ★★★★★

### 14. Military PoE (milpoe.net)
- **类型**: B类 - 军事PoE专家
- **规格**: PoE功率330W, 总预算720W, DC9-60V宽范围, -40~75°C, 过流/过压/短路保护, MIL-STD 810/IP67/NEMA 4X, NDAA合规
- **开发策略**: 军事PoE专家网站 ★★★★★

### 15. TacticalNet Systems (美国)
- **类型**: B类 - 军事TSN
- **产品**: VehicleCore TSN-10G, 加固管理10GbE, IEEE 802.1Qbv TSN, MIL-STD-810H/461G, 8口10GbE (2025 Q1发布)
- **开发策略**: 美国军事TSN PoE ★★★★★

---

## ☀️ 四、太阳能/风能可再生能源 PoE

### 16. Planet Technology 可再生能源系列 (台湾)
- **类型**: B类 - 可再生能源PoE专家
- **产品**:
  - BSP-115PV-15A: 5口千兆PoE+ + SFP, LCD显示, 太阳能/风能/水电充电, 120W, $345
  - BSP-115HP-5A: 5口混合PoE, 端口1 60W + 端口2-5 802.3at + 端口4-5被动24V/48V, 65W, $262.50
  - BSP-360: 5口千兆管理/路由, 4口PoE+ 30W/口 120W, 可再生能源, $945 (停产)
  - IGS-624HPT: 工业802.3at光纤PoE, 12-54V冗余, 120W, IP40, -40~75°C (太阳能农场案例)
- **案例**: 太阳能农场网络 (IP摄像头+门禁)
- **开发策略**: 台湾可再生能源PoE专家 ★★★★★

### 17. FICOTEK 太阳能PoE (中国)
- **类型**: A类 - 太阳能PoE
- **产品**: 工业温度, 防雷, 全管理, OEM/ODM
- **应用**: 安防, 能源, 风电, 铁路
- **开发策略**: 中国太阳能PoE ★★★★★

### 18. UTEPO 太阳能PoE (中国)
- **类型**: A类 - 太阳能工业PoE
- **产品**: UTP7310S-PSD240-W, 工业8口千兆PoE+ + 2x1G/2.5G SFP L2管理, 8口45W/口
- **开发策略**: 中国太阳能工业PoE ★★★★★

### 19. LIFEPOE 太阳能系列 (中国)
- **类型**: A类 - 太阳能PoE
- **产品**: 工业10口千兆, 8x802.3af/at 30W 120W + 2上行, DC12-24V升压DC48V, 双DC12-24V冗余自动故障切换, IP30, -10~60°C, 6KV浪涌
- **应用**: 太阳能/RV卡车/VoIP
- **开发策略**: 中国太阳能PoE升压 ★★★★★

### 20. Linovision 太阳能系列 (中国+美国)
- **类型**: A类 - 太阳能PoE专家
- **产品**:
  - POE-SW804G-Solar: 4口千兆PoE + 1上行, 内置MPPT, 太阳能+电池12V/24V, 120W@24V/60W@12V
  - POE-SW805G5U-Solar: 5口千兆PoE + 1.25G SFP, 内置PWM, 端口1 BT60W, 端口4-5可切换被动24V, 65W
  - POE-SW806GM-Solar: 4口千兆PoE + 2 SFP, 内置MPPT, 端口1-2可切换被动24V, 端口3-4 BT90W, 120W
  - 工业5口千兆12V: DC9-54V输入到48V PoE输出, 4x802.3af/at 30W 120W, IP40
- **开发策略**: 中国+美国太阳能PoE专家 ★★★★★

---

## 📊 Batch 43 统计

- **新增客户/情报**: 20 家
- **聚焦行业**: 铁路EN50155, 海事DNV GL, 军事MIL-STD, 可再生能源
- **覆盖国家**: +4 (德国, 丹麦, 印度, 以色列已有)

---

## 🎯 关键技术发现

1. **铁路EN50155**: TRENDnet M12系列 (5/8/10口), ORing Bypass, Inmax 16口, MEN Mikro (德国)
2. **海事DNV GL**: VOLKTEK (5口), Sbjlink (5/8口), Westermo Lynx, Danbit (丹麦), Kaira Global (印度)
3. **军事MIL-STD**: Milpower MILTECH (8/26口), 7STARLAKE THOR200 (台湾), Techaya (以色列), Bel Aerospace, milpoe.net 330W/720W
4. **可再生能源**: Planet BSP系列 (太阳能/风能/水电), FICOTEK, UTEPO, LIFEPOE升压, Linovision MPPT/PWM

---

## 📈 累计统计

- **总客户/情报数**: 1,171 家 (1151 + 20)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 45 次
- **超额完成**: 167% (目标 700客户)
