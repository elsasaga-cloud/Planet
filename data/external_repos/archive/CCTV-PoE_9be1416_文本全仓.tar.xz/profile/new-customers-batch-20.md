# Batch 20 — OpenWrt设备映射 + 中亚/高加索市场 + PoE照明新赛道 + 印度分销
> 深度挖掘 Round 59-62 (2026-10-25)
> 方法论：OpenWrt Realtek设备列表 / ExportGenius中亚进口数据 / PoE照明802.3bt生态 / 印度PoE分销商

---

## 一、OpenWrt/Realtek芯片设备映射（新品牌发现）

### 1. LevelOne LGS系列（德国）
- **类型**: C类 — RTL930x/RTL931x OpenWrt支持
- **网站**: levelone.com
- **型号**: LGS310MPC (€49, 10口1G RTL838x), LGS328C (€69, 28口RTL930x), LGS328MPC (€89, 28口PoE RTL930x), LGS352C (€99, 52口RTL931x)
- **开发策略**: 德国品牌使用Realtek芯片，OpenWrt社区推荐
- **置信度**: ★★★★★

### 2. Abaniact AML2-17GP（西班牙）
- **类型**: C类 — RTL8382 OpenWrt支持
- **网站**: abaniact.com
- **型号**: AML2-17GP 17口 RTL8382
- **开发策略**: 西班牙品牌使用Realtek芯片
- **置信度**: ★★★★☆

### 3. Mercury SE106（水星，中国）
- **类型**: 竞品 — RTL8372 2.5G
- **型号**: SE106 5口2.5G RTL8372
- **开发策略**: 水星2.5G交换机Realtek芯片
- **置信度**: ★★★★★

### 4. Linksys SE4008（美国）
- **类型**: 竞品 — RTL8370N
- **型号**: SE4008 WRT 8口千兆 RTL8370N
- **开发策略**: Linksys使用Realtek芯片
- **置信度**: ★★★★★

### 5. TRENDnet TEG-S80g/S82g（美国）
- **类型**: 竞品 — RTL8370N
- **型号**: TEG-S80g V2.0R / TEG-S82g V2.1R 8口千兆 RTL8370N
- **开发策略**: TRENDnet使用Realtek芯片
- **置信度**: ★★★★★

### 6. Western Digital My Net Switch（美国）
- **类型**: 竞品 — RTL8370
- **型号**: My Net Switch 8口千兆 RTL8370 (Alpha Networks制造, 2012)
- **开发策略**: WD已停产网络产品
- **置信度**: ★★★★☆

### 7. Sodola SL510S-4T2XS（深圳）
- **类型**: 白牌 (Hasivo OEM确认)
- **芯片**: RTL9303 + RTL8264B
- **规格**: 4口10G铜缆 + 2口SFP+
- **评测**: ServeTheHome确认
- **开发策略**: 10G白牌竞品，OpenWrt支持中
- **置信度**: ★★★★★

### 8. HORACO 2.5GbE Managed（深圳）
- **类型**: 白牌 (HRUI OEM确认)
- **芯片**: RTL837x
- **规格**: 5+1口2.5G管理型
- **来源**: OpenWrt论坛推荐
- **开发策略**: AliExpress白牌竞品
- **置信度**: ★★★★☆

### 9. TP-Link TL-SE2106（中国）
- **类型**: 竞品 — RTL8373 2.5G
- **芯片**: RTL8373
- **规格**: 5+1口2.5G管理型
- **开发策略**: TP-Link中国版2.5G Realtek
- **置信度**: ★★★★★

### 10. HPE 1920-8G-PoE+（美国）
- **类型**: 竞品 — RTL8380M
- **芯片**: RTL8380M
- **规格**: 8口千兆PoE+管理型
- **开发策略**: HPE SMB使用Realtek芯片
- **置信度**: ★★★★★

---

## 二、中亚/高加索市场情报

### 11. Uzbekistan PoE市场
- **类型**: B类区域市场
- **数据**: 2025年271批8口PoE交换机进口, 39活跃进口商, 35海外供应商, $1.55M进口额(2025.3-2026.2)
- **开发策略**: 中亚新兴市场，中国供应商有优势
- **置信度**: ★★★★★

### 12. Kazakhstan PoE市场
- **类型**: B类区域市场
- **数据**: 3,480台PoE交换机进口总量 (Volza)
- **开发策略**: 中亚市场，俄系渠道
- **置信度**: ★★★★★

### 13. Netis.ge（格鲁吉亚）
- **类型**: C类 — 格鲁吉亚PoE零售商
- **网站**: netis.ge
- **品牌**: Dahua/Ruijie/HPE/Hilook PoE交换机
- **地点**: Tbilisi
- **开发策略**: 高加索地区零售渠道
- **置信度**: ★★★★☆

---

## 三、PoE照明新赛道（802.3bt 90W）★★★★★

> ⚠️ **市场洞察**: PoE照明是2026年最快速增长的PoE应用之一，IEEE 802.3bt 90W/口使85%商业照明可直接PoE供电。市场预估2024年2亿+米以太网支持PoE端点。

### 14. IGOR / Nexos（美国）
- **类型**: B类 — PoE照明市场份额领导者
- **网站**: igornext.com
- **产品**: Nexos IoT平台, PoE照明控制
- **覆盖**: 30+国家
- **开发策略**: PoE照明领导者，需要高功率PoE交换机
- **置信度**: ★★★★★

### 15. GENISYS / Innovative Lighting（美国）
- **类型**: B类 — PoE照明制造商
- **网站**: genisyslighting.com
- **成立**: 1993年 (Iowa)
- **产品**: PoE LED灯具/控制器/软件, Made in USA
- **开发策略**: 美国PoE照明制造商，需PoE交换机
- **置信度**: ★★★★★

### 16. MHT Technologies / Inspextor（美国）
- **类型**: B类 — PoE智能楼宇
- **网站**: mht-technologies.com
- **成立**: 2008年 (NY)
- **产品**: Inspextor PoE楼宇自动化平台 (照明/窗帘/门禁/传感器)
- **开发策略**: 纽约PoE智能楼宇品牌
- **置信度**: ★★★★★

### 17. Signify / Philips（荷兰）
- **类型**: B类 — PoE照明
- **事件**: 2024年推出PoE灯具+传感器+边缘控制, 20+商业园区
- **开发策略**: 全球照明巨头进入PoE
- **置信度**: ★★★★★

### 18. PoE Texas（美国）
- **类型**: B类 — PoE照明交换机
- **网站**: shop.poetexas.com
- **产品**: GBTS-10-8-M 8口L2 BT 90W/口 720W, Denton Digital Building Intelligence
- **开发策略**: 美国PoE照明交换机品牌
- **置信度**: ★★★★★

### 19. IPCamPower / POEPower（美国）
- **类型**: B类 — 802.3bt PoE交换机
- **网站**: ipcampower.com
- **产品**: 4口/8口BT 90W交换机, 380-770W, PoE照明/PTZ
- **开发策略**: 美国高功率PoE交换机品牌
- **置信度**: ★★★★★

### 20. Fastcabling（中国/美国）
- **类型**: B类 — PoE照明方案
- **产品**: 5口BT 90W 180W, Amazon, CE/FCC
- **开发策略**: PoE照明交换机品牌
- **置信度**: ★★★★☆

### 21. Linovision（深圳/欧洲）
- **类型**: B类 — 工业BT PoE照明
- **网站**: eu.linovision.com
- **产品**: 工业8口BT 90W PoE交换机, RS485 IoT集成, NDAA
- **开发策略**: PoE照明+IoT方案
- **置信度**: ★★★★★

### 22. MICROSENS（德国）
- **类型**: B类 — PoE照明控制器
- **网站**: microsens.com
- **产品**: Smart Lighting Controller PoE 90W, 6输出/50W每通道
- **开发策略**: 德国PoE照明控制器
- **置信度**: ★★★★★

### 23. Tycon Systems / Tycon Power（美国）
- **类型**: B类 — PoE照明电源
- **网站**: tyconsystems.com
- **产品**: PoE注入器/交换机/中间跨度 for LED照明
- **开发策略**: 美国PoE照明电源品牌
- **置信度**: ★★★★★

### 24. Sinclair Digital / X-PoE（美国）
- **类型**: B类 — X-PoE照明方案
- **网站**: sinclair-digital.com
- **产品**: X-PoE交换机 (兼容IEEE 802.3af/at/bt)
- **开发策略**: PoE照明交换机新协议
- **置信度**: ★★★★☆

### 25. Procet PoE / LEDCET（中国）
- **类型**: B类 — PoE照明方案
- **网站**: procetpoe.com
- **产品**: BT High Power PoE + LEDCET PoE照明系统
- **开发策略**: PoE照明整体方案
- **置信度**: ★★★★★

### 26. Microchip/Microsemi（美国）
- **类型**: B类 — PoE照明交换机芯片
- **产品**: PDS-408G 8口BT 480W $980
- **开发策略**: 芯片级PoE照明方案
- **置信度**: ★★★★★

---

## 四、新发现交换机品牌/方案

### 27. LINKOH（深圳）
- **类型**: A类 — 交换机OEM/ODM
- **网站**: linkohnet.com
- **成立**: 2009年 (设计→2014国际)
- **产品**: 1G/2.5G/10G/Web-Smart/L2/L3-Lite/PoE+/PoE++/Industrial/TSN
- **规模**: 200+品牌客户 30+国家, 1500-2000㎡, 6KV浪涌
- **开发策略**: 深圳OEM/ODM，与Saga产品线高度匹配
- **置信度**: ★★★★★

### 28. Hyconext（全球）
- **类型**: B类 — 2.5G PoE招商
- **网站**: hyconext.com
- **产品**: NextWav/NextWav Lite 2.5G PoE交换机
- **目标**: WISP/企业市场
- **开发策略**: 全球招代理
- **置信度**: ★★★★☆

### 29. Network-Switch.com（中国/香港）
- **类型**: B类 — Ruijie独家全球分销
- **网站**: network-switch.com
- **品牌**: Ruijie + Huawei
- **开发策略**: 自有品牌出海+Ruijie分销
- **置信度**: ★★★★☆

### 30. Todahika（苏州）
- **类型**: B类 — PoE交换机批发
- **网站**: todahika.com
- **产品**: Suzhou Todahika Technology PoE交换机
- **开发策略**: 苏州PoE批发供应商
- **置信度**: ★★★☆☆

### 31. Focuscom（中国）
- **类型**: B类 — PoE OEM/ODM
- **网站**: en.focuscom.com.cn
- **产品**: 高速上行PoE交换机, OEM/ODM
- **市场**: 中东/欧洲/北美
- **开发策略**: PoE OEM品牌
- **置信度**: ★★★★☆

### 32. PoE Partner（德国）
- **类型**: B类 — PoE智能楼宇方案
- **网站**: poe-partner.com
- **产品**: PoE Texas Switch (90W/口), PoE riser系统
- **开发策略**: 德国PoE楼宇集成
- **置信度**: ★★★★☆

### 33. Atlantik Elektronik（德国）
- **类型**: C类 — Lantronix PoE分销
- **网站**: openPR.com
- **产品**: Lantronix SM24TBT4XPA/SM24TBT2DPB PoE++交换机
- **开发策略**: 德国IoT楼宇PoE分销
- **置信度**: ★★★★☆

### 34. Versitron（美国）
- **类型**: B类 — 工业PoE制造
- **网站**: versitron.com
- **产品**: 工业级PoE交换机 (IoT/安防/智慧城市/工厂)
- **开发策略**: 美国工业PoE品牌
- **置信度**: ★★★★★

---

## 五、印度PoE分销商

### 35. Lakshya Tech Solutions（New Delhi）
- **类型**: C类 — PoE批发
- **网站**: lakshyatechsolutions.com
- **开发策略**: 印度PoE分销
- **置信度**: ★★★☆☆

### 36. Syrotech Networks（Noida）
- **类型**: B类 — PoE制造
- **网站**: exportersindia.com
- **地点**: Sector 63, Noida
- **开发策略**: 印度PoE制造
- **置信度**: ★★★☆☆

### 37. Om Automation（New Delhi）
- **类型**: C类 — Teltonika/Ubiquiti PoE
- **产品**: Teltonika TSW101, Ubiquiti PoE
- **开发策略**: 印度PoE分销
- **置信度**: ★★★☆☆

---

**Batch 20 总计: 37家新客户/情报**

> 关键发现：
> 1. **OpenWrt设备映射10家** — LevelOne德国/Abaniact西班牙/Mercury/Linksys/TRENDnet/WD/Sodola 10G/HORACO/TP-Link/HPE 1920全部使用Realtek芯片
> 2. **中亚市场3家** — Uzbekistan 39进口商$1.55M / Kazakhstan 3,480台 / Netis.ge格鲁吉亚
> 3. **PoE照明新赛道13家** — IGOR(领导者30+国)/GENISYS/MHT/Signify/Philips/PoE Texas/IPCamPower/Fastcabling/Linovision/MICROSENS/Tycon/Sinclair/Procet/Microchip
> 4. **新交换机品牌8家** — LINKOH(OEM 200+品牌)/Hyconext/Network-Switch.com/Todahika/Focuscom/PoE Partner/Atlantik/Versitron
> 5. **印度分销3家** — Lakshya/Syrotech/Om Automation
