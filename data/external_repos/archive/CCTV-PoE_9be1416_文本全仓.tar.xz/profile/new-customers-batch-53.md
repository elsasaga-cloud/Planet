# Batch 53 — 新能源+户外PoE：停车场 + 电动车充电 + 太阳能/风能 + PoE扩展器

**日期**: 2026-10-25  
**搜索轮次**: Round 209-213  
**新增客户/情报**: 22 家  
**聚焦**: 智能停车场, 电动车充电站, 太阳能/风能PoE, PoE扩展器/注入器

---

## 🅿️ 一、智能停车场 PoE

### 1. Omnitron RuggedNet 智能停车 (美国)
- **类型**: B类 - 工业PoE停车
- **产品**: RuggedNet 10GPoEBT/Mi, 加固工业PoE交换机恶劣环境, 2×1/10G上行+4×10/100/1000 RJ-45 IEEE 802.3bt 60W或100W PoE
- **应用**: 智能停车场网络 - 光纤连接中心→RuggedNet PoE交换机分散停车场, 连接停车传感器 (实时空间可用数据) +安防摄像头+WiFi 6 AP
- **开发策略**: 美国工业PoE停车 (10G+100W) ★★★★★

### 2. Omnitron OmniConverter 停车PoE (美国)
- **类型**: B类 - 紧凑PoE停车
- **产品**: OmniConverter 10GPoE+/M, 紧凑管理PoE/PoE+, 2×1/10G上行+4或8×10/100/1000 RJ-45 PoE
- **开发策略**: 美国紧凑PoE停车 (10G+PoE+) ★★★★★

### 3. UGREEN 10口PoE车库 (中国)
- **类型**: A类 - 车库PoE长距离
- **产品**: 10口PoE以太网交换机, 8×PoE+ + 2×上行, 60W总预算, 802.3af/at, 自动检测PoE设备+自动重启, Extend Mode PoE 820ft (超越TP-Link LS108GP+NETGEAR GS308EP)
- **特点**: 紧凑耐用+优秀电源管理+长距离PoE, 加热/未加热车库安防摄像头+AP
- **开发策略**: 中国车库PoE长距离 (820ft 250m) ★★★★★

### 4. TP-Link LS108GP 车库 (中国)
- **类型**: B类 - 车库PoE
- **产品**: LS108GP 8口PoE千兆, 802.3at/af, 30W/口, 65W总, 16Gbps交换, 820ft扩展, 自动恢复, 无风扇
- **开发策略**: 中国车库PoE 820ft ★★★★★

### 5. keepLiNK 8口工业车库 (中国)
- **类型**: A类 - 工业PoE车库
- **产品**: 8口工业千兆PoE, 极端温度 (车库96-97°F/35°C+阁楼130-140°F/54-60°C), 黑色盒子海边直射阳光无问题
- **开发策略**: 中国工业PoE车库极端温度 ★★★★★

---

## ⚡ 二、电动车充电 PoE

### 6. EV充电市场情报 (美国)
- **类型**: 市场情报
- **规模**: 美国+加拿大96K公共充电站+294K充电口 (2026年8月中), 持续攀升
- **增长**: 2025年18K新DCFC口 (+30% YoY), 2027预测100K DCFC (2024年2倍), 2026年2月326K公开L2+DCFC口
- **领先CPO**: Tesla+ChargePoint+EVgo部署记录Q2 2025, Walmart+Ionna新CPO (Ionna 8车企JV 2025春首站→147站1,332口→2030承诺30K口)
- **标准**: NACS (North American Charging Standard) 北美主导, 2025+几乎所有新车企采用 (Ford+GM+Rivian+Volvo+Polestar+Mercedes+Nissan+Honda+JLR+Hyundai+Kia+BMW+Toyota+Subaru+VW+Mazda+Stellantis, 仅Mitsubishi未宣布)
- **技术**: BYD Super-e 2025年3月基准 400km/5分钟, 下一代SiC功率芯片+全液冷+1000V架构→1MW充电耦合
- **联邦**: NEVI资金2025解冻, ~100新NEVI资助站开放~500新充电器
- **开发策略**: EV充电市场潜力高 (294K口 CAGR 30%+) ★★★★★

### 7. ChargePoint+GM Energy (美国)
- **类型**: C类 - EV充电网络
- **案例**: ChargePoint+GM合作安装数百超快DC充电口美国, 品牌GM Energy, Omni Port系统 (CCS+NACS任何充电器无需适配器), Express Plus平台500kW, 2025年底快速部署战略位置
- **开发策略**: 美国EV充电网络 (ChargePoint+GM 500kW) ★★★★☆

### 8. Ionna 8车企JV (美国)
- **类型**: C类 - EV充电JV
- **案例**: 8车企JV (BMW+GM+Honda+Hyundai+Kia+Mercedes+Stellantis+Toyota可能), 2025春首站→147站1,332口→2030承诺30K口, Alpitronic硬件 (最可靠充电器之一)
- **开发策略**: 美国EV充电JV (8车企 30K口 2030) ★★★★☆

### 9. Tesla Supercharger NACS (美国)
- **类型**: C类 - EV充电标准
- **案例**: 25K Superchargers开放非Tesla (19品牌: Acura+Audi+Ford+GM+Genesis+Honda+Hyundai+JLR+Kia+Lucid+Mercedes+Nissan+Polestar+Porsche+Rivian+Subaru+Toyota+Volvo+VW), V3最常见+V4 2025年9月首台更高容量
- **开发策略**: 美国EV充电标准NACS (25K Superchargers) ★★★★☆

---

## ☀️ 三、太阳能/风能 PoE

### 10. Planet BSP-115HP-5A 太阳能 (台湾)
- **类型**: B类 - 太阳能PoE混合
- **产品**: BSP-115HP-5A Hybrid Solar PoE Switch, 5×10/100/1000TX + 1×100/1000X SFP, 非管理, 5口PoE, 802.3at PoE+, 65W总预算 (取决于输入), Port 1 60W+Port 2-5 802.3at PoE++Port 4-5被动24V/48V选项
- **特点**: ESG原则,  inexhaustible自然能源 (太阳能+风能+水电) 经济供电远程IP摄像头+无线AP, 12V/24V锂电/铅酸/磷酸铁锂充电, 零碳可再生能源
- **规格**: 3.36W待机/75.6W满载, -20~65°C, ESD ±8KV空气/±4KV接触
- **开发策略**: 台湾太阳能PoE混合 (ESG零碳) ★★★★★

### 11. Planet BSP-360 工业太阳能+风能 (台湾)
- **类型**: B类 - 工业可再生能源PoE
- **产品**: BSP-360 Industrial Renewable Power 5口千兆管理/路由+4口802.3at PoE+, IP30 DIN轨, -10~60°C, Web管理, USB备份/恢复, 远程监控+管理IP设备
- **开发策略**: 台湾工业太阳能+风能PoE ★★★★★

### 12. Planet BSP-115PV-15A LCD (台湾)
- **类型**: B类 - 太阳能PoE显示
- **产品**: BSP-115PV-15A 5口802.3at PoE+ Solar+1×1000X SFP+LCD显示, $345
- **开发策略**: 台湾太阳能PoE LCD显示 ★★★★☆

### 13. LINOVISION POE-SW806GM-Solar MPPT (中国)
- **类型**: A类 - 太阳能PoE MPPT
- **产品**: L2 Managed Solar PoE Switch+Built-in MPPT Solar Charge Controller, $339
- **规格**: 4×1G RJ45+2×1G SFP+1 Console, Port 1-2 802.3af/at 30W或被动24V 24W, Port 3-4 802.3bt PoE++ 90W, 120W总PoE, 12Gbps交换, 8.94Mpps转发, 8K MAC, 4.1Mb缓冲, 10240 Jumbo
- **太阳能**: 内置MPPT控制器, 300W最大PV ≤32V (DC 12V模式) 或≤45V (DC 24V), 外部DC充电支持, DC输入12-57V, 内置电池管理 (铅酸/锂电/LiFePO4), 12/24V 10A
- **电源优先**: 太阳能>外部DC>电池
- **尺寸**: 157×115×67mm 1.3kg 120W最大
- **开发策略**: 中国太阳能PoE MPPT (L2+90W PoE++) ★★★★★

### 14. LINOVISION POE-SW505GD 远程重启 (中国)
- **类型**: A类 - 太阳能PoE远程重启
- **产品**: POE-SW505GD, POE-Switch0504GD升级 (完全替代), 业界首创PoE交换机可通过Digital Input远程重启 (蜂窝路由器IOT-R32W/RUT956+多IP摄像头)
- **规格**: 双DC输入9-57V非隔离, PoE输出90W DC12V/120W DC24V+, DI触发远程重启, 稳定性+兼容性改进 (修复Victron太阳能充电控制器兼容性), DIN+壁挂安装
- **开发策略**: 中国太阳能PoE远程重启 (业界首创DI) ★★★★★

### 15. LIFEPOE 10口太阳能升压 (中国)
- **类型**: A类 - 太阳能PoE升压
- **产品**: Industrial 10口千兆太阳能PoE+升压, DC12-24V→48V, 8×IEEE802.3af/at 30W @120W, 2×千兆上行, 10/100/1000Mbps自适应全双工
- **应用**: 太阳能+RV卡车+VoIP
- **开发策略**: 中国太阳能PoE升压 (10口120W) ★★★★★

### 16. Wi-Tek 太阳能MPPT (专业)
- **类型**: B类 - 太阳能PoE MPPT
- **产品**: Solar Powered PoE Network Switch+Remote Access IoT Controller, 集成MPPT太阳能控制器15A
- **开发策略**: 太阳能PoE MPPT 15A ★★★★☆

### 17. FICOTEK+Ubiquiti+TP-Link+Cisco+Planet Top5太阳能 (全球)
- **类型**: B类 - 太阳能PoE领先
- **比较**:
  - FICOTEK: 工业级温度+防雷+全管理+OEM/ODM (安防+能源+风电+铁路)
  - Ubiquiti: Passive PoE+UniFi/EdgeOS+户外 (智慧农业+农村宽带)
  - TP-Link: 实惠+云管理+PoE调度 (小部署+成本敏感)
  - Cisco: 高级安全+高PoE+工业加固 (关键基础设施+太阳能农场)
  - Planet: M12连接器+90W PoE+L2+ (铁路+矿业+恶劣环境)
- **开发策略**: 全球太阳能PoE Top5 ★★★★★

---

## 🔌 四、PoE扩展器/注入器

### 18. PoE Texas GBT-4-IW 入墙 (美国)
- **类型**: B类 - PoE入墙扩展
- **产品**: GBT-4-IW 4口入墙千兆PoE扩展器, 802.3bt上行+最多4×802.3af或2×802.3at设备, 非管理PoE交换机
- **开发策略**: 美国PoE入墙扩展 (802.3bt上行) ★★★★★

### 19. Ubiquiti 2.5G PoE+适配器 (美国)
- **类型**: B类 - PoE适配器
- **产品**: UniFi 2.5G PoE+ Adapter 30W, U7 In-Wall酒店入墙WiFi 7配合
- **开发策略**: 美国PoE 2.5G适配器 ★★★★☆

### 20. 车库PoE市场情报
- **类型**: 市场情报
- **挑战**: 未加热/未空调车库极端温度 (-10°F~+100°F/-23~38°C), 阁楼更高130-140°F/54-60°C
- **解决**: 工业PoE交换机宽温, 长距离820ft/250m, 自动恢复 (冻结设备自动重启), 无风扇静音
- **案例**: TP-Link PoE DC地区车库0°F无中断 (AP+摄像头), Ubiquiti被动冷却高温PoE深南阁楼无问题, 无名5口PoE车库-10~100°F几年运行
- **开发策略**: 车库PoE市场潜力高 (极端温度+长距离) ★★★★★

### 21. EV充电PoE应用情报
- **类型**: 市场情报
- **应用**: 充电站监控 (PoE摄像头+WiFi AP+照明+数字标牌+门禁+支付终端), 充电站网络管理 (PoE交换机集中供电+数据)
- **开发策略**: EV充电PoE应用潜力高 ★★★★☆

### 22. 太阳能PoE市场情报
- **类型**: 市场情报
- **趋势**: 远程+离网网络高效 (电力+数据同以太网电缆+太阳能供电), ESG原则零碳, MPPT控制器高效充电, 远程重启创新 (DI触发)
- **开发策略**: 太阳能PoE市场潜力高 (ESG零碳+远程) ★★★★★

---

## 📊 Batch 53 统计

- **新增客户/情报**: 22 家
- **聚焦行业**: 智能停车场, 电动车充电站, 太阳能/风能PoE, PoE扩展器
- **覆盖国家**: 无新增 (美国, 中国, 台湾已有)

---

## 🎯 关键技术发现

1. **智能停车场**: Omnitron RuggedNet 10GPoEBT/Mi 2×1/10G+4×802.3bt 60W/100W停车传感器+摄像头+WiFi 6 (美国), OmniConverter 10GPoE+/M紧凑管理 (美国), UGREEN 10口8×PoE+ 60W 820ft自动恢复 (中国), TP-Link LS108GP 820ft (中国), keepLiNK 8口工业极端温度 (中国)
2. **电动车充电**: 美国+加拿大96K站294K口 2026, 18K新DCFC 2025 +30% YoY, 2027 100K DCFC预测, NACS标准主导 (2025+几乎所有新车企), BYD Super-e 400km/5min 1MW, NEVI资金解冻, ChargePoint+GM 500kW Omni Port, Ionna 8车企JV 30K口 2030, Tesla 25K Superchargers开放19品牌
3. **太阳能/风能**: Planet BSP-115HP-5A 5口混合PoE 65W -20~65°C ESG零碳 (台湾), Planet BSP-360工业5口千兆管理+路由4×802.3at IP30 -10~60°C (台湾), Planet BSP-115PV-15A LCD $345 (台湾), LINOVISION POE-SW806GM-Solar L2+MPPT 4×1G+2SFP 120W 802.3bt 90W $339 (中国), LINOVISION POE-SW505GD业界首创DI远程重启 (中国), LIFEPOE 10口太阳能升压DC12-24V→48V 8×30W 120W (中国), Wi-Tek MPPT 15A, Top5 FICOTEK+Ubiquiti+TP-Link+Cisco+Planet
4. **PoE扩展器**: PoE Texas GBT-4-IW 4口入墙802.3bt上行 (美国), Ubiquiti 2.5G PoE+ 30W适配器 (美国)
5. **市场情报**: 车库极端温度-10~100°F/-23~38°C+阁楼130-140°F/54-60°C, 长距离820ft/250m, 自动恢复, 无风扇; EV充电站PoE监控+WiFi+照明+标牌+门禁+支付; 太阳能ESG零碳+MPPT+远程重启DI

---

## 📈 累计统计

- **总客户/情报数**: 1,397 家 (1375 + 22)
- **覆盖国家**: 94+ 国家
- **Git 提交**: 55 次
- **超额完成**: 199% (目标 700客户)
